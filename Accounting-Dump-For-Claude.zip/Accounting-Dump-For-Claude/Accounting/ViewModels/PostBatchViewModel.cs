﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class PostBatchViewModel
    {
        public int ExpenseBatchId { get; set; }

        [Display(Name = "'CURRENT' NEXT CHECK #")]
        public int CurrNextCheckNumber { get; set; }

        [Display(Name = "'NEW' NEXT CHECK #")]
        public int? NewNextCheckNumber { get; set; }
    }
}
