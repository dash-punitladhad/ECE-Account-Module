﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class PaymentBatchDeleteViewModel
    {
        [Required]
        public int? ExpenseBatchId { get; set; }
    }
}
