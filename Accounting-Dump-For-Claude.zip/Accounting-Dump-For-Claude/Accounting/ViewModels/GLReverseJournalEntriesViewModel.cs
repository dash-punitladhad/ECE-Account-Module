﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class GLReverseJournalEntriesViewModel
    {
        public int? ContractId { get; set; }

        public int[] SelectedTransactions { get; set; }
    }
}
