﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class ArtistPaymentContractTransactionViewModel
    {
        public int ContractId { get; set; }

        public string PaymentType { get; set; }

        public decimal Amount { get; set; }

        public DateTime? EventDate { get; set; }
    }
}
