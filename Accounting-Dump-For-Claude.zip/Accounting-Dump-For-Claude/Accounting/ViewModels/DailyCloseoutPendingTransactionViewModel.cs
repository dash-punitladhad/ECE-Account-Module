﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class DailyCloseoutPendingTransactionViewModel
    {
        public int ContractId { get; set; }

        public int JournalId { get; set; }

        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy (ddd)}")]
        public DateTime PostedDate { get; set; }

        public string Description { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal? Debit { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal? Credit { get; set; }
    }
}