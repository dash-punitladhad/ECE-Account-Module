﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class PaymentBatchFileViewModel
    {
        public int PaymentBatchFileId { get; set; }

        public string FileName { get; set; }

        public string FilePath { get; set; }

        public string FileFormat { get; set; }

        public string FileType { get; set; }

        public string Description { get; set; }

        public DateTime? DateUploaded { get; set; }
    }
}