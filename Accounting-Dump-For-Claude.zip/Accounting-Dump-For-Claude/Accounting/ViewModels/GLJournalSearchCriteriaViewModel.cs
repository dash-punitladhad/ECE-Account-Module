﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Security.Principal;
    using System.Web.Mvc;
    using System.Linq;
    public class GLJournalSearchCriteriaViewModel
    {
        [Display(Name = "Contract #")]
        public int? ContractId { get; set; }

        [Display(Name = "Reference #")]
        public string ReferenceNumber { get; set; }

        [Display(Name = "Posted Date")]
        public DateTime? PostedDate { get; set; }

        [Display(Name = "Posted Start Date")]
        public DateTime? StartPostedDate { get; set; }

        [Display(Name = "Posted End Date")]
        public DateTime? EndPostedDate { get; set; }

        [Display(Name = "Posted Amount")]
        public decimal? PostedAmount { get; set; }

        [Display(Name = "Account")]
        public int? GeneralLedgerAccountId { get; set; }

        [Display(Name = "Event")]
        public int? GeneralLedgerEventId { get; set; }

        [Display(Name = "Agent")]
        public int? AgentId { get; set; }

        [Display(Name = "Office")]
        public int? OfficeId { get; set; }

        [Display(Name = "Transaction #")]
        public int? JournalTransactionNumber { get; set; }

        public SelectList GeneralLedgerEvents { get; set; }

        public SelectList GeneralLedgerAccounts { get; set; }

        public SelectList Agents { get; set; }

        public SelectList Offices { get; set; }

        public void LoadForSearch(IPrincipal User)
        {
            var events = LookupCache.GetAllGeneralLedgerEvents();
            this.GeneralLedgerEvents = events.ToSelectList("Text", "Value");

            var accounts = LookupCache.GetAllGeneralLedgerAccounts();
            this.GeneralLedgerAccounts = accounts.ToSelectList("Text", "Value");

            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();
            this.Offices = offices.ToSelectList("Name", "OfficeId");

            var agents =  (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();//LookupCache.GetAllAgents();
            this.Agents = agents.ToSelectList("FullName", "AppUserId");
        }
    }
}
