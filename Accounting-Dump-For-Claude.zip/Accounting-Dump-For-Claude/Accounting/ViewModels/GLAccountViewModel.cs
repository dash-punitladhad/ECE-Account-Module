﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class GLAccountViewModel
    {
        [Required]
        public int GeneralLedgerAccountId { get; set; }

        [Required]
        [MaxLength(100)]
        [MinLength(1)]
        public string AccountName { get; set; }

        [Required]
        public int GeneralLedgerAccountTypeId { get; set; }

        [Required]
        public string AccountUrl { get; set; }

        public decimal? AccountBalance { get; set; }

        public DateTime? CachedBalanceDate { get; set; }

        public string AccountBalanceCurrency => this.AccountBalance.Value.ToString("C");

        public SelectList ActivityTypes
        {
            get
            {
                SelectList types = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem() { Selected = true, Text = "All", Value = ((int)SearchHelper.All).ToString() },
                        new SelectListItem() { Selected = false, Text = "Debit", Value = "1" },
                        new SelectListItem() { Selected = false, Text = "Credit", Value = "2" }
                    },
                    "Value",
                    "Text",
                    1);

                return types;
            }
        }
    }
}