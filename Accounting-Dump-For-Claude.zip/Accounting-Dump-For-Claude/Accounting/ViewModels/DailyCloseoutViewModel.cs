﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Threading.Tasks;

    public class DailyCloseoutViewModel
    {
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal PendingTransferAmount { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal TotalCreditsAmount { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal TotalDebitsAmount { get; set; }

        [UIHint("ECEDateTime")]
        public DateTime LastCloseoutDate { get; set; }

        public async Task LoadForDetailsAsync(IDailyCloseoutService dailyCloseoutService)
        {
            var amounts = await dailyCloseoutService.GetDailyCloseoutAmountsAsync();

            this.TotalDebitsAmount = amounts[DailyCloseoutAmounts.Debits];

            this.TotalCreditsAmount = amounts[DailyCloseoutAmounts.Credits];

            this.PendingTransferAmount = amounts[DailyCloseoutAmounts.Total];

            this.LastCloseoutDate = await dailyCloseoutService.GetDailyCloseoutLastCloseoutDateAsync();
        }
    }
}