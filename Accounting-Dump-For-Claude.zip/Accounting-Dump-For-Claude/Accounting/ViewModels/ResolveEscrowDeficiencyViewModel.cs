﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class ResolveEscrowDeficiencyViewModel
    {
        public int ContractId { get; set; }

        public int ContractTransactionId { get; set; }

        public DateTime DueDate { get; set; }

        public decimal RequiredAmount { get; set; }

        public decimal PaidAmount { get; set; }

        public decimal EscrowAmount { get; set; }

        public decimal ContractEscrowAmount { get; set; }

        public decimal ContractRequiredAmount { get; set; }

        public decimal DueAmount { get; set; }

        public int ExpensePaymentId { get; set; }

        public ExpensePaymentStatus ExpensePaymentStatus { get; set; }

        public DateTime? CancellationDate { get; set; }

        [Required]
        [Display(Name = "Selected Action")]
        public EscrowDeficiencyAction? SelectedAction { get; set; }
    }
}
