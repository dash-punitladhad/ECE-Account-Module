﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;

    public class UnpaidCommissionsLineViewModel : UnpaidCommissionDto
    {
        public string OfficeName { get; set; }

        public string ContractOfficeName { get; set; }
    }
}
