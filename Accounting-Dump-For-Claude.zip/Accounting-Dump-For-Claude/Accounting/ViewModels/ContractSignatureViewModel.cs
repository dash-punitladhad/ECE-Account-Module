﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public class ContractSignatureViewModel
    {
        public string DueFromDisplay { get; set; }

        public string ContactEmail { get; set; }

        public string ContactFirstName { get; set; }

        public string ContactLastName { get; set; }

        public bool CanEmail { get; set; }

        public int ContractSignatureId { get; set; }

        public int ContractId { get; set; }

        public int EntityId { get; set; }

        public int EntityTypeId { get; set; }

        public string EntityName { get; set; }

        public int? SignatureId { get; set; }

        public DateTime? DueDate { get; set; }

        public DateTime? ReceivedDate { get; set; }

        public bool IsReceived { get; set; }

        public void SetDisplayName(ContractTransactionDto dto)
        {
            this.DueFromDisplay = dto.GetPayeeDisplayName();
        }
    }
}