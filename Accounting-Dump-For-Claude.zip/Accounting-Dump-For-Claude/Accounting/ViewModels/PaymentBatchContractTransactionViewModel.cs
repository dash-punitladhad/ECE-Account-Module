﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using System;

    public class PaymentBatchContractTransactionViewModel
    {
        public int ContractTransactionId { get; set; }

        public int? ArtistChargeId { get; set; }

        public int ContractId { get; set; }

        public string OfficeName { get; set; }

        public ContractTransactionType ContractTransactionType { get; set; }

        public string ContractTransactionTypeName { get; set; }

        public string ContractStatus { get; set; }

        public bool TransactionWarning { get; set; }

        public string WarningMessage { get; set; }

        public decimal Amount { get; set; }

        public decimal PaidAmount { get; set; }

        public decimal EscrowAmount { get; set; }

        public bool IsSubRow { get; set; }

        public DateTime? EventDate { get; set; }

        public bool InsufficientEscrow
        {
            get
            {
                return
                    this.WarningMessage != null &&
                    this.WarningMessage.Contains(ExpensePaymentWarning.InsufficientEscrow);
            }
        }

        public decimal TransactionAmount(bool posted)
        {
            if (posted)
            {
                return Amount;
            }

            if (ContractTransactionType == ContractTransactionType.CrossDeductionDeposit ||
                ContractTransactionType == ContractTransactionType.LoanRepayment)
            {
                return Amount;
            }

            return Amount - PaidAmount;
        }
    }
}