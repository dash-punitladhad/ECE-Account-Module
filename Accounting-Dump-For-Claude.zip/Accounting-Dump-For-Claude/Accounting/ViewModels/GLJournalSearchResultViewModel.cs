﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;

    public class GLJournalSearchResultViewModel
    {
        public int? ContractId { get; set; }

        public int GeneralLedgerAccountId { get; set; }

        public int GeneralLedgerJournalId { get; set; }

        public int GeneralLedgerTransactionTypeId { get; set; }

        public int GeneralLedgerEventId { get; set; }

        public string GeneralLedgerTransactionType { get; set; }

        public char ChangeType { get; set; }

        public char ChangeDirection { get; set; }

        public int JournalTransactionNumber { get; set; }

        public DateTime PostedDate { get; set; }

        public string FormattedPostedDate
        {
            get { return PostedDate.ToStandardDateWithDayAndTime(); }
        }

        public decimal PostedAmount { get; set; }

        public string ReferenceNumber { get; set; }

        public int ContractEntityTypeId { get; set; }

        public int ContractEntityId { get; set; }

        public string ContractEntity { get; set; }

        public int? AgentId { get; set; }

        public string AgentName { get; set; }

        public int? ContractTransactionId { get; set; }

        public int? LineOfBusinessId { get; set; }

        public int? OfficeId { get; set; }
    }
}
