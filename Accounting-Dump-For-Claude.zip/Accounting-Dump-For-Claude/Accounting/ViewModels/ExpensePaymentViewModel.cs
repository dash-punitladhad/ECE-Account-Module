﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using System;

    public class ExpensePaymentViewModel
    {
        public int ExpensePaymentId { get; set; }

        public int ExpenseBatchId { get; set; }

        public int ContractEntityId { get; set; }

        public string PayeeName { get; set; }

        public int TransactionCount { get; set; }

        public bool TransactionWarning { get; set; }

        public decimal GrossAmount { get; set; }

        public decimal DeductionAmount { get; set; }

        public decimal RepaymentAmount { get; set; }

        public decimal PaymentAmount { get; set; }

        public string ReferenceNumber { get; set; }

        public int ExpensePaymentTypeId { get; set; }

        public string ExpensePaymentTypeLabel { get; internal set; }

        public ArtistDto Artist { get; set; }

        public DateTime? DateVoided { get; set; }

        public bool IsVoided
        {
            get { return this.DateVoided.HasValue; }
        }

        public decimal TotalDeductions
        {
            get { return this.RepaymentAmount + this.DeductionAmount; }
        }

        public string WarningMessage { get; internal set; }

        public bool InsufficientEscrow
        {
            get
            {
                return
                    this.WarningMessage != null &&
                    this.WarningMessage.Contains(ExpensePaymentWarning.InsufficientEscrow);
            }
        }
    }
}