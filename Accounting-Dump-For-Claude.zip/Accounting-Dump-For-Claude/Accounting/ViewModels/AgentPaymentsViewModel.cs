﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    public class AgentPaymentsViewModel
    {
        public AgentPaymentsViewModel()
        {
            YearSelectList = new SelectList(Enumerable.Range(DateTime.Now.AddYears(-5).Year, 6).OrderByDescending(x => x));
        }

        public int AgentId { get; set; }

        public IList<SelectListItem> AgentSelectList { get; set; }

        public int Year { get; set; }

        public SelectList YearSelectList { get; set; }
    }
}