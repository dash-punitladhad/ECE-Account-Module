﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class AgentCafeteriaPlanViewModel
    {
        public int? CafeteriaPlanId { get; set; }

        public int AgentUserId { get; set; }

        public string AgentName { get; set; }

        public decimal? CurrentDeduction { get; set; }

        public int Year { get; set; }

        public decimal? YtdAmount { get; set; }
    }
}