﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;

    public class GeneralLedgerModalViewModel
    {
        public int ContractId { get; set; }

        public IEnumerable<GeneralLedgerJournalActivityDto> Entries { get; set; }
    }
}
