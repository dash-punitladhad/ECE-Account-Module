﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Contract;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class ContractWorkSheetViewModel : ContractBaseViewModel
    {
        public ContractWorkSheetViewModel()
        {
            CreateContractDeposit = new ContractDepositViewModel();
            AddDocumentForm = new DocumentFormViewModel();
            MarkSignatureAsReceived = new ContractSignatureReceivedViewModel();
        }

        [DisplayName("Contract #")]
        public int? ContractId { get; set; }

        [DisplayName("Status")]
        public string ContractStatusText => TextHelper.ContractStatusToString(this.ContractStatusId);

        public string Agent { get; set; }

        public string Presenter { get; set; }

        [DisplayName("Event Date(s)")]
        public IList<string> EventDates { get; set; }

        [DisplayName("Artist(s)")]
        public IList<string> Artists { get; set; }

        [DisplayName("Current Amount Due")]
        [DataType(DataType.Currency)]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal? CurrentAmountDue { get; set; }

        [DisplayName("Pickup Balance")]
        [DataType(DataType.Currency)]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal? PickupBalance { get; set; }

        public bool CanUnpostDeposits { get; set; }

        public bool CanPostDeposits { get; set; }

        public IList<ContractTransactionDto> ContractTransactions { get; set; }

        public IList<ContractDepositViewModel> ContractDeposits { get; set; }

        public IList<ContractSignatureViewModel> ContractSignatures { get; set; }

        public bool CanRemovePresenterSignature { get; set; }

        public ContractDepositViewModel CreateContractDeposit { get; set; }

        public IList<DocumentViewModel> Files { get; set; }

        public DocumentFormViewModel AddDocumentForm { get; set; }

        public ContractSignatureReceivedViewModel MarkSignatureAsReceived { get; set; }

        public SendContractViewModel SendContract { get; set; }

        [MaxLength(3000, ErrorMessage = "Contract notes must be under 3000 characters.")]
        public string Notes { get; set; }

        public bool ContractIsCanceled
        {
            get
            {
                return
                    this.ContractStatusId == (int)ContractStatus.Canceled ||
                    this.ContractStatusId == (int)ContractStatus.PartiallyCanceled;
            }
        }

        public bool ContractIsPartiallyCanceled
        {
            get
            {
                return this.ContractStatusId == (int)ContractStatus.PartiallyCanceled;
            }
        }

        public bool IsBuySell { get; set; }

        public bool CanInitialize { get; internal set; }

        public void LoadData(ContractDto contract, IList<ContractDepositViewModel> deposits, IList<ContractSignatureViewModel> signatures, IList<DocumentViewModel> files, string redirectUrl)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (contract.ContractTransactions == null)
            {
                throw new ArgumentNullException(nameof(contract.ContractTransactions));
            }

            ContractId = EntityId = contract.ContractId;
            Notes = contract.Notes;
            ContractStatusId = contract.ContractStatusId;
            IsNoIssue = contract.IsNoIssue.GetValueOrDefault();
            IsBuySell = contract.IsBuySell.GetValueOrDefault();

            ShowArtistAgreements = contract.IsBuySell == true || contract.ContractTypeId == (int)ContractType.Special;

            Agent = contract.Agent.FullName;
            Presenter = contract.PresenterAccountName;

            if (contract.ContractArtists != null)
            {
                Artists = contract.ContractArtists.Select(x => x.ArtistName).ToList();
                PickupBalance = contract.ContractArtists.Total(x => x.Pickup);
            }

            if (contract.EventDatesObject != null)
            {
                EventDates = contract.EventDatesObject.Select(x => x.EventDate.ToStandardWithDayString()).ToList();
            }

            if (contract.ContractTransactions != null)
            {
                CurrentAmountDue = contract.ContractTransactions.Where(x => !x.IsExpense).Total(x => x.DueAmount);
                ContractTransactions = contract.ContractTransactions.Where(x => !x.IsExpense).OrderBy(x => x.DueDate).ToList();

                // There is a copy of this logic in the ContractDepositService
                CanUnpostDeposits = !contract.ContractTransactions.Any(x => x.IsExpense && x.ContractEntityTypeId != (int)ContractEntityType.ECE && x.PaidDate != null);
            }

            Files = files;

            // Populate displays for deposits.
            if (deposits != null)
            {
                ContractDeposits = deposits
                    .OrderBy(x => x.ReceivedDate)
                    .ToList();
            }

            if (signatures != null)
            {
                ContractSignatures = signatures
                    .OrderByDescending(x => x.DueDate.HasValue)
                    .ThenBy(x => x.DueDate)
                    .ThenBy(x => x.EntityTypeId)
                    .ThenBy(x => x.ContractSignatureId)
                    .ToList();
            }

            if (ContractSignatures != null)
            {
                CanRemovePresenterSignature = ContractSignatures.Count(x => x.EntityTypeId == (int)EntityType.Presenter) > 1;
            }

            CreateContractDeposit.LoadForCreate(contract);

            AddDocumentForm.EntityId = contract.ContractId;
            AddDocumentForm.EntityTypeId = (int)EntityType.Contract;
            AddDocumentForm.RedirectUrl = redirectUrl;
            IsPandaDocContractBase = contract.IsPandaDoc;
        }
    }
}
