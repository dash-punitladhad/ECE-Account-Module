﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Mvc;

    public class UpdateCancellationViewModel
    {
        public int ContractCancellationId { get; set; }

        [Required]
        public int ContractId { get; set; }

        public int? CancellationReasonId { get; set; }

        public string CancellationReasonText
        {
            get
            {
                if (Cancellation != null)
                {
                    var cancellationReasons = LookupCache.GetAllCancelledReasons();
                    var item = cancellationReasons.FirstOrDefault(s => s.Value == $"{Cancellation.CancellationReasonId}");
                    if (item != null)
                    {
                        return item.Text;
                    }
                }

                return string.Empty;
            }
        }

        [MaxLength(500, ErrorMessage = "Notes exceeds max length of 500 characters.")]
        public string CancellationReasonNotes { get; set; }

        public bool ZeroUnpaidItems { get; set; }

        public bool NotifyArtist { get; set; }

        public int? NotifyArtistEmailQueueId { get; set; }

        public bool ApplyCancellationFee { get; set; }

        public int? CancellationFeeTransactionId { get; set; }

        public bool CreateReplacement { get; set; }

        public int? ReplacementContractId { get; set; }

        public bool GenerateRefunds { get; set; }

        public bool IsFinished { get; set; }

        public bool HasReceivedDeposits { get; set; }

        public SelectList CancellationReasons { get; set; }

        public ContractCancellationDto Cancellation { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        [DisplayFormat(DataFormatString = "{0:C0}")]
        public decimal CancellationFee
        {
            get { return ContractService.EceCancelFeeAmount; }
        }

        public void LoadForCreate()
        {
            var cancellationReasons = LookupCache.GetAllCancelledReasons();
            this.CancellationReasons = cancellationReasons.ToSelectList("Text", "Value");
        }

        public void LoadForUpdate(IList<ContractCancellationDto> cancellations)
        {
            var activeCancellation = cancellations.OrderByDescending(x => x.ContractCancellationId).FirstOrDefault();
            if (activeCancellation != null)
            {
                activeCancellation.ApplyCancellationFee = cancellations.Any(x => x.ApplyCancellationFee);
                activeCancellation.NotifyArtist = cancellations.Any(x => x.NotifyArtist);
                activeCancellation.ZeroUnpaidItems = cancellations.Any(x => x.ZeroUnpaidItems);
                activeCancellation.CreateReplacement = cancellations.Any(x => x.CreateReplacement);
                activeCancellation.GenerateRefunds = cancellations.Any(x => x.GenerateRefunds);
            }

            this.LoadForUpdate(activeCancellation);
        }

        public void LoadForUpdate(ContractCancellationDto cancellation)
        {
            var cancellationReasons = LookupCache.GetAllCancelledReasons();
            this.CancellationReasons = cancellationReasons.ToSelectList("Text", "Value");

            this.Cancellation = cancellation;

            if (cancellation != null)
            {
                this.CancellationReasonId = cancellation.CancellationReasonId;
                this.CancellationReasonNotes = cancellation.CancellationReasonNotes;
                ////this.ApplyCancellationFee = cancellation.ApplyCancellationFee;
                ////this.NotifyArtist = cancellation.NotifyArtist;
                ////this.ZeroUnpaidItems = cancellation.ZeroUnpaidItems;
                ////this.CreateReplacement = cancellation.CreateReplacement;
                ////this.GenerateRefunds = cancellation.GenerateRefunds;
                ////this.IsFinished = cancellation.IsFinished;
                ////this.ReplacementContractId = cancellation.ReplacementContractId;
                ////this.CancellationFeeTransactionId = cancellation.CancellationFeeTransactionId;
                ////this.NotifyArtistEmailQueueId = cancellation.NotifyArtistEmailQueueId;
            }
        }
    }
}
