﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class PreCreateContractDepositResultViewModel
    {
        public bool IsAppliedToMultipleContracts { get; set; }

        public bool DepositExceedsPaymentTotal { get; set; }

        public bool DepositMatchesRequiredAmount { get; set; }

        public bool DepositExceedsDueAmount { get; set; }

        public decimal ExpectedIncomeAmount { get; set; }

        public bool RequiresConfirmation => DepositExceedsPaymentTotal || !DepositMatchesRequiredAmount || DepositExceedsDueAmount;
    }
}
