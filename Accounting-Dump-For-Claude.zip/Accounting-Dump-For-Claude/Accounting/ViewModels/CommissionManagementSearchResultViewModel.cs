﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class CommissionManagementSearchResultViewModel
    {
        public int AgentCommissionId { get; set; }

        public int AgentId { get; set; }

        public string Agent { get; set; }

        public string Office { get; set; }

        public string Status { get; set; }

        public string CommissionType { get; set; }

        public decimal? OriginatingAgentPercentage { get; set; }

        public string MentoredBy { get; set; }

        public decimal? MentorshipPercentage { get; set; }
    }
}
