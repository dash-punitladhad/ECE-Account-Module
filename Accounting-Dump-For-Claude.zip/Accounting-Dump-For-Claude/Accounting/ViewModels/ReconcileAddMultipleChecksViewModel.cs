﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class ReconcileAddMultipleChecksViewModel
    {
        [Required]
        public int ReconciliationBatchId { get; set; }

        [FromJson]
        [Display(Name = "Checks")]
        public IList<ReconciliationItemViewModel> ChecksToAdd { get; set; }
    }
}
