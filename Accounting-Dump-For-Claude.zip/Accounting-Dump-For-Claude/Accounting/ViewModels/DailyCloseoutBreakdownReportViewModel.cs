﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using Infrastructure.Helpers;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading.Tasks;

    public class DailyCloseoutBreakdownReportViewModel : DailyCloseoutBreakdownReportRangeViewModel
    {
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? CloseoutDate { get; set; }

        public string Posted { get; set; }

        public bool PdfMode { get; set; }

        public IList<ContractDepositViewModel> Deposits { get; set; }

        public IList<DailyCloseoutPendingTransactionViewModel> Transactions { get; set; }

        public IList<ContractDepositViewModel> CheckDeposits
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.Cash, PaymentMethod.Check);
            }
        }

        public IList<ContractDepositViewModel> AchTransfers
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.AchEPay);
            }
        }

        public IList<ContractDepositViewModel> CreditCards
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.CreditCard);
            }
        }

        public IList<ContractDepositViewModel> WireTransfers
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.WireTransfer);
            }
        }

        public IList<ContractDepositViewModel> TodaysDeposits
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.Cash, PaymentMethod.Check, PaymentMethod.CreditCard);
            }
        }

        public int TodaysDepositsCount
        {
            get
            {
                var count = this.DepositsByPaymentMethod(PaymentMethod.Cash, PaymentMethod.Check).Count;

                if (this.CreditCards.Any())
                {
                    count += 1;
                }

                return count;
            }
        }

        public IList<ContractDepositViewModel> CrossDeductions
        {
            get
            {
                return this.DepositsByPaymentMethod(PaymentMethod.CrossDeduction);
            }
        }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal TotalTransactionsDebit
        {
            get
            {
                if (this.Transactions == null || !this.Transactions.Any())
                {
                    return decimal.Zero;
                }

                return this.Transactions.Total(x => x.Debit);
            }
        }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal TotalTransactionsCredit
        {
            get
            {
                if (this.Transactions == null || !this.Transactions.Any())
                {
                    return decimal.Zero;
                }

                return this.Transactions.Total(x => x.Credit);
            }
        }

        public string ResultFileName
        {
            get
            {
                var fileName = $"Daily Closeout Breakdown Report for {this.CloseoutDate:yyyy-dd-MM}";

                return FileHelper.GetSafeFileName(fileName.Replace(" ", "_") + ".pdf");
            }
        }

        public object RangeRouteData
        {
            get
            {
                return new { FromDate = this.FromDate, ToDate = this.ToDate };
            }
        }

        public async Task LoadForBreakdownReportAsync(IDailyCloseoutService dailyCloseoutService, DailyCloseoutBreakdownReportRangeViewModel range)
        {
            this.FromDate = range.FromDate;
            this.ToDate = range.ToDate;

            var lastCloseoutDate = await dailyCloseoutService.GetDailyCloseoutLastCloseoutDateAsync();

            DateTime fromReceivedDate = lastCloseoutDate;
            DateTime? toReceivedDate = null;

            if (this.FromDate.HasValue && this.ToDate.HasValue)
            {
                fromReceivedDate = this.FromDate.Value;
                toReceivedDate = this.ToDate.Value;
            }

            var deposits = await dailyCloseoutService.GetDailyCloseoutContractDepositsAsync(fromReceivedDate, toReceivedDate);

            var visibleDeposits = ContractDepositViewModel.GetDeposits(null, deposits).Where(x => x.PaymentMethodId != (int)PaymentMethod.CrossDeduction);

            var depositViewModels = Mapper.Map<List<ContractDepositViewModel>>(visibleDeposits.OrderBy(x => x.ReferenceNumber).ThenBy(x => x.ContractId));

            depositViewModels.ForEach(x =>
            {
                var entityType = (ContractEntityType)x.ContractEntityTypeId;
                x.ReceivedFrom = entityType.ToString();
            });

            this.Deposits = depositViewModels;
            this.CloseoutDate = this.FromDate ?? DateTime.Today;
        }

        private IList<ContractDepositViewModel> DepositsByPaymentMethod(params PaymentMethod[] methods)
        {
            if (this.Deposits == null || !this.Deposits.Any())
            {
                return Enumerable.Empty<ContractDepositViewModel>().ToList();
            }

            var methodIds = methods.Select(x => (int)x);

            return Deposits
                .Where(x => methodIds.Contains(x.PaymentMethodId))
                .ToList();
        }
    }
}
