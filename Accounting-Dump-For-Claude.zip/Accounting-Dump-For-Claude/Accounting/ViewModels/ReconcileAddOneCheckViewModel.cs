﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using System.ComponentModel.DataAnnotations;

    public class ReconcileAddOneCheckViewModel
    {
        [Required]
        public int ReconciliationBatchId { get; set; }

        [Required]
        [Display(Name = "Check #")]
        [StringLength(50)]
        [ForceToUppercase]
        public string ReferenceNumber { get; set; }

        [Required]
        [Display(Name = "Amount")]
        public decimal? PaymentAmount { get; set; }

        public ReconciliationItemDto CreateDto()
        {
            return new ReconciliationItemDto()
            {
                ReconciliationBatchId = this.ReconciliationBatchId,
                ReferenceNumber = this.ReferenceNumber,
                PaymentAmount = this.PaymentAmount.GetValueOrDefault()
            };
        }
    }
}
