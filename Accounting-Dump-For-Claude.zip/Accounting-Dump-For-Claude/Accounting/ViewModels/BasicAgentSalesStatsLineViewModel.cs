﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;

    public class BasicAgentSalesStatsLineViewModel : BasicAgentSalesStatsDto
    {
        public string OfficeName { get; set; }

        public string AgentName { get; set; }

        public int NetCount
        {
            get { return BookedCount - CancelledCount; }
        }
    }
}
