﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    public class CommissionManagementMentorModalViewModel
    {
        [Required]
        public int AgentId { get; set; }

        [Required]
        [DisplayName("Mentor")]
        public int? MentorId { get; set; }

        public SelectList Mentors { get; set; }

        [Required]
        [Range(0.00, 100.00, ErrorMessage = "The percentage must be between {1} and {2} percent.")]
        [DisplayName("Mentor Percentage")]
        public decimal? MentorshipPercentage { get; set; }

        [Required]
        [DisplayName("Start Date")]
        public DateTime? MentorshipStartDate { get; set; }

        [DisplayName("End Date")]
        [DateGreaterThan("MentorshipStartDate", true, ErrorMessage = "The End Date must be greater than or equal to the Start Date.")]
        [DateLessThan("MaximumEndDate", true, ErrorMessage = "The End Date must be less than 1 year from the Start Date.")]
        public DateTime? MentorshipEndDate { get; set; }

        public DateTime? MaximumEndDate { get; set; }

        public async Task LoadAsync(int agentId, AgentCommissionDto agentCommission, IUserService userService)
        {
            this.AgentId = agentId;

            var owners = userService.GetUsersByRole((int)ECERole.Owner, false);

            if (agentCommission != null)
            {
                this.MentorId = agentCommission.MentorId;
                this.MentorshipStartDate = agentCommission.MentorshipStartDate;
                this.MentorshipEndDate = agentCommission.MentorshipEndDate;
                this.MentorshipPercentage = agentCommission.MentorshipPercentage;
                this.MaximumEndDate = agentCommission.MentorshipStartDate.GetValueOrDefault().AddYears(1);

                if (agentCommission.MentorId.HasValue)
                {
                    var currentMentorIsOwner = owners.Any(x => x.AppUserId == agentCommission.MentorId.Value);
                    if (!currentMentorIsOwner)
                    {
                        var currentMentor = await userService.GetUserAsync(new AppUserDto { AppUserId = agentCommission.MentorId.Value }, false);
                        if (currentMentor != null)
                        {
                            owners.Add(currentMentor);
                        }
                    }
                }
            }

            this.Mentors = owners.ToSelectList("FullName", "AppUserId");
        }

        public AgentCommissionDto CreateDto()
        {
            var dto = new AgentCommissionDto();

            dto.AgentId = this.AgentId;
            dto.MentorId = this.MentorId;
            dto.MentorshipPercentage = this.MentorshipPercentage;
            dto.MentorshipStartDate = this.MentorshipStartDate;
            dto.MentorshipEndDate = this.MentorshipEndDate;

            return dto;
        }
    }
}
