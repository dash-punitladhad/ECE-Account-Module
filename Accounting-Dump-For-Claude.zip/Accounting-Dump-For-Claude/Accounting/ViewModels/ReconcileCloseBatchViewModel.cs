﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class ReconcileCloseBatchViewModel
    {
        [Required]
        public int ReconciliationBatchId { get; set; }

        [Required]
        [StringLength(100)]
        public string Description { get; set; }
    }
}