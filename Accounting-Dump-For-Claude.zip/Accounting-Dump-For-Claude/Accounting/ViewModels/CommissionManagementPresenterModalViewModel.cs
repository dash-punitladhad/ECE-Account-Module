﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class CommissionManagementPresenterModalViewModel
    {
        public CommissionManagementPresenterModalViewModel()
        {
            this.Percentage = CommissionManagementService.PresenterTransferCommissionPercentage;
        }

        [Required]
        public int AgentId { get; set; }

        public string ControllerActionName { get; set; }

        [Required]
        [DisplayName("Presenter")]
        public int? PresenterId { get; set; }

        public string PresenterName { get; set; }

        [Required]
        [DisplayName("Start Date")]
        public DateTime? StartDate { get; set; }

        [Required]
        [DisplayName("End Date")]
        [DateGreaterThan("StartDate", false, ErrorMessage = "The End Date must be greater than the Start Date.")]
        [DateLessThan("MaximumEndDate", true, ErrorMessage = "The End Date must be less than 4 years from the Start Date.")]
        public DateTime? EndDate { get; set; }

        public DateTime? MaximumEndDate { get; set; }

        [Required]
        [Range(0.00, 100.00, ErrorMessage = "The percentage must be between {1} and {2} percent.")]
        [DisplayName("Percentage")]
        public decimal? Percentage { get; set; }

        public bool PresenterReadOnly { get; set; }

        public AgentCommissionProgramDto CreateDto()
        {
            var dto = new AgentCommissionProgramDto();

            dto.CommissionProgramId = (int)CommissionProgram.PresenterTransfer;
            dto.ToAppUserId = this.AgentId;
            dto.FromEntityId = this.PresenterId.GetValueOrDefault();
            dto.FromEntityTypeId = (int)EntityType.Presenter;
            dto.StartDate = this.StartDate.GetValueOrDefault();
            dto.EndDate = this.EndDate.GetValueOrDefault();
            dto.SplitPercentage = this.Percentage.GetValueOrDefault();

            return dto;
        }

        public void LoadFromDto(AgentCommissionProgramDto dto)
        {
            this.AgentId = dto.ToAppUserId;
            this.PresenterId = dto.FromEntityId;
            this.PresenterName = dto.FromEntityName;
            this.StartDate = dto.StartDate;
            this.EndDate = dto.EndDate;
            this.Percentage = dto.SplitPercentage;
            this.MaximumEndDate = CommissionManagementService.GetPresenterTransferCommissionMaximumEndDate(this.StartDate.GetValueOrDefault());
            this.PresenterReadOnly = true;
        }
    }
}
