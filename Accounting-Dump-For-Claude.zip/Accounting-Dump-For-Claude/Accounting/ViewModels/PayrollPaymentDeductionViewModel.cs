﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class PayrollPaymentDeductionViewModel
    {
        public DateTime Date { get; set; }

        public decimal? Amount { get; set; }
    }
}
