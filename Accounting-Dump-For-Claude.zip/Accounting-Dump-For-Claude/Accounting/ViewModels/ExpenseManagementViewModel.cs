﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Security.Principal;
    using System.Web.Mvc;

    public class ExpenseManagementViewModel
    {
        public ExpenseManagementViewModel()
        {
            PendingBatches = new List<PaymentBatchViewModel>();
        }

        public SelectList PayeeTypes { get; set; }

        public SelectList ExpenseTypes { get; set; }

        public SelectList Status
        {
            get
            {
                SelectList statusTypes = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem() { Selected = true, Text = "All", Value = ((int)SearchHelper.All).ToString() },
                        new SelectListItem() { Selected = false, Text = "Not Approved for Payment", Value = "1" },
                        new SelectListItem() { Selected = false, Text = "Approved for Payment", Value = "2" },
                        new SelectListItem() { Selected = false, Text = "Paid", Value = "3" }
                    },
                    "Value",
                    "Text",
                    0);

                return statusTypes;
            }
        }

        [Required]
        public string IdsToPay { get; set; }

        public bool CanCreatePendingBatch { get; set; }

        public List<PaymentBatchViewModel> PendingBatches { get; set; }

        public IEnumerable<PaymentBatchViewModel> PendingArtistPaymentBatches
        {
            get
            {
                return PendingBatches.Where(x => x.BatchType == ExpenseBatchType.Artist);
            }
        }

        public IEnumerable<PaymentBatchViewModel> PendingOtherExpensesBatches
        {
            get
            {
                return PendingBatches.Where(x => x.BatchType == ExpenseBatchType.OtherExpenses);
            }
        }

        public List<int> GetIdsToPay()
        {
            if (string.IsNullOrWhiteSpace(this.IdsToPay))
            {
                return new List<int>();
            }

            return this.IdsToPay
                .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => Convert.ToInt32(x))
                .ToList();
        }

        public bool CanCreateAutomaticBatch(ExpenseBatchType batchType)
        {
            if (CanCreatePendingBatch == false)
            {
                return false;
            }

            return PendingBatches.Any(x => x.BatchType == batchType && x.IsManual == false) == false;
        }

        public void LoadPendingBatches(IEnumerable<PaymentBatchViewModel> pendingBatches, IPrincipal user)
        {
            PendingBatches.AddRange(pendingBatches);

            if (user.HasPermission(ECEPermissions.ACCOUNTING_CREATE))
            {
                CanCreatePendingBatch = true;
            }
        }
    }
}