﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;

    public class BasicAgentSalesStatsViewModel : BaseExportDataViewModel
    {
        private static int[] groupKeys = new[] { (int)LineOfBusiness.Core, (int)LineOfBusiness.National, (int)LineOfBusiness.Touring, (int)LineOfBusiness.Comedy };

        public BasicAgentSalesStatsViewModel()
            : base()
        {
        }

        public BasicAgentSalesStatsViewModel(DateTime fromDate, DateTime toDate)
            : base(fromDate, toDate)
        {
        }

        public override string WorksheetName
        {
            get
            {
                return $"Basic Agent Sales Stats";
            }
        }

        public static IEnumerable<IGrouping<string, BasicAgentSalesStatsLineViewModel>> GroupDataByOffice(IEnumerable<BasicAgentSalesStatsDto> data,IPrincipal User)
        {
            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();

            var view = from d in data
                       join ol in offices on d.OfficeId equals ol.OfficeId into jo
                       from o in jo.DefaultIfEmpty()
                       select new BasicAgentSalesStatsLineViewModel
                       {
                           AgentId = d.AgentId,
                           OfficeId = d.OfficeId,
                           OfficeName = o?.Name ?? "Unassigned",
                           BookedCount = d.BookedCount,
                           CancelledCount = d.CancelledCount,
                           NetSales = d.NetSales,
                           LineOfBusinessId = d.LineOfBusinessId,
                       };

            var officeGroups = from d in view.OrderBy(x => x.OfficeName)
                               group d by d.OfficeName;

            return officeGroups;
        }

        public static IEnumerable<IGrouping<int, BasicAgentSalesStatsLineViewModel>> GroupDataByLineOfBusiness(IEnumerable<BasicAgentSalesStatsLineViewModel> data,IPrincipal User)
        {
            var agents = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();

            var agentsInGroup = from d in data.Select(x => x.AgentId).Distinct()
                                join a in agents on d equals a.AppUserId
                                select new
                                {
                                    AgentId = d,
                                    AgentName = a.FullName
                                };

            var lobGroups = from d in data
                            group d by d.LineOfBusinessId;

            var orderedAgentList = agentsInGroup.Distinct().OrderBy(x => x.AgentName);

            foreach (var groupKey in groupKeys)
            {
                var groupData = data
                    .Where(x => x.LineOfBusinessId == groupKey)
                    .ToDictionary(x => x.AgentId);

                var tableData = new List<BasicAgentSalesStatsLineViewModel>();
                foreach (var item in orderedAgentList)
                {
                    var newLine = new BasicAgentSalesStatsLineViewModel();

                    newLine.AgentId = item.AgentId;
                    newLine.AgentName = item.AgentName;

                    if (groupData.ContainsKey(item.AgentId))
                    {
                        var groupItem = groupData[item.AgentId];

                        newLine.BookedCount = groupItem.BookedCount;
                        newLine.CancelledCount = groupItem.CancelledCount;
                        newLine.NetSales = groupItem.NetSales;
                    }

                    tableData.Add(newLine);
                }

                yield return tableData.GroupBy(x => groupKey).Single();
            }
        }

        public static byte[] ExportData(string worksheetName, string title, IEnumerable<IGrouping<string, BasicAgentSalesStatsLineViewModel>> officeGroups,IPrincipal user)
        {
            using (var ms = new MemoryStream())
            {
                using (var p = new OfficeOpenXml.ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(worksheetName))
                    {
                        ws.Cells[1, 1].Value = title;
                        ws.Cells[1, 1].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 21].Merge = true;

                        var row = 2;
                        var col = 3;

                        var columns = new[] { "Booked", "Cancelled", "Net", "Sales" };

                        for (int i = 0; i < groupKeys.Length; i++)
                        {
                            // Set the Line Of Business Group Label
                            ws.Cells[row, col].Value = ((LineOfBusiness)groupKeys[i]).ToString();
                            ws.Cells[row, col].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                            ws.Cells[row, col].Style.Font.Bold = true;
                            ws.Cells[row, col].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            ws.Cells[row, col, row, col + 3].Merge = true;

                            for (int j = 0; j < columns.Length; j++)
                            {
                                ws.Cells[row + 1, col + j].Value = columns[j];
                                ws.Cells[row + 1, col + j].Style.Font.Bold = true;
                                ws.Cells[row + 1, col + j].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            }

                            col += 5;
                        }

                        // Set the Totals Label
                        ws.Cells[row, col].Value = "Totals";
                        ws.Cells[row, col].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                        ws.Cells[row, col].Style.Font.Bold = true;
                        ws.Cells[row, col].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[row, col, row, col + 3].Merge = true;

                        for (int j = 0; j < columns.Length; j++)
                        {
                            ws.Cells[row + 1, col + j].Value = columns[j];
                            ws.Cells[row + 1, col + j].Style.Font.Bold = true;
                            ws.Cells[row + 1, col + j].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        }

                        row = 3;

                        foreach (var officeGroup in officeGroups)
                        {
                            var lobGroups = GroupDataByLineOfBusiness(officeGroup,user);

                            // Set the Office Group Label
                            ws.Cells[row, 1].Value = officeGroup.Key;
                            ws.Cells[row, 1].Style.Font.Bold = true;

                            col = 2;

                            var lineCount = 0;
                            var firstGroup = true;

                            var startingRow = row;

                            var salesCells = new List<int>();

                            foreach (var lobGroup in lobGroups)
                            {
                                row = startingRow;

                                var lines = lobGroup.ToList();

                                lineCount = lines.Count;

                                for (int i = 0; i < lineCount; i++)
                                {
                                    if (firstGroup)
                                    {
                                        ws.Cells[row + 1, col].Value = lines[i].AgentName;
                                    }

                                    ws.Cells[row + 1, col + 1].Value = lines[i].BookedCount;
                                    ws.Cells[row + 1, col + 2].Value = lines[i].CancelledCount;
                                    ws.Cells[row + 1, col + 3].Value = lines[i].NetCount;
                                    ws.Cells[row + 1, col + 4].Value = lines[i].NetSales;
                                    ws.Cells[row + 1, col + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                                    salesCells.Add(col + 1);

                                    row += 1;
                                }

                                for (int i = 1; i <= 4; i++)
                                {
                                    SpreadsheetExporter.AddSumCellToColumn(ws, startingRow + 1, row, col + i);
                                }

                                ws.Cells[row + 1, col + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                                col += 5;

                                firstGroup = false;
                            }

                            salesCells = salesCells.Distinct().ToList();

                            col += 1;

                            for (int i = 1; i <= lineCount + 1; i++)
                            {
                                for (int c = 0; c <= 3; c++)
                                {
                                    var formula = string.Empty;

                                    for (int j = 0; j < salesCells.Count; j++)
                                    {
                                        formula += $"+{ws.Cells[startingRow + i, salesCells[j] + c].Address}";
                                    }

                                    ws.Cells[startingRow + i, col + c].Formula = formula.Substring(1);
                                    ws.Cells[startingRow + i, col + c].Style.Numberformat.Format =
                                        ws.Cells[startingRow + i, salesCells[0] + c].Style.Numberformat.Format;
                                    ws.Cells[startingRow + i, col + c].Style.Font.Bold =
                                        ws.Cells[startingRow + i, salesCells[0] + c].Style.Font.Bold;
                                }
                            }

                            row += 3;
                            col = 2;
                        }

                        // Load the total label
                        ws.Cells[row, 1].Value = "Total";
                        ws.Cells[row, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                        ws.Cells[row, 1].Style.Font.Bold = true;

                        foreach (var lobGroup in groupKeys)
                        {
                            ws.Cells[row, col + 1].Value = officeGroups.Sum(x => x.Where(z => z.LineOfBusinessId == lobGroup).Sum(y => y.BookedCount));
                            ws.Cells[row, col + 1].Style.Font.Bold = true;

                            ws.Cells[row, col + 2].Value = officeGroups.Sum(x => x.Where(z => z.LineOfBusinessId == lobGroup).Sum(y => y.CancelledCount));
                            ws.Cells[row, col + 2].Style.Font.Bold = true;

                            ws.Cells[row, col + 3].Value = officeGroups.Sum(x => x.Where(z => z.LineOfBusinessId == lobGroup).Sum(y => y.NetCount));
                            ws.Cells[row, col + 3].Style.Font.Bold = true;

                            ws.Cells[row, col + 4].Value = officeGroups.Sum(x => x.Where(z => z.LineOfBusinessId == lobGroup).Sum(y => y.NetSales));
                            ws.Cells[row, col + 4].Style.Font.Bold = true;
                            ws.Cells[row, col + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                            col += 5;
                        }

                        ws.Cells[row, col + 1].Value = officeGroups.Sum(x => x.Sum(y => y.BookedCount));
                        ws.Cells[row, col + 1].Style.Font.Bold = true;

                        ws.Cells[row, col + 2].Value = officeGroups.Sum(x => x.Sum(y => y.CancelledCount));
                        ws.Cells[row, col + 2].Style.Font.Bold = true;

                        ws.Cells[row, col + 3].Value = officeGroups.Sum(x => x.Sum(y => y.NetCount));
                        ws.Cells[row, col + 3].Style.Font.Bold = true;

                        ws.Cells[row, col + 4].Value = officeGroups.Sum(x => x.Sum(y => y.NetSales));
                        ws.Cells[row, col + 4].Style.Font.Bold = true;
                        ws.Cells[row, col + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                        ws.Calculate();

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }

        public byte[] GetContents(IEnumerable<BasicAgentSalesStatsDto> data,IPrincipal user)
        {
            var officeGroups = BasicAgentSalesStatsViewModel.GroupDataByOffice(data,user);

            var contents = BasicAgentSalesStatsViewModel.ExportData(this.WorksheetName, this.WorksheetTitle, officeGroups,user);

            return contents;
        }
    }
}
