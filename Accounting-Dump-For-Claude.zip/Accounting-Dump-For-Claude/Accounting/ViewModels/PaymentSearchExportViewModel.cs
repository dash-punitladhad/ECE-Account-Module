﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;
    using System.Web;

    public class PaymentSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-ExpensePaymentSearch";
            }
        }

        [FromJson]
        public PaymentSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<PaymentSearchResultDto> results, string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();

            List<PaymentSearchResultExcelDto> listOfObjects = new List<PaymentSearchResultExcelDto>();
            foreach (var detail in sortedResults)
            {
                PaymentSearchResultExcelDto objectClass = new PaymentSearchResultExcelDto();
                objectClass.Id = detail.ExpensePaymentId;
                objectClass.Payee = detail.PayeeName;
                objectClass.PayeeType = detail.PayeeType;
                objectClass.PostedDate = detail.PostedDate;
                objectClass.Amount = detail.Amount;
                objectClass.CheckOrWire = detail.ReferenceNumber;
                objectClass.PaymentBatchNumber = detail.ExpenseBatchId;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                string baseUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                try
                {
                    if (dt.Columns.IndexOf("ID") != -1)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            string url = $"{baseUrl}/accounting/paymentbatch/transactiondetails/" + Convert.ToString(dr["ID"]);
                            dr[0] = "<a href='" + url + "'>" + Convert.ToString(dr[0]) + "</a>";
                        }
                        dt.Columns.Remove("ID");
                    }

                }
                catch { }
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }

        }
    }
}
