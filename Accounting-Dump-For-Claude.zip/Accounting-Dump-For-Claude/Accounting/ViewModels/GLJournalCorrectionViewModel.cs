﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class GLJournalCorrectionViewModel
    {
        public GLJournalCorrectionViewModel()
        {
            Entries = new List<GLJournalEntryViewModel>();
        }

        [Display(Name = "Selected Contract #")]
        public int? ContractId { get; set; }

        public int? AgentId { get; set; }

        public int? OfficeId { get; set; }

        public int? LineOfBusinessId { get; set; }

        [FromJson]
        public IList<GLJournalEntryViewModel> Entries { get; set; }
    }
}
