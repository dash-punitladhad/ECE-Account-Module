﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class AgentPayrollDetailsViewModel
    {
        public int PayrollBatchId { get; set; }

        public int PayrollPaymentId { get; set; }

        public int AgentId { get; set; }

        public string AgentFullName { get; set; }

        public bool NoCommissionProgram { get; set; }

        public DateTime? PostDate { get; set; }

        public DateTime PayrollDate { get; set; }

        public string PayrollDateFormatted
        {
            get
            {
                return DataHelper.ToStandardWithDayString(this.PayrollDate);
            }
        }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalCollections { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalCommissionsPrograms { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalAgentWorking { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal CafeteriaPlan { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal AgentPayrollTotal { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal YTDGross { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal YTDNet { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal AgentSubtotal { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal AgentEarned { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal Mentorships { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal PresenterTransfers { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal SharedBonus { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal NonExclusiveArtistFee { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal RegularCommissions { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal NationalCommissions { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TouringCommissions { get; set; }
    }
}