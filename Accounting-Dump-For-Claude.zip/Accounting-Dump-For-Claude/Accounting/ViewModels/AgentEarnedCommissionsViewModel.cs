﻿using System;

namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class AgentEarnedCommissionsViewModel
    {
        public int? AgentPayrollLogId { get; set; }
        public int AgentId { get; set; }

        public int ContractId { get; set; }

        public string ReceivedDate { get; set; }

        public string LastEventDate { get; set; }

        public decimal GrossCommission { get; set; }

        public decimal NetCommission { get; set; }

        public decimal Percentage { get; set; }

        public string EventType { get; set; }

        public string ContractType { get; set; }

        public string Split { get; set; }
        public bool? IsExclude { get; set; }
        public DateTime? ExcludeDate { get; set; }

    }
}
