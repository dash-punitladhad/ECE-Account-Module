﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class AddOneTimeChargeViewModel
    {
        public int ExpensePaymentId { get; set; }

        [Required(ErrorMessage = "Artist is required.")]
        public int? ArtistId { get; set; }

        [Display(Name = "Artist Name")]
        public string ArtistName { get; set; }

        [Display(Name = "Type")]
        [Required(ErrorMessage = "Type is required.")]
        public int? ArtistChargeTypeId { get; set; }

        [Display(Name = "Charge Amount")]
        [MoneyRange(13, 2, 0)]
        [MoneyLessThan(nameof(MaxOriginalAmount), true, ErrorMessage = "The Charge Amount must be less than or equal to the Payment Amount.")]
        public decimal OriginalAmount { get; set; }

        [Display(Name = "Notes")]
        [MaxLength(2000, ErrorMessage = TextHelper.StandardMaxLengthErrorMessage)]
        public string Notes { get; set; }

        public SelectList TypeSelectList { get; set; }

        public decimal MaxOriginalAmount { get; set; }

        public void LoadForCreate()
        {
            TypeSelectList = LookupCache.GetArtistChargeTypes().ToSelectList("Text", "Value");
        }
    }
}
