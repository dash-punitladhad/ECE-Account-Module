﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class ArtistChargeViewModel
    {
        public ArtistChargeViewModel()
        {
            Transactions = new List<ArtistChargeTransactionViewModel>();
        }

        public int ArtistChargeId { get; set; }

        [DisplayName("Artist")]
        public string ArtistName { get; set; }

        [DisplayName("Type")]
        public string ArtistChargeTypeLabel { get; set; }

        public int ArtistChargeTypeId { get; set; }

        [DisplayName("Status")]
        public string ArtistChargeStatusLabel { get; set; }

        [DisplayName("Amount")]
        public decimal OriginalAmount { get; set; }

        [DisplayName("Original Date")]
        public DateTime OriginalDate { get; set; }

        [DisplayName("Interest Calculated")]
        public string InterestCalculatedFrequencyLabel { get; set; }

        [DisplayName("Interest Rate")]
        public decimal InterestRate { get; set; }

        public bool SuspendInterest { get; set; }

        [DisplayName("Suspend Interest")]
        public string SuspendInterestLabel => this.SuspendInterest ? "Yes" : "No";

        [DisplayName("Payment Per Week With AREF")]
        public decimal PaymentAmount { get; set; }

        [DisplayName("Payments Received")]
        public decimal TotalPaymentsReceived { get; set; }

        [DisplayName("Balance")]
        public decimal RemainingBalance { get; set; }

        public DateTime LastPaymentDate { get; set; }

        [DisplayName("Notes")]
        public string Notes { get; set; }

        public bool IsDeleted { get; set; }

        public IList<ArtistChargeTransactionViewModel> Transactions { get; set; }

        [DisplayName("Amount")]
        [Required(ErrorMessage = "Adjustment amount is required.")]
        public decimal? AdjustmentAmount { get; set; }

        public void LoadTransactions(IList<ArtistChargeTransactionDto> transactions)
        {
            if (transactions != null)
            {
                var viewModels = Mapper.Map<List<ArtistChargeTransactionViewModel>>(transactions);

                var activeViewModels = viewModels.Where(x =>
                    (x.ExpensePaymentId == null || (x.ExpensePaymentDatePosted != null && x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)));

                this.Transactions = Mapper.Map<List<ArtistChargeTransactionViewModel>>(activeViewModels);

                foreach (var item in this.Transactions)
                {
                    item.TransactionAmount = decimal.MinusOne * item.TransactionAmount;
                }
            }
        }
    }
}