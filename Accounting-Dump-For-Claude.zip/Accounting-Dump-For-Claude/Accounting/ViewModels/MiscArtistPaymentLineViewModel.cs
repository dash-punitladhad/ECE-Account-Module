﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class MiscArtistPaymentLineViewModel
    {
        [DisplayName("Date")]
        [DataType(DataType.Date)]
        public DateTime TransactionDate { get; set; }

        [DisplayName("Amount")]
        [DataType(DataType.Currency)]
        public decimal TransactionAmount { get; set; }

        [DisplayName("Type")]
        public string TypeDisplay { get; set; }

        [DisplayName("Artist")]
        public string ArtistName { get; set; }

        [DisplayName("Reference #")]
        public string ReferenceNumber { get; set; }
    }
}
