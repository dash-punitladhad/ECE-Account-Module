﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class CommissionManagementTierModalViewModel
    {
        public CommissionManagementTierModalViewModel()
        {
            this.MaximumUpperNumber = decimal.MaxValue;
            this.MaximumUpperDate = DateTime.MaxValue;
        }

        public CommissionManagementTierModalViewModel(AgentCommissionDto agentCommission, int selectedId)
            : this(agentCommission)
        {
            var selectedTier = agentCommission.CommissionTiers.FirstOrDefault(x => x.AgentCommissionTypeDataId == selectedId);
            if (selectedTier != null)
            {
                if (selectedTier == agentCommission.CommissionTiers.First())
                {
                    this.LowerLimitReadOnly = false;
                }
                else
                {
                    this.LowerLimitReadOnly = true;
                }

                this.AgentCommissionTypeDataId = selectedTier.AgentCommissionTypeDataId;
                this.LowerDate = selectedTier.LowerDate;
                this.LowerNumeric = selectedTier.LowerNumeric;
                this.UpperDate = selectedTier.UpperDate;
                this.UpperNumeric = selectedTier.UpperNumeric;
                this.Percentage = selectedTier.Percentage;

                var nextTier = agentCommission.CommissionTiers
                    .SkipWhile(x => x != selectedTier)
                    .Skip(1)
                    .FirstOrDefault();

                if (nextTier != null)
                {
                    if (nextTier.UpperDate.HasValue)
                    {
                        this.MaximumUpperDate = nextTier.UpperDate.Value.AddDays(-1);
                    }

                    if (nextTier.UpperNumeric.HasValue)
                    {
                        this.MaximumUpperNumber = nextTier.UpperNumeric.Value - 0.01m;
                    }
                }
            }
        }

        public CommissionManagementTierModalViewModel(AgentCommissionDto agentCommission)
            : this()
        {
            if (agentCommission == null)
            {
                throw new ArgumentNullException(nameof(agentCommission));
            }

            this.AgentId = agentCommission.AgentId;
            this.AgentCommissionId = agentCommission.AgentCommissionId.GetValueOrDefault();

            this.CommissionType = AgentCommissionType.TieredCumulativePlan;
            if (agentCommission.AgentCommissionTypeId.HasValue)
            {
                this.CommissionType = (AgentCommissionType)agentCommission.AgentCommissionTypeId.Value;
            }

            var lastTier = agentCommission.CommissionTiers.LastOrDefault();
            if (lastTier != null)
            {
                this.LowerLimitReadOnly = true;

                this.LowerDate = lastTier.UpperDate?.AddDays(1);
                if (lastTier.UpperNumeric.HasValue)
                {
                    this.LowerNumeric = lastTier.UpperNumeric.Value + 0.01m;
                }
            }
        }

        public string ControllerActionName { get; set; }

        [Required]
        public int AgentId { get; set; }

        [Required]
        public int AgentCommissionId { get; set; }

        public int? AgentCommissionTypeDataId { get; set; }

        [Required]
        public AgentCommissionType CommissionType { get; set; }

        [DisplayName("Lower Limit")]
        [RequiredIf("CommissionType", AgentCommissionType.TieredCumulativePlan)]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        public decimal? LowerNumeric { get; set; }

        [DisplayName("Upper Limit")]
        [RequiredIf("CommissionType", AgentCommissionType.TieredCumulativePlan)]
        [NumberGreaterThan("LowerNumeric", true, ErrorMessage = "The Upper Limit must be greater than or equal to the Lower Limit.")]
        [NumberLessThan("MaximumUpperNumber", true, ErrorMessage = "The Upper Limit must be less than the Upper Limit of the next tier.")]
        public decimal? UpperNumeric { get; set; }

        [DisplayName("Lower Limit")]
        [RequiredIf("CommissionType", AgentCommissionType.TieredDatesPlan)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? LowerDate { get; set; }

        [DisplayName("Upper Limit")]
        [RequiredIf("CommissionType", AgentCommissionType.TieredDatesPlan)]
        [DateGreaterThan("LowerDate", true, ErrorMessage = "The Upper Limit must be greater than or equal to the Lower Limit.")]
        [DateLessThan("MaximumUpperDate", true, ErrorMessage = "The Upper Limit must be less than the Upper Limit of the next tier.")]
        public DateTime? UpperDate { get; set; }

        [Required]
        [Range(0.00, 100.00, ErrorMessage = "The percentage must be between {1} and {2} percent.")]
        public decimal? Percentage { get; set; }

        public decimal MaximumUpperNumber { get; set; }

        public DateTime MaximumUpperDate { get; set; }

        public bool LowerLimitReadOnly { get; set; }

        public AgentCommissionTypeDataDto CreateDto()
        {
            var dto = new AgentCommissionTypeDataDto();

            dto.AgentCommissionId = this.AgentCommissionId;
            dto.AgentCommissionTypeDataId = this.AgentCommissionTypeDataId.GetValueOrDefault();
            dto.LowerDate = this.LowerDate;
            dto.LowerNumeric = this.LowerNumeric;
            dto.UpperDate = this.UpperDate;
            dto.UpperNumeric = this.UpperNumeric;
            dto.Percentage = this.Percentage.Value;

            return dto;
        }
    }
}
