﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public class ArtistChargeTransactionViewModel
    {
        public int ArtistChargeTransactionId { get; set; }

        public int ArtistChargeId { get; set; }

        public int ArtistChargeTransactionTypeId { get; set; }

        public string ArtistChargeTransactionTypeLabel { get; set; }

        public DateTime TransactionDate { get; set; }

        public decimal TransactionAmount { get; set; }

        public int? ExpensePaymentId { get; set; }

        public int? ExpensePaymentStatusId { get; set; }

        public DateTime? ExpensePaymentDatePosted { get; set; }

        public string ExpensePaymentStatusLabel
        {
            get
            {
                if (this.ExpensePaymentStatusId == null)
                {
                    return "Posted";
                }

                var status = (ExpensePaymentStatus)ExpensePaymentStatusId.Value;
                switch (status)
                {
                    case ExpensePaymentStatus.HasSufficientEscrow:
                        return "Pending (Has Sufficient Escrow)";

                    case ExpensePaymentStatus.Insufficient:
                        return "Pending (Insufficient)";

                    case ExpensePaymentStatus.PayEscrowBalance:
                        return "Pending (Pay Escrow Balance)";

                    case ExpensePaymentStatus.PayInFull:
                        return "Pending (Pay In Full)";

                    case ExpensePaymentStatus.Withhold:
                        return "Pending (Withhold)";

                    default:
                        return "Posted";
                }
            }
        }

        public bool IsDeleted { get; set; }

        public decimal Balance { get; set; }
    }
}