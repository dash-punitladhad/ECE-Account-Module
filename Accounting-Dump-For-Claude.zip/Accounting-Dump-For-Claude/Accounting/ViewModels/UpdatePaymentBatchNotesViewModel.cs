﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class UpdatePaymentBatchNotesViewModel
    {
        public int ExpenseBatchId { get; set; }

        public string Notes { get; set; }
    }
}
