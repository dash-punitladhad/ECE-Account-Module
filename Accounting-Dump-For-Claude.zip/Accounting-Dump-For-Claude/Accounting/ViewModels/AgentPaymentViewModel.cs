﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class AgentPaymentViewModel
    {
        public int AgentId { get; set; }

        public int PaymentId { get; set; }

        public DateTime? DatePaid { get; set; }

        public decimal EceCollections { get; set; }

        public decimal AgentCommissions { get; set; }

        public decimal AgentWorkingAmount { get; set; }

        public decimal CafeteriaPlanAmount { get; set; }

        public decimal ProgramsAmount { get; set; }
    }
}