﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;

    public class BatchSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-ExpenseBatchSearch";
            }
        }

        [FromJson]
        public BatchSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<BatchSearchResultDto> results,string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();


            List<BatchSearchResultExcelDto> listOfObjects = new List<BatchSearchResultExcelDto>();
            foreach (var detail in sortedResults)
            {
                BatchSearchResultExcelDto objectClass = new BatchSearchResultExcelDto();
                objectClass.BatchNumber = detail.ExpenseBatchId;
                objectClass.BatchType = detail.BatchTypeName;
                objectClass.DatePosted = detail.DatePosted;
                objectClass.TotalAmount = detail.Amount;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }
        }
    }
}
