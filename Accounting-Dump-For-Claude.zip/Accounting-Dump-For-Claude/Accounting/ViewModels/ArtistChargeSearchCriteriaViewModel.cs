﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel;
    using System.Web.Mvc;

    public class ArtistChargeSearchCriteriaViewModel
    {
        [DisplayName("Artist")]
        public int? ArtistId { get; set; }

        [DisplayName("Type")]
        public int? ArtistChargeTypeId { get; set; }

        [DisplayName("Status")]
        public int? ArtistChargeStatusId { get; set; }

        [DisplayName("Balance")]
        public decimal? BalanceFrom { get; set; }

        public decimal? BalanceTo { get; set; }

        [DisplayName("Original Date")]
        public DateTime? OriginalDateFrom { get; set; }

        public DateTime? OriginalDateTo { get; set; }

        public SelectList TypeSelectList { get; set; }

        public SelectList StatusSelectList { get; set; }

        public void LoadForSearch()
        {
            TypeSelectList = LookupCache.GetArtistChargeTypes().ToSelectList("Text", "Value");
            StatusSelectList = LookupCache.GetArtistChargeStatuses().ToSelectList("Text", "Value");
        }
    }
}
