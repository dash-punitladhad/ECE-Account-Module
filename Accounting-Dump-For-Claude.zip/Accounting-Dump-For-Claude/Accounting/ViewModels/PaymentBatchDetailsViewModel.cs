﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class PaymentBatchDetailsViewModel
    {
        [Required]
        public int ExpenseBatchId { get; set; }

        [Required]
        public string BatchType { get; set; }

        [DisplayFormat(NullDisplayText = "NOT POSTED", DataFormatString = "POSTED {0:MM/dd/yyyy (ddd)}")]
        public DateTime? DatePosted { get; set; }

        [DisplayName("AREF Payments")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ArefPaymentsAmount { get; set; }

        [DisplayName("Programs")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ProgramsAmount { get; set; }

        [DisplayName("Batch Total Amount")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal BatchAmount { get; set; }

        [DisplayName("Deposit Payments")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal DepositPaymentsAmount { get; set; }

        [DisplayName("Loan Repayments")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal LoanRepaymentsAmount { get; set; }

        [DisplayName("Transaction Count")]
        public int TransactionCount { get; set; }

        [DisplayName("Files")]
        [DisplayFormat(NullDisplayText = "No files found for this Payment Batch.")]
        public List<PaymentBatchFileViewModel> ExpenseBatchFiles { get; set; }

        [DisplayName("Payments by Payee")]
        public List<ExpensePaymentViewModel> ExpensePayments { get; set; }

        [DisplayName("Notes")]
        [StringLength(2000, ErrorMessage = "Payment Batch Notes exceeds max length of 2000 characters.")]
        [DisplayFormat(NullDisplayText = "No notes on file for this Payment Batch.", ConvertEmptyStringToNull = true)]
        public string Notes { get; set; }

        public bool IsPosted { get; set; }

        public int EntityId { get; set; }

        public int EntityTypeId { get; set; }

        public bool IsManual { get; set; }

        public bool IncludeSharedBonus { get; set; }

        public bool IncludeGasCard { get; set; }

        public bool IncludeNational { get; set; }

        public bool HasIncludedOptions
        {
            get
            {
                return this.IncludeGasCard || this.IncludeSharedBonus || this.IncludeNational;
            }
        }

        public bool InsufficientEscrow
        {
            get
            {
                if (this.ExpensePayments == null)
                {
                    return false;
                }

                return this.ExpensePayments.Any(x => x.InsufficientEscrow);
            }
        }

        public bool HasCheckPayment
        {
            get
            {
                return ExpensePayments.Any(x => x.ExpensePaymentTypeId == (int)ExpensePaymentType.Check);
            }
        }
    }
}