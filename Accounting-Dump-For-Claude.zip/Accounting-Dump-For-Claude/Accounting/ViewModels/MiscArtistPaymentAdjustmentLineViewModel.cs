﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class MiscArtistPaymentAdjustmentLineViewModel
    {
        [DisplayName("Artist")]
        public string ArtistName { get; set; }

        [DisplayName("Loan #")]
        public int ArtistChargeId { get; set; }

        [DisplayName("Adjustment Amount")]
        [DataType(DataType.Currency)]
        public decimal TransactionAmount { get; set; }

        [DisplayName("Date Adjusted")]
        [DataType(DataType.Date)]
        public DateTime TransactionDate { get; set; }
    }
}
