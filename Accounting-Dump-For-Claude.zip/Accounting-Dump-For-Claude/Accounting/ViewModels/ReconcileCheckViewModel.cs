﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class ReconcileCheckViewModel
    {
        public ReconcileCheckViewModel()
        {
            this.ReconcileAddOneCheck = new ReconcileAddOneCheckViewModel();
            this.ReconcileAddMultipleChecks = new ReconcileAddMultipleChecksViewModel();
            this.ReconcileCloseBatch = new ReconcileCloseBatchViewModel();
            this.ChecksToReconcile = new List<ReconciliationItemViewModel>();
        }

        public int ReconciliationBatchId { get; set; }

        [Required(ErrorMessage = "You must provide at least one check.")]
        [Display(Name = "Multiple Checks")]
        public string AddMultipleChecks { get; set; }

        public ReconcileAddOneCheckViewModel ReconcileAddOneCheck { get; set; }

        public ReconcileAddMultipleChecksViewModel ReconcileAddMultipleChecks { get; set; }

        public ReconcileCloseBatchViewModel ReconcileCloseBatch { get; set; }

        public List<ReconciliationItemViewModel> ChecksToReconcile { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalReconciledAmount
        {
            get
            {
                return this.ChecksToReconcile.Sum(x => x.ReconciledAmount);
            }
        }

        public int NumOfChecks
        {
            get
            {
                return this.ChecksToReconcile.Count;
            }
        }

        public int NumOfMismatchedChecks
        {
            get
            {
                return this.ChecksToReconcile.Count(x => x.ExpensePaymentId == null);
            }
        }

        public int NumOfChecksWithAmountIssues
        {
            get
            {
                return this.ChecksToReconcile.Count(x => x.PaymentAmount != x.ReconciledAmount);
            }
        }

        public bool HasWarnings
        {
            get
            {
                return this.ChecksToReconcile.Any(x => x.HasWarning);
            }
        }
    }
}