﻿namespace ECE.CRM.WebUI.ViewModels.Contract
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class ContractReassignAgentViewModel
    {
        [Required]
        public int ContractId { get; set; }

        [Required]
        [Display(Name = "Agent")]
        public int? AgentId { get; set; }

        public bool FromMoneyScreen { get; set; }

        public IList<SelectListItem> Agents { get; set; }
    }
}
