﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;

    public class AgentPayrollLogViewModel : AgentPayrollLogViewDto
    {
        public string FormattedReceivedDate
        {
            get { return ReceivedDate.ToStandardString(); }
        }

        public string FormattedLastEventDate
        {
            get { return LastEventDate.ToStandardString(); }
        }
    }
}
