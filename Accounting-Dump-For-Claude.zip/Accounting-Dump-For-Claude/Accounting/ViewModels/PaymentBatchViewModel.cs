﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class PaymentBatchViewModel
    {
        [DisplayName("Batch #")]
        public int ExpenseBatchId { get; set; }

        [DisplayName("Batch Type")]
        public string BatchTypeName { get; set; }

        public int ExpenseBatchTypeId { get; set; }

        public ExpenseBatchType BatchType
        {
            get
            {
                return (ExpenseBatchType)ExpenseBatchTypeId;
            }
        }

        [DisplayName("Date Posted")]
        [DisplayFormat(NullDisplayText = "NOT POSTED", DataFormatString = "{0:MM/dd/yyyy (ddd)}")]
        public DateTime? DatePosted { get; set; }

        [DisplayName("Batch Amount")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal Amount { get; set; }

        [DisplayName("Payees")]
        public int PayeeCount { get; set; }

        [DisplayName("Created Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy (ddd)}")]
        public DateTime CreatedDate { get; set; }

        [DisplayName("Type")]
        public bool IsManual { get; set; }

        public bool IncludeSharedBonus { get; set; }

        public bool IncludeGasCard { get; set; }

        public bool IncludeNational { get; set; }
    }
}
