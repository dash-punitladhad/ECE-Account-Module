﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using Infrastructure.Helpers;
    using System.Collections.Generic;

    public class PayrollPageLogsViewModel
    {
        public PayrollPageLogsViewModel()
        {
            this.Logs = new List<PayrollPageLogViewModel>();
        }

        public PayrollPageLogsViewModel(IList<PayrollBatchLogDto> logs)
        {
            this.Logs = this.FormatBatchLogs(logs);
        }

        public decimal RegionalCollections { get; set; }

        public decimal NationalCollections { get; set; }

        public decimal TouringCollections { get; set; }

        public IList<PayrollPageLogViewModel> Logs { get; set; }

        public string FormattedCollectionTotals
        {
            get
            {
                return $"(C) {this.RegionalCollections.ToCurrency()}<br />(N) {this.NationalCollections.ToCurrency()}<br />(T) {this.TouringCollections.ToCurrency()}";
            }
        }

        public void ResetCollectionTotals()
        {
            this.RegionalCollections = decimal.Zero;
            this.NationalCollections = decimal.Zero;
            this.TouringCollections = decimal.Zero;
        }

        public IList<PayrollPageLogViewModel> FormatBatchLogs(IList<PayrollBatchLogDto> batchLogs)
        {
            var payrollPageLogs = new List<PayrollPageLogViewModel>();

            PayrollPageLogViewModel payrollPageLog = null;

            var prevBatchId = -1;

            for (int i = 0; i < batchLogs.Count; i++)
            {
                var batchLog = batchLogs[i];

                if (i == 0)
                {
                    prevBatchId = batchLog.PayrollBatchId;

                    payrollPageLog = CreatePayrollPageLog(batchLog);

                    payrollPageLogs.Add(payrollPageLog);
                }

                if (prevBatchId != batchLog.PayrollBatchId)
                {
                    payrollPageLog.ECECollections = this.FormattedCollectionTotals;

                    this.ResetCollectionTotals();

                    payrollPageLog = CreatePayrollPageLog(batchLog);

                    payrollPageLogs.Add(payrollPageLog);
                }

                if (batchLog.ECECollections_N != decimal.Zero)
                {
                    this.NationalCollections = batchLog.ECECollections_N;
                }
                else if (batchLog.ECECollections_R != decimal.Zero)
                {
                    this.RegionalCollections = batchLog.ECECollections_R;
                }
                else if (batchLog.ECECollections_T != decimal.Zero)
                {
                    this.TouringCollections = batchLog.ECECollections_T;
                }

                prevBatchId = batchLog.PayrollBatchId;
            }

            if (payrollPageLog != null)
            {
                payrollPageLog.ECECollections = this.FormattedCollectionTotals;
            }

            return payrollPageLogs;
        }

        private static PayrollPageLogViewModel CreatePayrollPageLog(PayrollBatchLogDto log)
        {
            PayrollPageLogViewModel row = new PayrollPageLogViewModel();

            row.PayrollBatchId = log.PayrollBatchId;
            row.PayrollBatchDate = DataHelper.ToStandardWithDayString(log.PayrollBatchDate);
            row.Commissions = log.Commissions;
            row.AgentWorking = log.AgentWorking;
            row.Programs = log.Total - log.Commissions - log.AgentWorking;
            row.Total = log.Total;

            return row;
        }
    }
}
