﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;

    public class FeesBreakdownLineViewModel : FeesBreakdownDto
    {
        public string OfficeName { get; set; }

        public decimal DebitAmount { get; set; }

        public decimal CreditAmount { get; set; }

        public decimal NetAmount
        {
            get { return this.CreditAmount - this.DebitAmount; }
        }
    }
}
