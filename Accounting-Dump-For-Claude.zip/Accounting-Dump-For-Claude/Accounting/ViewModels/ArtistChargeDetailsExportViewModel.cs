﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class ArtistChargeDetailsExportViewModel
    {
        public int ArtistChargeId { get; set; }

        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-ArtistChargeDetails-{ArtistChargeId}";
            }
        }

        public byte[] GetExportFileContents(IList<ArtistChargeTransactionViewModel> results,string fileName)
        {

            List<ArtistChargeTransactionExcelDto> listOfObjects = new List<ArtistChargeTransactionExcelDto>();

            foreach (var detail in results)
            {
                ArtistChargeTransactionExcelDto objectClass = new ArtistChargeTransactionExcelDto();
                objectClass.Date = detail.TransactionDate;
                objectClass.TransactionType = detail.ArtistChargeTransactionTypeLabel;
                objectClass.Status = detail.ExpensePaymentStatusLabel;
                objectClass.Amount = detail.TransactionAmount;
                listOfObjects.Add(objectClass);
            }
            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }
        }
    }
}
