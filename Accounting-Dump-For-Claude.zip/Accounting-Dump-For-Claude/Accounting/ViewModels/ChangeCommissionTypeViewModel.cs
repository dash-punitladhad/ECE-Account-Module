﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System.ComponentModel.DataAnnotations;

    public class ChangeCommissionTypeViewModel
    {
        public ChangeCommissionTypeViewModel()
        {
            this.CommissionType = AgentCommissionType.TieredCumulativePlan;
        }

        public ChangeCommissionTypeViewModel(int agentId, AgentCommissionDto agentCommission)
        {
            this.AgentId = agentId;

            if (agentCommission != null && agentCommission.AgentCommissionTypeId != null)
            {
                this.CommissionType = (AgentCommissionType)agentCommission.AgentCommissionTypeId.Value;
            }
        }

        [Required]
        public int AgentId { get; set; }

        public int? AgentCommissionId { get; set; }

        [Required]
        public AgentCommissionType? CommissionType { get; set; }
    }
}
