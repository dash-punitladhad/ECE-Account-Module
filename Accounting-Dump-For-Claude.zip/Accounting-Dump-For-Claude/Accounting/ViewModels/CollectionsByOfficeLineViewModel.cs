﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;

    public class CollectionsByOfficeLineViewModel : CollectionsByOfficeDto
    {
        public string OfficeName { get; set; }

        public string AgentName { get; set; }
    }
}
