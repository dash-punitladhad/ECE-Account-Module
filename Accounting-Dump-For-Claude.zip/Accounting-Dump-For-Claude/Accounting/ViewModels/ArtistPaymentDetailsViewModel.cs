﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;

    public class ArtistPaymentDetailsViewModel
    {
        public ArtistPaymentDetailsViewModel()
        {
        }

        public ArtistPaymentDetailsViewModel(ExpensePaymentDto payment)
        {
            Amount = payment.PaymentAmount;
            DatePaid = payment.DatePosted;
            ExpensePaymentId = payment.ExpensePaymentId;
            ReferenceNumber = payment.ReferenceNumber;
            IsVoided = payment.DateVoided.HasValue;
            PaymentMethod = payment.PaymentAmount == decimal.Zero
                ? string.Empty
                : payment.ExpensePaymentTypeLabel;
        }

        public int ArtistId { get; set; }

        public int Year { get; set; }

        [DisplayName("Artist")]
        public string ArtistName { get; set; }

        [DisplayName("Amount")]
        public decimal? Amount { get; set; }

        [DisplayName("Date Paid")]
        public DateTime? DatePaid { get; set; }

        [DisplayName("Payment Method")]
        public string PaymentMethod { get; set; }

        public int ExpensePaymentId { get; set; }

        public string ReferenceNumber { get; set; }

        public bool IsVoided { get; set; }

        public bool IsPaid
        {
            get { return this.DatePaid.HasValue; }
        }

        public List<PaymentBatchContractTransactionViewModel> Payments { get; set; }
    }
}
