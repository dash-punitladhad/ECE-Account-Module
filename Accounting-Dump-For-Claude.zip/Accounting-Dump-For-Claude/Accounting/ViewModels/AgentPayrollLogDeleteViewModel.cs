﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class AgentPayrollLogDeleteViewModel
    {
        public int AgentPayrollLogId { get; set; }

        public int ContractId { get; set; }

        public int? PayrollPaymentId { get; set; }

        public string ReturnUrl { get; set; }
    }
}
