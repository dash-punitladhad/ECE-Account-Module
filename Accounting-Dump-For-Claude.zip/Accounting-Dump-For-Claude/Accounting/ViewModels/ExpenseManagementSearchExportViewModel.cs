﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;

    public class ExpenseManagementSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-ExpenseManagementSearch";
            }
        }

        [FromJson]
        public ExpenseManagementSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<ExpenseManagementSearchResultDto> results, string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();
            List<ExpenseManagementSearchExcelDto> listOfObjects = new List<ExpenseManagementSearchExcelDto>();
            foreach (var detail in sortedResults)
            {
                ExpenseManagementSearchExcelDto objectClass = new ExpenseManagementSearchExcelDto();
                objectClass.ContractNumber = Convert.ToString(detail.ContractId);
                objectClass.PayeeName = detail.PayeeName;
                objectClass.Amount = detail.Amount;
                objectClass.ExpenseType = detail.ExpenseType;
                objectClass.Status = detail.Status;
                objectClass.BatchNumber = detail.ExpenseBatchId;
                if (detail.IsW9OnFile == false && detail.ContractEntityTypeId != (int)ContractEntityType.Presenter)
                {
                    objectClass.Note = "*** W9 Not On File ***";
                }
                else
                {
                    objectClass.Note = string.Empty;
                }
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }

        }
    }
}
