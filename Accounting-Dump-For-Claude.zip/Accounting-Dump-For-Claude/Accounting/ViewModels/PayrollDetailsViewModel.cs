﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class PayrollDetailsViewModel
    {
        public int PayrollBatchId { get; set; }

        [UIHint("ECEDate")]
        public DateTime PayrollDate { get; set; }

        [UIHint("ECEDate")]
        public DateTime PayrollPeriod { get; set; }

        [UIHint("ECEDate")]
        public DateTime PayrollPeriodStart { get; set; }

        [UIHint("ECEDate")]
        public DateTime PayrollPeriodEnd { get; set; }

        public DateTime? PostDate { get; set; }

        public string PayrollDateFormatted
        {
            get
            {
                return DataHelper.ToStandardWithDayString(this.PayrollDate);
            }
        }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalCommissions { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalAgentWorking { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalPayments { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalPrograms { get; set; }
    }
}