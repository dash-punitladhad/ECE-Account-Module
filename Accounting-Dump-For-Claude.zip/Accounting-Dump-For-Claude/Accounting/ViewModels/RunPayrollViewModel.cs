﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class RunPayrollViewModel
    {
        public RunPayrollViewModel()
        {
            AsofDate = TimeProvider.Current.Today;
        }

        [Required]
        [Display(Name = "As Of Date")]
        public DateTime AsofDate { get; set; }
    }
}
