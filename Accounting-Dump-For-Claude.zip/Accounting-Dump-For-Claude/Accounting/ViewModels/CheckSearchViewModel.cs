﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.Collections.Generic;
    using System.Web.Mvc;

    public class CheckSearchViewModel
    {
        public int ArtistId { get; set; }

        public int PresenterId { get; set; }

        public IList<SelectListItem> Agents { get; set; }

        public SelectList VoidedTypes
        {
            get
            {
                SelectList voidedTypes = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem() { Selected = false, Text = "Yes", Value = "1" },
                        new SelectListItem() { Selected = false, Text = "No", Value = "2" },
                    },
                    "Value",
                    "Text",
                    0);

                return voidedTypes;
            }
        }

        public SelectList ReconciledTypes
        {
            get
            {
                SelectList reconTypes = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem() { Selected = false, Text = "Yes", Value = "1" },
                        new SelectListItem() { Selected = false, Text = "No", Value = "2" },
                    },
                    "Value",
                    "Text",
                    0);

                return reconTypes;
            }
        }
    }
}