﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class MiscArtistPaymentInterestLineViewModel
    {
        [DisplayName("Artist")]
        public string ArtistName { get; set; }

        [DisplayName("Loan #")]
        public int ArtistChargeId { get; set; }

        [DisplayName("Original Loan Amount")]
        [DataType(DataType.Currency)]
        public decimal OriginalAmount { get; set; }

        [DisplayName("Interest Rate")]
        [DataType(DataType.Currency)]
        public decimal InterestRate { get; set; }

        [DisplayName("Assessed Amount")]
        [DataType(DataType.Currency)]
        public decimal TransactionAmount { get; set; }

        [DisplayName("Date Assessed")]
        [DataType(DataType.Date)]
        public DateTime TransactionDate { get; set; }
    }
}
