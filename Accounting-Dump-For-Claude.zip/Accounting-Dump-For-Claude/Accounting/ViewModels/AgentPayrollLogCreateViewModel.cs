﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class AgentPayrollLogCreateViewModel
    {
        public AgentPayrollLogCreateViewModel()
        {
        }

        public int? AgentId { get; set; }

        public int? PayrollPaymentId { get; set; }

        [Required]
        [Display(Name = "Contract #")]
        public int? ContractId { get; set; }

        [Required]
        [Display(Name = "Expense")]
        public int? ContractTransactionId { get; set; }

        [Required]
        [Display(Name = "Log Type")]
        public int? PayrollLogTypeId { get; set; }

        [Required]
        [Display(Name = "Gross Amount")]
        public decimal? GrossAmount { get; set; }

        [Required]
        [Display(Name = "Net Amount")]
        public decimal? NetAmount { get; set; }

        [Required]
        [Display(Name = "Rate")]
        public decimal? CommissionRate { get; set; }

        [Required]
        [Display(Name = "Received Date")]
        public DateTime? ReceivedDate { get; set; }

        public SelectList Agents { get; set; }

        public SelectList PayrollLogTypes { get; set; }

        public SelectList ContractExpenses { get; set; }

        public string ReturnUrl { get; set; }
    }
}
