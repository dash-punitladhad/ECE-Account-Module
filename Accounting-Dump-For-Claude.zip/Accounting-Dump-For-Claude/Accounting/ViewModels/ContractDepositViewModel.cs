﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using Microsoft.Ajax.Utilities;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Mvc;

    public class ContractDepositViewModel
    {
        public ContractDepositViewModel()
        {
            ReceivedDate = DateTime.Today;
        }

        public int ContractDepositId { get; set; }

        public int ContractId { get; set; }

        [Required]
        public int ContractEntityTypeId { get; set; }

        [Required(ErrorMessage = "Received From is required.")]
        public int ContractEntityId { get; set; }

        [Required(ErrorMessage = "Received From is required.")]
        public string ReceivedFrom { get; set; }

        [Required(ErrorMessage = "Date Received is required.")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime ReceivedDate { get; set; }

        [MoneyRange(10, 2, 0)]
        [Required(ErrorMessage = "Amount Received is required.")]
        public decimal ReceivedAmount { get; set; }

        [Required(ErrorMessage = "Payment Method is required.")]
        public int PaymentMethodId { get; set; }

        public string PaymentMethodDisplay { get; set; }

        [Required(ErrorMessage = "Reference is required.")]
        [MaxLength(50, ErrorMessage = "Reference exceeds max length of 50 characters.")]
        public string ReferenceNumber { get; set; }

        public string Note { get; set; }

        public decimal? AllocatedAmount { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Required(ErrorMessage = "Amount is required.")]
        [MoneyRange(10, 2, 0)]
        [MoneyLessThan("DueAmount", true, ErrorMessage = "The Amount cannot be greater than the amount due on the Contract.")]
        public decimal AppliedAmount { get; set; }

        public decimal DueAmount { get; set; }

        public bool IsDeleted { get; set; }

        public bool CanUnpost
        {
            get
            {
                return PaymentMethodId != (int)PaymentMethod.CrossDeduction;
            }
        }

        public SelectList ReceivedFromSelectList { get; set; }

        public SelectList PaymentMethodSelectList { get; set; }

        public static List<ContractDepositViewModel> GetDeposits(ContractDto contract, IList<ContractDepositDto> contractDeposits)
        {
            var visibleDeposits = contractDeposits
                .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                .Where(x => x.PaymentMethodId != (int)PaymentMethod.CrossDeduction || x.ExpensePaymentDatePosted != null)
                .ToList();

            var depositsViewModels = Mapper.Map<List<ContractDepositViewModel>>(visibleDeposits);

            if (contract != null)
            {
                depositsViewModels.ForEach(x =>
                {
                    var transaction = contract.ContractTransactions.Find(x);

                    x.SetDisplayNames(transaction);
                });
            }

            return depositsViewModels;
        }

        public void LoadForCreate(ContractDto contract)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (contract.ContractTransactions == null)
            {
                throw new ArgumentNullException(nameof(contract.ContractTransactions));
            }

            ContractId = contract.ContractId;

            var receivedFromSelectList = contract.ContractTransactions
                .DistinctBy(x => $"{x.ContractEntityTypeId} {x.ContractEntityId} {x.PayeeName}")
                .OrderBy(x => x.ContractEntityTypeId)
                .Select(x =>
                {
                    var newItem = new SelectListItem()
                    {
                        Text = x.GetPayeeDisplayName(),
                        Value = $"{x.ContractEntityTypeId.ToString()},{x.ContractEntityId.ToString()}"
                    };

                    return newItem;
                });

            ReceivedFromSelectList = receivedFromSelectList.ToSelectList("Text", "Value");
            PaymentMethodSelectList = LookupCache
                .GetAllPaymentMethods()
                .Where(x => x.Value != $"{(int)PaymentMethod.CrossDeduction}")
                .ToSelectList("Text", "Value");
            PaymentMethodId = (int)PaymentMethod.Check;

            DueAmount = contract.ContractTransactions.Where(x => x.IsIncome).Sum(x => x.DueAmount);
        }

        public void SetDisplayNames(ContractTransactionDto dto)
        {
            if (dto == null)
            {
                return;
            }

            this.PaymentMethodDisplay = LookupCache.GetAllPaymentMethods()
                .FirstOrDefault(y => y.Value == this.PaymentMethodId.ToString())?.Text;

            this.ReceivedFrom = dto.GetPayeeDisplayName();
        }
    }
}