﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class GLBreakdownSearchViewModel
    {
        [Display(Name = "POST DATE FROM")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? PostDateFrom { get; set; }

        [Display(Name = "POST DATE TO")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? PostDateTo { get; set; }

        public ExportDataCriteriaDto CreateDto()
        {
            if (this.PostDateFrom == null || this.PostDateTo == null)
            {
                return null;
            }

            return new ExportDataCriteriaDto
            {
                FromDate = this.PostDateFrom.Value,
                ToDate = this.PostDateTo.Value,
            };
        }
    }
}
