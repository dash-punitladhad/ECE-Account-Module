﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class GLJournalActivityViewModel
    {
        [Required]
        [DisplayName("Description")]
        public string ActivityDescription { get; set; }

        [Required]
        [DisplayName("Debit")]
        public string ActivityDebit { get; set; }

        [Required]
        [DisplayName("Credit")]
        public string ActivityCredit { get; set; }
    }
}