﻿using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class DrawTableViewModel
    {
        public DrawTableViewModel()
        {

        }

        public int AgentId { get; set; }

        public IList<SelectListItem> AgentSelectList { get; set; }

        public int Year { get; set; }

        public List<int> YearSelectList { get; set; }

        public int QuarterId { get; set; }
        public List<LuQuarterDto> QuartersList { get; set; }

    }

}