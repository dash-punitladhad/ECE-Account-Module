﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using OfficeOpenXml;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;

    public class UnpaidCommissionsViewModel : BaseExportDataViewModel
    {
        public override string FileName
        {
            get
            {
                var fileName = $"{this.WorksheetName} As Of {this.AsOfDate:MM/dd/yyyy}";

                fileName = FileHelper.GetSafeFileName(fileName.Replace(" ", "-") + ".xlsx");

                return fileName;
            }
        }

        public override string WorksheetName
        {
            get
            {
                return $"Unpaid Commissions";
            }
        }

        public override string WorksheetTitle
        {
            get
            {
                return $"{this.WorksheetName} As Of {this.AsOfDate:MM/dd/yyyy}";
            }
        }

        public byte[] GetContents(IList<UnpaidCommissionDto> data,IPrincipal User)
        {
            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();
            var agents = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();

            var view = from d in data
                       join ol in offices on d.OfficeId equals ol.OfficeId into jo
                       from o in jo.DefaultIfEmpty()
                       join col in offices on d.ContractOfficeId equals col.OfficeId into jco
                       from co in jco.DefaultIfEmpty()
                       join al in agents on d.AgentId equals al.AppUserId into ja
                       from a in ja.DefaultIfEmpty()
                       select new UnpaidCommissionsLineViewModel
                       {
                           OfficeId = d.OfficeId,
                           OfficeName = o?.Name ?? "Unassigned",
                           AgentId = d.AgentId,
                           AgentName = d.AgentName,
                           ContractId = d.ContractId,
                           MaxEventDate = d.MaxEventDate,
                           ReceivedAmount = d.ReceivedAmount,
                           ReceivedDate = d.ReceivedDate,
                           RequiredAmount = d.RequiredAmount,
                           ContractOfficeName = co?.Name ?? "Unassigned",
                       };

            var officeGroups =
                from ag in view
                orderby ag.OfficeName, ag.ContractId
                group ag by new { ag.OfficeId, ag.OfficeName };

            using (var ms = new MemoryStream())
            {
                using (var p = new ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(this.WorksheetName))
                    {
                        ws.Cells[1, 1].Value = this.WorksheetTitle;
                        ws.Cells[1, 1].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 4].Merge = true;

                        var row = 3;
                        var col = 1;

                        foreach (var officeGroup in officeGroups)
                        {
                            // Set the Office Group Label
                            ws.Cells[row, 1].Value = officeGroup.Key.OfficeName;
                            ws.Cells[row, 1].Style.Font.Bold = true;
                            row += 2;

                            var columns = new[] { "Contract #", "Agent", "ECE Commission", "Event Date", "Contract Office" };

                            for (int j = 0; j < columns.Length; j++)
                            {
                                ws.Cells[row, col + j].Value = columns[j];
                                ws.Cells[row, col + j].Style.Font.Bold = true;
                                ws.Cells[row, col + j].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            }

                            row += 1;

                            var startingRow = row;

                            var lines = officeGroup.ToArray();

                            for (int i = 0; i < lines.Length; i++)
                            {
                                ws.Cells[row, col + 0].Value = lines[i].ContractId;
                                ws.Cells[row, col + 1].Value = lines[i].AgentName;
                                ws.Cells[row, col + 2].Value = lines[i].RequiredAmount;
                                ws.Cells[row, col + 2].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                                ws.Cells[row, col + 3].Value = lines[i].MaxEventDate;
                                ws.Cells[row, col + 3].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                                ws.Cells[row, col + 4].Value = lines[i].ContractOfficeName;
                                if (officeGroup.Key.OfficeName != lines[i].ContractOfficeName)
                                {
                                    ws.Cells[row, col + 0, row, col + 4].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                    ws.Cells[row, col + 0, row, col + 4].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);
                                }

                                row += 1;
                            }

                            SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row - 1, col + 2, 4);
                            ws.Cells[row, col + 5].Value = officeGroup.Key.OfficeName;
                            ws.Cells[row, col + 5].Style.Font.Bold = true;
                            ws.Cells[row, col + 6].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                            row += 2;
                        }

                        SpreadsheetExporter.AddSumCellToColumn(ws, 3, row - 2, col + 6);
                        ws.Cells[row - 1, col + 5].Value = "TOTAL";
                        ws.Cells[row - 1, col + 5].Style.Font.Bold = true;
                        ws.Cells[row - 1, col + 6].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                        ws.Calculate();

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }
    }
}
