﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Security.Principal;
    using System.Web.Mvc;

    public class CommissionManagementSearchCriteriaViewModel
    {
        public CommissionManagementSearchCriteriaViewModel()
        {
            this.OfficeValues = new SelectList(Enumerable.Empty<SelectListItem>());
            this.CommissionTypeValues = new SelectList(Enumerable.Empty<SelectListItem>());
        }

        [DisplayName("Agent")]
        public int? AgentId { get; set; }

        public IList<SelectListItem> AgentValues { get; set; }

        [DisplayName("Office")]
        public int? OfficeId { get; set; }

        public SelectList OfficeValues { get; set; }

        [DisplayName("Commission Type")]
        public int? CommissionType { get; set; }

        public SelectList CommissionTypeValues { get; set; }

        [DisplayName("Status")]
        public int? Status { get; set; }

        public SelectList StatusValues
        {
            get
            {
                SelectList statusTypes = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem() { Selected = false, Text = "Active", Value = "1" },
                        new SelectListItem() { Selected = false, Text = "Not Active", Value = "2" },
                    },
                    "Value",
                    "Text");

                return statusTypes;
            }
        }

        public void LoadForIndex(IPrincipal User)
        {
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin) || User.IsInRole(ECERole.AccountingAdmin)) ? new List<AppUserDto>(LookupCache.GetActiveAgents()) : new List<AppUserDto>(LookupCache.GetActiveRestrictedAgents());
            var agents = agentList;            
            this.AgentValues = new AgentSelectList(agents, 0);

            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();
            this.OfficeValues = offices.ToSelectList("Name", "OfficeId");

            var commissionTypes = LookupCache.GetAllAgentCommissionTypes();
            this.CommissionTypeValues = commissionTypes.ToSelectList("Text", "Value");
        }
    }
}
