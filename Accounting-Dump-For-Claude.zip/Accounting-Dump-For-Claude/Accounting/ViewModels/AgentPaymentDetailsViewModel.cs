﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class AgentPaymentDetailsViewModel
    {
        public AgentPaymentDetailsViewModel()
        {
            this.Payments = new List<AgentPaymentDetailViewModel>();
        }

        public AgentPaymentDetailsViewModel(int agentId, int year, AppUserDto agent, IList<AgentPayrollLogViewDto> logs)
        {
            AgentId = agentId;
            Year = year;

            if (agent != null)
            {
                AgentName = agent.FullName;
            }

            var commissionLogs = logs.Where(x =>
                x.PayrollLogTypeId != (int)PayrollLogType.CafeteriaPlan);

            this.Payments = commissionLogs
                .Select(x => new AgentPaymentDetailViewModel(x))
                .OrderBy(x => x.ContractId)
                .ToList();

            this.EceCollections = commissionLogs.Sum(x => x.GrossAmount);

            this.AgentCommissions = commissionLogs
                .Where(x => x.PayrollLogTypeId == (int)PayrollLogType.AgentCommission)
                .Total(x => x.NetAmount);

            this.AgentWorking = commissionLogs
                .Where(x => x.PayrollLogTypeId == (int)PayrollLogType.AgentWorking)
                .Total(x => x.NetAmount);

            this.AgentPayments = commissionLogs
                .Total(x => x.NetAmount);

            this.OtherPayments = this.AgentPayments - this.AgentCommissions - this.AgentWorking;
        }

        public AgentPaymentDetailsViewModel(int agentId, int year, AppUserDto agent, IList<AgentPayrollLogDto> logs)
        {
            AgentId = agentId;
            Year = year;

            if (agent != null)
            {
                AgentName = agent.FullName;
            }

            var commissionLogs = logs.Where(x =>
                x.PayrollLogTypeId != (int)PayrollLogType.CafeteriaPlan);

            this.Payments = commissionLogs
                .Select(x => new AgentPaymentDetailViewModel(x))
                .OrderBy(x => x.ContractId)
                .ToList();

            this.EceCollections = commissionLogs.Sum(x => x.GrossAmount);

            this.AgentCommissions = commissionLogs
                .Where(x => x.PayrollLogTypeId == (int)PayrollLogType.AgentCommission)
                .Total(x => x.NetAmount);

            this.AgentWorking = commissionLogs
                .Where(x => x.PayrollLogTypeId == (int)PayrollLogType.AgentWorking)
                .Total(x => x.NetAmount);

            this.AgentPayments = commissionLogs
                .Total(x => x.NetAmount);

            this.OtherPayments = this.AgentPayments - this.AgentCommissions - this.AgentWorking;
        }

        public int AgentId { get; set; }

        public int Year { get; set; }

        [DisplayName("Agent")]
        public string AgentName { get; set; }

        [DisplayName("Payroll Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", NullDisplayText = "UNPAID")]
        public DateTime? PayrollDate { get; set; }

        [DisplayName("ECE Collections")]
        public decimal EceCollections { get; set; }

        [DisplayName("Agent Commissions")]
        public decimal AgentCommissions { get; set; }

        [DisplayName("Agent Working Fees")]
        public decimal AgentWorking { get; set; }

        [DisplayName("Agent Payments")]
        public decimal AgentPayments { get; set; }

        [DisplayName("Programs")]
        public decimal OtherPayments { get; set; }

        public List<AgentPaymentDetailViewModel> Payments { get; set; }
    }
}