﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;
    using System.Web;

    public class CheckSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-CheckSearch";
            }
        }

        [FromJson]
        public CheckSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<CheckSearchResultDto> results,string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();

            List<CheckSearchExcelDto> listOfObjects = new List<CheckSearchExcelDto>();
            foreach (var detail in sortedResults)
            {
                CheckSearchExcelDto objectClass = new CheckSearchExcelDto();
                objectClass.CheckNumber = detail.CheckNumber;
                objectClass.DateIssued = detail.DateIssued;
                objectClass.PayeeName = detail.PayeeName;
                objectClass.Amount = detail.Amount;
                objectClass.Reconciled = detail.IsReconciled.ToYesNo();
                objectClass.ExpensePaymentId = detail.ExpensePaymentId;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                string baseUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                try
                {
                    if (dt.Columns.IndexOf("EXPENSEPAYMENTID") != -1)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            string url = $"{baseUrl}/accounting/checkbook/details/" + Convert.ToString(dr["EXPENSEPAYMENTID"]);
                            dr[0] = "<a href='" + url + "'>" + Convert.ToString(dr[0]) + "</a>";
                        }
                        dt.Columns.Remove("EXPENSEPAYMENTID");
                    }

                }
                catch { }
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }
        }
    }
}
