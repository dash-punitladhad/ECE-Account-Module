﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using Newtonsoft.Json;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class ReconciliationItemViewModel
    {
        public int ReconciliationItemId { get; set; }

        public int ReconciliationBatchId { get; set; }

        [Required]
        [Display(Name = "Check #")]
        [StringLength(50)]
        [ForceToUppercase]
        [JsonConverter(typeof(ForceToUppercaseConverter))]
        public string ReferenceNumber { get; set; }

        public decimal? PaymentAmount { get; set; }

        public int? ExpensePaymentId { get; set; }

        public DateTime? DateIssued { get; set; }

        public string Payee { get; set; }

        [Required]
        public decimal ReconciledAmount { get; set; }

        public bool HasWarning { get; set; }

        public string WarningMessage { get; set; }
    }
}