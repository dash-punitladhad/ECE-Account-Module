﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Web;

    public class ContractSignatureReceivedViewModel
    {
        public ContractSignatureReceivedViewModel()
        {
            SendEmailNotifications = true;
        }

        public int ContractSignatureId { get; set; }

        public int EntityId { get; set; }

        public int EntityTypeId { get; set; }

        [Required]
        public DateTime DateReceived { get; set; }

        [Required]
        [Display(Name = "File to upload")]
        [MaximumFileSize(25)]
        [ValidFileType("PDF,XLS,XLSX,DOC,DOCX,JPG,JPEG,PNG,GIF,TIF,TIFF,TXT,CSV")]
        public HttpPostedFileBase File { get; set; }

        public bool SendEmailNotifications { get; set; }
    }
}
