﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class AgentPayrollLogUpdateViewModel : AgentPayrollLogCreateViewModel
    {
        public int AgentPayrollLogId { get; set; }

        public int LineOfBusinessId { get; set; }

        [Display(Name = "Post Date")]
        public DateTime? PostDate { get; set; }
    }
}
