﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class DeletePresenterTransferViewModel
    {
        [Required]
        public int? AgentId { get; set; }

        [Required]
        public int? PresenterId { get; set; }
    }
}
