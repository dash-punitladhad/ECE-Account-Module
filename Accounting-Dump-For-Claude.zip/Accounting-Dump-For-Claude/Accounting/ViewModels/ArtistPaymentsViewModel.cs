﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.Linq;
    using System.Web.Mvc;

    public class ArtistPaymentsViewModel
    {
        public ArtistPaymentsViewModel()
        {
            YearSelectList = new SelectList(Enumerable.Range(DateTime.Now.AddYears(-5).Year, 6).OrderByDescending(x => x));
        }

        public int ArtistId { get; set; }

        public string ArtistName { get; set; }

        public int Year { get; set; }

        public SelectList YearSelectList { get; set; }
    }
}
