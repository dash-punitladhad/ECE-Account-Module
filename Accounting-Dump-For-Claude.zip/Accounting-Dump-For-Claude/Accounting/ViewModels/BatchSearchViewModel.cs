﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Web.Mvc;

    public class BatchSearchViewModel
    {
        public BatchSearchViewModel()
        {
            this.BatchTypes = new SelectList(new List<SelectListItem>());

            this.BatchTypes = new SelectList(new List<SelectListItem>());
        }

        public SelectList BatchTypes
        {
            get
            {
                return new SelectList(
                    new List<SelectListItem>
                {
                    new SelectListItem { Text = "All", Value = ((int)SearchHelper.All).ToString() },
                    new SelectListItem { Text = "Artist", Value = ((int)ExpenseBatchType.Artist).ToString() },
                    new SelectListItem { Text = "ECE", Value = ((int)ExpenseBatchType.ECE).ToString() },
                    new SelectListItem { Text = "Other", Value = ((int)ExpenseBatchType.OtherExpenses).ToString() }
                }, "Value",
                    "Text");
            }

            set
            {
            }
        }

        public SelectList BatchStatus
        {
            get
            {
                return new SelectList(
                    new List<SelectListItem>
                {
                    new SelectListItem { Text = "All", Value = ((int)SearchHelper.All).ToString() },
                    new SelectListItem { Text = "Posted", Value = ((int)ExpenseBatchStatus.Posted).ToString() },
                    new SelectListItem { Text = "Not Posted", Value = ((int)ExpenseBatchStatus.NotPosted).ToString() }
                }, "Value",
                    "Text");
            }

            set
            {
            }
        }
    }
}