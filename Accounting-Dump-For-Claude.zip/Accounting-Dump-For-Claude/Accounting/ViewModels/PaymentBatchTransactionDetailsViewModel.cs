﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using ECE.CRM.WebUI.ViewModels;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Mvc;

    public class PaymentBatchTransactionDetailsViewModel : BaseMailingAddressViewModel
    {
        public PaymentBatchTransactionDetailsViewModel()
        {
            this.Transactions = new List<PaymentBatchContractTransactionViewModel>();
        }

        public int ExpenseBatchId { get; set; }

        public int ExpensePaymentId { get; set; }

        public int ExpensePaymentTypeId { get; set; }

        public int ContractEntityTypeId { get; set; }

        public int ContractEntityId { get; set; }

        public string ExpensePaymentTypeName
        {
            get
            {
                if (this.PaymentAmount == decimal.Zero)
                {
                    return "n/a";
                }

                var paymentType = LookupCache
                    .GetAllExpensePaymentTypes()
                    .FirstOrDefault(x => x.Value == this.ExpensePaymentTypeId.ToString());
                if (paymentType != null)
                {
                    return paymentType.Text;
                }

                return string.Empty;
            }
        }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal GrossAmount { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal DeductionAmount { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal PaymentAmount { get; set; }

        public string PayeeName { get; set; }

        public string MailingCityStateZip { get; set; }

        public string ReferenceNumber { get; set; }

        [DisplayName("AREF Payments")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ArefPaymentsAmount { get; set; }

        [DisplayName("Programs")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ProgramsAmount { get; set; }

        [DisplayName("Repayments")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal RepaymentAmount { get; set; }

        [DisplayName("Transaction Count")]
        public int TransactionCount
        {
            get { return this.Transactions?.Count ?? 0; }
        }

        [DisplayName("Transactions")]
        public List<PaymentBatchContractTransactionViewModel> Transactions { get; set; }

        public int PayBy { get; set; }

        public bool CanUseDirectDeposit { get; set; }

        public SelectList PayByTypes { get; set; }

        public string PayByText { get; set; }

        public string BatchDescription { get; set; }

        public DateTime? DatePosted { get; set; }

        public DateTime? DateVoided { get; set; }

        public bool CanAddOneTimeCharge
        {
            get { return this.ContractEntityTypeId == (int)ContractEntityType.Artist; }
        }

        public bool IsVoided
        {
            get { return this.DateVoided.HasValue; }
        }

        public bool IsPresenterRefund
        {
            get
            {
                return this.ContractEntityTypeId == (int)ContractEntityType.Presenter &&
                    this.Transactions.All(x => x.ContractTransactionType == ContractTransactionType.Refund);
            }
        }

        public bool CanEdit
        {
            get { return this.DatePosted == null && !this.IsVoided; }
        }

        public bool HasNoTransactions
        {
            get
            {
                return (this.Transactions?.Count ?? 0) == 0;
            }
        }

        public bool InsufficientEscrow
        {
            get
            {
                if (this.Transactions == null)
                {
                    return false;
                }

                return this.Transactions.Any(x => x.InsufficientEscrow);
            }
        }

        public void SetBatchDescription(PaymentBatchDetailsViewModel model)
        {
            this.BatchDescription = string.Empty;

            if (model == null)
            {
                return;
            }

            var batchType = model.BatchType;

            var postedDateFormatted = model.IsPosted
                ? $"POSTED {model.DatePosted.Value.ToStandardWithDayString()}"
                : "NOT POSTED";

            this.BatchDescription = $"{batchType} Batch # {model.ExpenseBatchId} - {postedDateFormatted}";
        }

        public void LoadPayByTypes(ExpensePaymentDto payment)
        {
            this.PayBy = payment.ExpensePaymentTypeId;

            var paymentTypes = LookupCache
                .GetAllExpensePaymentTypes()
                .ToDictionary(x => Convert.ToInt32(x.Value));

            var payByTypes = new List<LookupDto>();
            payByTypes.Add(new LookupDto((int)ExpensePaymentType.Check, paymentTypes[(int)ExpensePaymentType.Check].Text));
            payByTypes.Add(new LookupDto((int)ExpensePaymentType.WireTransfer, paymentTypes[(int)ExpensePaymentType.WireTransfer].Text));

            if (this.CanUseDirectDeposit)
            {
                payByTypes.Add(new LookupDto((int)ExpensePaymentType.DirectDeposit, paymentTypes[(int)ExpensePaymentType.DirectDeposit].Text));
            }

            this.PayByTypes = payByTypes.ToSelectList("Text", "Value");
        }

        public void LoadPayeeAddress(CheckPrintDto check)
        {
            this.MailingAddress1 = check.EntityMailingAddress1;
            this.MailingAddress2 = check.EntityMailingAddress2;
            this.MailingCity = check.EntityMailingCity;
            this.MailingStateId = check.EntityMailingStateId;
            this.MailingCountryId = check.EntityMailingCountryId;
            this.MailingZip = check.EntityMailingZip;
            this.MailingCityStateZip = check.EntityCityStateZip;

            this.LoadMailingAddressForDetails();
        }
    }
}