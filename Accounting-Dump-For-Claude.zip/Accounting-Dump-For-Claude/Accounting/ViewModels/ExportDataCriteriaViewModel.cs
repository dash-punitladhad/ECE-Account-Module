﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class ExportDataCriteriaViewModel
    {
        [Display(Name = "FROM")]
        [Required]
        public DateTime? FromDate { get; set; }

        [Display(Name = "TO")]
        [Required]
        public DateTime? ToDate { get; set; }

        [Display(Name = "AS OF")]
        [RequiredIf(nameof(SelectedDataSet), "/accounting/unpaid-commissions")]
        public DateTime? AsOfDate { get; set; }

        public string SelectedDataSet { get; set; }

        public ExportDataCriteriaDto CreateDto()
        {
            if (this.FromDate == null || this.ToDate == null)
            {
                return null;
            }

            return new ExportDataCriteriaDto
            {
                FromDate = this.FromDate.Value,
                ToDate = this.ToDate.Value,
            };
        }
    }
}
