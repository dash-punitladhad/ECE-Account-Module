﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;

    public class GLJournalSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-GLJournalSearch";
            }
        }

        [FromJson]
        public GLJournalSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<GLJournalSearchResultDto> results, string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();
            List<GLJournalDetailsSearchExcelDto> listOfObjects = new List<GLJournalDetailsSearchExcelDto>();
            foreach (var detail in sortedResults)
            {
                GLJournalDetailsSearchExcelDto objectClass = new GLJournalDetailsSearchExcelDto();
                objectClass.ID = detail.GeneralLedgerJournalId;
                objectClass.Account = detail.GeneralLedgerAccountId;
                objectClass.ContractNumber = detail.ContractId;
                objectClass.Event = detail.GeneralLedgerTransactionType;
                objectClass.TransactionNumber = detail.JournalTransactionNumber;
                objectClass.PostedDate = detail.PostedDate;
                objectClass.Amount = detail.PostedAmount;
                objectClass.CreditOrDebit = detail.ChangeType;
                objectClass.Agent = detail.AgentName;
                objectClass.Office = detail.OfficeName;
                objectClass.ReferenceNumber = detail.ReferenceNumber;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }
        }
    }
}
