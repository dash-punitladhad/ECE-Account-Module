﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    [Serializable]
    public class GLJournalDetailsSearchCriteriaViewModel
    {
        [Required]
        public int GeneralLedgerAccountId { get; set; }

        public DateTime? PostDateFrom { get; set; }

        public DateTime? PostDateTo { get; set; }

        [Required]
        [DisplayName("Activity Type")]
        public string ActivityType { get; set; }

        [DisplayName("Contract #")]
        public int ContractId { get; set; }
    }
}