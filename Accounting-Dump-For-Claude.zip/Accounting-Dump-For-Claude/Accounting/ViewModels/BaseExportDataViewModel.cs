﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;

    public class BaseExportDataViewModel : ExportDataCriteriaViewModel
    {
        public BaseExportDataViewModel()
        {
        }

        public BaseExportDataViewModel(DateTime fromDate, DateTime toDate)
        {
            this.FromDate = fromDate;
            this.ToDate = toDate;
        }

        public BaseExportDataViewModel(ExportDataCriteriaDto dto)
        {
            if (dto != null)
            {
                this.FromDate = dto.FromDate;
                this.ToDate = dto.ToDate;
            }
        }

        public virtual string FileName
        {
            get
            {
                var fileName = $"{this.WorksheetName} ({this.FromDate:MMddyyyy}-{this.ToDate:MMddyyyy})";

                fileName = FileHelper.GetSafeFileName(fileName.Replace(" ", "-") + ".xlsx");

                return fileName;
            }
        }

        public virtual string WorksheetName { get; protected set; }

        public virtual string WorksheetTitle
        {
            get
            {
                return $"{this.WorksheetName} from {this.FromDate:MM/dd/yyyy} to {this.ToDate:MM/dd/yyyy}";
            }
        }
    }
}
