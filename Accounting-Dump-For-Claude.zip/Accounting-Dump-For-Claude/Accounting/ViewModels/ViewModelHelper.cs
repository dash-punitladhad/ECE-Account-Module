﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class ViewModelHelper
    {
        public static ContractTransactionDto Find(this IList<ContractTransactionDto> transactions, ContractDepositViewModel deposit)
        {
            if (deposit == null)
            {
                return null;
            }

            return transactions.Find(deposit.ContractEntityId, deposit.ContractEntityTypeId);
        }

        public static ContractTransactionDto Find(this IList<ContractTransactionDto> transactions, ContractSignatureViewModel signature)
        {
            if (signature == null)
            {
                return null;
            }

            return transactions.Find(signature.EntityId, signature.EntityTypeId);
        }

        public static ContractTransactionDto Find(this IList<ContractTransactionDto> transactions, int entityId, int entityTypeId)
        {
            if (transactions == null)
            {
                return null;
            }

            return transactions
                .FirstOrDefault(y =>
                    y.ContractEntityId == entityId &&
                    y.ContractEntityTypeId == entityTypeId);
        }

        public static string GetPayeeDisplayName(this ContractTransactionDto dto)
        {
            if (dto == null)
            {
                return null;
            }

            var payeeName = dto.PayeeName;
            if (string.IsNullOrWhiteSpace(payeeName))
            {
                if (dto.ContractEntityTypeId == (int)ContractEntityType.Artist)
                {
                    payeeName = "ARTIST";
                }
                else if (dto.ContractEntityTypeId == (int)ContractEntityType.Presenter)
                {
                    payeeName = "PRESENTER";
                }

                return payeeName;
            }
            else
            {
                var entityName = LookupCache.GetAllContractEntityTypes()
                    .FirstOrDefault(y => y.Value == dto.ContractEntityTypeId.ToString())?.Text;

                return payeeName.Equals(entityName, StringComparison.OrdinalIgnoreCase)
                    ? payeeName
                    : $"{entityName} - {payeeName}";
            }
        }
    }
}
