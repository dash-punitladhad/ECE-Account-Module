﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    public class CafeteriaPlanDetailsViewModel : CafeteriaPlansViewModel
    {
        public int AgentUserId { get; set; }

        public string AgentName { get; set; }

        [DisplayName("Current Deduction")]
        [Required(ErrorMessage = "Current Deduction is required.")]
        [Range(0, 999.99, ErrorMessage = "Current Deduction must be between $0.00 and $999.99.")]
        public decimal? CurrentDeduction { get; set; }
    }
}