﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public class AgentPaymentDetailViewModel
    {
        public AgentPaymentDetailViewModel(AgentPayrollLogDto dto)
        {
            ContractId = dto.ContractId;
            PaymentType = dto.LuPayrollLogType.Name;
            GrossAmount = dto.GrossAmount;
            Amount = dto.NetAmount;
            EventDate = dto.LastEventDate;
            DepositCollected = dto.ReceivedDate;
        }

        public AgentPaymentDetailViewModel(AgentPayrollLogViewDto dto)
        {
            ContractId = dto.ContractId;
            PaymentType = dto.PayrollLogType;
            GrossAmount = dto.GrossAmount;
            Amount = dto.NetAmount;
            EventDate = dto.LastEventDate;
            DepositCollected = dto.ReceivedDate;
        }

        public AgentPaymentDetailViewModel(ContractTransactionDto dto)
        {
            ContractId = dto.ContractId;
            PaymentType = dto.ContractTransactionTypeName;
            Amount = dto.RequiredAmount;

            EventDate = dto.DueDate;
            DepositCollected = dto.PaidDate;
        }

        public int ContractId { get; set; }

        public string PaymentType { get; set; }

        public decimal? GrossAmount { get; set; }

        public decimal? Amount { get; set; }

        public DateTime? EventDate { get; set; }

        public DateTime? DepositCollected { get; set; }
    }
}