﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.Web.Mvc;

    public class PaymentSearchViewModel
    {
        public SelectList PayeeTypes { get; set; }

        public int? EntityId { get; set; }

        public int? EntityTypeId { get; set; }
    }
}