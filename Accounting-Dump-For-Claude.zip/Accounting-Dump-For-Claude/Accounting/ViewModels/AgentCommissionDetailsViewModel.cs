﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Security.Principal;

    public class AgentCommissionDetailsViewModel
    {
        public AgentCommissionDetailsViewModel()
        {
            this.CommissionTiers = new List<AgentCommissionTypeDataDto>();
        }

        public int? AgentCommissionId { get; set; }

        public int AgentId { get; set; }

        public string Agent { get; set; }

        public int? OfficeId { get; set; }

        public string Office { get; set; }

        public int? OfficeCount { get; set; }

        public int? AgentCommissionTypeId { get; set; }

        public string CommissionType { get; set; }

        public int StatusId { get; set; }

        public string Status { get; set; }

        public int? MentorId { get; set; }

        public string MentoredBy { get; set; }

        public decimal? MentorshipPercentage { get; set; }

        [UIHint("ECEDate")]
        public DateTime? MentorshipStartDate { get; set; }

        [UIHint("ECEDate")]
        public DateTime? MentorshipEndDate { get; set; }

        public IList<AgentCommissionTypeDataDto> CommissionTiers { get; set; }

        public bool AgentIsOwner { get; set; }

        public bool CanModify { get; set; }

        public bool CanAddCommissionTier { get; set; }

        public bool CanModifyCommissionTier { get; set; }

        public bool CanAddMentor { get; set; }

        public bool CanModifyMentor { get; set; }

        public bool CanAddTier
        {
            get
            {
                return this.AgentCommissionTypeId.HasValue
                    && this.AgentCommissionTypeId.Value != (int)AgentCommissionType.TieredInstancePlan;
            }
        }

        public void SetPermissions(IPrincipal user)
        {
            if (user == null)
            {
                return;
            }

            this.CanModify = user.HasPermission(ECEPermissions.ACCOUNTING_UPDATE);

            this.CanAddCommissionTier = this.CanModify && this.CanAddTier;
            this.CanModifyCommissionTier = this.CanModify && this.CanAddTier;
            this.CanAddMentor = this.CanModify && !this.AgentIsOwner && this.MentorId == null;
            this.CanModifyMentor = this.CanModify && !this.AgentIsOwner && this.MentorId > 0;
        }
    }
}
