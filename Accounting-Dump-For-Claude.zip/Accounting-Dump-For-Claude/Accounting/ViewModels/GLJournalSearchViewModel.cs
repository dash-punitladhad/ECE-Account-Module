﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.Web.Mvc;

    public class GLJournalSearchViewModel
    {
        public SelectList GeneralLedgerEvents { get; set; }

        public SelectList GeneralLedgerAccounts { get; set; }
    }
}
