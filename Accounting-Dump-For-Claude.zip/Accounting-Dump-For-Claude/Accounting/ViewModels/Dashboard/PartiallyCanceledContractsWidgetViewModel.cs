﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels.Dashboard
{
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System.Security.Principal;

    public class PartiallyCanceledContractsWidgetViewModel : BaseActionWidgetViewModel
    {
        public PartiallyCanceledContractsWidgetViewModel()
            : base()
        {
        }

        public PartiallyCanceledContractsWidgetViewModel(IPrincipal user)
            : base(user)
        {
        }

        public override bool ShowActionColumn { get; set; }

        public override int ColumnCount
        {
            get
            {
                return ShowActionColumn
                    ? 4
                    : 3;
            }
        }
    }
}
