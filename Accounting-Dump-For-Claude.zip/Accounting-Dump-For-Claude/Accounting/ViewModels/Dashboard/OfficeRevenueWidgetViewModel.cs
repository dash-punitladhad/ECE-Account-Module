﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels.Dashboard
{
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Web.Mvc;

    public class OfficeRevenueWidgetViewModel : BaseWidgetViewModel
    {
        public OfficeRevenueWidgetViewModel()
        {
            YearSelectList = new YearSelectList();
            MonthSelectList = new SelectList(Months, "Value", "Text");

            Year = DateTime.Today.Year;
            Month = DateTime.Today.Month;
        }

        public int? Month { get; set; }

        public SelectList MonthSelectList { get; set; }

        public int Year { get; set; }

        public SelectList YearSelectList { get; set; }

        public IEnumerable<SelectListItem> Months
        {
            get
            {
                return DateTimeFormatInfo
                       .InvariantInfo
                       .MonthNames
                       .Where(m => !string.IsNullOrEmpty(m))
                       .Select((monthName, index) => new SelectListItem
                       {
                           Value = (index + 1).ToString(),
                           Text = monthName
                       });
            }
        }
    }
}
