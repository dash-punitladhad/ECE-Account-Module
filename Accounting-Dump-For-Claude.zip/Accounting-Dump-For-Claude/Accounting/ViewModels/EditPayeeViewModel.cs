﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels;
    using System.ComponentModel.DataAnnotations;

    public class EditPayeeViewModel : BaseMailingAddressViewModel
    {
        public int ExpensePaymentId { get; set; }

        [Required]
        [Display(Name = "Payee Name")]
        [MaxLength(255, ErrorMessage = TextHelper.StandardMaxLengthErrorMessage)]
        public string PayeeName { get; set; }

        public void LoadForEdit(ExpensePaymentDto expensePayment, CheckPrintDto check)
        {
            this.ExpensePaymentId = expensePayment.ExpensePaymentId;
            this.PayeeName = expensePayment.PayeeName;

            this.MailingAddress1 = check.EntityMailingAddress1;
            this.MailingAddress2 = check.EntityMailingAddress2;
            this.MailingCity = check.EntityMailingCity;
            this.MailingStateId = check.EntityMailingStateId;
            this.MailingCountryId = check.EntityMailingCountryId;
            this.MailingZip = check.EntityMailingZip;

            this.LoadMailingAddressForEdit();
        }
    }
}
