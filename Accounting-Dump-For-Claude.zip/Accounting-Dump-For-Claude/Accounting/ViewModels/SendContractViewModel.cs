﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class SendContractViewModel
    {
        public int ContractSignatureId { get; set; }

        public int EntityId { get; set; }

        public int EntityTypeId { get; set; }

        [Required]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Contact First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Contact Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Signature Due Date")]
        public DateTime DateDue { get; set; }
    }
}