﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;

    public class ContractAgentPayrollLogsModalViewModel
    {
        public int ContractId { get; set; }

        public int? PayrollBatchId { get; set; }

        public IList<AgentPayrollLogDto> Logs { get; set; }
    }
}
