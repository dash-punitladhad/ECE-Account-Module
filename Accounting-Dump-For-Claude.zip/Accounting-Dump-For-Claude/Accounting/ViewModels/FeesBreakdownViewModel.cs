﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;

    public class FeesBreakdownViewModel : BaseExportDataViewModel
    {
        public static int[] Accounts = new[]
        {
            (int)GeneralLedgerAccounts.CostRecoveryFees,
            (int)GeneralLedgerAccounts.GasAccount,
            (int)GeneralLedgerAccounts.ContractFee,
            (int)GeneralLedgerAccounts.ContractFeeNonExclusive,
            (int)GeneralLedgerAccounts.AgentWorking,
            (int)GeneralLedgerAccounts.ARFee,
        };

        public FeesBreakdownViewModel()
            : base()
        {
        }

        public FeesBreakdownViewModel(DateTime fromDate, DateTime toDate)
            : base(fromDate, toDate)
        {
        }

        public override string WorksheetName
        {
            get
            {
                return $"Fees Breakdown";
            }
        }

        public byte[] GetContents(IList<FeesBreakdownDto> data,IPrincipal User)
        {
            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();

            var view = from d in data
                       join ol in offices on d.OfficeId equals ol.OfficeId into jo
                       from o in jo.DefaultIfEmpty()
                       select new FeesBreakdownLineViewModel
                       {
                           OfficeId = d.OfficeId,
                           OfficeName = o?.Name ?? "Unassigned",
                           PostedAmount = d.PostedAmount,
                           AccountName = d.AccountName,
                           GeneralLedgerAccountId = d.GeneralLedgerAccountId,
                           ChangeType = d.ChangeType
                       };

            var accountGroups =
                from d in view
                orderby d.GeneralLedgerAccountId, d.OfficeName
                group d by new { d.GeneralLedgerAccountId, d.AccountName };

            var lines = new List<FeesBreakdownLineViewModel>();

            foreach (var accountGroup in accountGroups)
            {
                var officeGroups =
                    from ag in accountGroup
                    orderby ag.ChangeType
                    group ag by new { ag.OfficeId, ag.OfficeName };

                foreach (var officeGroup in officeGroups)
                {
                    var officeGroupArray = officeGroup.ToArray();
                    if (officeGroupArray.Length == 2)
                    {
                        var line = new FeesBreakdownLineViewModel
                        {
                            GeneralLedgerAccountId = accountGroup.Key.GeneralLedgerAccountId,
                            AccountName = accountGroup.Key.AccountName,
                            OfficeId = officeGroupArray[0].OfficeId,
                            OfficeName = officeGroupArray[0].OfficeName,
                            CreditAmount = officeGroupArray[0].ChangeType == "C" ? officeGroupArray[0].PostedAmount : decimal.Zero,
                            DebitAmount = officeGroupArray[1].ChangeType == "D" ? officeGroupArray[1].PostedAmount : decimal.Zero,
                        };

                        lines.Add(line);
                    }
                    else
                    {
                        var line = new FeesBreakdownLineViewModel
                        {
                            GeneralLedgerAccountId = accountGroup.Key.GeneralLedgerAccountId,
                            AccountName = accountGroup.Key.AccountName,
                            OfficeId = officeGroupArray[0].OfficeId,
                            OfficeName = officeGroupArray[0].OfficeName,
                            CreditAmount = officeGroupArray[0].ChangeType == "C" ? officeGroupArray[0].PostedAmount : decimal.Zero,
                            DebitAmount = officeGroupArray[0].ChangeType == "D" ? officeGroupArray[0].PostedAmount : decimal.Zero,
                        };

                        lines.Add(line);
                    }
                }
            }

            using (var ms = new MemoryStream())
            {
                using (var p = new OfficeOpenXml.ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(this.WorksheetName))
                    {
                        const int FirstRow = 3;
                        const int FirstCol = 1;

                        ws.Cells[1, 1].Value = this.WorksheetTitle;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 5].Merge = true;

                        var row = FirstRow;
                        var col = FirstCol;

                        ws.Cells[row, col + 2].Value = "Debits";
                        ws.Cells[row, col + 3].Value = "Credits";
                        ws.Cells[row, col + 4].Value = "Net";

                        ws.Cells[row, col + 2, row, col + 4].Style.Font.Bold = true;
                        ws.Cells[row, col + 2, row, col + 4].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                        row += 1;

                        foreach (var account in Accounts)
                        {
                            var accountLines = lines
                                .Where(x => x.GeneralLedgerAccountId == account)
                                .ToArray();

                            if (accountLines.Length > 0)
                            {
                                ws.Cells[row, col].Value = account;
                                ws.Cells[row, col].Style.Font.Bold = true;
                                ws.Cells[row, col + 1].Value = accountLines[0].AccountName;
                                ws.Cells[row, col + 1].Style.Font.Bold = true;

                                var startingRow = row;

                                for (int i = 0; i < accountLines.Length; i++)
                                {
                                    row += 1;

                                    ws.Cells[row, col + 1].Value = accountLines[i].OfficeName;
                                    ws.Cells[row, col + 2].Value = accountLines[i].DebitAmount;
                                    ws.Cells[row, col + 3].Value = accountLines[i].CreditAmount;
                                    ws.Cells[row, col + 4].Value = accountLines[i].NetAmount;
                                }

                                SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row, col + 2);
                                SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row, col + 3);
                                SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row, col + 4);
                            }

                            row += 3;
                        }

                        ws.Calculate();

                        // Format all cells in the worksheet
                        ws.Cells[FirstRow, FirstCol + 2, row, FirstCol + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }
    }
}
