﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class VoidCheckViewModel
    {
        public int ExpensePaymentId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Reason exceeds max length of 100 characters.")]
        public string VoidedReason { get; set; }

        public int[] SelectedExpenses { get; set; }
    }
}
