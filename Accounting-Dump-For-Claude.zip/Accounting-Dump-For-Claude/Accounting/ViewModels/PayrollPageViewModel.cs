﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Mvc;

    public class PayrollPageViewModel
    {
        public PayrollPageViewModel()
        {
            YearSelectList = new SelectList(Enumerable.Range(DateTime.Now.AddYears(-5).Year, 6).OrderByDescending(x => x));
        }

        public int PayrollBatchId { get; set; }

        public DateTime NextPayrollDate { get; set; }

        public DateTime NextPayrollStartDate { get; set; }

        public DateTime NextPayrollEndDate { get; set; }

        public string NextPayrollDateFormatted
        {
            get
            {
                return DataHelper.ToStandardWithDayString(this.NextPayrollDate);
            }
        }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal EstimatedCommissions { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal EstimatedAgentWorking { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal EstimatedPrograms { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal EstimatedCafeteriaPlans { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalEstimatedPayments { get; set; }

        public int Year { get; set; }

        public SelectList YearSelectList { get; set; }

        [Display(Name = "As Of Date")]
        [DisplayFormat(DataFormatString = "${0:MM/dd/yyyy}")]
        public DateTime AsOfDate { get; set; }
    }
}