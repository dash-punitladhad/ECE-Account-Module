﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class UpdatePaymentNotesViewModel
    {
        public int ExpensePaymentId { get; set; }

        [StringLength(2000)]
        public string Notes { get; set; }
    }
}
