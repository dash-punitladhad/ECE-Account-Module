﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class ArtistChargeSearchResultViewModel
    {
        public int ArtistChargeId { get; set; }

        public string DetailsUrl { get; set; }

        public int ArtistId { get; set; }

        public string ArtistName { get; set; }

        public string TypeDisplay { get; set; }

        public string StatusDisplay { get; set; }

        public decimal? OriginalAmount { get; set; }

        public decimal? Balance { get; set; }

        public decimal? PaymentAmount { get; set; }

        public DateTime? LastPaymentDate { get; set; }

        public string InterestCalculated { get; set; }

        public decimal InterestRate { get; set; }

        public decimal? PaymentsReceived { get; set; }
    }
}
