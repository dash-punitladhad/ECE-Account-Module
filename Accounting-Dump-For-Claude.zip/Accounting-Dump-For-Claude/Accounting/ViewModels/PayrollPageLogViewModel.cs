﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;

    [Serializable]
    public class PayrollPageLogViewModel
    {
        public int PayrollBatchId { get; set; }

        public string PayrollBatchDate { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public string ECECollections { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal Commissions { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal AgentWorking { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal Programs { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal CafeteriaPlans { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal Total { get; set; }
    }
}