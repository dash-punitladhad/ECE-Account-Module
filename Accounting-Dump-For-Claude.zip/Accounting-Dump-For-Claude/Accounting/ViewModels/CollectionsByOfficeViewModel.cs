﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;

    public class CollectionsByOfficeViewModel : BaseExportDataViewModel
    {
        private static int[] groupKeys = new[] { (int)LineOfBusiness.National, (int)LineOfBusiness.Touring, (int)LineOfBusiness.Core, (int)LineOfBusiness.Comedy };

        public CollectionsByOfficeViewModel()
            : base()
        {
        }

        public CollectionsByOfficeViewModel(DateTime fromDate, DateTime toDate)
            : base(fromDate, toDate)
        {
        }

        public override string WorksheetName
        {
            get
            {
                return $"Collections By Office";
            }
        }

        public static IEnumerable<IGrouping<string, CollectionsByOfficeLineViewModel>> GroupDataByOffice(IEnumerable<CollectionsByOfficeDto> data,IPrincipal User)
        {
            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();

            var view = from d in data
                       join ol in offices on d.OfficeId equals ol.OfficeId into jo
                       from o in jo.DefaultIfEmpty()
                       select new CollectionsByOfficeLineViewModel
                       {
                           AgentId = d.AgentId,
                           OfficeId = d.OfficeId,
                           OfficeName = o?.Name ?? "Unassigned",
                           PostedAmount = d.PostedAmount,
                           LineOfBusinessId = d.LineOfBusinessId,
                       };

            var officeGroups = from d in view.OrderBy(x => x.OfficeName)
                               group d by d.OfficeName;

            return officeGroups;
        }

        public static IEnumerable<IGrouping<int, CollectionsByOfficeLineViewModel>> GroupDataByLineOfBusiness(IEnumerable<CollectionsByOfficeLineViewModel> data,IPrincipal User)
        {
            var agents = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList(); //LookupCache.GetAllAgents();

            var agentsInGroup = from d in data.Select(x => x.AgentId).Distinct()
                                join a in agents on d equals a.AppUserId
                                select new
                                {
                                    AgentId = d,
                                    AgentName = a.FullName
                                };

            var lobGroups = from d in data
                            group d by d.LineOfBusinessId;

            var orderedAgentList = agentsInGroup.Distinct().OrderBy(x => x.AgentName);

            foreach (var groupKey in groupKeys)
            {
                var isNullGroupData = data
                    .Where(x => x.LineOfBusinessId == groupKey);
                var groupData = new Dictionary<int?, CollectionsByOfficeLineViewModel>();
                if (isNullGroupData != null)
                {
                    IEnumerable<CollectionsByOfficeLineViewModel> groupListdata = isNullGroupData.ToList().GroupBy(l => l.AgentId)
                         .Select(cl => new CollectionsByOfficeLineViewModel
                         {
                             AgentId = cl.FirstOrDefault().AgentId,
                             ChangeType = cl.FirstOrDefault().ChangeType,
                             AgentName = cl.FirstOrDefault().AgentName,
                             LineOfBusinessId = cl.FirstOrDefault().LineOfBusinessId,
                             OfficeId = cl.FirstOrDefault().OfficeId,
                             OfficeName = cl.FirstOrDefault().OfficeName,
                             PostedAmount = cl.Sum(c => c.PostedAmount),
                         }).ToList();
                    groupData =
                       groupListdata
                       .Where(x => x.LineOfBusinessId == groupKey)
                       .ToDictionary(x => x.AgentId);
                }
                var tableData = new List<CollectionsByOfficeLineViewModel>();
                foreach (var item in orderedAgentList)
                {
                    var newLine = new CollectionsByOfficeLineViewModel();

                    newLine.AgentId = item.AgentId;
                    newLine.AgentName = item.AgentName;

                    if (groupData.ContainsKey(item.AgentId))
                    {
                        var groupItem = groupData[item.AgentId];

                        newLine.PostedAmount = groupItem.PostedAmount;
                    }

                    tableData.Add(newLine);
                }

                yield return tableData.GroupBy(x => groupKey).Single();
            }
        }

        ////public static void AddSumCellToRow(ExcelWorksheet ws, int row, int startCol, int endCol)
        ////{
        ////    var firstCellAddress = ws.Cells[row, startCol].Address;
        ////    var lastCellAddress = ws.Cells[row, endCol].Address;

        ////    ws.Cells[row, endCol + 1].Style.Font.Bold = true;
        ////    ws.Cells[row, endCol + 1].Formula = $"SUM({firstCellAddress}:{lastCellAddress})";
        ////}

        ////public static void AddSumCellToColumn(ExcelWorksheet ws, int startingRow, int endRow, int col)
        ////{
        ////    var firstCellAddress = ws.Cells[startingRow, col + 1].Address;
        ////    var lastCellAddress = ws.Cells[endRow, col + 1].Address;

        ////    ws.Cells[endRow + 1, col + 1].Style.Font.Bold = true;
        ////    ws.Cells[endRow + 1, col + 1].Formula = $"SUM({firstCellAddress}:{lastCellAddress})";
        ////}

        public static void AddTotalRowToWorkSheet(ExcelWorksheet ws, int row, int startingCol, IEnumerable<IGrouping<string, CollectionsByOfficeLineViewModel>> officeGroups)
        {
            var col = startingCol;

            // Add total row
            ws.Cells[row, 1].Value = "Total";
            ws.Cells[row, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
            ws.Cells[row, 1].Style.Font.Bold = true;

            foreach (var lobGroup in groupKeys)
            {
                ws.Cells[row, col + 1].Value = officeGroups.Sum(x => x.Where(z => z.LineOfBusinessId == lobGroup).Sum(y => y.PostedAmount));
                ws.Cells[row, col + 1].Style.Font.Bold = true;

                col += 1;
            }

            SpreadsheetExporter.AddSumCellToRow(ws, row, startingCol + 1, col);
        }

        public static byte[] ExportData(string worksheetName, string title, IEnumerable<IGrouping<string, CollectionsByOfficeLineViewModel>> officeGroups,IPrincipal user)
        {
            using (var ms = new MemoryStream())
            {
                using (var p = new OfficeOpenXml.ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(worksheetName))
                    {
                        const int FirstRow = 2;
                        const int FirstCol = 3;

                        ws.Cells[1, 1].Value = title;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 6].Merge = true;

                        var row = FirstRow;
                        var col = FirstCol;

                        for (int i = 0; i < groupKeys.Length; i++)
                        {
                            // Set the Line Of Business Group Label
                            ws.Cells[row, col].Value = ((LineOfBusiness)groupKeys[i]).ToString();
                            ws.Cells[row, col].Style.Font.Bold = true;
                            ws.Cells[row, col].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                            col += 1;
                        }

                        ws.Cells[row, col].Value = "Total";
                        ws.Cells[row, col].Style.Font.Bold = true;
                        ws.Cells[row, col].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                        row = 3;

                        foreach (var officeGroup in officeGroups)
                        {
                            var lobGroups = GroupDataByLineOfBusiness(officeGroup,user);

                            // Set the Office Group Label
                            ws.Cells[row, 1].Value = officeGroup.Key;
                            ws.Cells[row, 1].Style.Font.Bold = true;

                            col = 2;

                            var lineCount = 0;
                            var firstGroup = true;

                            var startingRow = row;

                            foreach (var lobGroup in lobGroups)
                            {
                                row = startingRow;

                                var lines = lobGroup.ToList();

                                lineCount = lines.Count;

                                for (int i = 0; i < lineCount; i++)
                                {
                                    if (firstGroup)
                                    {
                                        ws.Cells[row + 1, col].Value = lines[i].AgentName;
                                    }

                                    ws.Cells[row + 1, col + 1].Value = lines[i].PostedAmount;

                                    row += 1;
                                }

                                col += 1;

                                SpreadsheetExporter.AddSumCellToColumn(ws, startingRow + 1, row, col);

                                firstGroup = false;
                            }

                            for (int i = 1; i <= lineCount + 1; i++)
                            {
                                SpreadsheetExporter.AddSumCellToRow(ws, startingRow + i, 3, col);
                            }

                            col = 2;
                            row += 3;
                        }

                        // Add total row
                        ws.Cells[row, 1].Value = "Total";
                        ws.Cells[row, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                        ws.Cells[row, 1].Style.Font.Bold = true;

                        AddTotalRowToWorkSheet(ws, row, col, officeGroups);

                        ws.Calculate();

                        // Format all cells in the worksheet
                        var lastCol = FirstCol + groupKeys.Count() + 1;
                        ws.Cells[FirstRow, FirstCol, row, lastCol].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }

        public byte[] GetContents(IEnumerable<CollectionsByOfficeDto> data,IPrincipal user)
        {
            var officeGroups = CollectionsByOfficeViewModel.GroupDataByOffice(data,user);

            var contents = CollectionsByOfficeViewModel.ExportData(this.WorksheetName, this.WorksheetTitle, officeGroups,user);

            return contents;
        }
    }
}
