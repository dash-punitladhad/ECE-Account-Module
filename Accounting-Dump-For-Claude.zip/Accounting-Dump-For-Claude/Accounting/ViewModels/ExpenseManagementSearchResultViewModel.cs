﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    public class ExpenseManagementSearchResultViewModel
    {
        public int ContractTransactionId { get; set; }

        public bool IsSelected { get; set; }

        public int? ContractId { get; set; }

        public int? ContractEntityTypeId { get; set; }

        public string PayeeName { get; set; }

        public decimal? Amount { get; set; }

        public string ExpenseType { get; set; }

        public int StatusId { get; set; }

        public string Status { get; set; }

        public int? ExpenseBatchId { get; set; }

        public DateTime? ExpenseBatchDate { get; set; }

        public DateTime? PaidDate { get; set; }

        public bool? IsW9OnFile { get; set; }
    }
}