﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Mvc;

    public class ContractCancellationViewModel
    {
        public int ContractCancellationId { get; set; }

        [Required]
        public int ContractId { get; set; }

        public string CancellationReasonText
        {
            get
            {
                var cancellationReasons = LookupCache.GetAllCancelledReasons();
                var item = cancellationReasons.FirstOrDefault(s => s.Value == $"{this.CancellationReasonId}");
                if (item != null)
                {
                    return item.Text;
                }

                return string.Empty;
            }
        }

        [Required(ErrorMessage = "Cancellation Reason is required.")]
        public int CancellationReasonId { get; set; }

        [MaxLength(500, ErrorMessage = "Notes exceeds max length of 500 characters.")]
        public string CancellationReasonNotes { get; set; }

        public bool ZeroUnpaidItems { get; set; }

        public bool NotifyArtist { get; set; }

        public int? NotifyArtistEmailQueueId { get; set; }

        public bool ApplyCancellationFee { get; set; }

        public int? CancellationFeeTransactionId { get; set; }

        public bool CreateReplacement { get; set; }

        public int? ReplacementContractId { get; set; }

        public bool GenerateRefunds { get; set; }

        public bool IsFinished { get; set; }

        public bool HasReceivedDeposits { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public SelectList CancellationReasons { get; set; }

        public void LoadForCreate()
        {
            var cancellationReasons = LookupCache.GetAllCancelledReasons().OrderBy(x => x.Text);
            this.CancellationReasons = cancellationReasons.ToSelectList("Text", "Value");
        }
    }
}
