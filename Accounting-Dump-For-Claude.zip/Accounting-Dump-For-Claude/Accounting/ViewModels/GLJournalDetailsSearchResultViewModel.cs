﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;

    [Serializable]
    public class GLJournalDetailsSearchResultViewModel
    {
        public int JournalId { get; set; }

        public DateTime? PostDate { get; set; }

        public string Description { get; set; }

        public decimal? Debit { get; set; }

        public decimal? Credit { get; set; }

        public int ContractId { get; set; }
    }
}