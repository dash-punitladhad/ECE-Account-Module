﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class PreviewPayrollDetailsViewModel : PayrollDetailsViewModel
    {
        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalGrossCommissionAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalNetCommissionAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalAgentWorkingAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalPayrollAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalSharedBonusAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalNonExclusiveArtistFeeAmount { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal TotalCafeteriaPlanAmount { get; set; }

        public IList<PayrollPaymentDto> PayrollPayments { get; set; }
    }
}
