﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    public class ContractInitializeViewModel : ContractWorkSheetViewModel
    {
    }
}
