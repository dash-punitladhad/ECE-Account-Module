﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using CsvHelper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Shared;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Linq.Dynamic;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web;

    public class ArtistChargeSearchExportViewModel
    {
        public string FileName
        {
            get
            {
                return $"{DataHelper.ToStandardString(DateTime.Now)}-ArtistChargeSearch";
            }
        }

        [FromJson]
        public ArtistChargeSearchCriteriaDto Criteria { get; set; }

        [FromJson]
        public SearchRequestViewModel Request { get; set; }

        public byte[] GetExportFileContents(IList<ArtistChargeSearchResultDto> results, string fileName)
        {
            var sortedResults = results
                .AsQueryable()
                .OrderBy(Request.Ordering)
                .ToList();


            List<ArtistChargeExcelDto> artistChargeExcels = new List<ArtistChargeExcelDto>();

            foreach (var detail in sortedResults)
            {
                ArtistChargeExcelDto artistChargeExcel = new ArtistChargeExcelDto();
                artistChargeExcel.Artist = detail.ArtistName;
                artistChargeExcel.Type = detail.TypeDisplay;
                artistChargeExcel.Status = detail.StatusDisplay;
                artistChargeExcel.OriginalDate = detail.OriginalDate;
                artistChargeExcel.OriginalAmount = detail.OriginalAmount;
                artistChargeExcel.Balance = detail.Balance;
                artistChargeExcel.LastPayment = detail.LastPaymentDate;
                artistChargeExcel.InterestCalculated = detail.InterestCalculated;
                artistChargeExcel.InterestRate = detail.InterestRate;
                artistChargeExcel.PaymentsReceived = detail.PaymentsReceived;
                artistChargeExcel.ARTISTCHARGEID = detail.ArtistChargeId;
                artistChargeExcels.Add(artistChargeExcel);
            }
            if (artistChargeExcels.Any())
            {
                var dt = artistChargeExcels.ToDataTable();
                dt.TableName = fileName;
                string baseUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                try
                {
                    if (dt.Columns.IndexOf("ARTISTCHARGEID") != -1)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            string url = $"{baseUrl}/accounting/artistcharge/" + Convert.ToString(dr["ARTISTCHARGEID"]);
                            dr[0] = "<a href='" + url + "'>" + Convert.ToString(dr[0]) + "</a>";
                        }
                        dt.Columns.Remove("ARTISTCHARGEID");
                    }

                }
                catch { }
                var xlsBase64 = CRInfrastructure.DT_XLS(dt, fileName).ConfigureAwait(false).GetAwaiter().GetResult();
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return fileBytes;
            }
            else
            {
                return null;
            }

        }
    }
}
