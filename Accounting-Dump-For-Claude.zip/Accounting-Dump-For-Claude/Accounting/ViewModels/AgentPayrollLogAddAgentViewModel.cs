﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class AgentPayrollLogAddAgentViewModel
    {
        [Required]
        [Display(Name = "Agent")]
        public int? AgentId { get; set; }

        [Required]
        public int PayrollBatchId { get; set; }

        public SelectList Agents { get; set; }

        public void LoadForSearch()
        {
            var agents = LookupCache.GetAllAgents();
            this.Agents = agents.ToSelectList("FullName", "AppUserId");
        }
    }
}
