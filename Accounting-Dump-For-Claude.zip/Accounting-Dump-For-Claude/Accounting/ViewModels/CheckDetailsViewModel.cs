﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Security.Principal;

    public class CheckDetailsViewModel : BaseMailingAddressViewModel
    {
        public int ExpensePaymentId { get; set; }

        public string CheckNumber { get; set; }

        public int ExpenseBatchId { get; set; }

        public DateTime DateIssued { get; set; }

        [DisplayFormat(DataFormatString = "${0:#,0.00}")]
        public decimal Amount { get; set; }

        public string PayeeName { get; set; }

        public string MailingCityStateZip { get; set; }

        public bool IsVoided { get; set; }

        public DateTime? DateVoided { get; set; }

        public DateTime? DateCleared { get; set; }

        public int ExpensePaymentTypeId { get; set; }

        public bool IsReconciled { get; set; }

        public string Reconciled
        {
            get
            {
                return TextHelper.YesNoToString(this.IsReconciled);
            }
        }

        public string ReconcileButton
        {
            get
            {
                return this.IsReconciled ? "Un-Reconcile" : "Reconcile";
            }
        }

        public bool CanReconcile { get; set; }

        public bool CanVoid { get; set; }

        public List<PaymentBatchContractTransactionViewModel> ExpensesPaid { get; set; }

        public List<PaymentBatchContractTransactionViewModel> ExpensesToRecreate
        {
            get
            {
                if (this.ExpensesPaid == null)
                {
                    return null;
                }

                return this.ExpensesPaid
                    .Where(x => x.ContractTransactionType != ContractTransactionType.CrossDeductionDeposit)
                    .Where(x => x.ContractTransactionType != ContractTransactionType.LoanRepayment)
                    .ToList();
            }
        }

        [StringLength(2000, ErrorMessage = "Notes exceeds max length of 2000 characters.")]
        [DisplayFormat(NullDisplayText = "No notes on file for this payment.")]
        public string Notes { get; set; }

        [Required]
        [Display(Name = "Reason")]
        [StringLength(100, ErrorMessage = "Reason exceeds max length of 100 characters.")]
        public string VoidedReason { get; set; }

        public string VoidedReasonFromNote
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(this.Notes))
                {
                    var lines = this.Notes.Split(Environment.NewLine.ToCharArray());
                    foreach (var line in lines)
                    {
                        if (!string.IsNullOrWhiteSpace(line) &&
                            line.StartsWith("Voided Reason: "))
                        {
                            return line;
                        }
                    }
                }

                return string.Empty;
            }
        }

        public void LoadPayeeAddress(CheckPrintDto check)
        {
            this.MailingAddress1 = check.EntityMailingAddress1;
            this.MailingAddress2 = check.EntityMailingAddress2;
            this.MailingCity = check.EntityMailingCity;
            this.MailingStateId = check.EntityMailingStateId;
            this.MailingCountryId = check.EntityMailingCountryId;
            this.MailingZip = check.EntityMailingZip;
            this.MailingCityStateZip = check.EntityCityStateZip;

            this.LoadMailingAddressForDetails();
        }

        public void SetPermissions(IPrincipal user)
        {
            this.CanReconcile = user.HasPermission(ECEPermissions.ACCOUNTING_UPDATE) &&
                this.ExpensePaymentTypeId == (int)ExpensePaymentType.Check;

            this.CanVoid = !this.IsVoided;
        }
    }
}