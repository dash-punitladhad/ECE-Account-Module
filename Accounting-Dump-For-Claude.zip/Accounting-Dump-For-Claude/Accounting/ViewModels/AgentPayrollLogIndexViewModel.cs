﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class AgentPayrollLogIndexViewModel
    {
        [UIHint("ECEDate")]
        public DateTime NextPayrollDate { get; set; }

        [UIHint("ECEDate")]
        public DateTime NextPayrollStartDate { get; set; }

        [UIHint("ECEDate")]
        public DateTime NextPayrollEndDate { get; set; }

        [Required]
        public int? AgentId { get; set; }

        [Required]
        public DateTime? StartDate { get; set; }

        [Required]
        public DateTime? EndDate { get; set; }

        public SelectList AgentSelectList { get; set; }

        [Display(Name = "As Of Date")]
        [DisplayFormat(DataFormatString = "${0:MM/dd/yyyy}")]
        public DateTime AsOfDate { get; set; }
    }
}
