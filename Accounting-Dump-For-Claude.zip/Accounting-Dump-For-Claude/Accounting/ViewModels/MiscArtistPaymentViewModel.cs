﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class MiscArtistPaymentViewModel : BaseExportDataViewModel
    {
        public override string WorksheetName
        {
            get
            {
                return $"MISC Artist Payments";
            }
        }

        public void RenderPaymentsWorksheet(OfficeOpenXml.ExcelWorksheet ws, IList<MiscArtistPaymentLineViewModel> payments)
        {
            var artists = payments.GroupBy(x => x.ArtistName).OrderBy(x => x.Key);

            var row = 1;

            foreach (var artist in artists)
            {
                // Set the Artist Group Label
                ws.Cells[row, 1].Value = artist.Key;
                ws.Cells[row, 1].Style.Font.Bold = true;
                row += 1;

                var artistPayments = artist.ToList();
                var artistLoans = artistPayments.Sum(x => x.TransactionAmount);

                var paymentTypes = artist.GroupBy(x => x.TypeDisplay);
                foreach (var paymentType in paymentTypes)
                {
                    var repayments = paymentType.ToList();

                    // Set the Artist Group Label
                    ws.Cells[row, 2].Value = paymentType.Key;
                    ws.Cells[row, 2].Style.Font.Bold = true;

                    // Load all the transactions for the artist
                    SpreadsheetExporter.LoadList(ws, repayments, false, false, row + 1, 3);

                    row += repayments.Count + 1;

                    var paymentTypeLoans = repayments.Sum(x => x.TransactionAmount);

                    // Load the payment type sub-total label
                    ws.Cells[row, 3].Value = "Sub-Total";
                    ws.Cells[row, 3].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    ws.Cells[row, 3].Style.Font.Bold = true;
                    ws.Cells[row, 4].Value = paymentTypeLoans;
                    ws.Cells[row, 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                    ws.Cells[row, 4].Style.Font.Bold = true;

                    row += 1;
                }

                // Load the artist total label
                ws.Cells[row, 3].Value = "Artist Total";
                ws.Cells[row, 3].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                ws.Cells[row, 3].Style.Font.Bold = true;
                ws.Cells[row, 4].Value = artistLoans;
                ws.Cells[row, 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                ws.Cells[row, 4].Style.Font.Bold = true;
                row += 2;
            }

            // Load the export total label
            ws.Cells[row, 3].Value = "Total";
            ws.Cells[row, 3].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
            ws.Cells[row, 3].Style.Font.Bold = true;
            ws.Cells[row, 4].Value = payments.Sum(x => x.TransactionAmount);
            ws.Cells[row, 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
            ws.Cells[row, 4].Style.Font.Bold = true;

            ws.Cells[1, 5, row, 7].Clear();

            ws.Calculate();
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
        }

        public void RenderInterestWorksheet(OfficeOpenXml.ExcelWorksheet ws, IList<MiscArtistPaymentInterestLineViewModel> interestCharges)
        {
            foreach (var interestCharge in interestCharges)
            {
                interestCharge.TransactionAmount = -interestCharge.TransactionAmount;
            }

            SpreadsheetExporter.LoadList(ws, interestCharges, true, true, 1, 1);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, interestCharges.Count + 1, 5);
            ws.Cells[interestCharges.Count + 2, 5].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

            ws.Calculate();
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
        }

        public void RenderAdjustmentsWorksheet(OfficeOpenXml.ExcelWorksheet ws, IList<MiscArtistPaymentAdjustmentLineViewModel> adjustments)
        {
            foreach (var adjustment in adjustments)
            {
                adjustment.TransactionAmount = -adjustment.TransactionAmount;
            }

            SpreadsheetExporter.LoadList(ws, adjustments, true, true, 1, 1);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, adjustments.Count + 1, 3);
            ws.Cells[adjustments.Count + 2, 3].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

            ws.Calculate();
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
        }

        public void RenderLoanBalancesWorksheet(OfficeOpenXml.ExcelWorksheet ws, IList<OutstandingEscrowLoanDto> outstandingLoans)
        {
            SpreadsheetExporter.LoadList(ws, outstandingLoans, true, true, 1, 1);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 7);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 8);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 9);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 10);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 11);
            SpreadsheetExporter.AddSumCellToColumn(ws, 2, outstandingLoans.Count + 1, 12);
            ws.Cells[outstandingLoans.Count + 2, 7, outstandingLoans.Count + 2, 12].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

            ws.Calculate();
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
        }

        public byte[] GetContents(
            IList<MiscArtistPaymentLineViewModel> payments,
            IList<MiscArtistPaymentAdjustmentLineViewModel> adjustments,
            IList<MiscArtistPaymentInterestLineViewModel> interestCharges,
            IList<OutstandingEscrowLoanDto> outstandingLoans)
        {
            using (var ms = new MemoryStream())
            {
                using (var p = new OfficeOpenXml.ExcelPackage())
                {
                    var ws = p.Workbook.Worksheets.Add(this.WorksheetName);
                    RenderPaymentsWorksheet(ws, payments);

                    ws = p.Workbook.Worksheets.Add("Interest");
                    RenderInterestWorksheet(ws, interestCharges);

                    ws = p.Workbook.Worksheets.Add("Adjustments");
                    RenderAdjustmentsWorksheet(ws, adjustments);

                    ws = p.Workbook.Worksheets.Add("Loan Balances");
                    RenderLoanBalancesWorksheet(ws, outstandingLoans);

                    p.SaveAs(ms);
                }

                return ms.ToArray();
            }
        }
    }
}
