﻿namespace ECE.CRM.WebUI.ViewModels.Contract
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System.ComponentModel.DataAnnotations;
    using System.Security.Principal;
    using System.Web.Mvc;
    using System.Linq;
    public class ContractReassignOfficeLOBViewModel
    {
        [Required]
        public int ContractId { get; set; }

        [Required]
        [Display(Name = "Office")]
        public int? OfficeId { get; set; }

        public SelectList OfficeValues { get; set; }

        [Required]
        [Display(Name = "Line of Business")]
        public int? LineOfBusinessId { get; set; }

        public SelectList LineOfBusinessValues { get; set; }

        [Display(Name = "Reverse/Reapply GL Journal Entries")]
        public bool ReverseGeneralLedger { get; set; }

        public bool ShowReverseGeneralLedger { get; set; }

        public bool FromMoneyScreen { get; set; }

        public void LoadForModal(IPrincipal User)
        {
            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();
            this.OfficeValues = offices.ToSelectList("Name", "OfficeId");

            var linesOfBusiness = LookupCache.GetLinesOfBusiness();
            this.LineOfBusinessValues = linesOfBusiness.ToSelectList("Name", "LineOfBusinessId");
        }
    }
}
