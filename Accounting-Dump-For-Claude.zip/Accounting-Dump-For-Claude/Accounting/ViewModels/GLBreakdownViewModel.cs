﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class GLBreakdownViewModel : BaseExportDataViewModel
    {
        public GLBreakdownViewModel()
            : base()
        {
        }

        public GLBreakdownViewModel(DateTime fromDate, DateTime toDate)
            : base(fromDate, toDate)
        {
        }

        public override string WorksheetName
        {
            get
            {
                return $"G/L Breakdown";
            }
        }

        public List<FeesBreakdownLineViewModel> GetValues(IList<FeesBreakdownDto> data)
        {
            var view = from d in data
                       select new FeesBreakdownLineViewModel
                       {
                           PostedAmount = d.PostedAmount,
                           AccountName = d.AccountName,
                           GeneralLedgerAccountId = d.GeneralLedgerAccountId,
                           ChangeType = d.ChangeType
                       };

            var accountGroups =
                from d in view
                orderby d.GeneralLedgerAccountId, d.AccountName
                group d by new { d.GeneralLedgerAccountId, d.AccountName };

            var accounts = accountGroups.Select(x => x.Key.GeneralLedgerAccountId);

            var lines = new List<FeesBreakdownLineViewModel>();

            foreach (var accountGroup in accountGroups)
            {
                var accountGroupArray = accountGroup.ToArray();
                if (accountGroupArray.Length == 2)
                {
                    var line = new FeesBreakdownLineViewModel
                    {
                        GeneralLedgerAccountId = accountGroup.Key.GeneralLedgerAccountId,
                        AccountName = accountGroup.Key.AccountName,
                        CreditAmount = accountGroupArray[0].ChangeType == "C" ? accountGroupArray[0].PostedAmount : decimal.Zero,
                        DebitAmount = accountGroupArray[1].ChangeType == "D" ? accountGroupArray[1].PostedAmount : decimal.Zero,
                    };

                    lines.Add(line);
                }
                else
                {
                    var line = new FeesBreakdownLineViewModel
                    {
                        GeneralLedgerAccountId = accountGroup.Key.GeneralLedgerAccountId,
                        AccountName = accountGroup.Key.AccountName,
                        CreditAmount = accountGroupArray[0].ChangeType == "C" ? accountGroupArray[0].PostedAmount : decimal.Zero,
                        DebitAmount = accountGroupArray[0].ChangeType == "D" ? accountGroupArray[0].PostedAmount : decimal.Zero,
                    };

                    lines.Add(line);
                }
            }

            return lines;
        }

        public byte[] GetContents(IList<FeesBreakdownDto> data)
        {
            var view = from d in data
                       select new FeesBreakdownLineViewModel
                       {
                           PostedAmount = d.PostedAmount,
                           AccountName = d.AccountName,
                           GeneralLedgerAccountId = d.GeneralLedgerAccountId,
                           ChangeType = d.ChangeType
                       };

            var accountGroups =
                from d in view
                orderby d.GeneralLedgerAccountId, d.AccountName
                group d by new { d.GeneralLedgerAccountId, d.AccountName };

            var accounts = accountGroups.Select(x => x.Key.GeneralLedgerAccountId);

            var lines = GetValues(data);

            using (var ms = new MemoryStream())
            {
                using (var p = new OfficeOpenXml.ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(this.WorksheetName))
                    {
                        const int FirstRow = 3;
                        const int FirstCol = 1;

                        ws.Cells[1, 1].Value = this.WorksheetTitle;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 5].Merge = true;

                        var row = FirstRow;
                        var col = FirstCol;

                        ws.Cells[row, col + 2].Value = "Debits";
                        ws.Cells[row, col + 3].Value = "Credits";
                        ws.Cells[row, col + 4].Value = "Net";

                        ws.Cells[row, col + 2, row, col + 4].Style.Font.Bold = true;
                        ws.Cells[row, col + 2, row, col + 4].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;

                        row += 1;

                        var startingRow = row;

                        foreach (var account in accounts)
                        {
                            var accountLines = lines
                                .Where(x => x.GeneralLedgerAccountId == account)
                                .ToArray();

                            for (int i = 0; i < accountLines.Length; i++)
                            {
                                ws.Cells[row, col].Value = account;
                                ws.Cells[row, col].Style.Font.Bold = true;
                                ws.Cells[row, col + 1].Value = accountLines[0].AccountName;
                                ws.Cells[row, col + 1].Style.Font.Bold = true;
                                ws.Cells[row, col + 2].Value = accountLines[i].DebitAmount;
                                ws.Cells[row, col + 3].Value = accountLines[i].CreditAmount;
                                ws.Cells[row, col + 4].Formula = $"{ws.Cells[row, col + 3]}-{ws.Cells[row, col + 2]}";
                                ws.Cells[row, col + 4].Style.Font.Bold = true;

                                row += 1;
                            }
                        }

                        SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row - 1, col + 2);
                        SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row - 1, col + 3);
                        SpreadsheetExporter.AddSumCellToColumn(ws, startingRow, row - 1, col + 4);

                        ws.Calculate();

                        // Format all cells in the worksheet
                        ws.Cells[FirstRow, FirstCol + 2, row, FirstCol + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }
    }
}
