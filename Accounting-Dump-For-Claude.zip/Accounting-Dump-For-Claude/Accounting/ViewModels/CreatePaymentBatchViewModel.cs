﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;

    public class CreatePaymentBatchViewModel
    {
        public ExpenseBatchType BatchType { get; set; }

        public bool SharedBonusOption { get; set; }

        public bool GasCardOption { get; set; }

        public bool PayNationalsOption { get; set; }
    }
}
