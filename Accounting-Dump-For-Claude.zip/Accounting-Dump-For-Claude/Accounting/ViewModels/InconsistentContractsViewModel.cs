﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using OfficeOpenXml;
    using System.Collections.Generic;
    using System.IO;

    public class InconsistentContractsViewModel : BaseExportDataViewModel
    {
        public override string WorksheetName
        {
            get
            {
                return $"Inconsistent GL Contracts";
            }
        }

        public byte[] GetContents(IList<InconsistentGLDto> data)
        {
            using (var ms = new MemoryStream())
            {
                using (var p = new ExcelPackage())
                {
                    using (var ws = p.Workbook.Worksheets.Add(this.WorksheetName))
                    {
                        ws.Cells[1, 1].Value = this.WorksheetTitle;
                        ws.Cells[1, 1].Style.Numberformat.Format = SpreadsheetExporter.DateFormat;
                        ws.Cells[1, 1].Style.Font.Bold = true;
                        ws.Cells[1, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        ws.Cells[1, 1, 1, 5].Merge = true;

                        var row = 3;
                        var col = 1;

                        var columns = new[] { "Inconsistency Type", "Contract #", "Line Amount", "Posted Amount", "Difference", "Direction" };

                        for (int j = 0; j < columns.Length; j++)
                        {
                            ws.Cells[row, col + j].Value = columns[j];
                            ws.Cells[row, col + j].Style.Font.Bold = true;
                            ws.Cells[row, col + j].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        }

                        row += 1;

                        for (int i = 0; i < data.Count; i++)
                        {
                            ws.Cells[row, col + 0].Value = data[i].InconsistencyType;
                            ws.Cells[row, col + 1].Value = data[i].ContractId;
                            ws.Cells[row, col + 2].Value = data[i].LineItemAmount;
                            ws.Cells[row, col + 2].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                            ws.Cells[row, col + 3].Value = data[i].PostedAmount;
                            ws.Cells[row, col + 3].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                            ws.Cells[row, col + 4].Value = data[i].DifferenceAmount;
                            ws.Cells[row, col + 4].Style.Numberformat.Format = SpreadsheetExporter.AccountingFormat;
                            ws.Cells[row, col + 5].Value = data[i].Direction;

                            row += 1;
                        }

                        ws.Calculate();

                        ws.Cells[ws.Dimension.Address].AutoFitColumns();

                        p.SaveAs(ms);
                    }
                }

                return ms.ToArray();
            }
        }
    }
}
