﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.Collections.Generic;

    public class CancellationInfoViewModel
    {
        public int ContractId { get; set; }

        public IList<ContractCancellationViewModel> Cancellations { get; set; }

        public void LoadForInfo(IList<ContractCancellationViewModel> cancellations)
        {
            Cancellations = cancellations;
        }
    }
}
