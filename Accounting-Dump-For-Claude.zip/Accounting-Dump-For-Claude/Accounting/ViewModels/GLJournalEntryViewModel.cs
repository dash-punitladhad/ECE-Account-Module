﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Security.Principal;
    using System.Web.Mvc;

    public class GLJournalEntryViewModel
    {
        [Required]
        [Display(Name = "Account")]
        public int? GeneralLedgerAccountId { get; set; }

        [Required]
        [Display(Name = "Event")]
        public int? GeneralLedgerEventId { get; set; }

        [Required]
        [Display(Name = "Change Type")]
        public string ChangeType { get; set; }

        [Required]
        [Display(Name = "Amount")]
        [Range(0.01, 10000000)]
        public decimal? PostedAmount { get; set; }

        [Required]
        [Display(Name = "Posted Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? PostedDate { get; set; }

        [RequiredIf(nameof(ForContract), "True")]
        [Display(Name = "Contract #")]
        public int? ContractId { get; set; }

        [Display(Name = "Reference #")]
        [StringLength(50)]
        public string ReferenceNumber { get; set; }

        [RequiredIf(nameof(ForContract), "True")]
        [Display(Name = "Agent")]
        public int? AgentId { get; set; }

        [Display(Name = "Agent")]
        public string AgentName { get; set; }

        public IList<SelectListItem> AgentValues { get; set; }

        [RequiredIf(nameof(ForContract), "True")]
        [Display(Name = "Office")]
        public int? OfficeId { get; set; }

        public SelectList OfficeValues { get; set; }

        [RequiredIf(nameof(ForContract), "True")]
        [Display(Name = "Line of Business")]
        public int? LineOfBusinessId { get; set; }

        public SelectList LineOfBusinessValues { get; set; }

        [Required]
        [Display(Name = "Change Direction")]
        public string ChangeDirection { get; set; }

        public SelectList GeneralLedgerEvents { get; set; }

        public SelectList GeneralLedgerAccounts { get; set; }

        public int? GeneralLedgerTransactionTypeId { get; set; }

        public string GeneralLedgerTransactionType { get; set; }

        [RequiredIf(nameof(ForContract), "True")]
        [Display(Name = "Income/Expense")]
        public int? ContractTransactionId { get; set; }

        public SelectList ContractTransactions { get; set; }

        public int ContractEntityTypeId { get; set; }

        public int ContractEntityId { get; set; }

        public bool ForContract { get; set; }

        public void LoadForModal(IPrincipal User)
        {
            this.PostedDate = TimeProvider.Current.Today;

            var events = LookupCache.GetAllGeneralLedgerEvents().Where(x => Convert.ToInt32(x.Value) >= 100);
            this.GeneralLedgerEvents = events.ToSelectList("Text", "Value");

            var accounts = LookupCache.GetActiveGeneralLedgerAccounts();
            this.GeneralLedgerAccounts = accounts.ToSelectList("Text", "Value");

            var agents = new List<AppUserDto>(LookupCache.GetAllActiveAgents());
            this.AgentValues = new AgentSelectList(agents, 0);

            var offices = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin)) ? LookupCache.GetOffices() : LookupCache.GetRestrictedOffices().ToList(); //LookupCache.GetAllOffices();
            this.OfficeValues = offices.ToSelectList("Name", "OfficeId");

            var linesOfBusiness = LookupCache.GetLinesOfBusiness();
            this.LineOfBusinessValues = linesOfBusiness.ToSelectList("Name", "LineOfBusinessId");

            var emptyList = new List<LookupDto>();
            this.ContractTransactions = new SelectList(emptyList, "Value", "Text");
        }
    }
}
