﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class DailyCloseoutBreakdownReportRangeViewModel
    {
        public DailyCloseoutBreakdownReportRangeViewModel()
        {
        }

        [RequiredIf(nameof(DatesRequired), true)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? FromDate { get; set; }

        [RequiredIf(nameof(DatesRequired), true)]
        [DateGreaterThan(nameof(FromDate), true, ErrorMessage = "The To Date must be greater than the From Date.")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? ToDate { get; set; }

        public bool DatesRequired
        {
            get
            {
                return FromDate.HasValue || ToDate.HasValue;
            }
        }
    }
}
