﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class ArtistChargeCreateViewModel
    {
        public int ArtistChargeId { get; set; }

        [DisplayName("Artist")]
        [Required(ErrorMessage = "Artist is required.")]
        public int? ArtistId { get; set; }

        [DisplayName("Artist Name")]
        public string ArtistName { get; set; }

        [DisplayName("Type")]
        [Required(ErrorMessage = "Type is required.")]
        public int? ArtistChargeTypeId { get; set; }

        [DisplayName("Type")]
        public string ArtistChargeTypeLabel { get; set; }

        [DisplayName("Payments Received")]
        public decimal? TotalPaymentsReceived { get; set; }

        [DisplayName("Original Date")]
        public DateTime? OriginalDate { get; set; }

        [DisplayName("Amount")]
        [Required]
        [MoneyRange(13, 2, 0)]
        public decimal? OriginalAmount { get; set; }

        [DisplayName("Interest Calculated")]
        [Required(ErrorMessage = "Interest Calculated is required.")]
        public int? InterestCalculatedFrequencyId { get; set; }

        [DisplayName("Interest Rate")]
        [Required(ErrorMessage = "Interest Rate is required.")]
        [Range(0, 99.99, ErrorMessage = "Invalid interest rate.")]
        public decimal? InterestRate { get; set; }

        [DisplayName("Suspend Interest")]
        public bool SuspendInterest { get; set; }

        [DisplayName("Payment Per Week With AREF")]
        [Required(ErrorMessage = "Payment Per Week Amount With AREF is required.")]
        [MoneyRange(13, 2, 0)]
        public decimal? PaymentAmount { get; set; }

        [DisplayName("Notes")]
        [MaxLength(2000, ErrorMessage = TextHelper.StandardMaxLengthErrorMessage)]
        public string Notes { get; set; }

        public SelectList TypeSelectList { get; set; }

        public SelectList InterestCalcFreqSelectList { get; set; }

        public void LoadForCreate()
        {
            TypeSelectList = LookupCache.GetArtistChargeTypes().ToSelectList("Text", "Value");
            InterestCalcFreqSelectList = LookupCache.GetInterestCalculatedFrequencies().ToSelectList("Text", "Value");
        }

        public void LoadForEdit()
        {
            this.LoadForCreate();
        }
    }
}