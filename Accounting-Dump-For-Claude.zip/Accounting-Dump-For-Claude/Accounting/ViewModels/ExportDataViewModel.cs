﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System;
    using System.Web.Mvc;

    public class ExportDataViewModel : ExportDataCriteriaViewModel
    {
        public ExportDataViewModel()
        {
        }

        public ExportDataViewModel(DateTime? fromDate, DateTime? toDate)
        {
            this.FromDate = fromDate;
            this.ToDate = toDate;

            if (fromDate == null && toDate == null)
            {
                var firstDayOfMonth = DateTime.Today.AddMonths(-1).AddDays(-(DateTime.Today.Day - 1));
                var lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);

                this.FromDate = firstDayOfMonth;
                this.ToDate = lastDayOfMonth;
                this.AsOfDate = lastDayOfMonth;
            }
        }

        public SelectList DataSets { get; set; }
    }
}
