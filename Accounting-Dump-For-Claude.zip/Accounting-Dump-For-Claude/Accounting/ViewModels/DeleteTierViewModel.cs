﻿namespace ECE.CRM.WebUI.Areas.Accounting.ViewModels
{
    using System.ComponentModel.DataAnnotations;

    public class DeleteTierViewModel
    {
        [Required]
        public int? AgentId { get; set; }

        [Required]
        public int? AgentCommissionTypeDataId { get; set; }
    }
}
