﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class ExportDataController : BaseAccountingController
    {
        private readonly IAccountingDataService _accountingDataService;

        public ExportDataController(
            ILogger logger,
            IAccountingDataService accountingDataService)
            : base(logger)
        {
            this.Logger.Information("ExportData Controller Created.");

            this._accountingDataService = accountingDataService;
        }

        [HttpGet]
        [Route("export-data")]
        public ActionResult Index(DateTime? fromDate, DateTime? toDate)
        {
            var viewModel = new ExportDataViewModel(fromDate, toDate);

            return View(viewModel);
        }

        [HttpGet]
        [Route("basic-agent-sales-stats")]
        public async Task<ActionResult> BasicAgentSalesStats(BasicAgentSalesStatsViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();

            var data = await _accountingDataService.GetBasicAgentSalesStatsAsync(criteria.FromDate, criteria.ToDate);

            var contents = viewModel.GetContents(data,User);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        [HttpGet]
        [Route("collections-by-office")]
        public async Task<ActionResult> CollectionsByOffice(CollectionsByOfficeViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();

            var data = await _accountingDataService.GetCollectionsByOfficeAsync(criteria.FromDate, criteria.ToDate,User);

            var contents = viewModel.GetContents(data,User);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        [HttpGet]
        [Route("fees-breakdown")]
        public async Task<ActionResult> FeesBreakdown(FeesBreakdownViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();
            var accounts = FeesBreakdownViewModel.Accounts;

            var data = await _accountingDataService.GetFeesBreakdownAsync(criteria, accounts.ToList());

            var contents = viewModel.GetContents(data,User);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        [HttpGet]
        [Route("unpaid-commissions")]
        public async Task<ActionResult> UnpaidCommissions(UnpaidCommissionsViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var data = await _accountingDataService.GetUnpaidCommissionsAsync(viewModel.AsOfDate.Value);

            var contents = viewModel.GetContents(data,User);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        public async Task<ActionResult> GLBreakdown(GLBreakdownViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();

            var data = await _accountingDataService.GetGLBreakdownAsync(criteria);

            var contents = viewModel.GetContents(data);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        [HttpGet]
        [Route("misc-artist-payments")]
        public async Task<ActionResult> MiscArtistPayments(MiscArtistPaymentViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();
            var data = await _accountingDataService.GetMiscArtistPaymentsAsync(criteria.FromDate, criteria.ToDate);

            var outstandingLoans = await _accountingDataService.GetEscrowLoanBalancesAsync(criteria.FromDate, criteria.ToDate);

            var payments = Mapper.Map<List<MiscArtistPaymentLineViewModel>>(data.Where(x => x.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Repayment));
            var adjustments = Mapper.Map<List<MiscArtistPaymentAdjustmentLineViewModel>>(data.Where(x => x.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Adjustment));
            var interestCharges = Mapper.Map<List<MiscArtistPaymentInterestLineViewModel>>(data.Where(x => x.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Interest));

            var contents = viewModel.GetContents(payments, adjustments, interestCharges, outstandingLoans);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }

        [HttpGet]
        [Route("inconsistent-gl-contracts")]
        public async Task<ActionResult> InconsistentGLContracts(InconsistentContractsViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var criteria = viewModel.CreateDto();
            var data = await _accountingDataService.GetInconsistentGLContractsAsync(criteria);

            var contents = viewModel.GetContents(data);
            var contentType = MimeMapping.GetMimeMapping(viewModel.FileName);

            return File(contents, contentType, viewModel.FileName);
        }
        [HttpGet]
        [Route("artist-on-direct-deposit")]
        public async Task<ActionResult> ArtistOnDirectDeposit()
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }
            string filename = string.Empty;
             string file = string.Empty;
            byte[] arr;
            DataTable dt = await DaoHelper.GetDataSetStoreProcedureParticular("Sp_Get_Artist_Direct_Diposit_Export", null);
            if (dt != null && dt.Rows.Count > 0)
            {
                dt.TableName = "Artist_Direct_Deposit";
                dt.AcceptChanges();
             
                //MemoryStream stream =await CRInfrastructure.DT_XLS(dt, "artist");
                file = await CRInfrastructure.DT_XLS(dt, "Artist_Direct_Deposit");
                arr = Convert.FromBase64String(file);
                filename = "Artist_Direct_Deposit_" + DateTime.Now.Ticks.ToString()+".xlsx";
                
            }
            else
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }
            if(arr==null || arr.Length<=0)
            {
                AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }
            return File(arr, "application/excel", filename);
        }
    }
}
