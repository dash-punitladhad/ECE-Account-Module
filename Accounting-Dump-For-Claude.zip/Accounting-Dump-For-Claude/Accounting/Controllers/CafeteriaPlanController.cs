﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using Infinity.Mobius.Logging;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class CafeteriaPlanController : BaseAccountingController
    {
        private readonly IPayrollService _payrollService;

        public CafeteriaPlanController(ILogger logger, IPayrollService payrollService)
            : base(logger)
        {
            this._payrollService = payrollService;
        }

        public ActionResult Index()
        {
            var viewModel = new CafeteriaPlansViewModel();
            return View(viewModel);
        }

        [HttpGet]
        [Route("cafeteriaplan/{agentId}")]
        public async Task<ActionResult> Details(int agentId)
        {
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound(EntityType.Agent, agentId);
            }

            var cafePlan = await this._payrollService.GetCafeteriaPlanByAgentAsync(agentId);

            var viewModel = new CafeteriaPlanDetailsViewModel()
            {
                AgentName = agent?.FullName,
                AgentUserId = agentId,
                CurrentDeduction = cafePlan?.CurrentDeductionAmount ?? 0
            };

            return View("~/Areas/Accounting/Views/CafeteriaPlan/Details.cshtml", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("cafeteriaplan/update")]
        public async Task<ActionResult> Update(CafeteriaPlanDetailsViewModel viewModel)
        {
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == viewModel.AgentUserId);
            if (agent == null)
            {
                ModelState.AddModelError(string.Empty, $"Agent {viewModel.AgentUserId} Not Found");
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Details", new { agentId = viewModel.AgentUserId });
            }

            var dto = new CafeteriaPlanDto()
            {
                AppUserId = viewModel.AgentUserId,
                CurrentDeductionAmount = viewModel.CurrentDeduction.Value
            };

            await this._payrollService.UpdateCafeteriaPlanAsync(dto, this.User);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Cafeteria Plan"));

            return RedirectToAction("Details", new { agentId = viewModel.AgentUserId });
        }
    }
}