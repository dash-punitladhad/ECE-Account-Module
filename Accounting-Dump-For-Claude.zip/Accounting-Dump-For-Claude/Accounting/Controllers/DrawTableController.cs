﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataTransferObjects;
using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
using ECE.CRM.WebUI.Controllers;
using ECE.CRM.WebUI.Infrastructure;
using ECE.CRM.WebUI.Infrastructure.Helpers;
using Infinity.Mobius.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    [Authorize]
    [RouteArea("accounting")]
    public class DrawTableController : BaseController
    {
        private readonly IDrawTableService _drawTableService;

        public bool CanViewAllAgents
        {
            get
            {
                return User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin) || User.IsInRole(ECERole.LMD);
            }
        }

        public DrawTableController(IDrawTableService drawTableService, ILogger logger) : base(logger)
        {
            _drawTableService = drawTableService;
        }
        // GET: Accounting/DrawTable
        public ActionResult Index()
        {
            var viewModel = new DrawTableViewModel()
            {
                Year = DateTime.Now.Year,
                AgentId = 0,
                QuarterId = 0
            };
            var agents = new List<AppUserDto>();
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();

            if (this.CanViewAllAgents)
            {
                agents.AddRange(agentList);
            }
            else if (User.IsInRole(ECERole.Agent))
            {
                var userAgent = agentList.FirstOrDefault(x => x.AppUserId == User.GetUserId());
                agents.Add(userAgent);
            }
            else
            {
                return this.AccessForbidden();
            }

            // If current user is not accounting, make default selected agent.
            if (!this.CanViewAllAgents)
            {
                viewModel.AgentId = User.GetUserId();
            }
            var assAgentsSelectList = new AgentSelectList(agents, User.GetUserId());
            viewModel.AgentSelectList = assAgentsSelectList;
            Task.Run(async () => {
                viewModel.QuartersList = await _drawTableService.GetAllQuarters();
            }).Wait();
            viewModel.YearSelectList = _drawTableService.GetYears();
            return View(viewModel);
        }

        [HttpGet]
        public ActionResult CreateDrawData(DrawTableDto drawTableDto)
        {
            var viewModel = new DrawTableViewModel()
            {
                Year = DateTime.Now.Year,
                AgentId = 0,
                QuarterId = 0
            };
            var agents = new List<AppUserDto>();
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            if (this.CanViewAllAgents)
            {
                agents.AddRange(agentList);
            }
            else if (User.IsInRole(ECERole.Agent))
            {
                var userAgent = agentList.FirstOrDefault(x => x.AppUserId == User.GetUserId());
                agents.Add(userAgent);
            }
            else
            {
                return this.AccessForbidden();
            }

            // If current user is not accounting, make default selected agent.
            if (!this.CanViewAllAgents)
            {
                viewModel.AgentId = User.GetUserId();
            }
            var assAgentsSelectList = new AgentSelectList(agents, User.GetUserId());
            viewModel.AgentSelectList = assAgentsSelectList;
            Task.Run(async () => {
                viewModel.QuartersList = await _drawTableService.GetAllQuarters();
            }).Wait();
            viewModel.YearSelectList = _drawTableService.GetYears();
            return View(viewModel);
        }
    }
}