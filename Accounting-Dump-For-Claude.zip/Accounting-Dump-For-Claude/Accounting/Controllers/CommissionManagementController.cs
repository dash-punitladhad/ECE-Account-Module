﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using Infinity.Mobius.Logging;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    [RoutePrefix("commission-management")]
    public class CommissionManagementController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly ICommissionManagementService _commissionManagementService;

        public CommissionManagementController(ILogger logger,
            IUserService userService,
            ICommissionManagementService commissionManagementService)
            : base(logger)
        {
            this._userService = userService;
            this._commissionManagementService = commissionManagementService;
        }

        [HttpGet]
        [Route("search")]
        public ActionResult Index()
        {
            var viewModel = new CommissionManagementSearchCriteriaViewModel();

            viewModel.LoadForIndex(User);

            return this.View(viewModel);
        }

        [HttpGet]
        [Route("details/{id}")]
        public async Task<ActionResult> Details(int id)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(id);
            if (agentCommission == null)
            {
                return this.EntityNotFound($"AgentCommission Not Found for Agent {id} Not Found");
            }

            // Initialize the view
            var viewModel = Mapper.Map<AgentCommissionDetailsViewModel>(agentCommission);

            var agent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = id }, true);

            if (agent.Roles.Any(x => x.RoleId == (int)ECERole.Owner))
            {
                viewModel.AgentIsOwner = true;
            }

            viewModel.SetPermissions(this.User);

            return this.View(viewModel);
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("change-commission-type-modal/{agentId}")]
        public async Task<ActionResult> ChangeCommissionTypeModal(int agentId)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(agentId);
            if (agentCommission == null)
            {
                return this.EntityNotFound($"AgentCommission Not Found for Agent {agentId} Not Found");
            }

            var viewModel = new ChangeCommissionTypeViewModel(agentId, agentCommission);

            return PartialView("_ChangeCommissionTypeModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("change-commission-type")]
        public async Task<ActionResult> ChangeCommssionType(ChangeCommissionTypeViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            await this._commissionManagementService.ChangeCommissionTypeAsync(
                data.AgentId,
                data.CommissionType.Value,
                this.User);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Commission type change"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("mentor-modal/{id?}")]
        public async Task<ActionResult> MentorModal(int id)
        {
            var viewModel = new CommissionManagementMentorModalViewModel();

            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(id);
            if (agentCommission == null)
            {
                return this.EntityNotFound($"AgentCommission Not Found for Agent {id} Not Found");
            }

            await viewModel.LoadAsync(id, agentCommission, this._userService);

            return PartialView("_MentorModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("update-mentor")]
        public async Task<ActionResult> UpdateMentor(CommissionManagementMentorModalViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            AgentCommissionDto dto = data.CreateDto();

            await this._commissionManagementService.UpdateMentorAsync(dto, this.User);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Mentor"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("add-commission-tier-modal/{agentId}")]
        public async Task<ActionResult> AddCommissionTierModal(int agentId)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(agentId, includeChildren: true);
            if (agentCommission == null || agentCommission.AgentCommissionId == null)
            {
                return this.EntityNotFound();
            }

            var viewModel = new CommissionManagementTierModalViewModel(agentCommission);

            viewModel.ControllerActionName = "AddCommissionTier";

            return PartialView("_CommissionTierModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("add-commission-tier")]
        public async Task<ActionResult> AddCommissionTier(CommissionManagementTierModalViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            var dto = new AgentCommissionTypeDataDto();

            dto.AgentCommissionId = data.AgentCommissionId;
            dto.LowerDate = data.LowerDate;
            dto.LowerNumeric = data.LowerNumeric;
            dto.UpperDate = data.UpperDate;
            dto.UpperNumeric = data.UpperNumeric;
            dto.Percentage = data.Percentage.Value;

            await this._commissionManagementService.AddTierAsync(data.AgentId, dto, this.User);

            this.AddSuccessAlert("Commission Tier Added Successfully");

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("edit-commission-tier-modal/{agentId}/{selectedId}")]
        public async Task<ActionResult> EditCommissionTierModal(int agentId, int selectedId)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(agentId, includeChildren: true);
            if (agentCommission == null || agentCommission.AgentCommissionId == null)
            {
                return this.EntityNotFound();
            }

            var viewModel = new CommissionManagementTierModalViewModel(agentCommission, selectedId);

            viewModel.ControllerActionName = "EditCommissionTier";

            return PartialView("_CommissionTierModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("edit-commission-tier")]
        public async Task<ActionResult> EditCommissionTier(CommissionManagementTierModalViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            AgentCommissionTypeDataDto dto = data.CreateDto();

            await this._commissionManagementService.UpdateTierAsync(data.AgentId, dto, this.User);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Commission tier"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("delete-commission-tier")]
        public async Task<ActionResult> DeleteCommissionTier(DeleteTierViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            await this._commissionManagementService.DeleteTierAsync(
                data.AgentId.Value,
                data.AgentCommissionTypeDataId.Value,
                this.User);

            this.AddSuccessAlert(GenerateDeleteSuccessMessage("Commission tier"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("add-presenter-transfer-modal/{agentId}")]
        public PartialViewResult AddPresenterTransferModal(int agentId)
        {
            var viewModel = new CommissionManagementPresenterModalViewModel();

            viewModel.AgentId = agentId;
            viewModel.ControllerActionName = "AddPresenterTransfer";

            return PartialView("_PresenterTransferModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("add-presenter-transfer")]
        public async Task<ActionResult> AddPresenterTransfer(CommissionManagementPresenterModalViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            AgentCommissionProgramDto dto = data.CreateDto();

            try
            {
                await this._commissionManagementService.AddPresenterTransferAsync(dto, this.User);

                this.AddSuccessAlert(GenerateCreateSuccessMessage("Presenter transfer"));
            }
            catch (DuplicateCommissionProgramException)
            {
                this.AddWarningAlert("The selected presenter is already listed with an agent. Please select a different presenter.");
            }

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpGet]
        [CheckUserPermissions(new[] { ECEPermissions.ACCOUNTING_UPDATE })]
        [Route("edit-presenter-transfer-modal/{agentId}/{presenterId}")]
        public async Task<ActionResult> EditPresenterTransferModal(int agentId, int presenterId)
        {
            var presenterTransfer = await this._commissionManagementService.GetPresenterTransferAsync(presenterId);
            if (presenterTransfer == null || presenterTransfer.ToAppUserId != agentId)
            {
                return this.EntityNotFound();
            }

            var viewModel = new CommissionManagementPresenterModalViewModel();

            viewModel.LoadFromDto(presenterTransfer);
            viewModel.ControllerActionName = "EditPresenterTransfer";

            return PartialView("_PresenterTransferModal", viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("edit-presenter-transfer")]
        public async Task<ActionResult> EditPresenterTransfer(CommissionManagementPresenterModalViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            AgentCommissionProgramDto dto = data.CreateDto();

            await this._commissionManagementService.UpdatePresenterTransferAsync(dto, this.User);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Presenter transfer"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("delete-presenter-transfer")]
        public async Task<ActionResult> DeletePresenterTransfer(DeletePresenterTransferViewModel data)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction("Details", new { id = data.AgentId });
            }

            await this._commissionManagementService.DeletePresenterTransferAsync(
                data.PresenterId.Value,
                this.User);

            this.AddSuccessAlert(GenerateDeleteSuccessMessage("Presenter transfer"));

            return this.RedirectToAction("Details", new { id = data.AgentId });
        }
    }
}
