﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using CsvHelper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [Authorize]
    [RouteArea("accounting")]
    public class AgentPaymentController : BaseController
    {
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IPayrollService _payrollService;

        public AgentPaymentController(
            ILogger logger,
            IContractTransactionService contractTransactionService,
            IPayrollService payrollService)
            : base(logger)
        {
            this._contractTransactionService = contractTransactionService;
            this._payrollService = payrollService;
        }

        public bool CanViewAllAgents
        {
            get
            {
                return User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin) || User.IsInRole(ECERole.LMD);
            }
        }

        [HttpGet]
        [AgentPaymentPermissions]
        public ActionResult Index(int? agentId, int? year)
        {
            var viewModel = new AgentPaymentsViewModel()
            {
                Year = year ?? DateTime.Now.Year,
                AgentId = agentId ?? 0
            };

            var agents = new List<AppUserDto>();

            // If the current user is accounting, allow access to all users. Otherwise, only their own.
            if (this.CanViewAllAgents)
            {
                agents.AddRange(LookupCache.GetAllAgents());
            }
            else if (User.IsInRole(ECERole.Agent))
            {
                var userAgent = LookupCache.GetAllAgents().FirstOrDefault(x => x.AppUserId == User.GetUserId());
                agents.Add(userAgent);
            }
            else
            {
                return this.AccessForbidden();
            }

            // If current user is not accounting, make default selected agent.
            if (!this.CanViewAllAgents)
            {
                viewModel.AgentId = User.GetUserId();
            }
            bool isParent = false;
            if (this.ParentUserId > 0)
            {
                isParent = true;
            }
            var assAgentsSelectList = new AgentSelectList(agents, User.GetUserId(), !isParent);
            viewModel.AgentSelectList = assAgentsSelectList;//new SelectList(agents, "AppUserId", "FullName");

            return View(viewModel);
        }

        [HttpGet]
        [Route("agentpayment/{id}")]
        [AgentPaymentPermissions]
        public async Task<ActionResult> Details(int id)
        {
            return View("~/Areas/Accounting/Views/AgentPayment/Details.cshtml");
        }

        [HttpGet]
        [Route("agentpayment/unpaid/{agentId}")]
        [AgentPaymentPermissions]
        public async Task<ActionResult> UnpaidDetails(int agentId)
        {
            return View("~/Areas/Accounting/Views/AgentPayment/Details.cshtml");
        }

        [HttpGet]
        [Route("agentpayment/exportpayments")]
        [AgentPaymentPermissions]
        public async Task<ActionResult> ExportPayments(int agentId, int year)
        {
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }

            var agent = LookupCache.GetAllAgents().FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound();
            }

            var payrollPayments = await _payrollService.GetPayrollPaymentsByAgentAndYearAsync(agentId, year);

            if (year == DateTime.Today.Year)
            {
                var payrollBatch = await this._payrollService.CalculateNextPayrollBatchAsync();

                var unPaidLogs = await this._payrollService.GetUnpaidByAgentAsync(agentId, year);

                await this._payrollService.CalculateNetAmountsAsync(agentId, unPaidLogs, payrollBatch);

                var unPaidDetailsViewModel = new AgentPaymentDetailsViewModel(
                    agentId,
                    year,
                    null,
                    unPaidLogs);

                payrollPayments.Add(new PayrollPaymentDto
                {
                    AgentId = agentId,
                    GrossCommissionAmount = unPaidDetailsViewModel.EceCollections,
                    NetCommissionAmount = unPaidDetailsViewModel.AgentCommissions,
                    AgentWorkingAmount = unPaidDetailsViewModel.AgentWorking,
                    SharedBonusAmount = unPaidDetailsViewModel.OtherPayments,
                });
            }

            payrollPayments = payrollPayments
                .OrderByDescending(x => x.PostDate == null)
                .ThenByDescending(x => x.PostDate).ToList();

            var fileName = $"{agent.FirstName}-{agent.LastName}-{year}-AgentPayments";
            fileName = FileHelper.GetSafeFileName(fileName);
            List <PayrollPaymentExcelDto> PayrollPaymentExcels = new List<PayrollPaymentExcelDto>();
            foreach (var payment in payrollPayments)
            {
                PayrollPaymentExcelDto payrollPayment = new PayrollPaymentExcelDto();
                var postDate = payment.PostDate.HasValue
                    ? payment.PostDate.ToStandardString()
                    : "UNPAID";
                payrollPayment.DatePaid = postDate;
                payrollPayment.EceCollections = payment.GrossCommissionAmount;
                payrollPayment.AgentCommissions = payment.NetCommissionAmount;
                payrollPayment.Programs = (payment.NonExclusiveArtistFeeAmount + payment.SharedBonusAmount);
                payrollPayment.AgentWorking = payment.AgentWorkingAmount;
                PayrollPaymentExcels.Add(payrollPayment);
            }
            if (PayrollPaymentExcels.Any())
            {
                var dt = PayrollPaymentExcels.ToDataTable();
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, FileHelper.GetFirst30Characters(fileName));
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }

        }


        [HttpGet]
        [Route("agentpayment/paidcomissiondata")]
        [AgentPaymentPermissions]
        public async Task<ActionResult> PaidComissionData(int? agentId, int paymentId)
        {
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }

            var agent = LookupCache.GetAllAgents().FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound();
            }
            var year = DateTime.Today.Year;
            var unPaidLogs = await this._payrollService.GetUnpaidByAgentAsync((int)agentId, year);
            var fileName = $"{agent.FirstName}-{agent.LastName}-{year}-";
            fileName = fileName + "PaidComission";
            fileName = FileHelper.GetSafeFileName(fileName);
            var sb = new StringBuilder();


            var agentPayrollLogs = await this._payrollService.GetAgentPayrollLogsByPayrollPaymentIdAsync(paymentId);

            List<AgentPayrollLogViewExcelDto> agentPayrollLogViewExcels = new List<AgentPayrollLogViewExcelDto>();
            foreach (var payment in agentPayrollLogs.OrderBy(_ => _.ContractId))
            {
                AgentPayrollLogViewExcelDto agentPayrollLogViewExcel = new AgentPayrollLogViewExcelDto();
                agentPayrollLogViewExcel.ContractId = payment.ContractId;
                agentPayrollLogViewExcel.PaymentType = payment.PayrollLogType;
                agentPayrollLogViewExcel.GrossAmount = payment.GrossAmount;
                agentPayrollLogViewExcel.NetAmount = payment.NetAmount;
                agentPayrollLogViewExcel.EventDate = payment.LastEventDate;
                agentPayrollLogViewExcel.DepositCollected = payment.ReceivedDate;
                agentPayrollLogViewExcels.Add(agentPayrollLogViewExcel);
            }

            if (agentPayrollLogViewExcels.Any())
            {
                var dt = agentPayrollLogViewExcels.ToDataTable();
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, FileHelper.GetFirst30Characters(fileName));
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }
        }
    }
}
