﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    [RoutePrefix("generalledger")]
    public class GeneralLedgerController : BaseAccountingController
    {
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IContractService _contractService;

        public GeneralLedgerController(ILogger logger,
            IContractService contractService,
            IGeneralLedgerService generalLedgerService)
            : base(logger)
        {
            this._contractService = contractService;
            this._generalLedgerService = generalLedgerService;
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Search()
        {
            var viewModel = new GLJournalSearchCriteriaViewModel();

            viewModel.LoadForSearch(User);

            return View(viewModel);
        }

        [HttpGet]
        public ActionResult Breakdown()
        {
            var viewModel = new GLBreakdownSearchViewModel();

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("searchexport")]
        public async Task<ActionResult> SearchExport(GLJournalSearchExportViewModel viewModel)
        {
            viewModel.Criteria.MaxResults = int.MaxValue - 1;

            var results = await this._generalLedgerService.GetGLJournalEntriesByCriteriaAsync(viewModel.Criteria);

            var fileName = viewModel.FileName;
            fileName = FileHelper.GetSafeFileName(fileName);
            var bytes = viewModel.GetExportFileContents(results, fileName);

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
        }

        [HttpGet]
        public async Task<ActionResult> ContractModal(int id)
        {
            var criteria = new GLJournalDetailsSearchCriteriaDto
            {
                ContractId = id
            };

            var journalEntries = await this._generalLedgerService.GetGLJournalDetailsByCriteriaAsync(criteria);

            var viewModel = new GeneralLedgerModalViewModel
            {
                ContractId = id,
                Entries = journalEntries
            };

            return PartialView("~/Areas/Accounting/Views/GeneralLedger/_ContractModal.cshtml", viewModel);
        }

        [HttpGet]
        public async Task<ActionResult> AccountDetails(int id)
        {
            var accountDetail = await this._generalLedgerService.GetGLAccountByIdAsync(id);

            if (accountDetail == null)
            {
                return this.EntityNotFound("Account not found.");
            }

            var viewModel = Mapper.Map<GLAccountViewModel>(accountDetail);

            return this.View(viewModel);
        }

        [Route("correction")]
        public async Task<ActionResult> Correction(int? contractId)
        {
            var viewModel = new GLJournalCorrectionViewModel();

            if (contractId.HasValue)
            {
                var contract = await _contractService.GetByIdAsync(contractId.Value);
                if (contract != null)
                {
                    viewModel.ContractId = contract.ContractId;
                    viewModel.AgentId = contract.AgentId;
                    viewModel.OfficeId = contract.OfficeId;
                    viewModel.LineOfBusinessId = contract.LineOfBusinessId;
                }
                else
                {
                    AddDangerAlert($"Contract #{contractId.Value} does not exists.");
                }
            }

            return View("Correction", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("correction")]
        public async Task<ActionResult> Correction(GLJournalCorrectionViewModel viewModel)
        {
            if (viewModel != null && viewModel.Entries != null)
            {
                foreach (var item in viewModel.Entries)
                {
                    if (item.ReferenceNumber == string.Empty)
                    {
                        item.ReferenceNumber = null;
                    }

                    TryValidateModel(item);
                }
            }

            if (ModelState.IsValid)
            {
                var entries = Mapper.Map<IList<GeneralLedgerJournalDto>>(viewModel.Entries);

                await this._generalLedgerService.AddManualJournalEntriesAsync(entries, this.User);

                AddSuccessAlert(GenerateUpdateSuccessMessage("G/L Entries"));

                return RedirectToAction("Correction", new { ContractId = viewModel.ContractId });
            }

            AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);

            return View("Correction", viewModel);
        }

        [HttpGet]
        public async Task<ActionResult> CorrectionFormModal(int? id)
        {
            var viewModel = new GLJournalEntryViewModel();

            viewModel.LoadForModal(User);

            if (id.HasValue)
            {
                var contract = await _contractService.GetByIdAsync(id.Value, true);
                if (contract != null)
                {
                    viewModel.ContractId = contract.ContractId;
                    viewModel.AgentId = contract.AgentId;
                    viewModel.OfficeId = contract.OfficeId;
                    viewModel.LineOfBusinessId = contract.LineOfBusinessId;
                    viewModel.ForContract = true;

                    var contractTransactions = contract.ContractTransactions
                        .Select(x => new LookupDto(x.ContractTransactionId, $"{x.ContractTransactionTypeName} - {x.DueDate:MM/dd/yyyy} - {x.RequiredAmount:C} {x.AgentFullName}"));

                    viewModel.ContractTransactions = new SelectList(contractTransactions, "Value", "Text");
                }
                else
                {
                    AddDangerAlert($"Contract #{id.Value} does not exists.");
                }
            }

            return PartialView("_CorrectionFormModal", viewModel);
        }

        [HttpGet]
        public async Task<ActionResult> AddEventFormModal(int? id)
        {
            var viewModel = new GLJournalAddEventViewModel();

            viewModel.LoadForModal(User);

            if (id.HasValue)
            {
                var contract = await _contractService.GetByIdAsync(id.Value, true);
                if (contract != null)
                {
                    viewModel.ContractId = contract.ContractId;
                    viewModel.AgentId = contract.AgentId;
                    viewModel.OfficeId = contract.OfficeId;
                    viewModel.LineOfBusinessId = contract.LineOfBusinessId;
                    viewModel.ForContract = true;

                    var contractTransactions = contract.ContractTransactions
                        .Select(x => new LookupDto(x.ContractTransactionId, $"{x.ContractTransactionTypeName} - {x.DueDate:MM/dd/yyyy} - {x.RequiredAmount:C} {x.AgentFullName}"));

                    viewModel.ContractTransactions = new SelectList(contractTransactions, "Value", "Text");
                }
                else
                {
                    AddDangerAlert($"Contract #{id.Value} does not exists.");
                }
            }

            return PartialView("_AddEventFormModal", viewModel);
        }
    }
}