﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class AccountingApiController : BaseApiController
    {
        private readonly IUserService _userService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly ICheckbookService _checkbookService;
        private readonly IPayrollService _payrollService;

        public AccountingApiController(IUserService userService,
           IGeneralLedgerService generalLedgerService,
           IExpenseBatchService expenseBatchService,
           IContractTransactionService contractTransactionService,
           ICheckbookService checkbookService,
           IPayrollService payrollService)
        {
            this._userService = userService;
            this._generalLedgerService = generalLedgerService;
            this._expenseBatchService = expenseBatchService;
            this._contractTransactionService = contractTransactionService;
            this._checkbookService = checkbookService;
            this._payrollService = payrollService;
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/accounts")]
        public async Task<IHttpActionResult> GetAccounts()
        {
            var accountsList = await this._generalLedgerService.GetAccountsAsync();

            // This feature uses the MVC UrlHelper because it is aware of the attribute routing data associated with
            // MVC routes. Using the HTTP (Web API) UrlHelper didn't recognize the route attributes on MVC controllers.
            var helper = new System.Web.Mvc.UrlHelper(System.Web.HttpContext.Current.Request.RequestContext);

            var results = accountsList.Select(
                x =>
                {
                    var vm = Mapper.Map<GLAccountViewModel>(x);

                    var url = helper.Action("AccountDetails", "GeneralLedger", new { area = "Accounting", id = x.GeneralLedgerAccountId });

                    vm.AccountUrl = url;

                    return vm;
                });

            return this.Ok(results);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/journalactivity")]
        public async Task<IHttpActionResult> GetJournalActivity()
        {
            var journalActivity = await this._generalLedgerService.GetJournalActivityAsync();

            var results = new List<GLJournalActivityViewModel>();

            Tuple<int, int> prevPairKeys = new Tuple<int, int>(-1, -1);

            var row = new GLJournalActivityViewModel();

            for (int i = 0; i < journalActivity.Count; i++)
            {
                var entry = journalActivity[i];

                if (entry.ContractId > 0)
                {
                    row.ActivityDescription = $"Contract #{entry.ContractId} - ";
                }

                row.ActivityDescription += entry.TransactionTypeDescription;

                var creditDebit = $"{entry.GeneralLedgerAccountId} - {entry.PostedAmount.ToString("C")}";

                if (entry.ChangeType.Equals("D"))
                {
                    row.ActivityDebit = creditDebit;
                }
                else if (entry.ChangeType.Equals("C"))
                {
                    row.ActivityCredit = creditDebit;
                }

                var curPairKeys = new Tuple<int, int>(entry.GeneralLedgerTransactionTypeId, entry.JournalTransactionNumber);
                if (prevPairKeys.Equals(curPairKeys))
                {
                    results.Add(new GLJournalActivityViewModel()
                    {
                        ActivityDescription = row.ActivityDescription,
                        ActivityDebit = row.ActivityDebit,
                        ActivityCredit = row.ActivityCredit
                    });

                    row = new GLJournalActivityViewModel();
                }

                prevPairKeys = new Tuple<int, int>(entry.GeneralLedgerTransactionTypeId, entry.JournalTransactionNumber);
            }

            return this.Ok(results);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/journaldetails/search")]
        public async Task<IHttpActionResult> GetJournalDetailsSearchResults(GLJournalDetailsSearchCriteriaDto viewModel)
        {
            var criteriaDto = Mapper.Map<GLJournalDetailsSearchCriteriaDto>(viewModel);

            var results = await this._generalLedgerService.GetGLJournalDetailsByCriteriaAsync(criteriaDto);

            var searchResults = results.Select(Mapper.Map<GLJournalDetailsSearchResultViewModel>).ToList();

            return this.Ok(searchResults);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/expensemanagement/search")]
        public async Task<IHttpActionResult> GetExpenseManagementSearchResults(ExpenseManagementSearchCriteriaDto viewModel)
        {
            var criteriaDto = Mapper.Map<ExpenseManagementSearchCriteriaDto>(viewModel);

            var results = await this._generalLedgerService.GetExpenseManagementByCriteriaAsync(criteriaDto);

            var searchResults = results.Select(Mapper.Map<ExpenseManagementSearchResultViewModel>).ToList();

            return this.Ok(searchResults);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("api/accounting/expensemanagement/expense/toggleApproval")]
        public async Task<IHttpActionResult> ToggleExpenseApproval(int id, bool approve)
        {
            await this._contractTransactionService.ToggleExpenseApprovalAsync(id, approve, this.User);

            return this.Ok();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("api/accounting/expensemanagement/expense/marktobepaid")]
        public async Task<IHttpActionResult> MarkToBePaid(ExpenseManagementViewModel viewModel)
        {
            if (viewModel == null || viewModel.IdsToPay == null)
            {
                return this.BadRequest("Invalid list of expenses to pay.");
            }

            await this._contractTransactionService.MarkToBePaidAsync(viewModel.GetIdsToPay(), this.User);

            return this.Ok();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("api/accounting/paymentbatch/updatenotes")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ManuallyValidateModel]
        public async Task<IHttpActionResult> UpdateNotes(UpdatePaymentBatchNotesViewModel viewModel)
        {
            await this._expenseBatchService.UpdateNotesAsync(viewModel.ExpenseBatchId, viewModel.Notes);

            return this.Ok(viewModel.Notes);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/payment/paymentsearch")]
        public async Task<IHttpActionResult> GetPaymentSearchResults(PaymentSearchCriteriaDto dto)
        {
            var results = await this._expenseBatchService.GetPaymentsByCriteriaAsync(dto);

            return this.Ok(results);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/payment/batchsearch")]
        public async Task<IHttpActionResult> GetBatchSearchResults(BatchSearchCriteriaDto dto)
        {
            var results = await this._expenseBatchService.GetBatchesByCriteriaAsync(dto);

            return this.Ok(results);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/checkbook/checksearch")]
        public async Task<IHttpActionResult> GetCheckSearchResults(CheckSearchCriteriaDto dto)
        {
            var results = await this._checkbookService.GetChecksByCriteriaAsync(dto);

            return this.Ok(results);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("api/accounting/checkbook/updatenotes")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ManuallyValidateModel]
        public async Task<IHttpActionResult> UpdateCheckNotes(UpdatePaymentNotesViewModel viewModel)
        {
            await this._checkbookService.UpdateNotesAsync(viewModel.ExpensePaymentId, viewModel.Notes);

            return this.Ok(viewModel.Notes);
        }

        [HttpGet]
        [Route("api/accounting/checkbook/checks-to-reconcile")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<IHttpActionResult> ChecksToReconcile()
        {
            // The system shall display the in-progress Check Reconciliation Batch on the Reconcile Checks page if there is a batch in progress.
            var existingReconciliationBatch = await this._checkbookService.GetExistingReconciliationBatchAsync(this.User, includeItems: true);

            this._checkbookService.SetReconciliationItemWarnings(existingReconciliationBatch.ReconciliationItems);

            var model = Mapper.Map<ReconcileCheckViewModel>(existingReconciliationBatch);

            return this.Ok(model.ChecksToReconcile);
        }

        [HttpGet]
        [Route("api/accounting/payroll/payrollpagelogs/{year}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollPageLogs(int year)
        {
            var logs = await this._payrollService.GetPayrollLogsAsync(year);

            var viewModel = new PayrollPageLogsViewModel(logs);

            return this.Ok(viewModel.Logs);
        }

        [HttpGet]
        [Route("api/accounting/payroll/detailslog/{payrollBatchId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollDetailsLogs(int payrollBatchId)
        {
            var results = await this._payrollService.GetPayrollDetailsLogsAsync(payrollBatchId);

            return this.Ok(results);
        }
        [HttpGet]
        [Route("api/accounting/payroll/settingpayroll/{payrollBatchId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> SettingPayrollAsync(int payrollBatchId)
        {
            var results = await this._payrollService.GetSettingPayrollAsync(payrollBatchId);

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/payroll/agentearnedcommissions/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollAgentEarnedCommissions(int payrollPaymentId)
        {
            var results = await this._payrollService.GetAgentEarnedCommissionsAsync(payrollPaymentId);

            var viewModels = results.Select(x => new AgentEarnedCommissionsViewModel
            {
                AgentPayrollLogId = x.AgentPayrollLogId,
                AgentId = x.AgentId,
                ContractId = x.ContractId,
                ContractType = x.ContractType,
                EventType = x.EventType,
                GrossCommission = x.GrossCommission,
                LastEventDate = x.LastEventDate.HasValue ? x.LastEventDate.Value.ToStandardString() : string.Empty,
                NetCommission = x.NetCommission,
                Percentage = x.Percentage,
                ReceivedDate = x.ReceivedDate.ToStandardString(),
                Split = x.Split,
                IsExclude = x.IsExclude,
                ExcludeDate = x.ExcludeDate
            });

            return this.Ok(viewModels);
        }

        [HttpGet]
        [Route("api/accounting/payroll/mentorshipbonuscommissions/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollMentorshipBonusCommissions(int payrollPaymentId)
        {
            var results = await this._payrollService.GetMentorshipBonusCommissionsAsync(payrollPaymentId);

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/payroll/presentertransferbonuscommissions/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollPresenterTransferBonusCommissions(int payrollPaymentId)
        {
            var results = await this._payrollService.GetPresenterTransferBonusCommissionsAsync(payrollPaymentId);

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/payroll/sharedbonus/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollSharedBonus(int payrollPaymentId)
        {
            var results = await this._payrollService.GetSharedBonusAsync(payrollPaymentId);

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/payroll/nonexclusiveartistfee/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollNonExclusiveArtistFee(int payrollPaymentId)
        {
            var results = await this._payrollService.GetNonExclusiveArtistFeeAsync(payrollPaymentId);

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/payroll/agentworking/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> PayrollAgentWorking(int payrollPaymentId)
        {
            var results = await this._payrollService.GetAgentWorkingAsync(payrollPaymentId);

            return this.Ok(results);
        }


        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/payroll/SetPayrollPaymentAsync")]
        public async Task<IHttpActionResult> SetPayrollPaymentAsync(PayrollPaymentViewModel viewModel)
        {
            var results = await this._payrollService.SetPayrollPaymentAsync(viewModel, this.User);

            return this.Ok(results);
        }
        [HttpPost]
        [Route("api/accounting/payroll/SetAgentPayrollLogAsync")]
        public async Task<IHttpActionResult> SetAgentPayrollLogAsync(AgentPayrollPaymentLogViewModel viewModel)
        {
            var results = await this._payrollService.SetAgentPayrollLogAsync(viewModel, this.User);

            return this.Ok(results);
        }
        [HttpGet]
        [Route("api/accounting/payroll/ExcludePayrollPaymentAsync/{payrollBatchId}")]
        public async Task<IHttpActionResult> ExcludePayrollPaymentAsync(int payrollBatchId)
        {
            var results = await this._payrollService.ExcludePayrollPaymentAsync(payrollBatchId, this.User);

            return this.Ok(results);
        }
    }
}
