﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using Infinity.Mobius.Logging;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class ArtistChargeController : BaseApiController
    {
        private readonly IArtistChargeService _artistChargeService;

        public ArtistChargeController(ILogger logger, IArtistChargeService artistChargeService)
            : base(logger)
        {
            _artistChargeService = artistChargeService;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/artistcharge/search")]
        public async Task<IHttpActionResult> GetSearchResults(ArtistChargeSearchCriteriaViewModel viewModel)
        {
            var criteria = Mapper.Map<ArtistChargeSearchCriteriaDto>(viewModel);

            var results = await this._artistChargeService.GetArtistChargesByCriteriaAsync(criteria);

            var searchResults = results.Select(Mapper.Map<ArtistChargeSearchResultViewModel>).ToList();

            searchResults.ForEach(
                x =>
                {
                    var url = $"/accounting/artistcharge/{x.ArtistChargeId}";
                    x.DetailsUrl = url;
                });

            return this.Ok(searchResults);
        }
    }
}