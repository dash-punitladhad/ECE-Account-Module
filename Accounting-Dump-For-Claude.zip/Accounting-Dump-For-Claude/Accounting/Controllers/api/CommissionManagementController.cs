﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using Infinity.Mobius.Logging;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class CommissionManagementController : BaseApiController
    {
        private readonly ICommissionManagementService _commissionManagementService;

        public CommissionManagementController(ILogger logger,
            ICommissionManagementService commissionManagementService)
            : base(logger)
        {
            this._commissionManagementService = commissionManagementService;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/commission-management/search")]
        public async Task<IHttpActionResult> GetSearchResults(CommissionManagementSearchCriteriaViewModel viewModel)
        {
            var criteria = Mapper.Map<CommissionManagementSearchCriteriaDto>(viewModel);

            var results = await this._commissionManagementService.GetAgentCommissionsByCriteriaAsync(criteria);

            var searchResults = results.Select(Mapper.Map<CommissionManagementSearchResultViewModel>);

            return this.Ok(searchResults);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/commission-management/structure/{id}")]
        public async Task<IHttpActionResult> GetCommissionStructure(int id)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(id, true);
            if (agentCommission == null)
            {
                return this.EntityNotFound($"Agent Commission {id} Not Found");
            }

            return this.Ok(agentCommission.CommissionTiers);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/commission-management/presenter-transfers/{id}")]
        public async Task<IHttpActionResult> GetPresenterTransfers(int id)
        {
            var results = await this._commissionManagementService.GetPresenterTransfersByAgentIdAsync(id);

            return this.Ok(results);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/commission-management/presenter-transfer/{presenterId}")]
        public async Task<IHttpActionResult> GetPresenterTransfer(int presenterId)
        {
            var result = await this._commissionManagementService.GetPresenterTransferAsync(presenterId);
            if (result == null)
            {
                return this.Ok("not-found");
            }

            return this.Ok(result);
        }
    }
}
