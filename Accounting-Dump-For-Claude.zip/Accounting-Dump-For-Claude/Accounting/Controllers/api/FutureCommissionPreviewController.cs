﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
using ECE.CRM.WebUI.Controllers.api;
using ECE.CRM.WebUI.Infrastructure;
using ECE.CRM.WebUI.Infrastructure.Attributes;
using ECE.CRM.WebUI.Infrastructure.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    public class FutureCommissionPreviewController : BaseApiController
    {
        private readonly IFutureCommissionService _futureCommissionService;

        public FutureCommissionPreviewController(IFutureCommissionService futureCommissionService)
        {
            this._futureCommissionService = futureCommissionService;
        }

        [HttpGet]
        [AgentPaymentPermissions]
        [Route("api/accounting/getagentlist")]
        public async Task<IHttpActionResult> GetAgentList()
        {
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var assAgentsResultList = agentList;
            var agentSelectList = new AgentSelectList(assAgentsResultList, User.GetUserId());
            return Ok(agentSelectList);

        }

        [HttpPost]
        [AgentPaymentPermissions]
        [Route("api/accounting/futurecommission")]
        public async Task<IHttpActionResult> FutureCommissionPreview(AgentDrawFilterModel filterModel)
        {
            if (filterModel.AgentId == 0)
            {
                filterModel.AgentId = User.GetUserId();
            }
            return this.Ok(await _futureCommissionService.GetAgentFutureCommission(filterModel));
        }

        [HttpPost]
        [Route("api/accounting/searchFutureExport")]
        [CheckUserPermissions(ECEPermissions.CONTRACT_READ)]
        public async Task<IHttpActionResult> ExportData(AgentDrawFilterModel filterModel)
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            try
            {
                if (filterModel.AgentId == 0)
                {
                    filterModel.AgentId = User.GetUserId();
                }
                Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();

                var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
                var agent = agentList.FirstOrDefault(x => x.AppUserId == filterModel.AgentId);
                if (agent == null)
                {
                    return null;
                }

                var records = await _futureCommissionService.GetAgentFutureCommission(filterModel);
                keyValuePairsParams.Add("@AgentId", filterModel.AgentId);
                keyValuePairsParams.Add("@QuarterId", filterModel.QuarterId);
                keyValuePairsParams.Add("@QYear", filterModel.QYear);
                DataTable dtExport = new DataTable();
                dtExport.Columns.Add("ContractId", typeof(int));
                dtExport.Columns.Add("GrossAmount", typeof(decimal));
                dtExport.Columns.Add("NetAmount", typeof(decimal));
                dtExport.Columns.Add("AgentEarnedCommission", typeof(decimal));
                dtExport.Columns.Add("LastEventDate", typeof(DateTime));
                dtExport.Columns.Add("DepositCollectedDate", typeof(DateTime));
                dtExport.Columns.Add("ExpectedPayDate", typeof(DateTime));

                for (var i = 0; i < records.Count; i++)
                {
                    DataRow dr = dtExport.NewRow();
                    dr[0] = records[i].ContractId;
                    dr[1] = records[i].GrossAmount;
                    dr[2] = records[i].NetAmount;
                    dr[3] = records[i].AgentEarnedCommission;
                    dr[4] = records[i].LastEventDate;
                    dr[5] = records[i].DepositCollectedDate;
                    dr[6] = records[i].ExpectedPayDate;
                    dtExport.Rows.Add(dr);
                }

                if (dtExport != null && dtExport.Rows.Count > 0)
                {
                    dtExport.TableName = "futurecommission";
                    dtExport.AcceptChanges();
                    string file = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,";
                    file += await CRInfrastructure.DT_XLS(dtExport, "futurecommission");

                    string filename = $"{agent.FirstName}-{agent.LastName}-FutureCommissions";
                    keyValuePairs.Add("downloadUrl", file);
                    keyValuePairs.Add("filename", filename);
                    keyValuePairs.Add("error", "");
                }
                else
                {
                    keyValuePairs = new Dictionary<string, object>();
                    keyValuePairs.Add("error", "Record Not Found!");
                }
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                keyValuePairs = new Dictionary<string, object>();
                keyValuePairs.Add("error", ex.Message);
            }
            return this.Ok(keyValuePairs);
        }
        public DateTime GetExpectedPayDate(DateTime lastEventDate)
        {
            if (lastEventDate.Year < DateTime.Now.Year)
            {
                return new DateTime(DateTime.Now.Year, DateTime.Now.Month, 15);
            }
            else if (lastEventDate.Day <= 6 && lastEventDate.Year == DateTime.Now.Year)
            {
                return new DateTime(lastEventDate.Year, lastEventDate.Month, 15);
            }
            else
            {
                if (lastEventDate.Day <= 21 && lastEventDate.Year == DateTime.Now.Year)
                {
                    return new DateTime(lastEventDate.Year, lastEventDate.Month, DateTime.DaysInMonth(lastEventDate.Year, lastEventDate.Month));
                }
                else
                {
                    return new DateTime(lastEventDate.AddMonths(1).Year, lastEventDate.AddMonths(1).Month, 15);
                    //return new DateTime(lastEventDate.Year, lastEventDate.AddMonths(1).Month, 15);
                }

            }
        }

    }
}
