﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using ECE.CRM.WebUI.ViewModels.Contract;
    using Infinity.Mobius.Logging;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
    public class AccountingDashboardController : BaseApiController
    {
        private readonly IAccountingDashboardService _dashboardService;
        private readonly IEmailQueueService _emailQueueService;
        private readonly IDailyCloseoutService _dailyCloseoutService;
        private readonly IContractService _contractService;
        private readonly IPandaDocService _pandaDocService;

        public AccountingDashboardController(
            ILogger logger,
            IAccountingDashboardService dashboardService,
            IDailyCloseoutService dailyCloseoutService,
            IEmailQueueService emailQueueService,
            IContractService contractService,
            IPandaDocService pandaDocService)
            : base(logger)
        {
            _emailQueueService = emailQueueService;
            _dashboardService = dashboardService;
            _dailyCloseoutService = dailyCloseoutService;
            _contractService = contractService;
            _pandaDocService = pandaDocService;
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/OutgoingQueue")]
        public async Task<IHttpActionResult> OutgoingQueue()
        {
            var criteria = new EmailQueueSearchCriteriaDto
            {
                AppUserId = UserId,
                Status = EmailQueueStatus.Pending
            };

            var messages = await _emailQueueService.GetByCriteriaAsync(criteria);

            return Ok(messages);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/OfficeRevenue/{year}/{month}")]
        public async Task<IHttpActionResult> OfficeRevenue(int year, int month)
        {
            var offices = await _dashboardService.GetOfficeRevenueAsync(year, month);

            var viewModel = new
            {
                year = year,
                month = month,
                offices = offices,
            };

            return Ok(viewModel);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/ExpenseSummary")]
        public async Task<IHttpActionResult> ExpenseSummary()
        {
            var summary = await _dashboardService.GetExpenseSummaryAsync();

            var viewModel = new
            {
                otherExpensesReadyToPay = summary.OtherExpensesReadyToPay,
                estimatedUpcomingPayroll = summary.EstimatedUpcomingPayroll,
                estimatedUpcomingArtistPayments = summary.EstimatedUpcomingArtistPayments,
            };

            return Ok(viewModel);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/ArtistsMissingW9")]
        public async Task<IHttpActionResult> ArtistsMissingW9()
        {
            var missing = await _dashboardService.GetArtistsMissingW9Async();

            var viewModel = new
            {
                exclusiveMissingW9Count = missing.ExclusiveMissingW9Count,
                nonExclusiveMissingW9Count = missing.NonExclusiveMissingW9Count,
            };

            return Ok(viewModel);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/ContractSummary")]
        public async Task<IHttpActionResult> ContractSummary()
        {
            var summary = await _dashboardService.GetContractSummaryAsync();

            var viewModel = new
            {
                missingSignaturesCount = summary.MissingSignaturesCount,
                missingDepositsCount = summary.MissingDepositsCount,
                outOfBalanceContractCount = summary.OutOfBalanceContractCount,
                underwaterContractCount = summary.UnderwaterContractCount,
            };

            return Ok(viewModel);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/DailyTransfer")]
        public async Task<IHttpActionResult> DailyTransfer()
        {
            var amounts = await _dailyCloseoutService.GetDailyCloseoutAmountsAsync();

            var viewModel = new
            {
                currentTransferAmount = amounts[DailyCloseoutAmounts.Total],
            };

            return Ok(viewModel);
        }

        [HttpGet]
        [Route("api/Accounting/Dashboard/PartiallyCanceledContracts")]
        public async Task<IHttpActionResult> PartiallyCanceledContracts()
        {
            var criteria = new ContractSearchCriteriaDto
            {
                ContractStatusId = (int)ContractStatus.PartiallyCanceled
            };

            var contracts = await _contractService.GetByCriteriaAsync(criteria);

            return Ok(Mapper.Map<List<ContractSearchResultViewModel>>(contracts));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("api/Accounting/Dashboard/MarkFullyCanceled")]
        public async Task<IHttpActionResult> MarkFullyCanceled(ContractSearchResultViewModel viewModel)
        {
            var contract = await _contractService.GetByIdAsync(viewModel.ContractId);
            if (contract == null)
            {
                return this.EntityNotFound(EntityType.Contract, viewModel.ContractId);
            }

            const int fullyCanceled = (int)ContractStatus.Canceled;

            if (contract.ContractStatusId == (int)ContractStatus.PartiallyCanceled)
            {
                contract.ContractStatusId = fullyCanceled;

                await this._contractService.UpdateAsync(contract, this.User);
                await this._pandaDocService.RemoveSignaturesAndRevertDraftAsync(contract, this.User);
            }

            var success = contract.ContractStatusId == fullyCanceled;

            var message = success
                ? $"Contract {viewModel.ContractId} marked as fully canceled."
                : $"Contract {viewModel.ContractId} not marked as fully canceled (current status is '{TextHelper.ContractStatusToString(contract.ContractStatusId)}').";

            return Ok(new { Success = success, Message = message });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("api/Accounting/Dashboard/Reinstate")]
        public async Task<IHttpActionResult> Reinstate(ContractSearchResultViewModel viewModel)
        {
            var contract = await _contractService.GetByIdAsync(viewModel.ContractId);
            if (contract == null)
            {
                return this.EntityNotFound(EntityType.Contract, viewModel.ContractId);
            }

            if (contract.ContractStatusId == (int)ContractStatus.PartiallyCanceled)
            {
                await this._contractService.ReinstateAsync(viewModel.ContractId, this.User);

                contract = await _contractService.GetByIdAsync(viewModel.ContractId);

                var success = contract.ContractStatusId != (int)ContractStatus.PartiallyCanceled;

                var message = success
                    ? $"Contract {viewModel.ContractId} reinstated with status of '{TextHelper.ContractStatusToString(contract.ContractStatusId)}'."
                    : $"Contract {viewModel.ContractId} not reinstated.";

                return Ok(new { Success = success, Message = message });
            }
            else
            {
                var invalidMessage = $"Contract {viewModel.ContractId} not reinstated! Current status is '{TextHelper.ContractStatusToString(contract.ContractStatusId)}'.";

                return Ok(new { Success = false, Message = invalidMessage });
            }
        }
    }
}
