﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using Infinity.Mobius.Logging;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class DailyCloseoutController : BaseApiController
    {
        private readonly IDailyCloseoutService _dailyCloseoutService;

        public DailyCloseoutController(
            ILogger logger,
            IDailyCloseoutService dailyCloseoutService)
            : base(logger)
        {
            this.Logger.Information("Daily Closeout API Controller Created.");

            this._dailyCloseoutService = dailyCloseoutService;
        }

        [HttpGet]
        [Route("api/accounting/dailycloseout/pendingtransactions")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<IHttpActionResult> DailyCloseoutPendingTrans()
        {
            var lastCloseoutDate = await this._dailyCloseoutService.GetDailyCloseoutLastCloseoutDateAsync();

            var transactions = await this._dailyCloseoutService.GetDailyCloseoutPendingTransactionsAsync(lastCloseoutDate);

            var results = Mapper.Map<List<DailyCloseoutPendingTransactionViewModel>>(transactions);

            return this.Ok(results);
        }
    }
}
