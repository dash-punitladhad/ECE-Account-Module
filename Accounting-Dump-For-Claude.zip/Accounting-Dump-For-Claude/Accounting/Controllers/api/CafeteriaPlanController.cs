﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class CafeteriaPlanController : BaseApiController
    {
        private readonly IPayrollService _payrollService;

        public CafeteriaPlanController(IPayrollService payrollService)
        {
            this._payrollService = payrollService;
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/cafeteriaplans/{year}")]
        public async Task<IHttpActionResult> GetCafeteriaPlansAsync(int year)
        {
            var cafePlans = await _payrollService.GetAgentCafeteriaPlansAsync(year, DateTime.Today);

            var results = cafePlans.Select(x => new AgentCafeteriaPlanViewModel()
            {
                AgentName = x.AgentName,
                AgentUserId = x.AppUserId,
                CafeteriaPlanId = x.CafeteriaPlan?.CafeteriaPlanId,
                CurrentDeduction = x.CafeteriaPlan?.CurrentDeductionAmount,
                Year = year,
                YtdAmount = x.PayrollPayments?.Sum(y => y.CafeteriaPlanAmount)
            });

            results = results.OrderBy(x => x.CafeteriaPlanId == null).ThenBy(x => x.AgentName).ToList();

            return this.Ok(results);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/cafeteriaplans/{agentId}/deductions/{year}")]
        public async Task<IHttpActionResult> GetAgentDeductionsByYearAsync(int agentId, int year)
        {
            var payrollPayments = await this._payrollService.GetPayrollPaymentsByAgentAndYearAsync(agentId, year);

            var deductions = payrollPayments?.Select(x => new PayrollPaymentDeductionViewModel()
            {
                Date = x.PostDate.GetValueOrDefault(),
                Amount = x.CafeteriaPlanAmount
            });

            return this.Ok(deductions);
        }
    }
}