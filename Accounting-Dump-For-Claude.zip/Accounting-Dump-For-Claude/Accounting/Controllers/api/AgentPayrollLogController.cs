﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class AgentPayrollLogController : BaseApiController
    {
        private readonly IUserService _userService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IAgentPayrollLogService _agentPayrollLogService;
        private readonly IPayrollService _payrollService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IContractService _contractService;

        public AgentPayrollLogController(IUserService userService,
           IGeneralLedgerService generalLedgerService,
           IAgentPayrollLogService agentPayrollLogService,
           IPayrollService payrollService,
           IContractTransactionService contractTransactionService,
           IContractService contractService)
        {
            this._userService = userService;
            this._generalLedgerService = generalLedgerService;
            this._agentPayrollLogService = agentPayrollLogService;
            this._payrollService = payrollService;
            this._contractTransactionService = contractTransactionService;
            this._contractService = contractService;
        }

        [HttpGet]
        [Route("api/accounting/agentpayrolllog/logentries/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> LogEntries(int payrollPaymentId)
        {
            var results = await this._payrollService.GetAgentPayrollLogsByPayrollPaymentIdAsync(payrollPaymentId);

            var viewModels = Mapper.Map<IList<AgentPayrollLogViewModel>>(results);

            return this.Ok(viewModels);
        }

        [HttpGet]
        [Route("api/accounting/agentpayrolllog/contractexpenses/{contractId}/{payrollPaymentId}")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> ContractExpenses(int contractId, int payrollPaymentId)
        {
            var payment = await _payrollService.GetPayrollPaymentByIdAsync(payrollPaymentId);
            if (payment == null)
            {
                return EntityNotFound();
            }

            var transactions = await _contractTransactionService.GetByContractIdAsync(contractId);

            var agentId = payment.AgentId;

            var contract = await _contractService.GetByIdAsync(contractId);

            var agentHasBonusCommission = contract.CommissionProgramAgentId == agentId;

            var commissions = transactions
                .Where(x => x.IsExpense && x.ContractEntityTypeId == (int)ContractEntityType.ECE)
                .Where(x => x.AgentId == agentId ||
                            (x.ContractEntityId == agentId && x.ContractTransactionTypeId == (int)ContractTransactionType.AgentWorking) ||
                            agentHasBonusCommission);

            var viewModels = commissions.Select(x => new LookupDto(x.ContractTransactionId, $"{x.ContractTransactionTypeName} - {x.DueDate:MM/dd/yyyy} - {x.RequiredAmount:C} - {x.AgentFullName}"));

            return this.Ok(viewModels);
        }
    }
}
