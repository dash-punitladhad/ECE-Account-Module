﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using ClosedXML.Excel;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Http;

    [Authorize]
    public class AgentPaymentController : BaseApiController
    {
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IPayrollService _payrollService;

        public AgentPaymentController(IContractTransactionService contractTransactionService, IPayrollService payrollService)
        {
            _contractTransactionService = contractTransactionService;
            _payrollService = payrollService;
        }

        public bool CanViewAllAgents
        {
            get
            {
                return User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin) || User.IsInRole(ECERole.LMD);
            }
        }

        [HttpGet]
        [AgentPaymentPermissions]
        [Route("api/accounting/agentpayments")]
        public async Task<IHttpActionResult> GetAgentPayments(int agentId, int year)
        {
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }

            AgentPaymentDetailsViewModel unPaidDetailsViewModel = null;

            var payrollPayments = await _payrollService.GetPayrollPaymentsByAgentAndYearAsync(agentId, year);

            if (year == DateTime.Today.Year)
            {
                var preview = true;

                var payrollBatch = await _payrollService.GetNextPayrollBatchAsync(preview, agentId);

                var unPaidLogs = await _payrollService.GetUnpaidByAgentAsync(agentId, year);

                var unpaidGross = unPaidLogs.Sum(x => x.GrossAmount);

                await _payrollService.CalculateNetAmountsAsync(agentId, unPaidLogs, payrollBatch);

                unPaidDetailsViewModel = new AgentPaymentDetailsViewModel(
                    agentId,
                    year,
                    null,
                    unPaidLogs);

                payrollPayments.Add(new PayrollPaymentDto
                {
                    AgentId = agentId,
                    GrossCommissionAmount = unPaidDetailsViewModel.EceCollections,
                    NetCommissionAmount = unPaidDetailsViewModel.AgentCommissions,
                    AgentWorkingAmount = unPaidDetailsViewModel.AgentWorking,
                    SharedBonusAmount = unPaidDetailsViewModel.OtherPayments,
                });
            }
            else
            {
                unPaidDetailsViewModel = new AgentPaymentDetailsViewModel();
            }

            var criteria = new ContractTransactionSearchCriteriaDto();

            criteria.AgentId = agentId;
            criteria.IsExpense = true;
            criteria.YearDue = year;
            criteria.ContractTransactionTypeIds = new List<int> { (int)ContractTransactionType.Commission };

            var commissionsTransactions = await _payrollService.GetCommissionTransactionsAsync(criteria);

            var paymentViewModels = payrollPayments
                .OrderByDescending(x => x.PostDate == null)
                .ThenByDescending(x => x.PostDate)
                .Select(x => new AgentPaymentViewModel()
                {
                    AgentId = x.AgentId,
                    PaymentId = x.PayrollPaymentId,
                    DatePaid = x.PostDate,
                    EceCollections = x.GrossCommissionAmount,
                    AgentCommissions = x.NetCommissionAmount,
                    AgentWorkingAmount = x.AgentWorkingAmount,
                    CafeteriaPlanAmount = x.CafeteriaPlanAmount,
                    ProgramsAmount = x.NonExclusiveArtistFeeAmount + x.SharedBonusAmount,
                });

            var results = new
            {
                Payments = paymentViewModels,

                EceCommissionsSummary = commissionsTransactions.Total(x => x.RequiredAmount),

                EceCollectionsSummary = paymentViewModels.Total(x => x.EceCollections),

                UnpaidEceCollections = unPaidDetailsViewModel.EceCollections,

                UnpaidAgentCommissions = unPaidDetailsViewModel.AgentPayments
            };

            return this.Ok(results);
        }

        [HttpGet]
        [Route("api/accounting/agentpayment/unpaid")]
        public async Task<IHttpActionResult> UnpaidComission(int agentId)
        {
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound();
            }

            var year = DateTime.Today.Year;

            var payrollBatch = await _payrollService.GetNextPayrollBatchAsync(true, agentId);

            var unPaidLogs = await this._payrollService.GetUnpaidByAgentAsync(agentId, year);

            await this._payrollService.CalculateNetAmountsAsync(agentId, unPaidLogs, payrollBatch);

            var viewModel = new AgentPaymentDetailsViewModel(agentId, year, agent, unPaidLogs);

            return Ok(viewModel);
        }

        [HttpGet]
        [AgentPaymentPermissions]
        [Route("api/accounting/agentpayment/paid")]
        public async Task<IHttpActionResult> PaidCommission(int id)
        {
            var payrollPayment = await this._payrollService.GetPayrollPaymentByIdAsync(id);
            if (payrollPayment == null)
            {
                return this.EntityNotFound();
            }

            if (!this.CanViewAllAgents && payrollPayment.AgentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }

            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == payrollPayment.AgentId);

            var agentPayrollLogs = await this._payrollService.GetAgentPayrollLogsByPayrollPaymentIdAsync(id);
            var payrollData = new List<AgentPayrollLogDto>();

            var viewModel = new AgentPaymentDetailsViewModel(
                payrollPayment.AgentId,
                payrollPayment.PostDate.GetValueOrDefault().Year,
                agent,
                agentPayrollLogs);

            viewModel.PayrollDate = payrollPayment.PostDate.GetValueOrDefault();
            return Ok(viewModel);
        }


        [HttpGet]
        [Route("api/accounting/agentpayment/unpaidexport")]
        [AgentPaymentPermissions]
        public async Task<IHttpActionResult> UnpaidComissionData(int? agentId)
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }

            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound();
            }
            var year = DateTime.Today.Year;
            var unPaidLogs = await this._payrollService.GetUnpaidByAgentAsync((int)agentId, year);
            var fileName = $"{agent.FirstName}-{agent.LastName}-{year}-";
            fileName = fileName + "UnpaidComission";

            DataTable dt = new DataTable();
            dt.Columns.Add("Contract #", typeof(int));
            dt.Columns.Add("Payment Type", typeof(string));
            dt.Columns.Add("Gross Amount", typeof(decimal));
            dt.Columns.Add("Net Amount", typeof(decimal));
            dt.Columns.Add("Event Date", typeof(string));
            dt.Columns.Add("Deposit Collected Date", typeof(string));

            foreach (var payment in unPaidLogs.OrderBy(_ => _.ContractId))
            {
                DataRow dr = dt.NewRow();
                dr[0] = payment.ContractId;
                dr[1] = payment.LuPayrollLogType.Name;
                dr[2] = payment.GrossAmount;
                dr[3] = payment.NetAmount;
                dr[4] = payment.LastEventDate;
                dr[5] = payment.ReceivedDate;
                dt.Rows.Add(dr);
            }

            if (unPaidLogs != null && unPaidLogs.Any())
            {
                dt.TableName = "Unpaid Commission";
                dt.AcceptChanges();
                string file = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,";
                file += await CRInfrastructure.DT_XLS(dt, "Unpaid Commission");

                string filename = fileName;
                keyValuePairs.Add("downloadUrl", file);
                keyValuePairs.Add("filename", filename);
                keyValuePairs.Add("error", "");
            }
            else
            {
                keyValuePairs = new Dictionary<string, object>();
                keyValuePairs.Add("error", "Record Not Found!");
            }
            return this.Ok(keyValuePairs);

        }
        [HttpGet]
        [AgentPaymentPermissions]
        [Route("api/accounting/agentpayment/paidexport")]

        public async Task<IHttpActionResult> PaidComissionData(int? agentId, int paymentId)
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            if (!this.CanViewAllAgents && agentId != this.User.GetUserId())
            {
                return this.AccessForbidden();
            }
            var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
            var agent = agentList.FirstOrDefault(x => x.AppUserId == agentId);
            if (agent == null)
            {
                return this.EntityNotFound();
            }
            var year = DateTime.Today.Year;
            var fileName = $"{agent.FirstName}-{agent.LastName}-{year}-";
            fileName = fileName + "PaidComission";

            DataTable dt = new DataTable();
            dt.Columns.Add("Contract #", typeof(int));
            dt.Columns.Add("Payment Type", typeof(string));
            dt.Columns.Add("Gross Amount", typeof(decimal));
            dt.Columns.Add("Net Amount", typeof(decimal));
            dt.Columns.Add("Event Date", typeof(string));
            dt.Columns.Add("Deposit Collected Date", typeof(string));

            var agentPayrollLogs = await this._payrollService.GetAgentPayrollLogsByPayrollPaymentIdAsync(paymentId);

            foreach (var payment in agentPayrollLogs.OrderBy(_ => _.ContractId))
            {
                DataRow dr = dt.NewRow();
                dr[0] = payment.ContractId;
                dr[1] = payment.PayrollLogType;
                dr[2] = payment.GrossAmount;
                dr[3] = payment.NetAmount;
                dr[4] = payment.LastEventDate;
                dr[5] = payment.ReceivedDate;
                dt.Rows.Add(dr);
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                dt.TableName = "Paid Commission";
                dt.AcceptChanges();
                string file = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,";
                file += await CRInfrastructure.DT_XLS(dt, "Paid Commission");

                string filename = fileName;
                keyValuePairs.Add("downloadUrl", file);
                keyValuePairs.Add("filename", filename);
                keyValuePairs.Add("error", "");
            }
            else
            {
                keyValuePairs = new Dictionary<string, object>();
                keyValuePairs.Add("error", "Record Not Found!");
            }
            return this.Ok(keyValuePairs);
        }

    }
}