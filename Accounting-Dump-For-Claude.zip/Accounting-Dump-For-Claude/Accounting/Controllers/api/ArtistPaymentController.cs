﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class ArtistPaymentController : BaseApiController
    {
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IExpensePaymentService _expensePaymentService;
        private readonly IPayrollService _payrollService;

        public ArtistPaymentController(
            IContractTransactionService contractTransactionService,
            IExpensePaymentService expensePaymentService,
            IPayrollService payrollService)
        {
            _contractTransactionService = contractTransactionService;
            _expensePaymentService = expensePaymentService;
            _payrollService = payrollService;
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/artistpayments")]
        public async Task<IHttpActionResult> GetArtistPaymentsAsync(int artistId, int year)
        {
            // Get all transactions paid to the artist for the given year.
            var criteria = new ContractTransactionSearchCriteriaDto()
            {
                ContractEntityTypeIds = { (int)ContractEntityType.Artist },
                ContractEntityIds = { artistId },
                YearPaid = year,
                PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.Paid
            };

            var paidTransactions = await _payrollService.GetCommissionTransactionsAsync(criteria);

            // Calculate the sub-totals by transaction types
            var arefPaid = paidTransactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment)
                .Sum(x => x.PaidAmount);

            var programTypes = new List<int>()
            {
                (int)ContractTransactionType.ReserveAllowance,
                (int)ContractTransactionType.GasCard,
                (int)ContractTransactionType.SharedBonus
            };

            var programsPaid = paidTransactions
                .Where(x => programTypes.Contains(x.ContractTransactionTypeId))
                .Sum(x => x.PaidAmount);

            // Get all transactions due to be paid to the artist for the given year.
            criteria = new ContractTransactionSearchCriteriaDto()
            {
                ContractEntityTypeIds = { (int)ContractEntityType.Artist },
                ContractEntityIds = { artistId },
                YearDue = year,
                PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.NotPaid
            };

            var unpaidTransactions = await _payrollService.GetCommissionTransactionsAsync(criteria);

            var arefAndProgramTypes = programTypes;
            arefAndProgramTypes.Add((int)ContractTransactionType.ArtistPayment);

            var amountNotPaid = unpaidTransactions
                .Where(x => arefAndProgramTypes.Contains(x.ContractTransactionTypeId))
                .Sum(x => x.RequiredAmount);

            var loanRepayment = decimal.Zero;

            var payments = await _expensePaymentService.GetByPayeeAndYearAsync((int)ContractEntityType.Artist, artistId, year);

            // Calculate loan repayment amount.
            foreach (var payment in payments)
            {
                if (payment.ArtistChargeTransactions != null)
                {
                    loanRepayment += payment.ArtistChargeTransactions
                        .Where(x => x.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Repayment)
                        .Sum(x => x.TransactionAmount);
                }
            }

            var orderedPayments = payments.Select(x => new
            {
                ArtistId = x.ContractEntityId,
                x.ExpensePaymentId,
                DatePaid = x.DateIssued,
                Amount = x.PaymentAmount,
                PaymentMethod = GeneratePaymentTypeDisplay(x),
                IsVoided = x.DateVoided.HasValue,
            }).OrderByDescending(x => x.DatePaid);

            var result = new
            {
                Payments = orderedPayments,
                ArefPaid = arefPaid,
                ProgramsPaid = programsPaid,
                AmountNotPaid = amountNotPaid,
                LoanRepayment = loanRepayment
            };

            return this.Ok(result);
        }

        private string GeneratePaymentTypeDisplay(ExpensePaymentDto expensePayment)
        {
            if (expensePayment.PaymentAmount == decimal.Zero)
            {
                return "n/a";
            }

            return $"{expensePayment.ExpensePaymentTypeLabel} {expensePayment.ReferenceNumber}";
        }
    }
}