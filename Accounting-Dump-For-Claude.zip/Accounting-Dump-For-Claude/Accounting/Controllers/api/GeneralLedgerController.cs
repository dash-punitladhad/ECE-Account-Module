﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class GeneralLedgerController : BaseApiController
    {
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IContractService _contractService;
        private readonly IAccountingDataService _accountingDataService;

        public GeneralLedgerController(
            ILogger logger,
            IGeneralLedgerService generalLedgerService,
            IContractTransactionService contractTransactionService,
            IContractService contractService,
            IAccountingDataService accountingDataService)
            : base(logger)
        {
            this._generalLedgerService = generalLedgerService;
            this._contractTransactionService = contractTransactionService;
            this._contractService = contractService;
            this._accountingDataService = accountingDataService;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/generalledger/search")]
        public async Task<IHttpActionResult> GetSearchResults(GLJournalSearchCriteriaViewModel viewModel)
        {
            var criteria = Mapper.Map<GLJournalSearchCriteriaDto>(viewModel);

            var results = await this._generalLedgerService.GetGLJournalEntriesByCriteriaAsync(criteria);

            var searchResults = results.Select(Mapper.Map<GLJournalSearchResultViewModel>).ToList();

            return this.Ok(searchResults);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/generalledger/transaction-type/{id}")]
        public async Task<IHttpActionResult> GetTransactionType(int id)
        {
            var transactionTypes = await this._generalLedgerService.GetTransactionTypesByEventIdAsync(id, null);

            return this.Ok(transactionTypes.FirstOrDefault());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ManuallyValidateModel]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/generalledger/load-entry")]
        public async Task<IHttpActionResult> LoadEntry(GLJournalEntryViewModel viewModel)
        {
            if (viewModel == null)
            {
                return this.Ok(viewModel);
            }

            var transactionTypes = await this._generalLedgerService.GetTransactionTypesByEventIdAsync(viewModel.GeneralLedgerEventId.Value, null);

            var transactionType = transactionTypes.FirstOrDefault();

            viewModel.GeneralLedgerTransactionType = transactionType.Description;
            viewModel.GeneralLedgerTransactionTypeId = transactionType.GeneralLedgerTransactionTypeId;

            if (viewModel.GeneralLedgerAccountId.HasValue &&
                !string.IsNullOrWhiteSpace(viewModel.ChangeType) &&
                string.IsNullOrWhiteSpace(viewModel.ChangeDirection))
            {
                var changeDirection = GeneralLedgerRules.GetChangeDirection(viewModel.GeneralLedgerAccountId.Value, viewModel.ChangeType[0]);

                viewModel.ChangeDirection = new string(new[] { changeDirection });
            }

            if (viewModel.ContractId.HasValue)
            {
                var contract = await _contractService.GetByIdAsync(viewModel.ContractId.Value);
                if (contract != null)
                {
                    viewModel.LineOfBusinessId = contract.LineOfBusinessId;
                    viewModel.OfficeId = contract.OfficeId;

                    if (viewModel == null)
                    {
                        viewModel.AgentId = contract.AgentId;
                    }
                }
            }

            if (viewModel.AgentId.HasValue)
            {
                var agent = LookupCache.GetAllActiveAgents().FirstOrDefault(x => x.AppUserId == viewModel.AgentId);
                if (agent != null)
                {
                    viewModel.AgentName = agent.FullName;
                }
            }

            if (viewModel.ContractTransactionId > 0)
            {
                var transaction = await _contractTransactionService.GetByIdAsync(viewModel.ContractTransactionId.Value);
                if (transaction != null)
                {
                    viewModel.ContractEntityId = transaction.ContractEntityId;
                    viewModel.ContractEntityTypeId = transaction.ContractEntityTypeId;
                }
            }

            return this.Ok(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ManuallyValidateModel]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/generalledger/load-event")]
        public async Task<IHttpActionResult> LoadEvent(GLJournalAddEventViewModel viewModel)
        {
            if (viewModel == null)
            {
                return this.Ok(viewModel);
            }

            var glEvent = (GeneralLedgerEvent)viewModel.GeneralLedgerEventId;

            var entries = new List<GLJournalSearchResultViewModel>();

            var originalTransactionTypes = await this._generalLedgerService.GetTransactionTypesByEventIdAsync(viewModel.GeneralLedgerEventId.GetValueOrDefault(), null);

            if (viewModel.AgentId.HasValue)
            {
                var agent = LookupCache.GetAllActiveAgents().FirstOrDefault(x => x.AppUserId == viewModel.AgentId);
                if (agent != null)
                {
                    viewModel.AgentName = agent.FullName;
                }
            }

            int contractEntityId = 0;
            int contractEntityTypeId = 0;

            if (viewModel.ContractTransactionId > 0)
            {
                var transaction = await _contractTransactionService.GetByIdAsync(viewModel.ContractTransactionId.Value);
                if (transaction != null)
                {
                    contractEntityId = transaction.ContractEntityId;
                    contractEntityTypeId = transaction.ContractEntityTypeId;
                }
            }

            foreach (var gltt in originalTransactionTypes)
            {
                var debitLedger = new GLJournalSearchResultViewModel
                {
                    GeneralLedgerAccountId = gltt.DebitAccountId,
                    AgentId = viewModel.AgentId,
                    AgentName = viewModel.AgentName,
                    ChangeDirection = gltt.DebitChangeDirection,
                    ChangeType = 'D',
                    ContractId = viewModel.ContractId,
                    ContractTransactionId = viewModel.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    GeneralLedgerEventId = viewModel.GeneralLedgerEventId.GetValueOrDefault(),
                    PostedDate = DateTime.Now,
                    PostedAmount = viewModel.PostedAmount.GetValueOrDefault(),
                    OfficeId = viewModel.OfficeId,
                    LineOfBusinessId = viewModel.LineOfBusinessId,
                    ReferenceNumber = viewModel.ReferenceNumber,
                    GeneralLedgerTransactionType = gltt.Description,
                    ContractEntityId = contractEntityId,
                    ContractEntityTypeId = contractEntityTypeId
                };

                var creditLedger = new GLJournalSearchResultViewModel
                {
                    GeneralLedgerAccountId = gltt.CreditAccountId,
                    AgentId = viewModel.AgentId,
                    AgentName = viewModel.AgentName,
                    ChangeDirection = gltt.CreditChangeDirection,
                    ChangeType = 'C',
                    ContractId = viewModel.ContractId,
                    ContractTransactionId = viewModel.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    GeneralLedgerEventId = viewModel.GeneralLedgerEventId.GetValueOrDefault(),
                    PostedDate = DateTime.Now,
                    PostedAmount = viewModel.PostedAmount.GetValueOrDefault(),
                    OfficeId = viewModel.OfficeId,
                    LineOfBusinessId = viewModel.LineOfBusinessId,
                    ReferenceNumber = viewModel.ReferenceNumber,
                    GeneralLedgerTransactionType = gltt.Description,
                    ContractEntityId = contractEntityId,
                    ContractEntityTypeId = contractEntityTypeId
                };

                entries.Add(debitLedger);
                entries.Add(creditLedger);
            }

            return Ok(entries);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ManuallyValidateModel]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("api/accounting/generalledger/reverse-entries")]
        public async Task<IHttpActionResult> ReverseEntries(GLReverseJournalEntriesViewModel viewModel)
        {
            var criteria = new GLJournalSearchCriteriaDto
            {
                ContractId = viewModel.ContractId,
                SelectedTransactions = viewModel.SelectedTransactions
            };

            var results = await this._generalLedgerService.GetGLJournalEntriesByCriteriaAsync(criteria);

            var events = results
                .Select(x => new
                {
                    x.JournalTransactionNumber,
                    x.GeneralLedgerEventId,
                    x.PostedAmount,
                    x.ReferenceNumber,
                    x.ContractEntityTypeId,
                    x.ContractTransactionId,
                    x.AgentId,
                    x.ContractEntityId,
                    x.OfficeId,
                    x.LineOfBusinessId
                })
                .Distinct();

            var reversedEvents = new List<GLJournalSearchResultViewModel>();

            foreach (var glEvent in events)
            {
                List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes;

                if (glEvent.GeneralLedgerEventId == 9999)
                {
                    // Do a simple reversal of all entries when the Unknown Transaction Type is used (9999).
                    var logEntries = results.Where(x => x.JournalTransactionNumber == glEvent.JournalTransactionNumber);

                    var transaction = results.FirstOrDefault(x => x.JournalTransactionNumber == glEvent.JournalTransactionNumber);

                    foreach (var logEntry in logEntries.OrderBy(x => x.GeneralLedgerJournalId))
                    {
                        var reversedEntry = new GLJournalSearchResultViewModel
                        {
                            GeneralLedgerAccountId = logEntry.GeneralLedgerAccountId,
                            AgentId = transaction.AgentId,
                            AgentName = transaction.AgentName,
                            ChangeDirection = logEntry.ChangeDirection == "D" ? 'I' : 'D',
                            ChangeType = logEntry.ChangeType == "C" ? 'D' : 'C',
                            ContractId = transaction.ContractId,
                            ContractTransactionId = transaction.ContractTransactionId,
                            GeneralLedgerTransactionTypeId = logEntry.GeneralLedgerTransactionTypeId,
                            GeneralLedgerEventId = logEntry.GeneralLedgerEventId,
                            ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                            ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                            PostedDate = DateTime.Now,
                            PostedAmount = logEntry.PostedAmount,
                            OfficeId = transaction.OfficeId,
                            LineOfBusinessId = transaction.LineOfBusinessId,
                            ReferenceNumber = glEvent.ReferenceNumber,
                            GeneralLedgerTransactionType = "Unknown Transaction Type"
                        };

                        reversedEvents.Add(reversedEntry);
                    }
                }
                else
                {
                    var reversedEvent = this._generalLedgerService.GetReversedGlEvent((GeneralLedgerEvent)glEvent.GeneralLedgerEventId);
                    if (reversedEvent == GeneralLedgerEvent.Unknown)
                    {
                        // Create a list of reverse transaction types.
                        generalLedgerTransactionTypes = new List<GeneralLedgerTransactionTypeDto>();

                        var originalTransactionTypes = await this._generalLedgerService.GetTransactionTypesByEventIdAsync(glEvent.GeneralLedgerEventId, glEvent.ContractEntityTypeId);
                        foreach (var originalTransactionType in originalTransactionTypes)
                        {
                            generalLedgerTransactionTypes.Add(originalTransactionType.Reverse());
                        }
                    }
                    else
                    {
                        // Use the list of transaction types for the reverse event.
                        generalLedgerTransactionTypes = await this._generalLedgerService.GetTransactionTypesByEventIdAsync((int)reversedEvent, glEvent.ContractEntityTypeId);
                    }

                    var transaction = results.FirstOrDefault(x => x.JournalTransactionNumber == glEvent.JournalTransactionNumber);

                    var amount = transaction.PostedAmount;

                    foreach (var gltt in generalLedgerTransactionTypes)
                    {
                        var debitLedger = new GLJournalSearchResultViewModel
                        {
                            GeneralLedgerAccountId = gltt.DebitAccountId,
                            AgentId = transaction.AgentId,
                            AgentName = transaction.AgentName,
                            ChangeDirection = gltt.DebitChangeDirection,
                            ChangeType = 'D',
                            ContractId = transaction.ContractId,
                            ContractTransactionId = transaction.ContractTransactionId,
                            GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                            GeneralLedgerEventId = (int)reversedEvent,
                            ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                            ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                            PostedDate = DateTime.Now,
                            PostedAmount = amount,
                            OfficeId = transaction.OfficeId,
                            LineOfBusinessId = transaction.LineOfBusinessId,
                            ReferenceNumber = glEvent.ReferenceNumber,
                            GeneralLedgerTransactionType = gltt.Description
                        };

                        var creditLedger = new GLJournalSearchResultViewModel
                        {
                            GeneralLedgerAccountId = gltt.CreditAccountId,
                            AgentId = transaction.AgentId,
                            AgentName = transaction.AgentName,
                            ChangeDirection = gltt.CreditChangeDirection,
                            ChangeType = 'C',
                            ContractId = transaction.ContractId,
                            ContractTransactionId = transaction.ContractTransactionId,
                            GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                            GeneralLedgerEventId = (int)reversedEvent,
                            ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                            ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                            PostedDate = DateTime.Now,
                            PostedAmount = amount,
                            OfficeId = transaction.OfficeId,
                            LineOfBusinessId = transaction.LineOfBusinessId,
                            ReferenceNumber = glEvent.ReferenceNumber,
                            GeneralLedgerTransactionType = gltt.Description
                        };

                        reversedEvents.Add(creditLedger);
                        reversedEvents.Add(debitLedger);
                    }
                }
            }

            return this.Ok(reversedEvents);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("api/accounting/generalledger/gl-breakdown")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<IHttpActionResult> GetGLBreakdown(GLBreakdownSearchViewModel viewModel)
        {
            var criteria = viewModel.CreateDto();

            var data = await _accountingDataService.GetGLBreakdownAsync(criteria);

            var vm = new GLBreakdownViewModel();

            var lines = vm.GetValues(data);

            return this.Ok(lines);
        }
    }
}
