﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataTransferObjects;
using ECE.CRM.WebUI.Controllers.api;
using ECE.CRM.WebUI.Infrastructure.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web.Http;

namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    public class DrawTableController : BaseApiController
    {
        private readonly IDrawTableService _drawTableService;

        public DrawTableController(IDrawTableService drawTableService)
        {
            _drawTableService = drawTableService;
        }

        [HttpPost]
        [Route("api/drawTable/getAllData")]
        public async Task<List<AgentDrawTableDTO>> GetDrawData(AgentDrawFilterModel filterModel)
        {
            return await _drawTableService.GetAgentDrawData(filterModel);
        }

        [HttpPost]
        [Route("api/drawTable/getAgentQuarterComm")]
        public async Task<decimal> GetAgentQuarterlyCommission(AgentDrawFilterModel filterModel)
        {
            if (filterModel.AgentId == 0 || filterModel.QuarterId == 0 || filterModel.QYear == 0)
            {
                return 0;
            }
            return await _drawTableService.GetAgentQuarterlyCommission(filterModel);
        }

        [HttpPost]
        [Route("api/drawTable/getAgentStartingAmount")]
        public async Task<decimal> GetAgentStartingAmount(AgentDrawFilterModel filterModel)
        {
            if (filterModel.AgentId == 0 || filterModel.QuarterId == 0 || filterModel.QYear == 0)
            {
                return 0;
            }
            return await _drawTableService.GetAgentStartingAmount(filterModel);
        }

        [HttpPost]
        [AgentPaymentPermissions]
        [Route("api/drawTable/addDrawData")]
        public async Task<bool> AddDrawData(DrawTableDto drawTableDto, IPrincipal user)
        {
            return await _drawTableService.AddDrawData(drawTableDto, user);
        }

        [HttpPost]
        [Route("api/drawTable/getAgentPrevQuarterComm")]
        public async Task<PreviousDrawDto> GetAgentPrevQuarterlyCommission(AgentDrawFilterModel filterModel)
        {
            if (filterModel.AgentId == 0 || filterModel.QuarterId == 0 || filterModel.QYear == 0)
            {
                return new PreviousDrawDto();
            }
            return await _drawTableService.GetAgentPreviousQuarterlyCommission(filterModel);
        }

        [HttpPost]
        [Route("api/drawTable/settleDrawData")]
        public async Task<bool> SettleDrawData(DrawTableDto drawTableDto, IPrincipal user)
        {
            return await _drawTableService.SettleTransaction(drawTableDto, user);
        }

        [HttpPost]
        [Route("api/drawTable/checkDrawData")]
        public async Task<AgentDrawTableDTO> CheckDrawData(AgentDrawFilterModel filterModel)
        {
            return await _drawTableService.CheckDrawData(filterModel);
        }

        [HttpPost]
        [Route("api/drawTable/getAgentYearlyDrawData")]
        public async Task<List<AgentYearlyDrawDTO>> GetAgentYearlyDrawData(AgentDrawFilterModel filterModel)
        {
            if (filterModel.AgentId == 0)
            {
                filterModel.AgentId = User.GetUserId();
            }
            return await _drawTableService.GetAgentYearlyDrawData(filterModel);
        }

        [HttpGet]
        [Route("api/drawTable/deleteDrawData")]
        public async Task<bool> DeleteDrawData(int drawID, IPrincipal user)
        {
            return await _drawTableService.DeleteDrawData(drawID, user);
        }
    }
}
