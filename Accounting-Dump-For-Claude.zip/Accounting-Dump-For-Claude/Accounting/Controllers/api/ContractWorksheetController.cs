﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers.api
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Controllers.api;
    using ECE.CRM.WebUI.Infrastructure.Http;
    using System.Threading.Tasks;
    using System.Web.Http;

    [Authorize]
    public class ContractWorksheetController : BaseApiController
    {
        private readonly IContractDepositService _contractDepositService;

        public ContractWorksheetController(IContractDepositService contractDepositService)
        {
            this._contractDepositService = contractDepositService;
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("api/accounting/contractworksheet/precreatedeposit")]
        [ManuallyValidateModel]
        public async Task<IHttpActionResult> PreCreateDeposit(ContractWorkSheetViewModel viewModel)
        {
            var depositDto = Mapper.Map<ContractDepositDto>(viewModel.CreateContractDeposit);
            depositDto.AllocatedAmount = depositDto.AppliedAmount;

            var result = await this._contractDepositService.PreCreateDepositCheckAsync(depositDto);

            var resultViewModel = Mapper.Map<PreCreateContractDepositResultViewModel>(result);

            return this.Ok(resultViewModel);
        }
    }
}
