﻿using AutoMapper;
using CsvHelper;

using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
using ECE.CRM.WebUI.Controllers;
using ECE.CRM.WebUI.Infrastructure;
using ECE.CRM.WebUI.Infrastructure.Attributes;
using ECE.CRM.WebUI.Infrastructure.Helpers;
using Infinity.Mobius.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
	[Authorize]
	[RouteArea("accounting")]
	public class FutureCommissionEstimateController : BaseController
	{
		private readonly IFutureCommissionService _futureCommissionService;
		private readonly IDrawTableService _drawTableService;
		private readonly IEceCrmEntities _context;
		public FutureCommissionEstimateController(ILogger logger, IFutureCommissionService futureCommissionService, IDrawTableService drawTableService, IEceCrmEntities context) : base(logger)
		{
			this._futureCommissionService = futureCommissionService;
			this._drawTableService = drawTableService;
			this._context = context;
		}

		public bool CanViewAllAgents
		{
			get
			{
				return User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin) || User.IsInRole(ECERole.LMD);
			}
		}

		// GET: Accounting/FutureCommissionPreview
		public ActionResult Index()
		{
			var userId = User.GetUserId();
			var viewModel = new DrawTableViewModel()
			{
				Year = DateTime.Now.Year,
				AgentId = 0,
				QuarterId = 0
			};

			var agents = new List<AppUserDto>();
			var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();

			if (User.IsInRole(ECERole.LMD) && !User.IsInRole(ECERole.Owner))
			{

				var result = (from au in _context.AppUsers
							  join ar in _context.AppUserRoles on au.AppUserId equals ar.AppUserId
							  where ar.RoleId == 1 && ar.IsDeleted == false && au.IsActive == true
							  && (from aur in _context.AppUserRoles
								  where aur.RoleId == 4 && aur.AppUserId == userId
								  select aur.OfficeId).Contains(ar.OfficeId)
							  select au).Distinct().ToList();
				var users = Mapper.Map<IList<AppUserDto>>(result);
				agents.AddRange(users);
			}
			else if (this.CanViewAllAgents)
			{
				agents.AddRange(agentList);
			}
			else if (User.IsInRole(ECERole.Agent) && !User.IsInRole(ECERole.LMD))
			{
				var userAgent = agentList.FirstOrDefault(x => x.AppUserId == User.GetUserId());
				agents.Add(userAgent);
			}
			else
			{
				return this.AccessForbidden();
			}

			// If current user is not accounting, make default selected agent.
			if (!this.CanViewAllAgents)
			{
				viewModel.AgentId = User.GetUserId();
			}
			var assAgentsSelectList = new AgentSelectList(agents, User.GetUserId());
			viewModel.AgentSelectList = assAgentsSelectList;
			Task.Run(async () => {
				viewModel.QuartersList = await _drawTableService.GetAllQuarters();
			}).Wait();
			viewModel.YearSelectList = _drawTableService.GetYears();
			return View(viewModel);
		}

	}
}