﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using Infinity.Mobius.Logging;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class PaymentController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly IExpenseBatchService _expenseBatchService;

        public PaymentController(
            ILogger logger,
            IUserService userService,
            IExpenseBatchService expenseBatchService)
            : base(logger)
        {
            this.Logger.Information("Payment Controller Created.");

            this._userService = userService;
            this._expenseBatchService = expenseBatchService;
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        [Route("payments/paymentsearch")]
        public ActionResult PaymentSearch(int? entityTypeId, int? entityId)
        {
            var payeeTypes = LookupCache.GetAllContractEntityTypes().ToSelectList("Text", "Value");

            var model = new PaymentSearchViewModel()
            {
                PayeeTypes = payeeTypes,
                EntityId = entityId,
                EntityTypeId = entityTypeId
            };

            return View("~/Areas/Accounting/Views/Payment/PaymentSearch.cshtml", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("payments/paymentsearchexport")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<ActionResult> PaymentSearchExport(PaymentSearchExportViewModel viewModel)
        {
            var results = await this._expenseBatchService.GetPaymentsByCriteriaAsync(viewModel.Criteria);

            var fileName = FileHelper.GetSafeFileName(viewModel.FileName);
            var bytes = viewModel.GetExportFileContents(results, fileName);

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");

        }

        [HttpGet]
        [Route("payments/batchsearch")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public ActionResult BatchSearch()
        {
            var model = new BatchSearchViewModel();

            return View("~/Areas/Accounting/Views/Payment/BatchSearch.cshtml", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("payments/batchsearchexport")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<ActionResult> BatchSearchExport(BatchSearchExportViewModel viewModel)
        {
            var results = await this._expenseBatchService.GetBatchesByCriteriaAsync(viewModel.Criteria);

            var fileName = FileHelper.GetSafeFileName(viewModel.FileName);

            var bytes = viewModel.GetExportFileContents(results, fileName);

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");

        }
    }
}