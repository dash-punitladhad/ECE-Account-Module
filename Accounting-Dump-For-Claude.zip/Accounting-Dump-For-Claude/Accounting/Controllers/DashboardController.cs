﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels.Dashboard;
    using Infinity.Mobius.Logging;
    using System.Web.Mvc;

    public class DashboardController : BaseAccountingController
    {
        public DashboardController(ILogger logger)
            : base(logger)
        {
        }

        public ActionResult SetList()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult OutgoingQueue()
        {
            return View();
        }

        public ActionResult OfficeRevenueWidget()
        {
            var viewModel = new OfficeRevenueWidgetViewModel();

            return PartialView("_OfficeRevenueWidget", viewModel);
        }

        public ActionResult PartiallyCanceledContractsWidget()
        {
            var viewModel = new PartiallyCanceledContractsWidgetViewModel(User);

            viewModel.ShowWidgetContainer = ControllerContext.IsChildAction;

            return PartialView("_PartiallyCanceledContractsWidget", viewModel);
        }
    }
}