﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using Infinity.Mobius.Logging;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Web.Mvc;

    [Authorize]
    [RouteArea("accounting")]
    public class AgentPayrollLogController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly IAgentPayrollLogService _agentPayrollLogService;
        private readonly IPayrollService _payrollService;

        public AgentPayrollLogController(ILogger logger,
            IUserService userService,
            IAgentPayrollLogService agentPayrollLogService,
            IPayrollService payrollService)
            : base(logger)
        {
            Logger.Information("AgentPayrollLog Controller Created.");

            _userService = userService;
            _agentPayrollLogService = agentPayrollLogService;
            _payrollService = payrollService;
        }

        [HttpGet]
        [Route("agent-payroll-log")]
        public ActionResult Index(string date)
        {
            PayrollPageViewModel viewModel = null;

            DateTime asOfDate = ParseAsOfDate(date);

            try
            {
                var nextPayrollDate = _payrollService.GetNextPayrollDate(asOfDate);

                var startDate = _payrollService.GetPayrollStartDate(asOfDate, nextPayrollDate);

                var endDate = _payrollService.GetPayrollEndDate(asOfDate, nextPayrollDate);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);
                AddDangerAlert("The next payroll batch could not be calculated.");
                viewModel = new PayrollPageViewModel();
            }

            viewModel.AsOfDate = asOfDate;

            return View("Index", viewModel);
        }

        [NonAction]
        public DateTime ParseAsOfDate(string date)
        {
            DateTime asOfDate = TimeProvider.Current.Today;

            if (!string.IsNullOrWhiteSpace(date))
            {
                DateTime temp = asOfDate;
                if (DateTime.TryParse(date, out temp))
                {
                    asOfDate = temp;
                }
            }

            return asOfDate;
        }
    }
}
