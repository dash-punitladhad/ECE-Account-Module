﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Controllers;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using Infinity.Mobius.Logging;
    using System.Web.Mvc;

    [Authorize]
    [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
    public abstract class BaseAccountingController : BaseController
    {
        protected BaseAccountingController(ILogger logger)
            : base(logger)
        {
        }
    }
}
