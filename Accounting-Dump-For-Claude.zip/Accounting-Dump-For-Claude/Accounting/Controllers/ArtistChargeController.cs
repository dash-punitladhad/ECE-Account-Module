﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    [RoutePrefix("artistcharge")]
    public class ArtistChargeController : BaseAccountingController
    {
        private readonly IArtistChargeService _artistChargeService;

        public ArtistChargeController(ILogger logger, IArtistChargeService artistChargeService)
            : base(logger)
        {
            this._artistChargeService = artistChargeService;
        }

        public ActionResult Index()
        {
            var viewModel = new ArtistChargeSearchCriteriaViewModel();
            viewModel.LoadForSearch();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("searchexport")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<ActionResult> SearchExport(ArtistChargeSearchExportViewModel viewModel)
        {
            var results = await this._artistChargeService.GetArtistChargesByCriteriaAsync(viewModel.Criteria);

            var fileName = FileHelper.GetSafeFileName(viewModel.FileName);

            var bytes = viewModel.GetExportFileContents(results, FileHelper.GetFirst30Characters(fileName));

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<ActionResult> Details(int id)
        {
            var artistCharge = await _artistChargeService.GetArtistChargeByIdAsync(id);
            if (artistCharge == null)
            {
                return EntityNotFound();
            }

            var viewModel = Mapper.Map<ArtistChargeViewModel>(artistCharge);
            var transactions = await _artistChargeService.GetArtistChargeTransactionsByArtistChargeIdAsync(id);

            viewModel.LoadTransactions(transactions);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("detailsexport")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_READ)]
        public async Task<ActionResult> DetailsExport(ArtistChargeDetailsExportViewModel viewModel)
        {
            var artistCharge = await _artistChargeService.GetArtistChargeByIdAsync(viewModel.ArtistChargeId);
            if (artistCharge == null)
            {
                return EntityNotFound();
            }

            var detailsViewModel = Mapper.Map<ArtistChargeViewModel>(artistCharge);
            var transactions = await _artistChargeService.GetArtistChargeTransactionsByArtistChargeIdAsync(viewModel.ArtistChargeId);

            detailsViewModel.LoadTransactions(transactions);

            var fileName = FileHelper.GetSafeFileName(viewModel.FileName);

            var bytes = viewModel.GetExportFileContents(detailsViewModel.Transactions, FileHelper.GetFirst30Characters(fileName));

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("create")]
        public ActionResult Create()
        {
            var viewModel = new ArtistChargeCreateViewModel();
            viewModel.LoadForCreate();

            return View(viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("create")]
        public async Task<ActionResult> Create(ArtistChargeCreateViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(Infrastructure.InvalidDataAlertOption.ShowAllErrors);
                viewModel.LoadForCreate();
                return View(viewModel);
            }

            var dto = Mapper.Map<ArtistChargeDto>(viewModel);

            await this._artistChargeService.CreateAsync(dto, User);
            AddSuccessAlert(GenerateCreateSuccessMessage("Artist Charge/Loan"));
            return RedirectToAction("Details", new { id = dto.ArtistChargeId });
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("edit/{id}")]
        public async Task<ActionResult> Edit(int id)
        {
            var artistCharge = await _artistChargeService.GetArtistChargeByIdAsync(id);
            var viewModel = Mapper.Map<ArtistChargeEditViewModel>(artistCharge);
            viewModel.LoadForEdit();
            return View(viewModel);
        }

        [HttpPost]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [ValidateAntiForgeryToken]
        [Route("edit/{id}")]
        public async Task<ActionResult> Edit(int id, ArtistChargeEditViewModel viewModel)
        {
            var dto = Mapper.Map<ArtistChargeDto>(viewModel);

            var current = await this._artistChargeService.GetArtistChargeByIdAsync(viewModel.ArtistChargeId);
            dto.ArtistChargeTypeId = current.ArtistChargeTypeId;
            dto.ArtistId = current.ArtistId;
            dto.OriginalDate = current.OriginalDate;
            dto.TotalPaymentsReceived = current.TotalPaymentsReceived;

            await this._artistChargeService.UpdateAsync(dto, User);

            return RedirectToAction("Details", new { id = dto.ArtistChargeId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("{id}/adjustment/create")]
        public async Task<ActionResult> CreateAdjustment(int id, ArtistChargeViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                AddInvalidDataAlert(Infrastructure.InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Details", new { id });
            }

            var adjustmentAmount = viewModel.AdjustmentAmount.GetValueOrDefault() * decimal.MinusOne;

            await _artistChargeService.SaveArtistChargeAdjustmentAsync(id, adjustmentAmount, User);
            AddSuccessAlert(GenerateCreateSuccessMessage("Adjustment"));

            return RedirectToAction("Details", new { id });
        }
    }
}
