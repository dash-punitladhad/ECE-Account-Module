﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using CsvHelper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using EO.Pdf.Mvc;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class DailyCloseoutController : BaseAccountingController
    {
        private readonly IDailyCloseoutService _dailyCloseoutService;

        public DailyCloseoutController(
            ILogger logger,
            IDailyCloseoutService dailyCloseoutService)
            : base(logger)
        {
            this.Logger.Information("Daily Closeout Controller Created.");

            this._dailyCloseoutService = dailyCloseoutService;
        }

        [HttpGet]
        [Route("dailycloseout")]
        public async Task<ActionResult> Index()
        {
            var model = new DailyCloseoutViewModel();

            await model.LoadForDetailsAsync(this._dailyCloseoutService);

            return View("~/Areas/Accounting/Views/DailyCloseout/Index.cshtml", model);
        }

        [HttpGet]
        [Route("dailycloseout/breakdown-report")]
        public async Task<ActionResult> BreakdownReport(DailyCloseoutBreakdownReportRangeViewModel range)
        {
            var viewModel = new DailyCloseoutBreakdownReportViewModel();

            await viewModel.LoadForBreakdownReportAsync(this._dailyCloseoutService, range);

            return View("~/Areas/Accounting/Views/DailyCloseout/BreakdownReport.cshtml", viewModel);
        }

        [HttpGet]
        [RenderAsPDF]
        [Route("dailycloseout/breakdown-report-pdf")]
        public ActionResult BreakdownReportPdf(DailyCloseoutBreakdownReportRangeViewModel range)
        {
            var viewModel = new DailyCloseoutBreakdownReportViewModel();

            // Running the task in this manner was necessary to work correctly with the RenderAsPDF
            // processing. Using the async/await pattern caused the custom page margins to
            // be ignored.
            var task = Task.Run(async () =>
            {
                await viewModel.LoadForBreakdownReportAsync(this._dailyCloseoutService, range);
            });

            // Wait for the task to complete.
            task.Wait();

            viewModel.PdfMode = true;

            MVCToPDF.ResultFileName = viewModel.ResultFileName;
            EO.Pdf.HtmlToPdf.Options.UsePrintMedia = true;

            return View("~/Areas/Accounting/Views/DailyCloseout/BreakdownReport.cshtml", viewModel);
        }

        [HttpGet]
        [Route("dailycloseout/export")]
        public async Task<ActionResult> ExportTransactions()
        {
            var lastCloseoutDate = await this._dailyCloseoutService.GetDailyCloseoutLastCloseoutDateAsync();

            var transactions = await this._dailyCloseoutService.GetDailyCloseoutPendingTransactionsAsync(lastCloseoutDate);

            var results = Mapper.Map<List<DailyCloseoutPendingTransactionViewModel>>(transactions);

            var fileName = $"Daily Closeout Pending Transactions {DateTime.Today:MMddyyyy}";
            fileName = FileHelper.GetSafeFileName(fileName);


            List<DailyCloseoutPendingTransactionsExcelDto> listOfObjects = new List<DailyCloseoutPendingTransactionsExcelDto>();
            foreach (var trans in results)
            {
                DailyCloseoutPendingTransactionsExcelDto objectClass = new DailyCloseoutPendingTransactionsExcelDto();
                objectClass.Contract = Convert.ToString(trans.ContractId);
                objectClass.JournalId = trans.JournalId;
                objectClass.PostedDate = trans.PostedDate;
                objectClass.Description = trans.Description;
                objectClass.Debit = trans.Debit;
                objectClass.Credit = trans.Credit;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, fileName);
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }


        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("dailycloseout/processcloseout")]
        public async Task<ActionResult> ProcessDailyCloseout()
        {
            await this._dailyCloseoutService.ProcessDailyCloseoutAsync(this.User);

            // display a success message
            this.AddSuccessAlert("The Daily Closeout has been processed successfully.");

            return RedirectToAction("Index");
        }
    }
}