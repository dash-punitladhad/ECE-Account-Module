﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.ViewModels.Contract;
    using Infinity.Mobius.ExceptionHandling;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Contract = ECE.CRM.WebUI.ViewModels.Contract;

    [Authorize]
    [RouteArea("accounting")]
    public class ContractWorkSheetController : BaseAccountingController
    {
        private static readonly string DepositUnpostSuccess = "Deposit un-posted successfully.";
        private static readonly string DepositUnpostSuccessNoECE = "Deposit un-posted successfully. However, as non-ECE Expenses were paid from the contract, only the Income and GL entries have been updated.";
        private static readonly string ContractSendError = "An error occurred while sending the contract.";
        private static readonly string ContactNoArtistAgreementFound = "<strong>NO ARTIST AGREEMENT FOUND:</strong> Please have the Booking Agent create an Artist Agreement prior to sending the Contract to the Artist.";
        private static readonly string ContractSendSuccess = "Contract has been sent.";
        private static readonly string ContractSignatureMarked = "Signature marked as received.";
        private static readonly string ContractSignatureRejected = "Signature has been rejected.";
        private static readonly string DocumentDeleteSuccess = "Document deleted successfully.";
        private static readonly string SignatureDeleteSuccess = "Signature deleted successfully.";
        private static readonly string ContractAlreadyCancelledError = "ERROR: No action taken, this contract was already cancelled.";
        private static readonly string ContractCancelError = "Your permissions do not allow you to cancel this contract.";
        private static readonly string ContractCancelSuccess = "Contract cancelled successfully.";
        private static readonly string ContractCancelUpdateError = "Your permissions do not allow you to update the cancellation of this contract.";
        private static readonly string ContractCancelUpdateSuccess = "Updates applied successfully.";

        private readonly IContactService _contactService;
        private readonly IContractService _contractService;
        private readonly IContractDepositService _contractDepositService;
        private readonly IContractDocumentService _contractDocumentService;
        private readonly IContractEventDateService _contractEventDateService;
        private readonly IContractSignatureService _contractSignatureService;
        private readonly IContractCancellationService _contractCancellationService;
        private readonly IDocumentService _documentService;
        private readonly IUserService _userService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IArtistService _artistService;
        private readonly IPayrollService _payrollService;
        private readonly IContractArtistAgreementService _contractArtistAgreementService;

        public ContractWorkSheetController(ILogger logger,
            IContactService contactService,
            IContractService contractService,
            IContractDepositService contractDepositService,
            IContractDocumentService contractDocumentService,
            IContractEventDateService contractEventDateService,
            IContractSignatureService contractSignatureService,
            IContractCancellationService contractCancellationService,
            IDocumentService documentService,
            IUserService userService,
            IGeneralLedgerService generalLedgerService,
            IArtistService artistService,
            IPayrollService payrollService,
            IContractArtistAgreementService contractArtistAgreementService)
            : base(logger)
        {
            this._contactService = contactService;
            this._contractService = contractService;
            this._contractDepositService = contractDepositService;
            this._contractDocumentService = contractDocumentService;
            this._contractEventDateService = contractEventDateService;
            this._contractSignatureService = contractSignatureService;
            this._contractCancellationService = contractCancellationService;
            this._documentService = documentService;
            this._userService = userService;
            this._generalLedgerService = generalLedgerService;
            this._artistService = artistService;
            this._payrollService = payrollService;
            this._contractArtistAgreementService = contractArtistAgreementService;
        }

        [Route("contractworksheet")]
        public async Task<ActionResult> Index(int? id)
        {
            var viewModel = new ContractWorkSheetViewModel();

            if (!id.HasValue)
            {
                return View("Index");
            }

            var contract = await _contractService.GetByIdAsync(id.Value, includeChildren: true);
            if (contract == null)
            {
                this.AddDangerAlert($"No contract found with Contract # {id}.");
                return View("Index");
            }

            if (contract.ContractStatusId == (int)ContractStatus.InProgress)
            {
                this.AddDangerAlert($"Contract # {id} has not been created yet.");
                return View("Index");
            }

            var contractEventDates = await this._contractEventDateService.GetByContractIdAsync(contract.ContractId);
            contract.EventDatesObject = contractEventDates
                .OrderBy(x => x.EventDate)
                .ToList();

            // deposits
            var depositDtos = await this._contractDepositService.GetContractDepositsByContractIdAsync(id.Value);
            var deposits = ContractDepositViewModel.GetDeposits(contract, depositDtos);

            // signatures
            var signatureDtos = await this._contractSignatureService.GetByContractIdAsync(id.Value);
            var signatures = Mapper.Map<IList<ViewModels.ContractSignatureViewModel>>(signatureDtos).ToList();

            foreach (var sig in signatures)
            {
                var transaction = contract.ContractTransactions.Find(sig);
                if (transaction != null)
                {
                    sig.SetDisplayName(transaction);
                }
                else if (sig.EntityTypeId == (int)EntityType.Artist)
                {
                    sig.DueFromDisplay = "ARTIST";
                    var artist = await this._artistService.GetArtistByIdAsync(sig.EntityId);
                    if (artist != null)
                    {
                        sig.DueFromDisplay = $"Artist - {artist.Name}";
                    }
                }

                if (sig.EntityTypeId == (int)EntityType.Presenter &&
                    (string.IsNullOrWhiteSpace(sig.DueFromDisplay) ||
                     sig.DueFromDisplay == "PRESENTER"))
                {
                    sig.DueFromDisplay = "PRESENTER";
                    if (!string.IsNullOrWhiteSpace(contract.PresenterAccountName))
                    {
                        sig.DueFromDisplay = $"Presenter - {contract.PresenterAccountName}";
                    }
                }
                else if (sig.EntityTypeId == (int)EntityType.Presenter)
                {
                    sig.DueFromDisplay = "PRESENTER";
                }

                var entityType = (EntityType)sig.EntityTypeId;
                var entityId = sig.EntityId;

                if (entityType == EntityType.Presenter)
                {
                    entityType = EntityType.Contract;
                    entityId = contract.ContractId;
                }

                var contacts = await this._contactService.GetContactsAsync(entityType, entityId);

                var primaryContact = contacts.FirstOrDefault(y => y.IsPrimary);

                sig.ContactEmail = primaryContact?.EmailAddress;
                sig.ContactFirstName = primaryContact?.FirstName;
                sig.ContactLastName = primaryContact?.LastName;

                sig.CanEmail = true;
                if (sig.EntityTypeId == (int)EntityType.Artist)
                {
                    // sig.CanEmail = (await this._userService.GetUserByEntityAsync(sig.EntityId, ECERole.Artist)) == null;
                    var artistUser = await this._userService.GetUserByEntityAsync(sig.EntityId, ECERole.Artist, true);
                    sig.CanEmail = artistUser == null;
                }
                else if (sig.EntityTypeId == (int)EntityType.Presenter)
                {
                    sig.CanEmail = false;
                }

                if (!sig.CanEmail)
                {
                    sig.ContactEmail = "notRequired";
                    sig.ContactFirstName = "notRequired";
                    sig.ContactLastName = "notRequired";
                }
            }

            // documents

            var documents = await ContractDocumentViewModel.GetContractDocumentsAsync(id.Value, _contractDocumentService, _contractService, Url, this.User);

            var redirectUrl = Url.Action("Index", "ContractWorkSheet", new { area = "Accounting", id = contract.ContractId });
            var internalId = (int)DocumentType.InternalUseOnly;
            viewModel.LoadData(contract, deposits, signatures, documents.Where(_ => _.DocumentTypeId != internalId).ToList(), redirectUrl);

            if ((contract.ContractStatusId == (int)ContractStatus.Created) ||
                contract.ContractStatusId == (int)ContractStatus.PartiallyCanceled ||
                contract.ContractStatusId == (int)ContractStatus.Canceled ||
                contract.ContractStatusId == (int)ContractStatus.Issued ||
                contract.ContractStatusId == (int)ContractStatus.ReIssue ||
                contract.IsNoIssue.HasValue ||
                contract.IssueDate.HasValue
                )
            {
                if (await _generalLedgerService.ContractIsInitializedAsync(contract.ContractId))
                {
                    viewModel.CanPostDeposits = true;
                }
                else
                {
                    viewModel.CanPostDeposits = false;
                    viewModel.CanInitialize = true;
                }
            }

            return View("Index", viewModel);
        }

        [Route("contractworksheet/initialize/{id}")]
        public async Task<ActionResult> NotInitialized(int id)
        {
            var contract = await _contractService.GetByIdAsync(id, includeChildren: true);
            if (contract == null)
            {
                this.AddDangerAlert($"No contract found with Contract # {id}.");
                return View("Index");
            }

            var viewModel = new ContractInitializeViewModel();

            // deposits
            var depositDtos = await this._contractDepositService.GetContractDepositsByContractIdAsync(id);
            var deposits = ContractDepositViewModel.GetDeposits(contract, depositDtos);

            var redirectUrl = Url.Action("Index", "ContractWorkSheet", new { area = "Accounting", id = contract.ContractId });

            viewModel.LoadData(contract, deposits, null, null, redirectUrl);

            return View("NotInitialized", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_CREATE)]
        public async Task<ActionResult> Initialize(ContractInitializeViewModel viewModel)
        {
            try
            {
                await this._contractService.InitializeAsync(viewModel.ContractId.GetValueOrDefault(), User);

                this.AddSuccessAlert("Contract successfully initialized");
            }
            catch (Exception ex)
            {
                this.AddDangerAlert(ex.GetBaseException());
            }

            return RedirectToAction("Index", new { id = viewModel.ContractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_CREATE)]
        public async Task<ActionResult> CreateDeposit(ContractWorkSheetViewModel viewModel)
        {
            if (viewModel == null || viewModel.CreateContractDeposit == null)
            {
                this.AddInvalidDataAlert();
                return RedirectToAction("Index", new { id = viewModel.ContractId });
            }

            ModelState.Clear();
            if (!this.TryValidateModel(viewModel.CreateContractDeposit, "CreateContractDeposit"))
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index", new { id = viewModel.ContractId });
            }

            var depositDto = Mapper.Map<ContractDepositDto>(viewModel.CreateContractDeposit);
            depositDto.AllocatedAmount = depositDto.AppliedAmount;

            var result = await this._contractDepositService.PreCreateDepositCheckAsync(depositDto);
            if (result.DepositExceedsDueAmount)
            {
                this.AddInvalidDataAlert($"DEPOSIT NOT POSTED: Deposit exceeds the amount due from the selected payee of {result.ExpectedIncomeAmount:C}.");
                return RedirectToAction("Index", new { id = viewModel.ContractId });
            }

            await this._contractDepositService.PostContractDepositAsync(depositDto, User);

            this.AddSuccessAlert(GenerateCreateSuccessMessage("Deposit"));
            return RedirectToAction("Index", new { id = viewModel.ContractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> UnpostDeposit(int contractId, int depositId, bool canUnpayECETransactions)
        {
            await this._contractDepositService.UnpostContractDepositAsync(depositId, User);

            if (canUnpayECETransactions)
            {
                this.AddSuccessAlert(DepositUnpostSuccess);
            }
            else
            {
                this.AddSuccessAlert(DepositUnpostSuccessNoECE);
            }

            return RedirectToAction("Index", new { id = contractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> SendContract(ContractWorkSheetViewModel viewModel)
        {
            if (viewModel == null || viewModel.SendContract == null)
            {
                this.AddInvalidDataAlert(ContractSendError);
                return RedirectToAction("Index", new { id = viewModel.ContractId });
            }

            ModelState.Clear();
            if (!this.TryValidateModel(viewModel.SendContract, "SendContract"))
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index", new { id = viewModel.ContractId });
            }

            var contractSignatureDto = new ContractSignatureDto()
            {
                ContractId = viewModel.ContractId.GetValueOrDefault(),
                ContractSignatureId = viewModel.SendContract.ContractSignatureId,
                EntityId = viewModel.SendContract.EntityId,
                EntityTypeId = viewModel.SendContract.EntityTypeId,
                DueDate = viewModel.SendContract.DateDue
            };

            // Create a http client and pass into service method, it may or may not get used :'(
            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler { CookieContainer = cookieContainer };

            var success = false;
            var errorMessage = ContractSendError;

            try
            {
                using (var client = new HttpClient(handler))
                {
                    var helper = new UrlHelper(this.Request.RequestContext);
                    string scheme = helper.RequestContext.HttpContext.Request.Url?.Scheme ?? " ";

                    var url = new Uri(helper.Action("Index", "ContractPrint", new { area = string.Empty, id = viewModel.ContractId.GetValueOrDefault(), sendContract = true }, scheme));

                    var authenticationCookie = new Cookie(
                        ApplicationHelper.AuthCookieName,
                        this.Request.Cookies[ApplicationHelper.AuthCookieName].Value);
                    cookieContainer.Add(url, authenticationCookie);

                    var contact = new ContactDto
                    {
                        EmailAddress = viewModel.SendContract.Email,
                        FirstName = viewModel.SendContract.FirstName,
                        LastName = viewModel.SendContract.LastName,
                    };

                    success = await this._contractSignatureService.SendContractAsync(contractSignatureDto, contact, User, client, url);
                }
            }
            catch (NoArtistAgreementException ex)
            {
                this.Logger.LogInformation(ex.Message);

                errorMessage = ContactNoArtistAgreementFound;

                success = false;
            }
            catch (SendContractEmailException ex)
            {
                this.Logger.LogInformation(ex.Message);

                errorMessage = $"<strong>CONTRACT NOT SENT:</strong> {ex.Message}";

                success = false;
            }
            catch (Exception ex)
            {
                ExceptionPolicy.HandleException(ex, PolicyName.Application);

                success = false;
            }

            if (success)
            {
                this.AddSuccessAlert(ContractSendSuccess);
            }
            else
            {
                this.AddDangerAlert(errorMessage);
            }

            return RedirectToAction("Index", new { id = viewModel.ContractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> MarkSignatureReceived(ContractWorkSheetViewModel viewModel)
        {
            var i = viewModel.MarkSignatureAsReceived.File.FileName.LastIndexOf('.');
            var name = $"{viewModel.ContractId}-{viewModel.MarkSignatureAsReceived.DateReceived.ToString("MM_dd_yyyy")}";
            var ext = viewModel.MarkSignatureAsReceived.File.FileName.Substring(i + 1).ToUpper();

            var documentDto = new DocumentDto()
            {
                Contents = viewModel.MarkSignatureAsReceived.File.InputStream,
                OriginalFileName = name,
                StorageFileName = viewModel.MarkSignatureAsReceived.File.FileName,
                Description = $"{viewModel.MarkSignatureAsReceived.DateReceived.ToString("MM-dd-yyyy")} Signed Contract",
                DocumentTypeId = (int)DocumentType.Contract,
                DocumentExtension = new LookupDto() { Text = ext }
            };

            if (viewModel.MarkSignatureAsReceived.EntityTypeId == (int)EntityType.Artist)
            {
                var contract = await _contractService.GetByIdAsync(viewModel.ContractId.GetValueOrDefault(), includeChildren: false);
                if (contract == null)
                {
                    this.AddDangerAlert($"No contract found with Contract # {viewModel.ContractId.GetValueOrDefault()}.");
                }

                if (contract.IsBuySell == true || contract.ContractTypeId == (int)ContractType.Special)
                {
                    var artist = await _artistService.GetArtistByIdAsync(viewModel.MarkSignatureAsReceived.EntityId);

                    documentDto.OriginalFileName = $"{name}_{artist.Name}_signed_agreement";
                    documentDto.Description = $"{viewModel.MarkSignatureAsReceived.DateReceived.ToString("MM-dd-yyyy")} Signed Artist Agreement";
                    documentDto.DocumentTypeId = (int)DocumentType.ArtistAgreement;
                }
            }

            var contractSignatureDto = new ContractSignatureDto()
            {
                ContractId = viewModel.ContractId.GetValueOrDefault(),
                ContractSignatureId = viewModel.MarkSignatureAsReceived.ContractSignatureId,
                ReceivedDate = viewModel.MarkSignatureAsReceived.DateReceived,
                SendEmailNotifications = viewModel.MarkSignatureAsReceived.SendEmailNotifications,
                EntityId = viewModel.MarkSignatureAsReceived.EntityId,
                EntityTypeId = viewModel.MarkSignatureAsReceived.EntityTypeId,
            };

            try
            {
                await this._contractSignatureService.MarkAsReceivedAsync(contractSignatureDto, documentDto, User);
            }
            finally
            {
                if (documentDto.Contents != null)
                {
                    documentDto.Contents.Close();
                    documentDto.Contents.Dispose();
                }
            }

            this.AddSuccessAlert(ContractSignatureMarked);
            return RedirectToAction("Index", new { id = viewModel.ContractId });
        }

        [HttpGet]
        public async Task<ActionResult> ViewContract(int contractId)
        {
            // If an uploaded contract (wet signature) exists return the latest record. Otherwise use the Print method in the ContractController.
            var contractDoc = _documentService
                .GetDocuments(EntityType.Contract, contractId)
                .OrderByDescending(x => x.CreatedDate)
                .FirstOrDefault(x => x.DocumentTypeId == (int)DocumentType.Contract && !x.IsContractPDF);

            if (contractDoc != null)
            {
                var contentStream = this._documentService.GetFromStorage(contractDoc, EntityType.Contract.ToString());
                var mimeType = LookupCache.GetDocumentExtensions()
                    .FirstOrDefault(x => x.DocumentExtensionId == contractDoc.DocumentExtensionId)?.MimeType;
                return this.File(contentStream.ToArray(), mimeType);
            }

            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler { CookieContainer = cookieContainer };

            using (var client = new HttpClient(handler))
            {
                var helper = new UrlHelper(this.Request.RequestContext);
                string scheme = helper.RequestContext.HttpContext.Request.Url.Scheme;
                var url = new Uri(helper.Action("Index", "ContractPrint", new { area = string.Empty, id = contractId }, scheme));

                var authenticationCookie = new Cookie(
                    ApplicationHelper.AuthCookieName,
                    this.Request.Cookies[ApplicationHelper.AuthCookieName].Value);
                cookieContainer.Add(url, authenticationCookie);

                var result = await client.GetAsync(url);
                var resultContents = await result.Content.ReadAsStreamAsync();
                var mimeType = LookupCache.GetDocumentExtensions()
                    .FirstOrDefault(x => x.DocumentExtensionId == (int)DocumentExtension.PDF)?.MimeType;
                return this.File(resultContents, mimeType);
            }
        }

        [HttpGet]
        public async Task<ActionResult> ViewArtistAgreement(int contractId, int artistId)
        {
            var contractSignatures = await _contractSignatureService.GetByEntityIdAndEntityTypeAsync(contractId, artistId, (int)EntityType.Artist);

            var contractSignature = contractSignatures.FirstOrDefault();
            if (contractSignature != null && contractSignature.SignatureId == null)
            {
                var contractDoc = _documentService
                    .GetDocuments(EntityType.ContractSignature, contractSignature.ContractSignatureId)
                    .OrderByDescending(x => x.CreatedDate)
                    .FirstOrDefault(x => x.DocumentTypeId == (int)DocumentType.ArtistAgreement);

                if (contractDoc != null)
                {
                    var contentStream = this._documentService.GetFromStorage(contractDoc, EntityType.Contract.ToString());
                    var mimeType = LookupCache.GetDocumentExtensions()
                        .FirstOrDefault(x => x.DocumentExtensionId == contractDoc.DocumentExtensionId)?.MimeType;
                    return this.File(contentStream.ToArray(), mimeType);
                }
            }

            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler { CookieContainer = cookieContainer };

            using (var client = new HttpClient(handler))
            {
                var helper = new UrlHelper(this.Request.RequestContext);
                string scheme = helper.RequestContext.HttpContext.Request.Url.Scheme;
                var url = new Uri(helper.Action("Index", "ArtistAgreementPrint", new { area = string.Empty, contractId, artistId }, scheme));

                var authenticationCookie = new Cookie(
                    ApplicationHelper.AuthCookieName,
                    this.Request.Cookies[ApplicationHelper.AuthCookieName].Value);
                cookieContainer.Add(url, authenticationCookie);

                var result = await client.GetAsync(url);
                var resultContents = await result.Content.ReadAsStreamAsync();
                var mimeType = LookupCache.GetDocumentExtensions()
                    .FirstOrDefault(x => x.DocumentExtensionId == (int)DocumentExtension.PDF)?.MimeType;
                return this.File(resultContents, mimeType);
            }
        }

        [HttpGet]
        public async Task<ActionResult> ViewArtistContract(int contractId, int artistId)
        {
            var contractSignatures = await _contractSignatureService.GetByEntityIdAndEntityTypeAsync(contractId, artistId, (int)EntityType.Artist);

            var contractSignature = contractSignatures.FirstOrDefault();
            if (contractSignature != null && contractSignature.SignatureId == null)
            {
                var contractDoc = _documentService
                    .GetDocuments(EntityType.ContractSignature, contractSignature.ContractSignatureId)
                    .OrderByDescending(x => x.CreatedDate)
                    .FirstOrDefault(x => x.DocumentTypeId == (int)DocumentType.Contract && !x.IsContractPDF);

                if (contractDoc != null)
                {
                    var contentStream = this._documentService.GetFromStorage(contractDoc, EntityType.Contract.ToString());
                    var mimeType = LookupCache.GetDocumentExtensions()
                        .FirstOrDefault(x => x.DocumentExtensionId == contractDoc.DocumentExtensionId)?.MimeType;
                    return this.File(contentStream.ToArray(), mimeType);
                }
            }

            var cookieContainer = new CookieContainer();
            var handler = new HttpClientHandler { CookieContainer = cookieContainer };

            using (var client = new HttpClient(handler))
            {
                var helper = new UrlHelper(this.Request.RequestContext);
                string scheme = helper.RequestContext.HttpContext.Request.Url.Scheme;
                var url = new Uri(helper.Action("Index", "ContractPrint", new { area = string.Empty, id = contractId }, scheme));

                var authenticationCookie = new Cookie(
                    ApplicationHelper.AuthCookieName,
                    this.Request.Cookies[ApplicationHelper.AuthCookieName].Value);
                cookieContainer.Add(url, authenticationCookie);

                var result = await client.GetAsync(url);
                var resultContents = await result.Content.ReadAsStreamAsync();
                var mimeType = LookupCache.GetDocumentExtensions()
                    .FirstOrDefault(x => x.DocumentExtensionId == (int)DocumentExtension.PDF)?.MimeType;
                return this.File(resultContents, mimeType);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> RejectSignature(int contractId, int contractSignatureId)
        {
            await this._contractSignatureService.RejectSignatureAsync(contractId, contractSignatureId, User);

            this.AddSuccessAlert(ContractSignatureRejected);

            return RedirectToAction("Index", new { id = contractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> UpdateNotes(ContractWorkSheetViewModel viewModel)
        {
            await this._contractService.UpdateNotesAsync(viewModel.ContractId.GetValueOrDefault(), viewModel.Notes);

            this.AddSuccessAlert(GenerateUpdateSuccessMessage("Contract Notes"));
            return RedirectToAction("Index", new { id = viewModel.ContractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public ActionResult DeleteDocument(int contractId, int documentId)
        {
            this._documentService.RemoveDocumentFrom(EntityType.Contract, contractId, documentId, User.GetUserId());

            this.AddSuccessAlert(DocumentDeleteSuccess);
            return RedirectToAction("Index", new { id = contractId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> DeleteSignature(int contractId, int contractSignatureId)
        {
            await this._contractSignatureService.DeleteAsync(contractSignatureId);

            this.AddSuccessAlert(SignatureDeleteSuccess);
            return RedirectToAction("Index", new { id = contractId });
        }

        [HttpGet]
        public async Task<ActionResult> CancelContractModal(int contractId)
        {
            var viewModel = new ContractCancellationViewModel
            {
                ContractId = contractId
            };

            var contract = await this._contractService.GetByIdAsync(contractId, true);
            if (contract == null)
            {
                return this.EntityNotFound(EntityType.Contract, contractId);
            }

            var paidDeposit = contract.ContractTransactions.FirstOrDefault(x => x.IsIncome && x.PaidDate != null);
            if (paidDeposit != null)
            {
                viewModel.HasReceivedDeposits = true;
            }

            viewModel.LoadForCreate();

            return this.PartialView("_CancelContractModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.CONTRACT_CANCEL)]
        public async Task<ActionResult> CancelContract(ContractCancellationViewModel viewModel, string returnUrl)
        {
            var redirectAction = string.IsNullOrWhiteSpace(returnUrl)
                    ? this.RedirectToAction("Details", "Contract", new { area = string.Empty, id = viewModel.ContractId }) as ActionResult
                    : this.Redirect(returnUrl) as ActionResult;

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return redirectAction;
            }

            var contractViewModel = new Contract.ContractDetailsViewModel();

            var contract = await this._contractService.GetByIdAsync(viewModel.ContractId);
            if (contract == null)
            {
                return EntityNotFound(EntityType.Contract, viewModel.ContractId);
            }

            await contractViewModel.SetPermissionsAsync(contract, this._contractService, this._userService, this.User);
            if (!contractViewModel.CanPartiallyCancel)
            {
                if (contract.CancellationDate.HasValue)
                {
                    this.AddDangerAlert(ContractAlreadyCancelledError);
                }
                else
                {
                    this.AddDangerAlert(ContractCancelError);
                }

                return redirectAction;
            }

            var contractCancellation = Mapper.Map<ContractCancellationDto>(viewModel);

            await this._contractService.CancelContractAsync(contractCancellation, User);

            this.AddSuccessAlert(ContractCancelSuccess);
            return redirectAction;
        }

        [HttpGet]
        public async Task<ActionResult> UpdateCancellationModal(int contractId)
        {
            var contract = await this._contractService.GetByIdAsync(contractId, true);
            if (contract == null)
            {
                return this.EntityNotFound(EntityType.Contract, contractId);
            }

            var viewModel = new UpdateCancellationViewModel
            {
                ContractId = contractId
            };

            var paidDeposit = contract.ContractTransactions.FirstOrDefault(x => x.IsIncome && x.PaidDate != null);
            if (paidDeposit != null)
            {
                viewModel.HasReceivedDeposits = true;
            }

            var cancellations = await this._contractCancellationService.GetByContractIdAsync(contractId);

            viewModel.LoadForUpdate(cancellations);

            viewModel.Cancellation.GenerateRefunds = contract.ContractTransactions.Any(x => x.ContractTransactionTypeId == (int)ContractTransactionType.Refund);

            return this.PartialView("_UpdateCancellationModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.CONTRACT_CANCEL)]
        public async Task<ActionResult> UpdateCancellation(UpdateCancellationViewModel viewModel, string returnUrl)
        {
            var redirectAction = string.IsNullOrWhiteSpace(returnUrl)
                    ? this.RedirectToAction("Details", "Contract", new { area = string.Empty, id = viewModel.ContractId }) as ActionResult
                    : this.Redirect(returnUrl) as ActionResult;

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return redirectAction;
            }

            var contractViewModel = new Contract.ContractDetailsViewModel();

            var contract = await this._contractService.GetByIdAsync(viewModel.ContractId);
            if (contract == null)
            {
                return EntityNotFound(EntityType.Contract, viewModel.ContractId);
            }

            await contractViewModel.SetPermissionsAsync(contract, this._contractService, this._userService, this.User);
            if (!contractViewModel.CanFullyCancel)
            {
                this.AddDangerAlert(ContractCancelUpdateError);
                return redirectAction;
            }

            var contractCancellation = Mapper.Map<ContractCancellationDto>(viewModel);

            await this._contractService.UpdateCanceledContractAsync(contractCancellation, User);

            this.AddSuccessAlert(ContractCancelUpdateSuccess);
            return redirectAction;
        }
    }
}