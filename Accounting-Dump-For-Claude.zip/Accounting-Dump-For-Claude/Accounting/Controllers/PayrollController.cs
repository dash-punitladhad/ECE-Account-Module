﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using CsvHelper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using Infinity.Mobius.Logging;
    using Infinity.Mobius.TimeProvider;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class PayrollController : BaseAccountingController
    {
        private static readonly string NoCommissionProgamWarningMessage = "<strong>Log Entry Not Added</strong>: No commission program is confgured for this agent. Please configure one using the Commission Management";
        private static readonly string PayrollNotCreatedMessage = "<strong>Payroll Not Created</strong>: No commission program is confgured for one or more agents. Please configure one using the Commission Management";
        private static readonly string PayrollNotCreatedForAgentMessage = "<strong>Payroll Not Created</strong>: No commission program is confgured for agent {0}. Please configure one using the Commission Management";

        private readonly IUserService _userService;
        private readonly IPayrollService _payrollService;
        private readonly ILookupService _lookupService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly ICommissionManagementService _commissionManagementService;

        public PayrollController(ILogger logger,
            IUserService userService,
            IPayrollService payrollService,
            ILookupService lookupService,
            IContractTransactionService contractTransactionService,
            ICommissionManagementService commissionManagementService)
            : base(logger)
        {
            _userService = userService;
            _payrollService = payrollService;
            _lookupService = lookupService;
            _contractTransactionService = contractTransactionService;
            _commissionManagementService = commissionManagementService;
        }

        [HttpGet]
        [Route("payroll")]
        public async Task<ActionResult> Index(string date)
        {
            PayrollPageViewModel viewModel = null;

            DateTime asOfDate = ParseAsOfDate(date);

            try
            {
                var batch = await _payrollService.GetPendingPayrollBatchAsync();
                if (batch == null)
                {
                    batch = await _payrollService.CalculateNextPayrollBatchAsync(asOfDate);
                    viewModel = Mapper.Map<PayrollPageViewModel>(batch as PreviewPayrollBatchDto);
                }
                else
                {
                    viewModel = Mapper.Map<PayrollPageViewModel>(batch);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex);

                if (TempData.ContainsKey(BootstrapAlert.Danger) == false)
                {
                    AddDangerAlert("The next payroll batch could not be calculated.");
                }

                viewModel = new PayrollPageViewModel();
            }

            viewModel.AsOfDate = asOfDate;

            return View("~/Areas/Accounting/Views/Payroll/Index.cshtml", viewModel);
        }

        [HttpGet]
        [Route("payroll/details/{id}")]
        public async Task<ActionResult> Details(int id)
        {
            var batch = await _payrollService.GetPayrollBatchByIdAsync(id);
            if (batch == null)
            {
                return EntityNotFound();
            }

            var model = Mapper.Map<PayrollDetailsViewModel>(batch);

            return View("~/Areas/Accounting/Views/Payroll/Details.cshtml", model);
        }

        [HttpGet]
        [Route("payroll/preview")]
        public async Task<ActionResult> Preview(string date)
        {
            DateTime asOfDate = ParseAsOfDate(date);

            var batch = await _payrollService.CalculateNextPayrollBatchAsync(asOfDate);
            if (batch == null)
            {
                AddDangerAlert("Cannot preview payroll batch.");
                return RedirectToAction("Index");
            }

            PreviewPayrollBatchDto previewBatch = batch as PreviewPayrollBatchDto;

            var model = Mapper.Map<PreviewPayrollDetailsViewModel>(previewBatch);

            return View("~/Areas/Accounting/Views/Payroll/Preview.cshtml", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/runpayroll")]
        public async Task<ActionResult> RunPayroll(RunPayrollViewModel viewModel)
        {
            try
            {
                var batch = await _payrollService.RunPayrollAsync(viewModel.AsofDate, User);
                if (batch == null)
                {
                    AddDangerAlert("Cannot create payroll batch.");
                    return RedirectToAction("Index");
                }

                return RedirectToAction("Details", new { id = batch.PayrollBatchId });
            }
            catch (NoCommissionProgramException ex)
            {
                var errorMessage = PayrollNotCreatedMessage;

                var data = ex.Data["DTO"] as string;
                if (!string.IsNullOrWhiteSpace(data))
                {
                    var log = JsonConvert.DeserializeObject<AgentPayrollLogDto>(data);

                    var agentList = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();
                    var agent = agentList.FirstOrDefault(x => x.AppUserId == log.AgentId);
                    if (agent != null)
                    {
                        errorMessage = string.Format(PayrollNotCreatedForAgentMessage, agent.FullName);
                    }
                }

                AddDangerAlert(errorMessage);
            }
            catch (Exception ex)
            {
                AddDangerAlert(ex.GetBaseException());
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/removepayroll")]
        public async Task<ActionResult> RemovePayroll(RunPayrollViewModel viewModel)
        {
            await _payrollService.DeletePendingPayrollBatch();

            AddSuccessAlert("Pending payroll batch removed.");
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/postpayroll/{id}")]
        public async Task<ActionResult> PostPayroll(int id)
        {
            var batch = await _payrollService.GetPayrollBatchByIdAsync(id);
            if (batch == null)
            {
                return EntityNotFound();
            }

            if (batch.IsPosted)
            {
                AddDangerAlert("Cannot re-post a Posted Batch.");
                return RedirectToAction("Details", new { id = id });
            }

            await _payrollService.PostPayrollAsync(batch, User);

            AddSuccessAlert("Payroll posted successfully.");
            return RedirectToAction("Details", new { id = id });
        }

        [HttpGet]
        [Route("payroll/exportdetails/{payrollBatchId}")]
        public async Task<ActionResult> ExportDetails(int payrollBatchId)
        {
            var batch = await _payrollService.GetPayrollBatchByIdAsync(payrollBatchId);
            if (batch == null)
            {
                return EntityNotFound();
            }

            var detailsLog = await _payrollService.GetPayrollDetailsLogsAsync(payrollBatchId);

            var fileName = $"{DataHelper.ToStandardString(batch.PayrollPeriod)}-PayrollDetails";
            fileName = FileHelper.GetSafeFileName(fileName);
            List<PayrollDetailsLogExcelDto> listOfObjects = new List<PayrollDetailsLogExcelDto>();
            foreach (var detail in detailsLog)
            {
                PayrollDetailsLogExcelDto objectClass = new PayrollDetailsLogExcelDto();
                objectClass.Agent = detail.AgentName;
                objectClass.EceCollections = detail.ECECollections;
                objectClass.AgentEarned = detail.AgentEarned;
                objectClass.Programs = detail.Programs;
                objectClass.TotalCommissions = (detail.Programs + detail.AgentEarned);
                objectClass.Transfers = detail.Transfers;
                objectClass.Mentorships = detail.Mentorships;
                objectClass.AgentWorking = detail.AgentWorking;
                objectClass.AgentTotal = detail.AgentTotal;
                objectClass.AgentId = detail.AgentId;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;

                string baseUrl = HttpContext.Request.Url.GetLeftPart(UriPartial.Authority);
                try
                {
                    if (dt.Columns.IndexOf("AGENTID") != -1)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            string url = $"{baseUrl}/accounting/payroll/agentpayrolldetails/"+ Convert.ToString(dr["AGENTID"] + "?ispartial=false&isexclude=false");
                            dr[0] = "<a href='" + url + "'>" + Convert.ToString(dr[0]) + "</a>";
                        }
                        dt.Columns.Remove("AGENTID");
                    }

                }
                catch { }
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, fileName);
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }
        }

        [HttpGet]
        [Route("payroll/agentpayrolldetails/{payrollPaymentId}")]
        public async Task<ActionResult> AgentPayrollDetails(int payrollPaymentId)
        {
            var details = await _payrollService.GetAgentPayrollDetailsAsync(payrollPaymentId);

            var model = Mapper.Map<AgentPayrollDetailsViewModel>(details);

            var agentCommission = await _commissionManagementService.GetAgentCommissionByAgentIdAsync(details.AgentId);
            if (agentCommission == null || agentCommission.AgentCommissionId == null)
            {
                model.NoCommissionProgram = true;
            }

            return View("~/Areas/Accounting/Views/Payroll/AgentPayrollDetails.cshtml", model);
        }

        [HttpGet]
        [Route("payroll/agentpayrolleditlog/{payrollPaymentId}")]
        public async Task<ActionResult> AgentPayrollEditLog(int payrollPaymentId)
        {
            var details = await _payrollService.GetAgentPayrollDetailsAsync(payrollPaymentId);

            if (details.PostDate.HasValue)
            {
                return AccessForbidden();
            }

            var model = Mapper.Map<AgentPayrollDetailsViewModel>(details);

            return View("AgentPayrollEditLog", model);
        }

        [HttpGet]
        [Route("payroll/agentpayrolleditlog/LogEntryFormCreateModal/{payrollPaymentId}")]
        public async Task<ActionResult> LogEntryFormCreateModal(int payrollPaymentId)
        {
            var payment = await _payrollService.GetPayrollPaymentByIdAsync(payrollPaymentId);
            if (payment == null)
            {
                return EntityNotFound();
            }

            var viewModel = new AgentPayrollLogCreateViewModel();

            var logTypes = _lookupService
                .GetAllPayrollLogTypes()
                .Where(x => x.IsActive)
                .OrderBy(x => x.Name);

            viewModel.PayrollLogTypes = new SelectList(logTypes, "PayrollLogTypeId", "Name");
            viewModel.PayrollPaymentId = payment.PayrollPaymentId;

            var emptyList = new List<LookupDto>();
            viewModel.ContractExpenses = new SelectList(emptyList, "Value", "Text");

            return PartialView("_LogEntryFormCreateModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/agentpayrolleditlog/AgentPayrollCreateLog")]
        public async Task<ActionResult> AgentPayrollCreateLog(AgentPayrollLogCreateViewModel viewModel)
        {
            var payment = await _payrollService.GetPayrollPaymentByIdAsync(viewModel.PayrollPaymentId.GetValueOrDefault());
            if (payment == null)
            {
                return EntityNotFound();
            }

            var returlUrl = viewModel.ReturnUrl;
            if (string.IsNullOrWhiteSpace(returlUrl))
            {
                if (viewModel.PayrollPaymentId > 0)
                {
                    returlUrl = Url.Action("AgentPayrollEditLog", new { viewModel.PayrollPaymentId });
                }
                else
                {
                    returlUrl = Url.Action("Money", "Contract", new { area = string.Empty, id = viewModel.ContractId });
                }
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return Redirect(returlUrl);
            }

            var agentPayrollLog = new AgentPayrollLogDto();

            agentPayrollLog.CommissionRate = viewModel.CommissionRate.GetValueOrDefault();
            agentPayrollLog.ContractId = viewModel.ContractId.GetValueOrDefault();
            agentPayrollLog.ContractTransactionId = viewModel.ContractTransactionId;
            agentPayrollLog.GrossAmount = viewModel.GrossAmount.GetValueOrDefault();
            agentPayrollLog.NetAmount = viewModel.NetAmount.GetValueOrDefault();
            agentPayrollLog.PayrollLogTypeId = viewModel.PayrollLogTypeId.GetValueOrDefault();
            agentPayrollLog.PayrollPaymentId = viewModel.PayrollPaymentId;
            agentPayrollLog.ReceivedDate = viewModel.ReceivedDate.GetValueOrDefault();
            agentPayrollLog.AgentId = payment.AgentId;

            if (agentPayrollLog.ContractTransactionId.HasValue)
            {
                var transaction = await _contractTransactionService.GetByIdAsync(agentPayrollLog.ContractTransactionId.Value);
                if (transaction != null)
                {
                    agentPayrollLog.LineOfBusinessId = transaction.LineOfBusinessId.GetValueOrDefault();
                }
            }

            await _payrollService.CreateAgentPayrollLogAsync(agentPayrollLog, User);

            AddSuccessAlert("Log Entry Created Successfully");
            return Redirect(returlUrl);
        }

        [HttpGet]
        [Route("payroll/agentpayrolleditlog/LogEntryFormUpdateModal/{agentPayrollLogId}")]
        public async Task<ActionResult> LogEntryFormUpdateModal(int agentPayrollLogId)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(agentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var viewModel = new AgentPayrollLogUpdateViewModel();

            var logTypes = _lookupService
                .GetAllPayrollLogTypes()
                .Where(x => x.IsActive)
                .OrderBy(x => x.Name);

            viewModel.PayrollLogTypes = new SelectList(logTypes, "PayrollLogTypeId", "Name");

            viewModel.AgentPayrollLogId = agentPayrollLog.AgentPayrollLogId;
            viewModel.AgentId = agentPayrollLog.AgentId;
            viewModel.CommissionRate = agentPayrollLog.CommissionRate;
            viewModel.ContractId = agentPayrollLog.ContractId;
            viewModel.ContractTransactionId = agentPayrollLog.ContractTransactionId;
            viewModel.GrossAmount = agentPayrollLog.GrossAmount;
            viewModel.LineOfBusinessId = agentPayrollLog.LineOfBusinessId;
            viewModel.NetAmount = agentPayrollLog.NetAmount;
            viewModel.PayrollLogTypeId = agentPayrollLog.PayrollLogTypeId;
            viewModel.PostDate = agentPayrollLog.PostDate;
            viewModel.ReceivedDate = agentPayrollLog.ReceivedDate;
            viewModel.PayrollPaymentId = agentPayrollLog.PayrollPaymentId;

            var transactions = await _contractTransactionService.GetByContractIdAsync(agentPayrollLog.ContractId);

            var agentExpenses = transactions
                .Where(x => x.IsExpense)
                .Where(x => x.AgentId == agentPayrollLog.AgentId || (agentPayrollLog.PayrollLogTypeId == (int)PayrollLogType.MentorshipCommission || agentPayrollLog.PayrollLogTypeId == (int)PayrollLogType.TransferCommission))
                .Where(x => x.ContractEntityTypeId == (int)ContractEntityType.ECE || x.ContractTransactionTypeId == (int)ContractTransactionType.AgentWorking)
                .ToList();

            if (agentPayrollLog.ContractTransactionId != null)
            {
                if (agentExpenses.Any(x => x.ContractTransactionId == agentPayrollLog.ContractTransactionId))
                {
                    var transaction = transactions.FirstOrDefault(x => x.ContractTransactionId == agentPayrollLog.ContractTransactionId);
                    if (transaction != null)
                    {
                        agentExpenses.Add(transaction);
                    }
                }
            }

            agentExpenses = agentExpenses.OrderBy(x => x.ContractEntityId)
                .ThenBy(x => x.ContractEntityTypeId)
                .ThenBy(x => x.PayeeName)
                .ThenBy(x => x.DueDate)
                .ThenBy(x => x.ContractTransactionTypeId)
                .ThenBy(x => x.AgentId)
                .ThenBy(x => x.ContractTransactionId)
                .ToList();

            var expenses = agentExpenses.Select(x => new LookupDto(x.ContractTransactionId, $"{x.ContractTransactionTypeName} - {x.DueDate:MM/dd/yyyy} - {x.RequiredAmount:C}"));

            viewModel.ContractExpenses = new SelectList(expenses, "Value", "Text");

            return PartialView("_LogEntryFormUpdateModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/agentpayrolleditlog/AgentPayrollUpdateLog")]
        public async Task<ActionResult> AgentPayrollUpdateLog(AgentPayrollLogUpdateViewModel viewModel)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(viewModel.AgentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var returlUrl = viewModel.ReturnUrl;
            if (string.IsNullOrWhiteSpace(returlUrl))
            {
                if (agentPayrollLog.PayrollPaymentId > 0)
                {
                    returlUrl = Url.Action("AgentPayrollEditLog", new { agentPayrollLog.PayrollPaymentId });
                }
                else
                {
                    returlUrl = Url.Action("Money", "Contract", new { area = string.Empty, id = agentPayrollLog.ContractId });
                }
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction(returlUrl);
            }

            agentPayrollLog.CommissionRate = viewModel.CommissionRate.GetValueOrDefault();
            agentPayrollLog.ContractId = viewModel.ContractId.GetValueOrDefault();
            agentPayrollLog.ContractTransactionId = viewModel.ContractTransactionId;
            agentPayrollLog.GrossAmount = viewModel.GrossAmount.GetValueOrDefault();
            agentPayrollLog.NetAmount = viewModel.NetAmount.GetValueOrDefault();
            agentPayrollLog.PayrollLogTypeId = viewModel.PayrollLogTypeId.GetValueOrDefault();
            agentPayrollLog.PayrollPaymentId = viewModel.PayrollPaymentId;
            agentPayrollLog.ReceivedDate = viewModel.ReceivedDate.GetValueOrDefault();
            agentPayrollLog.PostDate = viewModel.PostDate;

            var transaction = await _contractTransactionService.GetByIdAsync(agentPayrollLog.ContractTransactionId.Value);
            if (transaction != null)
            {
                agentPayrollLog.LineOfBusinessId = transaction.LineOfBusinessId.GetValueOrDefault();
                agentPayrollLog.AgentId = transaction.AgentId.GetValueOrDefault();
            }

            await _payrollService.UpdateAgentPayrollLogAsync(agentPayrollLog, User);

            AddSuccessAlert("Log Entry Updated Successfully");
            return Redirect(returlUrl);
        }

        [HttpGet]
        [Route("payroll/agentpayrolleditlog/LogEntryFormDeleteModal/{agentPayrollLogId}")]
        public async Task<ActionResult> LogEntryFormDeleteModal(int agentPayrollLogId)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(agentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var viewModel = new AgentPayrollLogDeleteViewModel();

            var logTypes = _lookupService
                .GetAllPayrollLogTypes()
                .Where(x => x.IsActive)
                .OrderBy(x => x.Name);

            viewModel.AgentPayrollLogId = agentPayrollLog.AgentPayrollLogId;
            viewModel.PayrollPaymentId = agentPayrollLog.PayrollPaymentId;
            viewModel.ContractId = agentPayrollLog.ContractId;

            return PartialView("_LogEntryFormDeleteModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/agentpayrolleditlog/AgentPayrollRemoveLogFromPayroll")]
        public async Task<ActionResult> AgentPayrollRemoveLogFromPayroll(AgentPayrollLogUpdateViewModel viewModel)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(viewModel.AgentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var returlUrl = viewModel.ReturnUrl;
            if (string.IsNullOrWhiteSpace(returlUrl))
            {
                if (agentPayrollLog.PayrollPaymentId > 0)
                {
                    returlUrl = Url.Action("AgentPayrollEditLog", new { agentPayrollLog.PayrollPaymentId });
                }
                else
                {
                    returlUrl = Url.Action("Money", "Contract", new { area = string.Empty, id = agentPayrollLog.ContractId });
                }
            }

            await _payrollService.RemoveAgentPayrollLogFromPayrollAsync(agentPayrollLog, User);

            AddSuccessAlert("Log Entry Removed From Payroll Successfully");
            return Redirect(returlUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/agentpayrolleditlog/AgentPayrollAddLogToPayroll")]
        public async Task<ActionResult> AgentPayrollAddLogToPayroll(AgentPayrollLogUpdateViewModel viewModel)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(viewModel.AgentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var returlUrl = viewModel.ReturnUrl;
            if (string.IsNullOrWhiteSpace(returlUrl))
            {
                if (agentPayrollLog.PayrollPaymentId > 0)
                {
                    returlUrl = Url.Action("AgentPayrollEditLog", new { agentPayrollLog.PayrollPaymentId });
                }
                else
                {
                    returlUrl = Url.Action("Money", "Contract", new { area = string.Empty, id = agentPayrollLog.ContractId });
                }
            }

            try
            {
                await _payrollService.AddAgentPayrollLogToPayrollAsync(agentPayrollLog, User);

                AddSuccessAlert("Log Entry Added To Payroll Successfully");
            }
            catch (NoCommissionProgramException)
            {
                AddDangerAlert(NoCommissionProgamWarningMessage);
            }
            catch (Exception ex)
            {
                AddDangerAlert(ex.GetBaseException());
            }

            return Redirect(returlUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/agentpayrolleditlog/AgentPayrollDeleteLog")]
        public async Task<ActionResult> AgentPayrollDeleteLog(AgentPayrollLogUpdateViewModel viewModel)
        {
            var agentPayrollLog = await _payrollService.GetAgentPayrollLogByIdAsync(viewModel.AgentPayrollLogId);
            if (agentPayrollLog == null)
            {
                return EntityNotFound();
            }

            var returlUrl = viewModel.ReturnUrl;
            if (string.IsNullOrWhiteSpace(returlUrl))
            {
                if (agentPayrollLog.PayrollPaymentId > 0)
                {
                    returlUrl = Url.Action("AgentPayrollEditLog", new { agentPayrollLog.PayrollPaymentId });
                }
                else
                {
                    returlUrl = Url.Action("Money", "Contract", new { area = string.Empty, id = agentPayrollLog.ContractId });
                }
            }

            await _payrollService.DeleteAgentPayrollLogAsync(agentPayrollLog, User);

            AddSuccessAlert("Log Entry Deleted Successfully");
            return Redirect(returlUrl);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/AddAgentModal/{payrollBatchId}")]
        public async Task<ActionResult> AddAgentModal(int payrollBatchId)
        {
            var payrollBatch = await _payrollService.GetPendingPayrollBatchAsync();
            if (payrollBatch == null || payrollBatchId != payrollBatch.PayrollBatchId)
            {
                return EntityNotFound();
            }

            var viewModel = new AgentPayrollLogAddAgentViewModel();

            var payments = await _payrollService.GetPayrollPaymentsByPayrollBatchIdAsync(payrollBatch);

            var agents = (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.AccountingAdmin))
? LookupCache.GetAgents() : LookupCache.GetRestrictedAgents().ToList();

            var addedAgents = payments.Select(x => x.AgentId);

            var agentsNotAdded = agents.Where(x => !addedAgents.Contains(x.AppUserId.GetValueOrDefault()));

            viewModel.Agents = agentsNotAdded.ToSelectList("FullName", "AppUserId");

            return PartialView("_AddAgentModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/AddAgent")]
        public async Task<ActionResult> AddAgent(AgentPayrollLogAddAgentViewModel viewModel)
        {
            var payrollBatch = await _payrollService.GetPendingPayrollBatchAsync();
            if (payrollBatch == null || viewModel.PayrollBatchId != payrollBatch.PayrollBatchId)
            {
                return EntityNotFound();
            }

            var returlUrl = Url.Action("Details", new { id = viewModel.PayrollBatchId });

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return Redirect(returlUrl);
            }

            await _payrollService.AddAgentToPayrollBatchAsync(payrollBatch, viewModel.AgentId.GetValueOrDefault(), User);

            AddSuccessAlert("Agent Added To Payroll Successfully");
            return Redirect(returlUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("payroll/Recalculate")]
        public async Task<ActionResult> Recalculate()
        {
            var payrollBatch = await _payrollService.GetPendingPayrollBatchAsync();
            if (payrollBatch == null)
            {
                return EntityNotFound();
            }

            await _payrollService.RecalculatePayrollBatchAsync(payrollBatch, User);

            var returlUrl = Url.Action("Details", new { id = payrollBatch.PayrollBatchId });



            AddSuccessAlert("Payroll Totals Recaulculated Successfully");
            return Redirect(returlUrl);
        }

        [NonAction]
        public DateTime ParseAsOfDate(string date)
        {
            DateTime asOfDate = TimeProvider.Current.Today;

            if (!string.IsNullOrWhiteSpace(date))
            {
                DateTime temp = asOfDate;
                if (DateTime.TryParse(date, out temp))
                {
                    asOfDate = temp;
                }
            }

            return asOfDate;
        }
    }
}