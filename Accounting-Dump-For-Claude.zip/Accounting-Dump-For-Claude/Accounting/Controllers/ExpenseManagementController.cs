﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using ECE.CRM.WebUI.Infrastructure.Validation;
    using Infinity.Mobius.Logging;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class ExpenseManagementController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IContractTransactionService _contractTransactionService;

        public ExpenseManagementController(ILogger logger,
            IUserService userService,
            IGeneralLedgerService generalLedgerService,
            IExpenseBatchService expenseBatchService,
            IContractTransactionService contractTransactionService)
            : base(logger)
        {
            this.Logger.Information("Expense Management Controller Created.");

            this._userService = userService;
            this._generalLedgerService = generalLedgerService;
            this._expenseBatchService = expenseBatchService;
            this._contractTransactionService = contractTransactionService;
        }

        [HttpGet]
        public async Task<ActionResult> Index()
        {
            var payeeTypes = LookupCache.GetAllContractEntityTypes().ToSelectList("Text", "Value");

            var expenseTypes = LookupCache.GetAllContractTransactionTypes().ToSelectList("Text", "Value");

            var viewModel = new ExpenseManagementViewModel()
            {
                PayeeTypes = payeeTypes,
                ExpenseTypes = expenseTypes
            };

            var criteria = new BatchSearchCriteriaDto();

            criteria.BatchStatus = (int)ExpenseBatchStatus.NotPosted;

            var batches = await _expenseBatchService.GetBatchesByCriteriaAsync(criteria);

            var pendingBatches = Mapper.Map<IList<PaymentBatchViewModel>>(batches);

            viewModel.LoadPendingBatches(pendingBatches, User);

            return this.View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("searchexport")]
        public async Task<ActionResult> SearchExport(ExpenseManagementSearchExportViewModel viewModel)
        {
            var results = await this._generalLedgerService.GetExpenseManagementByCriteriaAsync(viewModel.Criteria);

            var fileName = viewModel.FileName;
            fileName = FileHelper.GetSafeFileName(fileName);
            var bytes = viewModel.GetExportFileContents(results, fileName);

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
        }

        [HttpGet]
        public ActionResult PaymentBatchDetails(int id = -1)
        {
            var model = new PaymentBatchDetailsViewModel();

            return this.View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> PaySelectedExpensesNow(ExpenseManagementViewModel viewModel, CreatePaymentBatchViewModel createPaymentBatch)
        {
            if (viewModel.IdsToPay == null)
            {
                this.ModelState.AddModelError("IdsToPay", "IdsToPay cannot be null!");
            }

            var idsToPay = viewModel.GetIdsToPay();

            if (!idsToPay.Any())
            {
                this.ModelState.AddModelError("IdsToPay", "IdsToPay cannot be empty!");
            }

            if (!this.ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index");
            }

            var options = new CreatePaymentBatchDto
            {
                IsManual = true,
                ExpenseBatchType = createPaymentBatch.BatchType,
                IncludeSharedBonus = createPaymentBatch.SharedBonusOption,
                IncludeGasCard = createPaymentBatch.GasCardOption,
                IncludeNational = createPaymentBatch.PayNationalsOption,
                IdsToPay = idsToPay,
            };

            var batch = await this._expenseBatchService.CreateExpenseBatchForSelectedExpensesAsync(options, this.User);

            return this.RedirectToAction("Details", "PaymentBatch", new { id = batch.ExpenseBatchId });
        }
    }
}