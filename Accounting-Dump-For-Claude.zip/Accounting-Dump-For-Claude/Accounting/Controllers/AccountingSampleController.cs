﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using Infinity.Mobius.Logging;
    using System.Web.Mvc;
    using WebUI.Controllers;

    public class AccountingSampleController : BaseController
    {
        public AccountingSampleController(ILogger logger)
            : base(logger)
        {
        }

        // GET: Accounting/Sample
        public ActionResult Index()
        {
            return View();
        }
    }
}