﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using CsvHelper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class ArtistPaymentController : BaseAccountingController
    {
        private readonly IArtistService _artistService;
        private readonly IContractService _contractService;
        private readonly IContractEventDateService _contractEventDateService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IExpensePaymentService _expensePaymentService;
        private readonly IPayrollService _payrollService;

        public ArtistPaymentController(
            ILogger logger,
            IArtistService artistService,
            IContractService contractService,
            IContractEventDateService contractEventDateService,
            IContractTransactionService contractTransactionService,
            IExpenseBatchService expenseBatchService,
            IExpensePaymentService expensePaymentService,
            IPayrollService payrollService)
            : base(logger)
        {
            this._artistService = artistService;
            this._contractService = contractService;
            this._contractEventDateService = contractEventDateService;
            this._contractTransactionService = contractTransactionService;
            this._expenseBatchService = expenseBatchService;
            this._expensePaymentService = expensePaymentService;
            this._payrollService = payrollService;
        }

        [HttpGet]
        public async Task<ActionResult> Index(int? artistId, int? year)
        {
            var viewModel = new ArtistPaymentsViewModel()
            {
                Year = year ?? DateTime.Now.Year,
                ArtistId = artistId ?? 0
            };

            if (artistId.HasValue && artistId.Value > 0)
            {
                var artist = await this._artistService.GetArtistByIdAsync(artistId.Value);
                if (artist != null)
                {
                    viewModel.ArtistName = artist.Name;
                }
            }

            return View(viewModel);
        }

        [HttpGet]
        [Route("artistpayment/{id}")]
        public async Task<ActionResult> Details(int id)
        {
            var payment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (payment == null)
            {
                return this.EntityNotFound();
            }

            // Must be a posted artist payment
            if (payment.ContractEntityTypeId != (int)ContractEntityType.Artist || payment.DatePosted == null)
            {
                return this.EntityNotFound();
            }

            var artistId = payment.ContractEntityId;
            var year = payment.DatePosted.GetValueOrDefault().Year;

            var transactions = await this._expenseBatchService.GetExpensePaymentTransactionsAsync(id);

            var paymentTransactions = Mapper.Map<List<PaymentBatchContractTransactionViewModel>>(transactions);

            var artist = await this._artistService.GetArtistByIdAsync(artistId);

            var contractIds = paymentTransactions
                .Select(x => x.ContractId)
                .Distinct()
                .ToArray();

            var statusValues = await this._contractService.GetContractStatusValues(contractIds);

            var statusLookup = statusValues.ToDictionary(x => x.ContractId);

            // Get event date.
            var contractId = 0;
            DateTime? eventDate = null;

            foreach (var paymentTransaction in paymentTransactions)
            {
                if (paymentTransaction.ContractId == 0)
                {
                    paymentTransaction.IsSubRow = true;
                    paymentTransaction.OfficeName = string.Empty;
                }
                else
                {
                    if (paymentTransaction.ContractId != contractId)
                    {
                        var eventDates = await this._contractEventDateService.GetByContractIdAsync(paymentTransaction.ContractId);
                        contractId = paymentTransaction.ContractId;
                        eventDate = eventDates.FirstOrDefault()?.EventDate;
                    }

                    paymentTransaction.EventDate = eventDate;

                    if (statusLookup.ContainsKey(paymentTransaction.ContractId))
                    {
                        var status = statusLookup[paymentTransaction.ContractId];

                        paymentTransaction.ContractStatus = TextHelper.ContractStatusToString(status.ContractStatusId);
                    }
                }
            }

            var viewModel = new ArtistPaymentDetailsViewModel(payment)
            {
                Year = year,
                ArtistId = artistId,
                ArtistName = artist.Name,
                Payments = paymentTransactions
            };

            return View("~/Areas/Accounting/Views/ArtistPayment/Details.cshtml", viewModel);
        }

        [HttpGet]
        [Route("artistpayment/unpaid/{artistId}")]
        public async Task<ActionResult> UnpaidDetails(int artistId)
        {
            var artist = await this._artistService.GetArtistByIdAsync(artistId);
            if (artist == null)
            {
                return this.EntityNotFound();
            }

            var year = DateTime.Today.Year;
            ExpensePaymentDto payment = null;
            IEnumerable<PayrollContractTransactionDto> transactions = null;

            var criteria = new ContractTransactionSearchCriteriaDto()
            {
                ContractEntityTypeIds = { (int)ContractEntityType.Artist },
                ContractEntityIds = { artistId },
                YearDue = year,
                ContractTransactionTypeIds =
                {
                    (int)ContractTransactionType.ReserveAllowance,
                    (int)ContractTransactionType.GasCard,
                    (int)ContractTransactionType.SharedBonus,
                    (int)ContractTransactionType.ArtistPayment
                },
                PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.NotPaid
            };

            transactions = await _payrollService.GetCommissionTransactionsAsync(criteria);

            payment = new ExpensePaymentDto()
            {
                PaymentAmount = transactions.Total(x => x.RequiredAmount),
                ExpensePaymentTypeLabel = "UNPAID"
            };

            var paymentTransactions = transactions
                .Where(x => x.RequiredAmount != decimal.Zero)
                .Select(x => new PaymentBatchContractTransactionViewModel()
                {
                    ContractId = x.ContractId,
                    ContractTransactionTypeName = x.ContractTransactionTypeName,
                    Amount = x.RequiredAmount ?? decimal.Zero
                })
                .OrderBy(x => x.ContractId)
                .ToList();

            var contractIds = paymentTransactions
                .Select(x => x.ContractId)
                .Distinct()
                .ToArray();

            var statusValues = await this._contractService.GetContractStatusValues(contractIds);

            var statusLookup = statusValues.ToDictionary(x => x.ContractId);

            // Get event date.
            var contractId = 0;
            DateTime? eventDate = null;

            foreach (var paymentTransaction in paymentTransactions)
            {
                if (paymentTransaction.ContractId != contractId)
                {
                    var eventDates = await this._contractEventDateService.GetByContractIdAsync(paymentTransaction.ContractId);
                    contractId = paymentTransaction.ContractId;
                    eventDate = eventDates.FirstOrDefault()?.EventDate;
                }

                paymentTransaction.EventDate = eventDate;

                if (statusLookup.ContainsKey(paymentTransaction.ContractId))
                {
                    var status = statusLookup[paymentTransaction.ContractId];

                    paymentTransaction.ContractStatus = TextHelper.ContractStatusToString(status.ContractStatusId);
                }
            }

            var viewModel = new ArtistPaymentDetailsViewModel(payment)
            {
                Year = year,
                ArtistId = artistId,
                ArtistName = artist.Name,
                Payments = paymentTransactions
            };

            return View("~/Areas/Accounting/Views/ArtistPayment/Details.cshtml", viewModel);
        }

        [HttpGet]
        [Route("artistpayment/exportpayments")]
        public async Task<ActionResult> ExportPayments(int artistId, int year)
        {
            var artist = await this._artistService.GetArtistByIdAsync(artistId);
            if (artist == null)
            {
                return this.EntityNotFound();
            }

            var payments = await _expensePaymentService.GetByPayeeAndYearAsync((int)ContractEntityType.Artist, artistId, year);

            var orderedPayments = payments.Select(x => new
            {
                ArtistId = x.ContractEntityId,
                x.ExpensePaymentId,
                DatePaid = (DateTime?)x.DateIssued,
                Amount = x.PaymentAmount,
                PaymentMethod = GeneratePaymentTypeDisplay(x),
                IsVoided = x.DateVoided.HasValue,
            }).OrderByDescending(x => x.DatePaid)
            .ToList();

            if (year == DateTime.Today.Year)
            {
                var criteria = new ContractTransactionSearchCriteriaDto()
                {
                    ContractEntityTypeIds = { (int)ContractEntityType.Artist },
                    ContractEntityIds = { artistId },
                    YearDue = year,
                    PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.NotPaid
                };

                var unpaidTransactions = await _payrollService.GetCommissionTransactionsAsync(criteria);

                var programTypes = new List<int>()
                {
                    (int)ContractTransactionType.ReserveAllowance,
                    (int)ContractTransactionType.GasCard,
                    (int)ContractTransactionType.SharedBonus,
                    (int)ContractTransactionType.ArtistPayment
                };

                var amountNotPaid = unpaidTransactions
                    .Where(x => programTypes.Contains(x.ContractTransactionTypeId))
                    .Total(x => x.RequiredAmount);

                var notPaid = new
                {
                    ArtistId = 0,
                    ExpensePaymentId = 0,
                    DatePaid = (DateTime?)null,
                    Amount = amountNotPaid,
                    PaymentMethod = string.Empty,
                    IsVoided = false,
                };

                orderedPayments.Insert(0, notPaid);
            }

            var fileName = $"{artist.Name}-{year}-Payments";
            fileName = FileHelper.GetSafeFileName(fileName);

            List <ArtistPaymentExcelDto> listOfObjects = new List<ArtistPaymentExcelDto>();
            foreach (var payment in orderedPayments)
            {
                ArtistPaymentExcelDto objectClass = new ArtistPaymentExcelDto();
                var postDate = payment.DatePaid.HasValue
                       ? payment.DatePaid.ToStandardString()
                       : "UNPAID";
                objectClass.DatePaid = postDate;
                objectClass.Amount = payment.Amount;
                objectClass.PaymentMethod = payment.PaymentMethod;
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, fileName);
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }

        }

        private string GeneratePaymentTypeDisplay(ExpensePaymentDto expensePayment)
        {
            if (expensePayment.DatePosted == null)
            {
                return string.Empty;
            }

            return $"{expensePayment.ExpensePaymentTypeLabel} {expensePayment.ReferenceNumber}";
        }
    }
}
