﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using CsvHelper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class PaymentBatchController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IExpensePaymentService _expensePaymentService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IArtistChargeService _artistChargeService;
        private readonly IArtistService _artistService;
        private readonly ICheckGenerationService _checkGenerationService;

        public PaymentBatchController(
            ILogger logger,
            IUserService userService,
            IExpenseBatchService expenseBatchService,
            IExpensePaymentService expensePaymentService,
            IContractTransactionService contractTransactionService,
            IArtistChargeService artistChargeService,
            IArtistService artistService,
            ICheckGenerationService checkGenerationService)
            : base(logger)
        {
            this.Logger.Information("Payment Batch Controller Created.");

            this._userService = userService;
            this._expenseBatchService = expenseBatchService;
            this._expensePaymentService = expensePaymentService;
            this._contractTransactionService = contractTransactionService;
            this._artistChargeService = artistChargeService;
            this._artistService = artistService;
            this._checkGenerationService = checkGenerationService;
        }

        [HttpGet]
        [Route("paymentbatch/details/{id}")]
        public async Task<ActionResult> Details(int id)
        {
            var batch = await this._expenseBatchService.GetByIdAsync(id);
            if (batch == null)
            {
                return this.EntityNotFound("Payment Batch not found.");
            }

            if (batch.IsPosted)
            {
                return await this.ShowPostedBatchAsync(batch);
            }
            else
            {
                return await this.ShowUnpostedBatchAsync(batch);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_CREATE)]
        [Route("paymentbatch/create")]
        public async Task<ActionResult> CreateBatch(CreatePaymentBatchViewModel viewModel)
        {
            var options = new CreatePaymentBatchDto
            {
                IsManual = false,
                ExpenseBatchType = viewModel.BatchType,
                IncludeSharedBonus = viewModel.SharedBonusOption,
                IncludeGasCard = viewModel.GasCardOption,
                IncludeNational = viewModel.PayNationalsOption,
            };

            var batch = await this._expenseBatchService.CreateExpenseBatchAsync(options, this.User);

            return this.RedirectToBatchDetails(batch);
        }

        [CheckUserPermissions(ECEPermissions.ACCOUNTING_CREATE)]
        [Route("paymentbatch/post-batch-modal/{id}")]
        public async Task<ActionResult> PostBatchModal(int id)
        {
            var batch = await this._expenseBatchService.GetByIdAsync(id);
            if (batch == null)
            {
                throw new UnhandledBusinessException($"Batch # {id} not found");
            }

            var viewModel = new PostBatchViewModel();

            viewModel.ExpenseBatchId = id;

            var sequence = await _expenseBatchService.GetCheckNumberSequenceAsync();
            if (sequence == null)
            {
                throw new UnhandledBusinessException($"Check Number Sequence not found");
            }

            viewModel.CurrNextCheckNumber = sequence.NextNumber;

            return PartialView("_PostBatchModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/post")]
        public async Task<ActionResult> PostBatch(PostBatchViewModel viewModel)
        {
            var batch = await this._expenseBatchService.GetByIdAsync(viewModel.ExpenseBatchId);
            if (batch == null)
            {
                throw new UnhandledBusinessException($"Batch # {viewModel.ExpenseBatchId} not found");
            }

            if (batch.IsPosted)
            {
                this.AddDangerAlert("Cannot re-post a Posted Batch.");
                return this.RedirectToBatchDetails(batch);
            }

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                if (await this._expenseBatchService.PostBatchAsync(batch, viewModel.NewNextCheckNumber, this.User))
                {
                    this.AddSuccessAlert($"Payment Batch # {viewModel.ExpenseBatchId} has been posted.");
                }
            }
            catch (AlreadyPostedException ex)
            {
                this.AddDangerAlert(ex.Message);
                return this.RedirectToBatchDetails(batch);
            }
            catch (InvalidACHPayeeException ex)
            {
                this.AddDangerAlert($"Batch Not Posted: {ex.Message}");
                return this.RedirectToBatchDetails(batch);
            }
            catch (Exception)
            {
                throw;
            }

            stopwatch.Stop();

            if (Request.IsLocal)
            {
                return RedirectToAction("Details", new { id = viewModel.ExpenseBatchId, time = stopwatch.ElapsedMilliseconds });
            }

            return RedirectToAction("Details", new { id = viewModel.ExpenseBatchId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/delete")]
        public async Task<ActionResult> DeleteBatch(PaymentBatchDeleteViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(Infrastructure.InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index", "ExpenseManagement");
            }

            var id = viewModel.ExpenseBatchId.Value;

            try
            {
                await this._expenseBatchService.DeletePendingBatchAsync(id, this.User);
                this.AddSuccessAlert($"Payment Batch # {id} has been deleted.");
            }
            catch (AlreadyPostedException ex)
            {
                this.AddDangerAlert(ex.Message);
                return RedirectToAction("Index", "ExpenseManagement");
            }
            catch (Exception)
            {
                throw;
            }

            return RedirectToAction("Index", "ExpenseManagement");
        }

        [HttpGet]
        [Route("paymentbatch/transactiondetails/{id}")]
        public async Task<ActionResult> TransactionDetails(int id)
        {
            var payment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (payment == null)
            {
                return this.EntityNotFound();
            }

            var model = Mapper.Map<PaymentBatchTransactionDetailsViewModel>(payment);

            var check = new CheckPrintDto();
            await _checkGenerationService.PopulateEntityDetailsAsync(payment, check);

            model.LoadPayeeAddress(check);

            var batch = await this._expenseBatchService.GetByIdAsync(payment.ExpenseBatchId, false);
            var batchViewModel = Mapper.Map<PaymentBatchDetailsViewModel>(batch);

            model.SetBatchDescription(batchViewModel);

            var transactions = await this._expenseBatchService.GetExpensePaymentTransactionsAsync(id, batch);

            model.Transactions = Mapper.Map<List<PaymentBatchContractTransactionViewModel>>(transactions);

            foreach (var trans in model.Transactions)
            {
                if (trans.ContractId == 0)
                {
                    trans.IsSubRow = true;
                    trans.OfficeName = string.Empty;
                }
                else
                {
                    var transaction = transactions.First(x => x.ContractTransactionId == trans.ContractTransactionId);

                    var warnings = await this._contractTransactionService.CheckTransactionForWarningAsync(transaction);

                    string warningMessage = string.Join(" ", warnings);

                    if (!string.IsNullOrEmpty(warningMessage))
                    {
                        trans.TransactionWarning = true;
                        trans.WarningMessage = warningMessage;
                    }
                }
            }

            if (payment.ContractEntityTypeId == (int)ContractEntityType.Artist)
            {
                var artist = await this._artistService.GetArtistByIdAsync(payment.ContractEntityId);
                model.CanUseDirectDeposit = this._artistService.CanUseDirectDeposit(artist);
            }

            model.LoadPayByTypes(payment);

            // get totals
            var groupedTrans = from p in transactions.Where(x => x.ContractId > 0)
                               group p by new { p.ContractTransactionTypeId };

            var transSums = new Dictionary<ContractTransactionType, decimal>();

            // get transaction type totals
            foreach (var trans in groupedTrans)
            {
                transSums.Add((ContractTransactionType)trans.Key.ContractTransactionTypeId, trans.Total(p => p.RequiredAmount));
            }

            model.ArefPaymentsAmount = (from t in transSums
                                        where t.Key == ContractTransactionType.ArtistPayment
                                        select t.Value).Sum();

            model.ProgramsAmount = (from t in transSums
                                    where t.Key == ContractTransactionType.ReserveAllowance ||
                                          t.Key == ContractTransactionType.GasCard ||
                                          t.Key == ContractTransactionType.SharedBonus
                                    select t.Value).Sum();

            return this.View("~/Areas/Accounting/Views/PaymentBatch/TransactionDetails.cshtml", model);
        }

        [HttpGet]
        [Route("paymentbatch/exportpayments/{id}")]
        public async Task<ActionResult> ExportPayments(int id)
        {
            var batch = await this._expenseBatchService.GetByIdAsync(id);
            if (batch == null)
            {
                return this.EntityNotFound();
            }

            var model = Mapper.Map<PaymentBatchDetailsViewModel>(batch);

            model.ExpensePayments = model.ExpensePayments.OrderBy(p => p.PayeeName).ToList();

            var contractTransactions = await this._expenseBatchService.GetBatchTransactionsAsync(batch);

            foreach (var expense in model.ExpensePayments)
            {
                var expenseTransactions = contractTransactions
                    .Where(x => x.ExpensePaymentId == expense.ExpensePaymentId && x.IsExpense)
                    .ToList();

                string warningMessage = await this._expenseBatchService.CheckExpensePaymentForWarningsAsync(expenseTransactions);
                if (!string.IsNullOrEmpty(warningMessage))
                {
                    expense.TransactionWarning = true;
                    expense.WarningMessage = warningMessage;
                }
            }

            var fileName = $"{model.BatchType} Batch # {model.ExpenseBatchId} Summary";
            fileName = FileHelper.GetSafeFileName(fileName);
            bool isArtistBatch = batch.ExpenseBatchTypeId == (int)ExpenseBatchType.Artist;
            bool hasDatePosted = batch.DatePosted.HasValue;



            List<ExpensePaymentExcelDto> listOfObjects = new List<ExpensePaymentExcelDto>();
            foreach (var payment in model.ExpensePayments)
            {
                ExpensePaymentExcelDto objectClass = new ExpensePaymentExcelDto();
                objectClass.ArtistId = isArtistBatch ? payment.ContractEntityId : (int?)null;
                objectClass.ArtistName = isArtistBatch ? payment.Artist?.Name : null;
                objectClass.PayeeName = payment.PayeeName;
                objectClass.TransactionCount = payment.TransactionCount;
                objectClass.Gross = payment.GrossAmount;
                objectClass.Deductions = payment.TotalDeductions;
                objectClass.Net = payment.PaymentAmount;
                objectClass.ExpensePaymentId = payment.ExpensePaymentId;

                if (hasDatePosted)
                {
                    objectClass.Reference = $"{payment.ReferenceNumber} Voided {payment.DateVoided:MM/dd/yyyy}";
                }
                else
                {
                    objectClass.Reference = payment.ReferenceNumber;
                }

                objectClass.PaymentType = payment.ExpensePaymentTypeLabel;
                objectClass.Warnings = payment.WarningMessage;
                listOfObjects.Add(objectClass);
            }



            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                string baseUrl = HttpContext.Request.Url.GetLeftPart(UriPartial.Authority);
                try
                {
                    if (dt.Columns.IndexOf("EXPENSEPAYMENTID") != -1)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            string url = $"{baseUrl}/accounting/paymentbatch/transactiondetails/" + Convert.ToString(dr["EXPENSEPAYMENTID"]);
                            dr[0] = "<a href='" + url + "'>" + Convert.ToString(dr[0]) + "</a>";
                        }
                        dt.Columns.Remove("EXPENSEPAYMENTID");
                    }

                }
                catch { }
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, fileName);
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");

            }
        }

        [HttpGet]
        [Route("paymentbatch/transactiondetails/export/{id}")]
        public async Task<ActionResult> ExportTransactions(int id)
        {
            var payment = await this._expensePaymentService.GetByIdAsync(id);
            if (payment == null)
            {
                return this.EntityNotFound();
            }

            var model = Mapper.Map<PaymentBatchTransactionDetailsViewModel>(payment);

            var batch = await this._expenseBatchService.GetByIdAsync(model.ExpenseBatchId);

            var transactions = await this._expenseBatchService.GetExpensePaymentTransactionsAsync(id, batch);

            model.Transactions = Mapper.Map<List<PaymentBatchContractTransactionViewModel>>(transactions);

            var batchModel = Mapper.Map<PaymentBatchDetailsViewModel>(batch);

            var fileName = $"{batchModel.BatchType} Batch # {model.ExpenseBatchId} {model.PayeeName} Details";
            fileName = FileHelper.GetSafeFileName(fileName);


            List<PaymentBatchDetailsExcelDto> listOfObjects = new List<PaymentBatchDetailsExcelDto>();


            foreach (var trans in model.Transactions)
            {
                PaymentBatchDetailsExcelDto objectClass = new PaymentBatchDetailsExcelDto();
                objectClass.ContractNumber = trans.ContractId;
                objectClass.Office = trans.OfficeName;
                objectClass.Type = trans.ContractTransactionTypeName;
                objectClass.Amount = trans.TransactionAmount(batch.DatePosted.HasValue);
                listOfObjects.Add(objectClass);
            }

            if (listOfObjects.Any())
            {
                var dt = listOfObjects.ToDataTable();
                dt.TableName = fileName;
                var xlsBase64 = await CRInfrastructure.DT_XLS(dt, fileName);
                byte[] fileBytes = Convert.FromBase64String(xlsBase64);
                return this.File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
            }
            else
            {
                return RedirectToAction("NotFound", "Error");
            }
       }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/transactiondetails/remove-expense/{contractTransactionId}/{expensePaymentId}")]
        public async Task<ActionResult> RemoveExpenseFromPayment(int contractTransactionId, int expensePaymentId)
        {
            try
            {
                var expensePayment = await this._expensePaymentService.RemoveTransactionFromPaymentAsync(contractTransactionId, expensePaymentId, this.User);
                if (expensePayment == null)
                {
                    this.AddWarningAlert("Transaction was already removed from the payment.");
                    return this.RedirectToTransactionDetails(expensePaymentId);
                }

                if (expensePayment.IsDeleted)
                {
                    this.AddSuccessAlert("Transaction and associated payment removed successfully.");
                    return this.RedirectToBatchDetails(expensePayment.ExpenseBatchId);
                }
            }
            catch (RemoveTransactionException ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePaymentId);
            }

            this.AddSuccessAlert("Transaction removed successfully.");
            return this.RedirectToTransactionDetails(expensePaymentId);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/transactiondetails/remove-repayment/{artistChargeTransactionId}/{expensePaymentId}")]
        public async Task<ActionResult> RemoveLoanRepaymentFromPayment(int artistChargeTransactionId, int expensePaymentId)
        {
            try
            {
                var expensePayment = await this._expensePaymentService.RemoveLoanRepaymentFromPaymentAsync(artistChargeTransactionId, expensePaymentId, this.User);
                if (expensePayment == null)
                {
                    this.AddWarningAlert("Loan Repayment was already removed from the payment.");
                    return this.RedirectToTransactionDetails(expensePaymentId);
                }
            }
            catch (RemoveTransactionException ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePaymentId);
            }

            this.AddSuccessAlert("Loan Repayment removed successfully.");
            return this.RedirectToTransactionDetails(expensePaymentId);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/transactiondetails/remove-xded/{contractDepositId}/{expensePaymentId}")]
        public async Task<ActionResult> RemoveCrossDeductionFromPayment(int contractDepositId, int expensePaymentId)
        {
            try
            {
                var expensePayment = await this._expensePaymentService.RemoveCrossDeductionFromPaymentAsync(contractDepositId, expensePaymentId, this.User);
                if (expensePayment == null)
                {
                    this.AddWarningAlert("Cross deduction was already removed from the payment.");
                    return this.RedirectToTransactionDetails(expensePaymentId);
                }
            }
            catch (RemoveTransactionException ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePaymentId);
            }

            this.AddSuccessAlert("Cross deduction removed successfully.");
            return this.RedirectToTransactionDetails(expensePaymentId);
        }

        [HttpGet]
        [Route("paymentbatch/PaymentActionModal/{id}")]
        public async Task<ActionResult> PaymentActionModal(int id, decimal escrowAmount)
        {
            var contractTransaction = await this._contractTransactionService.GetByIdAsync(id);
            if (contractTransaction == null)
            {
                return this.EntityNotFound($"Contract transaction {id} not found.");
            }

            var expensePaymentData = await this._contractTransactionService.GetExpensePaymentDataAsync(contractTransaction);

            var viewModel = Mapper.Map<ResolveEscrowDeficiencyViewModel>(expensePaymentData);

            if (escrowAmount > decimal.Zero && escrowAmount < viewModel.RequiredAmount)
            {
                viewModel.PaidAmount = escrowAmount;
                viewModel.DueAmount = viewModel.RequiredAmount - viewModel.PaidAmount;
            }
            else if (escrowAmount < decimal.Zero)
            {
                viewModel.PaidAmount = escrowAmount;
                viewModel.DueAmount = viewModel.RequiredAmount - escrowAmount;
            }

            return this.PartialView("_PaymentActionModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/ResolveEscrowDeficiency")]
        public async Task<ActionResult> ResolveEscrowDeficiency(ResolveEscrowDeficiencyViewModel viewModel)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(viewModel.ExpensePaymentId);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{viewModel.ExpensePaymentId} Not Found");
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(Infrastructure.InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            try
            {
                await this._expenseBatchService.ResolveEscrowDeficiencyAsync(
                    viewModel.SelectedAction.GetValueOrDefault(),
                    viewModel.ContractTransactionId,
                    viewModel.ExpensePaymentId,
                    viewModel.PaidAmount,
                    this.User);
            }
            catch (Exception ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            this.AddSuccessAlert($"The expense has been updated successfully.");
            return this.RedirectToTransactionDetails(expensePayment);
        }

        public async Task<ActionResult> EditPayeeModal(int id)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{id} Not Found");
            }

            if (expensePayment.ContractEntityTypeId != (int)ContractEntityType.Presenter)
            {
                throw new ArgumentException("Payee edits only permittedfor Presenters.");
            }

            var viewModel = new EditPayeeViewModel();

            var check = new CheckPrintDto();
            await _checkGenerationService.PopulateEntityDetailsAsync(expensePayment, check);

            viewModel.LoadForEdit(expensePayment, check);

            return this.PartialView("_EditPayeeModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> EditPayee(EditPayeeViewModel viewModel)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(viewModel.ExpensePaymentId);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{viewModel.ExpensePaymentId} Not Found");
            }

            if (expensePayment.ContractEntityTypeId != (int)ContractEntityType.Presenter)
            {
                throw new ArgumentException("Payee edits only permittedfor Presenters.");
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            try
            {
                var dto = new PresenterRefundDto();

                dto.ExpensePaymentId = viewModel.ExpensePaymentId;
                dto.PayeeName = viewModel.PayeeName;
                dto.MailingAddress1 = viewModel.MailingAddress1;
                dto.MailingAddress2 = viewModel.MailingAddress2;
                dto.MailingCity = viewModel.MailingCity;
                dto.MailingCountryId = viewModel.MailingCountryId;
                dto.MailingStateId = viewModel.MailingStateId;
                dto.MailingZip = viewModel.MailingZip;

                await _expensePaymentService.UpdatePresenterRefundAsync(dto, viewModel.ExpensePaymentId, User);
            }
            catch (Exception ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            this.AddSuccessAlert($"The expense has been updated successfully.");
            return this.RedirectToTransactionDetails(expensePayment);
        }

        public async Task<ActionResult> AddOneTimeChargeModal(int id)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{id} Not Found");
            }

            if (expensePayment.ContractEntityTypeId != (int)ContractEntityType.Artist)
            {
                throw new ArgumentException("One-Time charge only permitted for Artists.");
            }

            var artist = await this._artistService.GetArtistByIdAsync(expensePayment.ContractEntityId);
            if (artist == null)
            {
                return this.EntityNotFound($"Artist #{expensePayment.ContractEntityId} Not Found");
            }

            var viewModel = new AddOneTimeChargeViewModel();
            viewModel.LoadForCreate();

            viewModel.ArtistId = artist.ArtistId;
            viewModel.ArtistName = artist.Name;
            viewModel.ExpensePaymentId = id;
            viewModel.ArtistChargeTypeId = (int)ArtistChargeType.Wire;
            viewModel.MaxOriginalAmount = expensePayment.PaymentAmount;

            return this.PartialView("_AddOneTimeChargeModal", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> AddOneTimeCharge(AddOneTimeChargeViewModel viewModel)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(viewModel.ExpensePaymentId);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{viewModel.ExpensePaymentId} Not Found");
            }

            if (expensePayment.ContractEntityTypeId != (int)ContractEntityType.Artist)
            {
                throw new ArgumentException("One-Time charge only permitted for Artists.");
            }

            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            try
            {
                var artistCharge = Mapper.Map<ArtistChargeDto>(viewModel);

                artistCharge.InterestCalculatedFrequencyId = (int)InterestCalculatedFrequency.Monthly;
                artistCharge.InterestRate = decimal.Zero;
                artistCharge.PaymentAmount = viewModel.OriginalAmount;

                await this._expensePaymentService.AddOneTimeChargeAsync(
                    artistCharge,
                    viewModel.ExpensePaymentId,
                    this.User);
            }
            catch (Exception ex)
            {
                this.AddDangerAlert(ex);
                return this.RedirectToTransactionDetails(expensePayment);
            }

            this.AddSuccessAlert($"The expense has been updated successfully.");
            return this.RedirectToTransactionDetails(expensePayment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("paymentbatch/transactiondetails/payby/{id}")]
        public async Task<ActionResult> TogglePayBy(int id, int payBy)
        {
            var expensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (expensePayment == null)
            {
                return this.EntityNotFound($"Expense Payment #{id} Not Found");
            }

            if (expensePayment.IsReadOnly)
            {
                this.AddDangerAlert("Cannot modify a posted transaction.");
                return this.RedirectToTransactionDetails(expensePayment);
            }

            var paymentType = LookupCache
                .GetAllExpensePaymentTypes()
                .FirstOrDefault(x => x.Value == payBy.ToString());
            if (paymentType == null)
            {
                return this.EntityNotFound($"Expense Payment Type {payBy} Not Found");
            }

            var messageType = paymentType.Text;

            expensePayment.ExpensePaymentTypeId = payBy;

            await this._expenseBatchService.UpdateExpensePaymentAsync(expensePayment, this.User);

            this.AddSuccessAlert($"The payment has been marked to be paid by {messageType}");
            return this.RedirectToTransactionDetails(expensePayment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> Reset(PaymentBatchDeleteViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(Infrastructure.InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("Index", "ExpenseManagement");
            }

            var id = viewModel.ExpenseBatchId.Value;
            ExpenseBatchDto batch = null;

            try
            {
                batch = await this._expenseBatchService.ResetPendingBatchAsync(id, this.User);
                if (batch == null)
                {
                    return this.EntityNotFound($"Payment Batch {id} not found.");
                }
            }
            catch (AlreadyPostedException ex)
            {
                this.AddDangerAlert(ex.Message);
                return RedirectToAction("Index", "ExpenseManagement");
            }
            catch (Exception)
            {
                throw;
            }

            this.AddSuccessAlert("Batch reset successfully");
            return this.RedirectToAction("Details", "PaymentBatch", new { id = batch.ExpenseBatchId });
        }

        private async Task<ActionResult> ShowUnpostedBatchAsync(ExpenseBatchDto batch)
        {
            var model = new PaymentBatchDetailsViewModel();

            model = Mapper.Map<PaymentBatchDetailsViewModel>(batch);

            var contractTransactions = await this._expenseBatchService.GetBatchTransactionsAsync(batch);

            contractTransactions = contractTransactions.Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold).ToList();

            foreach (var expense in model.ExpensePayments)
            {
                var expenseTransactions = contractTransactions
                    .Where(x => x.ExpensePaymentId == expense.ExpensePaymentId && x.IsExpense)
                    .ToList();

                string warningMessage = await this._expenseBatchService.CheckExpensePaymentForWarningsAsync(expenseTransactions);
                if (!string.IsNullOrEmpty(warningMessage))
                {
                    expense.TransactionWarning = true;
                    expense.WarningMessage = warningMessage;
                }
            }

            model.EntityTypeId = (int)EntityType.Accounting;
            model.EntityId = batch.ExpenseBatchId;

            model.IsPosted = false;

            var transactionTypeTotals = new Dictionary<ContractTransactionType, decimal>();

            var groupedTrans = from p in contractTransactions
                               where p.IsExpense == true
                               group p by new { p.ContractTransactionTypeId };

            // get transaction type totals - need clarification on this
            foreach (var trans in groupedTrans)
            {
                transactionTypeTotals.Add((ContractTransactionType)trans.Key.ContractTransactionTypeId, trans.Total(p => p.DueAmount));
            }

            model.ArefPaymentsAmount = (from t in transactionTypeTotals
                                        where t.Key == ContractTransactionType.ArtistPayment
                                        select t.Value).Sum();

            model.ProgramsAmount = (from t in transactionTypeTotals
                                    where t.Key != ContractTransactionType.ArtistPayment
                                    select t.Value).Sum();

            model.DepositPaymentsAmount = -contractTransactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.CrossDeductionDeposit)
                .Total(x => x.RequiredAmount);

            model.LoanRepaymentsAmount = -(model.BatchAmount - model.ArefPaymentsAmount - model.ProgramsAmount + model.DepositPaymentsAmount);

            model.ExpensePayments = model.ExpensePayments.OrderBy(p => p.PayeeName).ToList();

            return this.View("~/Areas/Accounting/Views/PaymentBatch/Details.cshtml", model);
        }

        private async Task<ActionResult> ShowPostedBatchAsync(ExpenseBatchDto batch)
        {
            var model = new PaymentBatchDetailsViewModel();

            model = Mapper.Map<PaymentBatchDetailsViewModel>(batch);

            model.EntityTypeId = (int)EntityType.Accounting;
            model.EntityId = batch.ExpenseBatchId;

            var contractTransactions = await this._expenseBatchService.GetBatchTransactionsAsync(batch);

            foreach (var expense in model.ExpensePayments)
            {
                var expenseTransactions = contractTransactions
                    .Where(x => x.ExpensePaymentId == expense.ExpensePaymentId && x.IsExpense)
                    .ToList();

                string warningMessage = await this._expenseBatchService.CheckExpensePaymentForWarningsAsync(expenseTransactions);
                if (!string.IsNullOrEmpty(warningMessage))
                {
                    expense.TransactionWarning = true;
                    expense.WarningMessage = warningMessage;
                }
            }

            model.ExpensePayments = model.ExpensePayments.OrderBy(p => p.PayeeName).ToList();

            var transactionTypeTotals = this._expenseBatchService.GetBatchTransactionTypeTotals(contractTransactions);

            model.ArefPaymentsAmount = (from t in transactionTypeTotals
                                        where t.Key == ContractTransactionType.ArtistPayment
                                        select t.Value).Sum();
            model.ProgramsAmount = (from t in transactionTypeTotals
                                    where t.Key != ContractTransactionType.ArtistPayment
                                    select t.Value).Sum();

            model.DepositPaymentsAmount = -contractTransactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.CrossDeductionDeposit)
                .Total(x => x.RequiredAmount);

            model.LoanRepaymentsAmount = -(model.BatchAmount - model.ArefPaymentsAmount - model.ProgramsAmount + model.DepositPaymentsAmount);

            return this.View("~/Areas/Accounting/Views/PaymentBatch/Details.cshtml", model);
        }

        private ActionResult RedirectToBatchDetails(ExpenseBatchDto batch)
        {
            return this.RedirectToBatchDetails(batch.ExpenseBatchId);
        }

        private ActionResult RedirectToBatchDetails(int expenseBatchId)
        {
            return this.RedirectToAction("Details", new { id = expenseBatchId });
        }

        private ActionResult RedirectToTransactionDetails(ExpensePaymentDto payment)
        {
            return this.RedirectToTransactionDetails(payment.ExpensePaymentId);
        }

        private ActionResult RedirectToTransactionDetails(int expensePaymentId)
        {
            return this.RedirectToAction("TransactionDetails", new { id = expensePaymentId });
        }
    }
}