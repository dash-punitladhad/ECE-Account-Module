﻿namespace ECE.CRM.WebUI.Areas.Accounting.Controllers
{
    using AutoMapper;
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.WebUI.Areas.Accounting.ViewModels;
    using ECE.CRM.WebUI.Infrastructure;
    using ECE.CRM.WebUI.Infrastructure.Attributes;
    using ECE.CRM.WebUI.Infrastructure.Helpers;
    using Infinity.Mobius.Logging;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Mvc;

    [RouteArea("accounting")]
    public class CheckbookController : BaseAccountingController
    {
        private readonly IUserService _userService;
        private readonly ICheckbookService _checkbookService;
        private readonly ICheckGenerationService _checkGenerationService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IContractTransactionService _contractTransactionService;

        public CheckbookController(ILogger logger,
            IUserService userService,
            ICheckbookService checkbookService,
            ICheckGenerationService checkGenerationService,
            IExpenseBatchService expenseBatchService,
            IContractTransactionService contractTransactionService)
            : base(logger)
        {
            this.Logger.Information("Checkbook Controller Created.");

            this._userService = userService;
            this._checkbookService = checkbookService;
            this._checkGenerationService = checkGenerationService;
            this._expenseBatchService = expenseBatchService;
            this._contractTransactionService = contractTransactionService;
        }

        [HttpGet]
        [Route("checkbook/search")]
        public ActionResult CheckSearch()
        {
            // agents lookup

            bool isParent = false;
            //if (this.ParentUserId > 0)
            //{
            //    isParent = true;
            //}
            var agentsList = this._userService.GetUsersByRole((int)ECERole.Agent);
            var agentsSelectList = new AgentSelectList(agentsList, this.UserId, !isParent);

            var model = new CheckSearchViewModel()
            {
                Agents = agentsSelectList
            };

            return View("~/Areas/Accounting/Views/Checkbook/Search.cshtml", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("checkbook/searchexport")]
        public async Task<ActionResult> CheckSearchExport(CheckSearchExportViewModel viewModel)
        {
            var results = await this._checkbookService.GetChecksByCriteriaAsync(viewModel.Criteria);

            var fileName = FileHelper.GetSafeFileName(viewModel.FileName);

            var bytes = viewModel.GetExportFileContents(results, fileName);

            return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FileHelper.GetSafeFileName(fileName.Replace(" ", "_")) + ".xlsx");
        }

        [HttpGet]
        [Route("checkbook/details/{id}")]
        public async Task<ActionResult> CheckDetails(int id)
        {
            var payment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (payment == null)
            {
                return this.EntityNotFound("Check not found.");
            }

            var batch = await this._expenseBatchService.GetByIdAsync(payment.ExpenseBatchId);

            var model = Mapper.Map<CheckDetailsViewModel>(payment);

            var check = new CheckPrintDto();
            await this._checkGenerationService.PopulateEntityDetailsAsync(payment, check);

            model.LoadPayeeAddress(check);

            model.IsReconciled = await this._checkbookService.GetIsReconciledByExpensePaymentIdAsync(model.ExpensePaymentId);

            model.SetPermissions(this.User);

            // Expenses Paid
            var expenses = await this._expenseBatchService.GetExpensePaymentTransactionsAsync(id, batch);

            model.ExpensesPaid = Mapper.Map<List<PaymentBatchContractTransactionViewModel>>(expenses);

            foreach (var trans in model.ExpensesPaid)
            {
                if (trans.ContractId == 0)
                {
                    trans.IsSubRow = true;
                    trans.OfficeName = string.Empty;
                }
            }

            return View("~/Areas/Accounting/Views/Checkbook/Details.cshtml", model);
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("checkbook/reconcile")]
        public async Task<ActionResult> ReconcileChecksPage()
        {
            // The system shall display the in-progress Check Reconciliation Batch on the Reconcile Checks page if there is a batch in progress.
            var existingReconciliationBatch = await this._checkbookService.GetExistingReconciliationBatchAsync(this.User, includeItems: false);

            var model = Mapper.Map<ReconcileCheckViewModel>(existingReconciliationBatch);

            return View("~/Areas/Accounting/Views/Checkbook/Reconcile.cshtml", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("checkbook/reconcileclosebatch")]
        public async Task<ActionResult> ReconcileCloseBatch(ReconcileCheckViewModel viewModel)
        {
            this.ModelState.Clear();

            if (!this.TryValidateModel(viewModel.ReconcileCloseBatch, nameof(viewModel.ReconcileCloseBatch)))
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction(nameof(ReconcileChecksPage));
            }

            var batch = await this._checkbookService.GetReconciliationBatchByIdAsync(viewModel.ReconcileCloseBatch.ReconciliationBatchId);
            if (batch == null)
            {
                return this.EntityNotFound($"Reconciliation Batch {viewModel.ReconcileCloseBatch.ReconciliationBatchId} not found.");
            }

            var hasWarnings = this._checkbookService.HasReconciliationItemWarnings(batch.ReconciliationItems);
            if (hasWarnings)
            {
                this.AddDangerAlert("Error: The checks can not be reconciled while any check has a warning.");
                return this.RedirectToAction(nameof(ReconcileChecksPage));
            }

            batch.Description = viewModel.ReconcileCloseBatch.Description;

            await this._checkbookService.CloseReconciliationBatchAsync(batch, this.User);

            this.AddSuccessAlert("The checks have been reconciled successfully.");

            return RedirectToAction(nameof(CheckSearch));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("reconcilechecks/resetbatch")]
        public async Task<ActionResult> ReconcileResetBatch(ReconcileCheckViewModel viewModel)
        {
            await this._checkbookService.DeleteAllReconciliationItemsAsync(this.User);

            this.AddSuccessAlert("All reconciliation items have been removed successfully.");

            return RedirectToAction(nameof(ReconcileChecksPage));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("reconcilechecks/addmultiplechecks")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> ReconcileAddMultipleChecks(ReconcileCheckViewModel viewModel)
        {
            this.ModelState.Clear();

            if (!this.TryValidateModel(viewModel.ReconcileAddMultipleChecks, nameof(viewModel.ReconcileAddMultipleChecks)))
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction(nameof(ReconcileChecksPage));
            }

            var checksToAdd = Mapper.Map<IList<ReconciliationItemDto>>(viewModel.ReconcileAddMultipleChecks.ChecksToAdd);

            await this._checkbookService.CreateReconciliationItemsAsync(
                viewModel.ReconcileAddMultipleChecks.ReconciliationBatchId,
                checksToAdd,
                this.User);

            this.AddSuccessAlert("The checks have been added successfully.");

            return RedirectToAction(nameof(ReconcileChecksPage));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("reconcilechecks/addonecheck")]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> ReconcileAddOneCheck(ReconcileCheckViewModel viewModel)
        {
            this.ModelState.Clear();

            if (!this.TryValidateModel(viewModel.ReconcileAddOneCheck, "ReconcileAddOneCheck"))
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return this.RedirectToAction(nameof(ReconcileChecksPage));
            }

            var newItem = viewModel.ReconcileAddOneCheck.CreateDto();

            await this._checkbookService.CreateReconciliationItemAsync(
                viewModel.ReconcileAddOneCheck.ReconciliationBatchId,
                newItem,
                this.User);

            this.AddSuccessAlert("The check has been added successfully.");

            return RedirectToAction(nameof(ReconcileChecksPage));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("checkbook/reconcileonecheck")]
        public async Task<ActionResult> ReconcileOneCheck(int expensePaymentId)
        {
            var check = await this._expenseBatchService.GetExpensePaymentByIdAsync(expensePaymentId);
            if (check == null)
            {
                return this.EntityNotFound($"Expense payment {expensePaymentId} not found.");
            }

            // if check is already reconciled, un-reconcile check
            if (check.DateCleared != null)
            {
                return await this.UnReconcileOneCheck(expensePaymentId);
            }

            await this._checkbookService.ReconcileCheckAsync(check, this.User);

            // Display a success message
            this.AddSuccessAlert("The check has been reconciled successfully.");

            // Navigate to the Check Details page
            return RedirectToAction(nameof(CheckDetails), new { id = expensePaymentId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("checkbook/unreconcileonecheck")]
        public async Task<ActionResult> UnReconcileOneCheck(int expensePaymentId)
        {
            var check = await this._expenseBatchService.GetExpensePaymentByIdAsync(expensePaymentId);
            if (check == null)
            {
                return this.EntityNotFound($"Expense payment {expensePaymentId} not found.");
            }

            await this._checkbookService.UnreconcileCheckAsync(check, this.User);

            this.AddSuccessAlert("The check has been un-reconciled successfully.");

            return RedirectToAction(nameof(CheckDetails), new { id = expensePaymentId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("reconcilechecks/removecheck")]
        public async Task<ActionResult> RemoveReconciliationItem(int reconciliationItemId)
        {
            await this._checkbookService.DeleteReconciliationItemAsync(reconciliationItemId, this.User);

            this.AddSuccessAlert("The check has been removed successfully.");

            return RedirectToAction(nameof(ReconcileChecksPage));
        }

        [HttpGet]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        [Route("checkbook/printcheck")]
        public async Task<ActionResult> PrintCheck(int id)
        {
            var check = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
            if (check == null || check.ExpensePaymentTypeId != (int)ExpensePaymentType.Check)
            {
                return this.EntityNotFound($"Check {id} not found.");
            }

            var mimeType = LookupCache.GetDocumentExtensions()
                    .FirstOrDefault(x => x.DocumentExtensionId == (int)DocumentExtension.PDF)?.MimeType;

            var fileDownloadName = $"{check.ReferenceNumber}_{check.DatePosted:MMddyy}.pdf";

            var pdfStream = await this._checkbookService.PrintCheckAsync(check);

            return this.File(pdfStream, mimeType, fileDownloadName);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> VoidCheck(VoidCheckViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                this.AddInvalidDataAlert(InvalidDataAlertOption.ShowAllErrors);
                return RedirectToAction("CheckDetails", new { id = viewModel.ExpensePaymentId });
            }

            var voidCheck = new VoidCheckDto
            {
                ExpensePaymentId = viewModel.ExpensePaymentId,
                VoidedReason = viewModel.VoidedReason,
                SelectedExpenses = viewModel.SelectedExpenses,
            };

            await this._checkbookService.VoidCheckAsync(voidCheck, this.User);

            this.AddSuccessAlert("The check has been voided successfully.");

            // Navigate to the Check Details page
            return RedirectToAction("CheckDetails", new { id = viewModel.ExpensePaymentId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [CheckUserPermissions(ECEPermissions.ACCOUNTING_UPDATE)]
        public async Task<ActionResult> ResendACHNotification(int id)
        {
            var releaseDate = await this._expenseBatchService.ResendACHNotificationAsync(id, User);

            this.AddSuccessAlert($"The ACH notification has been queued for release on {releaseDate:MM/dd/yyyy} at {releaseDate:hh:mm tt} (EASTERN).");

            // Navigate to the Check Details page
            return RedirectToAction("CheckDetails", new { id });
        }
    }
}