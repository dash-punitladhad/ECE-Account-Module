﻿using Infinity.Mobius.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ECE.CRM.DataAccess
{


    public interface IDatabaseConnectionFactory
    {
        IDbConnection CreateConnection();
    }

    public class SqlConnectionFactory : IDatabaseConnectionFactory, IDisposable
    {
        public string _connectionString;
        EceCrmEntities eceCrmEntities = new EceCrmEntities();
        SqlConnection sqlConnection = new SqlConnection();
        public SqlConnectionFactory()
        {
            _connectionString = MobiusConfiguration.ConnectionString("log4net");
        }
        ~SqlConnectionFactory()
        {
            if (sqlConnection.State == ConnectionState.Open)
            {
                try
                {
                    //sqlConnection.Close();
                }
                catch { }
            }
            SqlConnection.ClearAllPools();
        }
        public IDbConnection CreateConnection()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(_connectionString);
            builder.ConnectTimeout = 999;
            sqlConnection = new SqlConnection(builder.ToString());
            if (sqlConnection.State == ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
            return sqlConnection;
        }

        public void close()
        {
            if (sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(disposing: true);

            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
            SqlConnection.ClearAllPools();

        }
    }

}
