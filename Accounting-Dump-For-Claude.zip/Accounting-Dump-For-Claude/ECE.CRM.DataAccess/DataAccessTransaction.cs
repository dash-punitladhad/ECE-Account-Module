﻿// -----------------------------------------------------------------------
// <copyright file="DataAccessTransaction.cs" company="FBMC Benefits Management">
//     Copyright (c) FBMC Benefits Management 2013
// </copyright>
// -----------------------------------------------------------------------

namespace ECE.CRM.DataAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.Linq;
    using System.Data.Entity.Core.Objects;

    /// <summary>
    /// DataAccessTransaction Class.
    /// </summary>
    public class DataAccessTransaction : IDisposable
    {
        /// <summary>
        /// The context for the transaction
        /// </summary>
        private ObjectContext _context;

        /// <summary>
        /// The database connection for the database transaction
        /// </summary>
        private DbConnection _connection;

        /// <summary>
        /// The database transaction this object is wrapping
        /// </summary>
        private DbTransaction _transaction;

        /// <summary>
        /// Represents the participant that is the first to start the transaction
        /// </summary>
        private Guid _topLevelParticipant;

        /// <summary>
        /// Represents the participant that is currently using the transaction
        /// </summary>
        private Guid _currentParticipant;

        /// <summary>
        /// Contains a list of the transaction's participants
        /// </summary>
        private Stack<Guid> _participants;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the DataAccessTransaction class.
        /// Default constructor to get the database connection and begin the transaction.
        /// </summary>
        /// <param name="connectionString">The connection string to use for the transaction.</param>
        public DataAccessTransaction(string connectionString)
        {
            // Create the database and connection object to get the DbTransaction
            this._getConnection(connectionString);

            // start the transaction
            this._transaction = this._connection.BeginTransaction();

            this._initializeParticipants();
        }

        /// <summary>
        /// Initializes a new instance of the DataAccessTransaction class.
        /// Constructor to get the database connection and begin the transaction with
        /// a <see cref="IsolationLevel"/> for the transaction locking behavior for the connection
        /// wrapped by the <see cref="DataAccessTransaction"/>.
        /// </summary>
        /// <param name="connectionString">The connection string to use for the transaction.</param>
        /// <param name="isolationLevel">The <see cref="IsolationLevel"/> which specifies 
        /// the locking behavior for the transaction.</param>
        public DataAccessTransaction(string connectionString, IsolationLevel isolationLevel)
        {
            // Create the database and connection object to get the DbTransaction
            this._getConnection(connectionString);

            // start the transaction with the correct isolation level
            this._transaction = this._connection.BeginTransaction(isolationLevel);

            this._initializeParticipants();
        }

        /// <summary>
        /// Initializes a new instance of the DataAccessTransaction class.
        /// Constructor to get the database connection and begin the transaction with
        /// a <see cref="IsolationLevel"/> for the transaction locking behavior for the connection
        /// wrapped by the <see cref="DataAccessTransaction"/>.
        /// </summary>
        /// <param name="connection">The connection to the database</param>
        public DataAccessTransaction(DbConnection connection)
        {
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }

            this._connection = connection;
            this._connection.Open();

            // start the transaction with the correct isolation level
            this._transaction = this._connection.BeginTransaction();

            this._initializeParticipants();
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets the current DbConnection object that transaction is using.
        /// </summary>
        /// <returns>DbConnection</returns>
        public DbConnection InnerConnection
        {
            get { return this._connection; }
        }

        /// <summary>
        /// Gets the current participant in the transaction
        /// </summary>
        public Guid CurrentParticipant
        {
            get { return this._currentParticipant; }
        }

        /// <summary>
        /// Gets the DbTransaction object that the transaction is wrapping.
        /// </summary>
        public DbTransaction InnerTransaction
        {
            get { return this._transaction; }
        }

        /// <summary>
        /// Gets the top-level participant in the transaction (the one that
        /// create the transaction).
        /// </summary>
        /// <returns>Guid</returns>
        public Guid TopLevelParticipant
        {
            get { return this._topLevelParticipant; }
        }

        /// <summary>
        /// Gets a value indicating whether the transaction has no participants
        /// </summary>
        public bool HasNoParticipants
        {
            get { return this._participants.Count == 0; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Commits the transaction and closes the database connection.
        /// </summary>
        public void Commit()
        {
            if (this._transaction != null)
            {
                this._transaction.Commit();
                this._transaction.Dispose();
                this._transaction = null;
            }

            if (this._connection != null)
            {
                if (this._connection.State == ConnectionState.Open)
                {
                    this._connection.Close();
                }

                this._connection.Dispose();
                this._connection = null;
            }
        }

        /// <summary>
        /// Rolls back the transaction and closes the database connection.
        /// </summary>
        public void Rollback()
        {
            if (this._transaction != null)
            {
                this._transaction.Rollback();
                this._transaction.Dispose();
                this._transaction = null;
            }

            if (this._connection != null)
            {
                if (this._connection.State == ConnectionState.Open)
                {
                    this._connection.Close();
                }

                this._connection.Dispose();
                this._connection = null;
            }
        }

        /// <summary>
        /// Pushes a new participant to the top of the participants stack.
        /// </summary>
        public void PushParticipant()
        {
            if (this._participants == null)
            {
                return;
            }

            var participant = Guid.NewGuid();
            this._participants.Push(participant);
        }

        /// <summary>
        /// Removes the participant at the top of participants stack.
        /// </summary>
        public void PopParticipant()
        {
            if (this._participants == null)
            {
                return;
            }

            if (this._participants.Count > 0)
            {
                this._currentParticipant = this._participants.Pop();
            }
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this._transaction != null)
                {
                    this._transaction.Rollback();
                    this._transaction.Dispose();
                    this._transaction = null;
                }

                if (this._connection != null)
                {
                    if (this._connection.State == ConnectionState.Open)
                    {
                        this._connection.Close();
                    }

                    this._connection.Dispose();
                    this._connection = null;
                }

                if (this._context != null)
                {
                    this._context.Dispose();
                    this._context = null;
                }
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Creates a database and establishes the connection
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        private void _getConnection(string connectionString)
        {
            if (string.IsNullOrEmpty(connectionString) || connectionString.Trim().Length == 0)
            {
                this._context = new DataContext();
            }
            else
            {
                this._context = new DataContext(connectionString);
            }

            this._connection = this._context.Connection;
            this._connection.Open();
        }

        /// <summary>
        /// Initializes the participants for this transaction
        /// </summary>
        private void _initializeParticipants()
        {
            // Add the top level participant to the stack.
            this._topLevelParticipant = Guid.NewGuid();
            this._participants = new Stack<Guid>(4);
            this._participants.Push(this._topLevelParticipant);
        }

        #endregion
    }
}
