﻿namespace System.Data.Entity
{
    using System.Threading.Tasks;

    // FROM: https://stackoverflow.com/questions/21800967/no-findasync-method-on-idbsett
    public static class IDbSetExtensions
    {
        public static async Task<TEntity> FindAsync<TEntity>(this IDbSet<TEntity> @this, params object[] keyValues)
            where TEntity : class
        {
            DbSet<TEntity> thisDbSet = @this as DbSet<TEntity>;
            if (thisDbSet != null)
            {
                return await thisDbSet.FindAsync(keyValues);
            }
            else
            {
                return @this.Find(keyValues);
            }
        }
    }
}