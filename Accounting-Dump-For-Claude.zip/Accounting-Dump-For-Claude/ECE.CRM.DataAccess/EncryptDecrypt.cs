﻿using System;
using System.Text;

public static class EncryptDecrypt
{
    public static string Encrypt(string data)
    {
        try
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(data));
        }
        catch (Exception ex)
        {
            return "";
        }
    }

    public static string Decrypt(string data)
    {
        try
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(data));
        }
        catch (Exception ex)
        {
            return "";
        }
    }

}