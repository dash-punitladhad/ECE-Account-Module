namespace ECE.CRM.DataAccess
{
    using System.Data.Entity;

    public partial interface IEceCrmEntities
    {
        IDbSet<LuOfficeAmendmentApprover> LuOfficeAmendmentApprovers { get; set; }
    }

    public partial class EceCrmEntities
    {
        public virtual IDbSet<LuOfficeAmendmentApprover> LuOfficeAmendmentApprovers { get; set; }
    }
}
