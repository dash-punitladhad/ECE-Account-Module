﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using LinqKit;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Text;
    using System.Threading.Tasks;

    public class ArtistDao : BaseDataAccessObject, IArtistDao
    {
        public static Expression<Func<Artist, bool>> IsW9OnFileForExclusiveFunction = (x) =>
            x.IsActive == true
            && x.IsExclusive == true
            && x.IsW9OnFile == false
            && x.IsNational == false;

        public static Expression<Func<Artist, bool>> IsW9OnFileForNonExclusiveFunction = (x) =>
            x.IsActive == true
            && x.IsExclusive == false
            && x.IsW9OnFile == false
            && x.IsNational == false
            && x.Name.StartsWith("EASTCOAST") == false
            && x.Name.StartsWith("ECE") == false
            && x.ContractArtists.Any(y =>
            y.Contract.ContractStatusId != (int)ContractStatus.Canceled &&
            y.Contract.ContractStatusId != (int)ContractStatus.PartiallyCanceled &&
            y.Contract.IssueDate > NonExclusiveW9Limit);

        public ArtistDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public static DateTime NonExclusiveW9Limit
        {
            get
            {
                return DateTime.Now.AddYears(-1);
            }
        }

        public IQueryable<EntityHistory> GetMostRecentPriceChangeQuery()
        {
            var query = this.Context.EntityHistories
                .Where(x => x.EntityTypeId == (int)EntityType.Artist && x.AuditEventId == (int)AuditEvent.NationalArtistPriceChange)
                .OrderByDescending(x => x.CreatedDate);

            return query;
        }

        public async Task<List<ArtistDto>> GetArtistsByCharsAsync(string chars)
        {
            var maxResultCount = MobiusConfiguration.GetInt32("Typeahead.MaxResults");

            var query =
                await this.Context.Artists
                    .Where(x => x.IsActive
                                && x.Name.Contains(chars)
                                && !x.ArchiveDate.HasValue)
                    .OrderBy(x => x.Name)
                    .Take(maxResultCount)
                    .ToListAsync();

            var artists = Mapper.Map<List<ArtistDto>>(query);

            return artists;
        }

        public async Task<int> CreateAsync(ArtistDto dto)
        {
            var newArtist = Mapper.Map<Artist>(dto);

            newArtist.PhysicalGeography = DaoHelper.CreatePoint((double)dto.PhysicalGeoLatitude, (double)dto.PhysicalGeoLongitude);
            if (newArtist.IsNational)
            {
                newArtist.IsAR = false;
            }
            else
            {
                newArtist.IsAR = true;
            }
            this.Context.Artists.Add(newArtist);

            await this.Context.SaveChangesAsync();

            dto.ArtistId = newArtist.ArtistId;

            return dto.ArtistId;
        }

        /// <summary>
        /// Gets artists meeting search criteria.
        /// </summary>
        /// <param name="criteria">The search criteria.</param>
        /// <returns>The artists meeting the search criteria.</returns>
        public async Task<IList<ArtistSearchResultsDto>> GetByCriteriaAsync(ArtistSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var predicate = BuildCriteriaPredicate(criteria);

            var maxResults = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Search.MaxResults"]);

            var results = await Context.Artists.AsExpandable()
                .Where(predicate)
                .OrderBy(x => x.Name)
                .Take(maxResults + 1)
                .Select(x => new ArtistSearchResultsDto
                {
                    ArtistId = x.ArtistId,
                    AssignedAgentName = x.AppUser.FirstName + " " + x.AppUser.LastName,
                    BasePrice = x.ArtistPrices.FirstOrDefault(ap => ap.ArtistId == x.ArtistId && ap.IsBasePrice).Price,
                    ExclusiveStartDate = x.ExclusiveStartDate,
                    IsActive = x.IsActive,
                    IsExclusive = x.IsExclusive,
                    IsNational = x.IsNational,
                    Name = x.Name,
                    PhysicalCityState = x.PhysicalAddressCity + " " + x.LuStatePhysical.Abbreviation,
                    PhysicalGeoLatitude = x.PhysicalGeoLatitude,
                    PhysicalGeoLongitude = x.PhysicalGeoLongitude,
                })
                .ToListAsync();

            return results;
        }

        public async Task<(string, string)> GetByCriteriaExportAsync(ArtistSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var predicate = BuildCriteriaWhereClause(criteria);


            return predicate;
        }


        public ArtistDto GetById(int id)
        {
            var artist = this.Context.Artists.FirstOrDefault(x => x.ArtistId == id);

            if (artist == null)
            {
                return null;
            }

            var dto = Mapper.Map<ArtistDto>(artist);

            return dto;
        }

        public async Task<ArtistDto> GetByIdAsync(int id)
        {
            var artist = await this.Context.Artists.FindAsync(id);

            if (artist == null)
            {
                return null;
            }

            var dto = Mapper.Map<ArtistDto>(artist);

            return dto;
        }

        public async Task UpdateAsync(ArtistDto dto, bool canUpdateAccounting)
        {
            var artist = await this.Context.Artists.FirstOrDefaultAsync(x => x.ArtistId == dto.ArtistId);

            if (artist == null)
            {
                throw new ArgumentException($"Artist {dto.ArtistId} not found.");
            }

            // Get the secret key for encryption.
            dto.SecretKey = artist.SecretKey;

            // We map to encrypt the relevant values, then obtain these values when they are needed.
            var encryptedValueSource = Mapper.Map<Artist>(dto);

            if (dto.IsExclusive && !artist.IsExclusive)
            {
                artist.AgentId = dto.AgentId;
            }

            // IsActive is updated in other methods.
            artist.Name = dto.Name;
            artist.AgencyName = dto.AgencyName;
            artist.IsExclusive = dto.IsExclusive;
            artist.ExclusiveStartDate = dto.ExclusiveStartDate;

            // Multiselect values are updated in other methods.
            artist.IsDateClearedByRA = dto.IsDateClearedByRA;
            artist.MailingAddress1 = dto.MailingAddress1;
            artist.MailingAddress2 = dto.MailingAddress2;
            artist.MailingCity = dto.MailingCity;
            artist.MailingStateId = dto.MailingStateId;
            artist.MailingZip = dto.MailingZip;
            artist.MailingCountryId = dto.MailingCountryId;

            artist.PhysicalAddressCity = dto.PhysicalAddressCity;
            artist.PhysicalAddressStateId = dto.PhysicalAddressStateId;
            artist.PhysicalGeoLatitude = dto.PhysicalGeoLatitude ?? decimal.Zero;
            artist.PhysicalGeoLongitude = dto.PhysicalGeoLongitude ?? decimal.Zero;
            artist.PhysicalGeography = DaoHelper.CreatePoint((double)dto.PhysicalGeoLatitude, (double)dto.PhysicalGeoLongitude);

            // Financial Info
            artist.PayeeName = dto.PayeeName;
            artist.TINHashed = dto.TINHashed;
            artist.PaymentInfo = dto.PaymentInfo;
            artist.OtherTerms = dto.OtherTerms;

            if (canUpdateAccounting)
            {
                artist.TIN = encryptedValueSource.TIN;
                artist.BankName = dto.BankName;
                artist.BankRoutingNumber = encryptedValueSource.BankRoutingNumber;
                artist.BankAccountNumber = encryptedValueSource.BankAccountNumber;
                artist.IsW9OnFile = dto.IsW9OnFile;
                artist.W9OnFileDate = dto.W9OnFileDate;
                artist.Is1099Exempt = dto.Is1099Exempt ?? false;
                artist.ArefMailingInstructions = dto.ArefMailingInstructions;
                artist.IsDirectDeposit = dto.IsDirectDeposit;
            }

            artist.SalesPitchNotes = dto.SalesPitch;
            artist.Notes = dto.Notes;

            // National Values
            artist.NationalAgencyId = dto.NationalAgencyId;
            artist.NationalNetPriceLowerBound = dto.NationalNetPriceLowerBound;
            artist.NationalNetPriceUpperBound = dto.NationalNetPriceUpperBound;
            artist.NationalOneOffPrice = dto.NationalOneOffPrice;
            if (artist.IsNational)
            {
                artist.IsAR = false;
            }
            else
            {
                artist.IsAR = dto.IsAR;
            }
            artist.IsNotParticipating = dto.IsNotParticipating;
            artist.ContractLink = dto.ContractLink;
            artist.UpdatedById = dto.UpdatedById;
            artist.UpdatedDate = dto.UpdatedDate;            
            await this.Context.SaveChangesAsync();
        }

        public async Task<ICollection<ActTypeDto>> GetActTypesAsync(int id)
        {
            var results = await (from aat in this.Context.ArtistActTypes
                                 join lu in this.Context.LuActTypes on aat.ActTypeId equals lu.ActTypeId
                                 where aat.ArtistId == id
                                 && lu.IsActive == true
                                 select new ActTypeDto
                                 {
                                     ActTypeId = lu.ActTypeId,
                                     Name = lu.Name
                                 }).ToListAsync();

            return results;
        }

        public async Task<ICollection<GenreTypeDto>> GetGenreTypesAsync(int id)
        {
            var results = await (from agt in this.Context.ArtistGenreTypes
                                 join lu in this.Context.LuGenreTypes on agt.GenreTypeId equals lu.GenreTypeId
                                 where agt.ArtistId == id
                                 && lu.IsActive
                                 select new GenreTypeDto
                                 {
                                     GenreTypeId = lu.GenreTypeId,
                                     Abbreviation = lu.Abbrevation,
                                     Name = lu.Name,
                                 }).ToListAsync();

            return results;
        }

        public async Task<ICollection<EventTypeDto>> GetEventTypesAsync(int id)
        {
            var results = await (from aet in this.Context.ArtistEventTypes
                                 join lu in this.Context.LuEventTypes on aet.EventTypeId equals lu.EventTypeId
                                 where aet.ArtistId == id
                                 && lu.IsActive
                                 select new EventTypeDto
                                 {
                                     EventTypeId = lu.EventTypeId,
                                     Name = lu.Name,
                                     DisplayOrder = lu.DisplayOrder
                                 }).ToListAsync();

            return results;
        }

        public async Task<ICollection<ProgramDto>> GetProgramsAsync(int id)
        {
            var results = await (from ap in this.Context.ArtistPrograms
                                 join lu in this.Context.LuPrograms on ap.ProgramId equals lu.ProgramId
                                 where ap.ArtistId == id
                                 && lu.IsActive
                                 && ap.IsActive
                                 select new ProgramDto
                                 {
                                     ProgramId = lu.ProgramId,
                                     Name = lu.Name,
                                     Amount = lu.Amount,
                                     EcePercentage = lu.EcePercentage,
                                     ArtistPercentage = lu.ArtistPercentage
                                 }).ToListAsync();

            return results;
        }

        public async Task ToggleArtistStatusAsync(int artistId, bool isActive, int updatedBy)
        {
            var artist = await Context.Artists.FirstOrDefaultAsync(x => x.ArtistId == artistId);

            if (artist == null)
            {
                throw new ArgumentException($"Artist {artistId} not found.");
            }

            artist.IsActive = isActive;
            artist.UpdatedById = updatedBy;
            artist.UpdatedDate = DateTime.Now;

            await this.Context.SaveChangesAsync();
        }

        public async Task ToggleArchiveStatusAsync(int artistId, DateTime? archiveDate, bool isActive, int updatedBy)
        {
            var artist = await Context.Artists.FirstOrDefaultAsync(x => x.ArtistId == artistId);

            if (artist == null)
            {
                throw new ArgumentException($"Artist {artistId} not found.");
            }

            artist.IsActive = isActive;
            artist.ArchiveDate = archiveDate;
            artist.UpdatedById = updatedBy;
            artist.UpdatedDate = DateTime.Now;

            await this.Context.SaveChangesAsync();
        }

        public async Task ReassignArtistAgentAsync(int artistId, int agentId, int updatedBy)
        {
            var artist = await Context.Artists.FirstOrDefaultAsync(x => x.ArtistId == artistId);

            if (artist == null)
            {
                throw new ArgumentException($"Artist {artistId} not found.");
            }

            if (agentId == 0)
            {
                artist.AgentId = null;
            }
            else
            {
                artist.AgentId = agentId;
            }

            artist.UpdatedById = updatedBy;
            artist.UpdatedDate = DateTime.Now;

            await this.Context.SaveChangesAsync();
        }

        public async Task<bool> IsExclusiveArtistFormPendingAsync(int id)
        {
            var result = true;

            var artist = await Context.Artists.Where(x => x.ArtistId == id).FirstOrDefaultAsync();
            var isExclusive = artist.IsExclusive;

            if (isExclusive)
            {
                var formSubmitted = await (from dl in this.Context.DocumentLinks
                                           join d in this.Context.Documents on dl.DocumentId equals d.DocumentId
                                           join lu in this.Context.LuDocumentTypes on d.DocumentTypeId equals lu.DocumentTypeId
                                           where lu.Name == "Exclusive Agreement"
                                           && d.IsDeleted != true
                                           && dl.IsDeleted != true
                                           && dl.EntityTypeId == (int)EntityType.Artist
                                           && dl.EntityId == id
                                           select dl.DocumentLinkId).AnyAsync();

                result = !formSubmitted;
            }
            else
            {
                result = false;
            }

            return result;
        }

        public async Task<int> CreateArtistActTypeAsync(ArtistActTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newItem = Mapper.Map<ArtistActTypeDto, ArtistActType>(dto);

            this.Context.ArtistActTypes.Add(newItem);

            await this.Context.SaveChangesAsync();

            return newItem.ArtistActTypeId;
        }

        public async Task DeleteArtistActTypeAsync(ArtistActTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var entity = this.Context.ArtistActTypes.FirstOrDefault(x => x.ArtistId == dto.ArtistId && x.ActTypeId == dto.ActTypeId);

            if (entity == null)
            {
                return;
            }

            this.Context.ArtistActTypes.Remove(entity);

            await this.Context.SaveChangesAsync();
        }

        public async Task<int> CreateArtistGenreTypeAsync(ArtistGenreTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newItem = Mapper.Map<ArtistGenreTypeDto, ArtistGenreType>(dto);

            this.Context.ArtistGenreTypes.Add(newItem);

            await this.Context.SaveChangesAsync();

            return newItem.ArtistGenreTypeId;
        }

        public async Task DeleteArtistGenreTypeAsync(ArtistGenreTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var entity = this.Context.ArtistGenreTypes.FirstOrDefault(x => x.ArtistId == dto.ArtistId && x.GenreTypeId == dto.GenreTypeId);

            if (entity == null)
            {
                return;
            }

            this.Context.ArtistGenreTypes.Remove(entity);

            await this.Context.SaveChangesAsync();
        }

        public async Task<int> CreateArtistProgramAsync(ArtistProgramDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var artistProgramExists = this.Context.ArtistPrograms.Any(x => x.ArtistId == dto.ArtistId && x.ProgramId == dto.ProgramId);

            // If it already exists, we update its flag.
            if (artistProgramExists)
            {
                var artistProgram = this.Context.ArtistPrograms.First(x => x.ArtistId == dto.ArtistId && x.ProgramId == dto.ProgramId);

                artistProgram.IsActive = true;
                artistProgram.UpdatedById = dto.CreatedById;
                artistProgram.UpdatedDate = dto.CreatedDate;

                await this.Context.SaveChangesAsync();

                return artistProgram.ArtistProgramId;
            }
            else
            {
                // Otherwise, we create the new record.
                var newItem = Mapper.Map<ArtistProgramDto, ArtistProgram>(dto);

                this.Context.ArtistPrograms.Add(newItem);

                await this.Context.SaveChangesAsync();

                return newItem.ArtistProgramId;
            }
        }

        public async Task DeleteArtistProgramAsync(ArtistProgramDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var entity = this.Context.ArtistPrograms.FirstOrDefault(x => x.ArtistId == dto.ArtistId && x.ProgramId == dto.ProgramId);

            if (entity == null)
            {
                return;
            }

            entity.IsActive = false;
            entity.UpdatedById = dto.UpdatedById;
            entity.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task<int> CreateArtistEventTypeAsync(ArtistEventTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newItem = Mapper.Map<ArtistEventTypeDto, ArtistEventType>(dto);

            this.Context.ArtistEventTypes.Add(newItem);

            await this.Context.SaveChangesAsync();

            return newItem.ArtistEventTypeId;
        }

        public async Task DeleteArtistEventTypeAsync(ArtistEventTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var entity = this.Context.ArtistEventTypes.FirstOrDefault(x => x.ArtistId == dto.ArtistId && x.EventTypeId == dto.EventTypeId);

            if (entity == null)
            {
                return;
            }

            this.Context.ArtistEventTypes.Remove(entity);

            await this.Context.SaveChangesAsync();
        }

        public async Task<bool> CheckForDuplicates(string artistName)
        {
            bool result = await this.Context.Artists.Where(x =>
                    x.Name.Equals(artistName, StringComparison.InvariantCultureIgnoreCase) && !x.ArchiveDate.HasValue)
                .AnyAsync();

            return result;
        }

        public async Task<IList<NationalArtistSearchResultDto>> GetNationalArtistsByCriteriaAsync(NationalArtistSearchCriteriaDto criteria)
        {
            var results = new List<NationalArtistSearchResultDto>();

            var maxResults = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Search.MaxResults"]);
            var conn = this.Context.Database.Connection;
            try
            {
                
                    if (conn.State != System.Data.ConnectionState.Open)
                        conn.Open();
                    var genreIds = (criteria.GenreTypes != null && criteria.GenreTypes.Any()) ? string.Join(",", criteria.GenreTypes) : null;
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "dbo.GetNationalArtistsByCriteria";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        // Parameters
                        cmd.Parameters.Add(new SqlParameter("@Name", (object)criteria.Name ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@Agency", (object)criteria.Agency ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@Status", (object)criteria.Status ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@GenreTypeIds", (object)genreIds ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@AgentFirstName", (object)criteria.AgentFirstName ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@AgentLastName", (object)criteria.AgentLastName ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@OneOffPriceFrom", (object)criteria.OneOffPriceFrom ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@OneOffPriceTo", (object)criteria.OneOffPriceTo ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@NetPriceFrom", (object)criteria.NationalNetPriceFrom ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@NetPriceTo", (object)criteria.NationalNetPriceTo ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@InquiryId", (object)criteria.InquiryId ?? DBNull.Value));
                        cmd.Parameters.Add(new SqlParameter("@MaxResults", maxResults));

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var item = new NationalArtistSearchResultDto
                                {
                                    ArtistId = reader.GetInt32(reader.GetOrdinal("ArtistId")),
                                    ArtistName = reader["ArtistName"]?.ToString(),
                                    AgencyName = reader["AgencyName"]?.ToString(),
                                    BasePrice = reader["BasePrice"] as decimal?,

                                    GenreTypes = string.IsNullOrEmpty(reader["GenreTypes"]?.ToString()) ? new List<string>() : reader["GenreTypes"].ToString().Split(',').ToList(),

                                    NationalNetPriceLowerBound = reader["NationalNetPriceLowerBound"] as decimal?,
                                    NationalNetPriceUpperBound = reader["NationalNetPriceUpperBound"] as decimal?,
                                    NationalOneOffPrice = reader["NationalOneOffPrice"] as decimal?,

                                    AgentFirstName = reader["AgentFirstName"]?.ToString(),
                                    AgentLastName = reader["AgentLastName"]?.ToString(),

                                    CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                                    UpdatedDate = reader["UpdatedDate"] as DateTime?,

                                    IsExclusive = reader.GetBoolean(reader.GetOrdinal("IsExclusive")),
                                    ExclusiveStartDate = reader["ExclusiveStartDate"] as DateTime?,

                                    PriceLastUpdatedDate = reader["PriceLastUpdatedDate"] as DateTime?
                                };


                                results.Add(item);
                            }
                        }

                    } 
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close(); // 
            }

            return results;
        }
        public async Task<DateTime?> GetPriceLastUpdatedDateAsync(int id)
        {
            var historyQuery = this.GetMostRecentPriceChangeQuery();

            var query = historyQuery.Where(x => x.EntityId == id);

            var lastUpdated = await query.FirstOrDefaultAsync();
            if (lastUpdated != null)
            {
                return lastUpdated.CreatedDate;
            }

            return null;
        }

        public async Task<bool> ArtistIsRelatedToUrlKey(
            UrlKeyHolderType urlKeyHolder,
            string urlKey,
            int artistId)
        {
            if (urlKeyHolder == UrlKeyHolderType.BlueCardPromoArtists)
            {
                var entityQuery = this.Context.BlueCardPromoes.Where(x => x.UrlKey == urlKey);
                entityQuery = entityQuery
                    .Where(x => x.BlueCardPromoArtists
                        .Any(y => y.IsDeleted == false && y.BlueCardArtist.ArtistId == artistId));

                return await entityQuery.AnyAsync();
            }

            return false;
        }

        public async Task<List<ArtistBookDateDto>> GetBookedDatesAsync(IList<int> artistIds)
        {
            var query = (from c in this.Context.Contracts.ForBookedDates()
                         join ce in this.Context.ContractEventDates on c.ContractId equals ce.ContractId
                         join cae in this.Context.ContractArtistEventDates on ce.ContractEventDateId equals cae.ContractEventDateId
                         join ca in this.Context.ContractArtists on cae.ContractArtistId equals ca.ContractArtistId
                         where artistIds.Contains(ca.ArtistId)
                         select new ArtistBookDateDto
                         {
                             ContractId = c.ContractId,
                             AgentId = c.AgentId,
                             EventDate = ce.EventDate,
                             PresenterId = c.PresenterId ?? 0,
                             PresenterName = c.PresenterAccountName,
                             Gross = c.Gross.Value,
                             EventCity = c.VenuePhysicalCity,
                             EventStateId = c.VenuePhysicalStateId,
                             VenueName = c.VenueName,
                             VenueId = c.VenueId,
                             CityState = c.VenuePhysicalCity + ", " + c.LuState1.Abbreviation,
                             HasVenue = c.VenueId != null ? true : false,
                             IsBlocked = false
                         })
                        .Union(
                        from b in this.Context.ArtistBlockedDates
                        where artistIds.Contains(b.ArtistId)
                        && !b.IsDeleted
                        select new ArtistBookDateDto
                        {
                            ContractId = 0,
                            AgentId = 0,
                            EventDate = b.BlockedDate,
                            PresenterId = b.ArtistBlockedDateId,
                            PresenterName = "BLOCKED DATE",
                            Gross = -1m,
                            EventCity = b.PhysicalAddressCity,
                            EventStateId = b.PhysicalAddressStateId,
                            VenueName = string.Empty,
                            VenueId = 0,
                            CityState = b.PhysicalAddressCity + ", " + b.LuState.Abbreviation,
                            HasVenue = false,
                            IsBlocked = true
                        });

            var result = await query
                .OrderThenFilter()
                .ToListAsync();

            result.ForEach(x =>
            {
                x.CityState = x.CityState?.Trim().Trim(new[] { ',' });
            });

            return result;
        }

        public async Task<List<ArtistBookDateDto>> GetBookedDatesAsync(IList<int> artistIds, IList<DateTime> dates)
        {
            var query = (from c in this.Context.Contracts.ForBookedDates()
                         join ce in this.Context.ContractEventDates on c.ContractId equals ce.ContractId
                         join cae in this.Context.ContractArtistEventDates on ce.ContractEventDateId equals cae.ContractEventDateId
                         join ca in this.Context.ContractArtists on cae.ContractArtistId equals ca.ContractArtistId
                         where artistIds.Contains(ca.ArtistId) && dates.Contains(ce.EventDate)
                         select new ArtistBookDateDto
                         {
                             ContractId = c.ContractId,
                             AgentId = c.AgentId,
                             EventDate = ce.EventDate,
                             PresenterId = c.PresenterId ?? 0,
                             PresenterName = c.PresenterAccountName,
                             Gross = c.Gross.Value,
                             EventCity = c.VenuePhysicalCity,
                             EventStateId = c.VenuePhysicalStateId,
                             VenueName = c.VenueName,
                             VenueId = c.VenueId,
                             CityState = c.VenuePhysicalCity + ", " + c.LuState1.Abbreviation,
                             HasVenue = c.VenueId != null ? true : false,
                             IsBlocked = false
                         })
                        .Union(
                        from b in this.Context.ArtistBlockedDates
                        where artistIds.Contains(b.ArtistId) && dates.Contains(b.BlockedDate)
                        && !b.IsDeleted
                        select new ArtistBookDateDto
                        {
                            ContractId = 0,
                            AgentId = 0,
                            EventDate = b.BlockedDate,
                            PresenterId = b.ArtistBlockedDateId,
                            PresenterName = "BLOCKED DATE",
                            Gross = -1m,
                            EventCity = b.PhysicalAddressCity,
                            EventStateId = b.PhysicalAddressStateId,
                            VenueName = string.Empty,
                            VenueId = 0,
                            CityState = b.PhysicalAddressCity + ", " + b.LuState.Abbreviation,
                            HasVenue = false,
                            IsBlocked = true
                        });

            var result = await query
                .OrderThenFilter()
                .ToListAsync();

            result.ForEach(x =>
            {
                x.CityState = x.CityState?.Trim().Trim(new[] { ',' });
            });

            return result;
        }

        public async Task<IList<ArtistDto>> GetByArtistIdsAsync(int[] artistIds)
        {
            var query = this.Context.Artists.Where(x => artistIds.Contains(x.ArtistId));

            var results = await query.ToListAsync();

            var artists = Mapper.Map<List<ArtistDto>>(results);

            return artists;
        }

        public async Task<ArtistsMissingW9Dto> GetArtistsMissingW9Async()
        {
            var dto = new ArtistsMissingW9Dto();

            var w9OnFilePredicate = PredicateBuilder.New<Artist>();
            w9OnFilePredicate = w9OnFilePredicate.And(IsW9OnFileForExclusiveFunction);
            var exclusiveQuery = this.Context.Artists.AsExpandable().Where(w9OnFilePredicate);
            dto.ExclusiveMissingW9Count = await exclusiveQuery.CountAsync();

            w9OnFilePredicate = PredicateBuilder.New<Artist>();
            w9OnFilePredicate = w9OnFilePredicate.Or(IsW9OnFileForNonExclusiveFunction);
            var nonExclusiveQuery = this.Context.Artists.AsExpandable().Where(w9OnFilePredicate);
            dto.NonExclusiveMissingW9Count = await nonExclusiveQuery.CountAsync();

            return dto;
        }

        private ExpressionStarter<Artist> BuildCriteriaPredicate(ArtistSearchCriteriaDto dto)
        {
            var predicate = PredicateBuilder.New<Artist>();

            // Ensure no national artists appear in this search
            predicate = predicate.And(x => x.IsNational == false);

            if (!string.IsNullOrEmpty(dto.Name))
            {
                predicate = predicate.And(x => x.Name.Contains(dto.Name));
            }

            if (dto.ActTypes != null && dto.ActTypes.Any())
            {
                predicate = predicate.And(x => x.ArtistActTypes.Any(aat => dto.ActTypes.Contains(aat.ActTypeId)));
            }

            if (dto.GenreTypes != null && dto.GenreTypes.Any())
            {
                predicate = predicate.And(x => x.ArtistGenreTypes.Any(agt => dto.GenreTypes.Contains(agt.GenreTypeId)));
            }

            if (dto.EventTypes != null && dto.EventTypes.Any())
            {
                predicate = predicate.And(x => x.ArtistEventTypes.Any(aet => dto.EventTypes.Contains(aet.EventTypeId)));
            }

            if (dto.ArtistType.HasValue)
            {
                switch (dto.ArtistType.Value)
                {
                    case 0: // Non-Exclusive
                        predicate = predicate.And(x => !x.IsExclusive);
                        break;

                    case 1: // Exclusive
                        predicate = predicate.And(x => x.IsExclusive);
                        break;

                    case 2: // Touring
                        predicate = predicate.And(x => x.ArtistActTypes.Any(aat => aat.ActTypeId == (int)ActType.PerformingArtsTheater));
                        break;

                    default:
                        break;
                }
            }

            if (dto.AssignedAgent.HasValue)
            {
                predicate = predicate.And(x => x.AgentId == dto.AssignedAgent);
            }

            if (dto.Status.HasValue)
            {
                predicate = predicate.And(x => x.IsActive == dto.Status);
            }

            if (dto.IsW9OnFile.HasValue)
            {
                if (dto.IsW9OnFile == true)
                {
                    predicate = predicate.And(x =>
                        x.IsExclusive == true
                        && x.IsW9OnFile == true
                        && x.IsNational == false);
                }
                else
                {
                    var w9OnFilePredicate = PredicateBuilder.New<Artist>();

                    w9OnFilePredicate = w9OnFilePredicate.And(x => false);

                    w9OnFilePredicate = w9OnFilePredicate.Or(IsW9OnFileForExclusiveFunction);

                    w9OnFilePredicate = w9OnFilePredicate.Or(IsW9OnFileForNonExclusiveFunction);

                    predicate = predicate.And(w9OnFilePredicate);
                }
            }

            if (dto.Is1099Exempt.HasValue)
            {
                predicate = predicate.And(x => x.Is1099Exempt == dto.Is1099Exempt);
            }

            if (dto.BasePriceMaximum.HasValue)
            {
                predicate = predicate.And(x => x.ArtistPrices.Any(ap => ap.IsBasePrice == true && ap.Price <= dto.BasePriceMaximum));
            }

            if (dto.BasePriceMinimum.HasValue)
            {
                predicate = predicate.And(x => x.ArtistPrices.Any(ap => ap.IsBasePrice == true && ap.Price >= dto.BasePriceMinimum));
            }

            if (dto.Distance.HasValue && !string.IsNullOrEmpty(dto.NearbyCity) && !string.IsNullOrEmpty(dto.NearbyState))
            {
                var origin = DaoHelper.CreatePoint(dto.CityStateLat, dto.CityStateLng);

                predicate = predicate.And(x => x.PhysicalGeoLatitude != (decimal)0 && x.PhysicalGeoLongitude != (decimal)0);

                predicate = predicate.And(
                    x =>
                            x.PhysicalGeography.Distance(origin) <= dto.Distance * DaoHelper.MilesToMetersRatio);
            }

            if (dto.Distance.HasValue)
            {
                if (dto.Latitude.HasValue && dto.Longitude.HasValue)
                {
                    var origin = DaoHelper.CreatePoint((double)dto.Latitude.Value, (double)dto.Longitude.Value);

                    predicate =
                        predicate.And(
                            x => x.PhysicalGeography.Distance(origin) <= (double)dto.Distance.Value * DaoHelper.MilesToMetersRatio);
                }
            }

            if (!string.IsNullOrEmpty(dto.TaxIdentificationNumber))
            {
                // exact match
                predicate = predicate.And(x => x.TINHashed == dto.TaxIdentificationNumber);
            }

            if (!string.IsNullOrEmpty(dto.Agency))
            {
                predicate = predicate.And(x => x.AgencyName.Contains(dto.Agency) || x.NationalAgency.Name.Contains(dto.Agency));
            }

            if (dto.IsArchived.HasValue)
            {
                if (!dto.IsArchived.Value)
                {
                    predicate = predicate.And(x => !x.ArchiveDate.HasValue);
                }
                else
                {
                    predicate = predicate.And(x => x.ArchiveDate.HasValue);
                }
            }

            return predicate;
        }

        private (string, string) BuildCriteriaWhereClause(ArtistSearchCriteriaDto dto)
        {
            string getMileLatLong = "0.00";
            StringBuilder sb = new StringBuilder();

            // Ensure no national artists appear in this search
            sb.Append(" IsNational=0 ");

            if (!string.IsNullOrEmpty(dto.Name))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and Name like '%" + dto.Name.ToString().Replace("'", "''") + "%' ");
                }
                else
                {
                    sb.Append(" Name like '%" + dto.Name.ToString().Replace("'", "''") + "%' ");
                }
            }

            if (dto.ActTypes != null && dto.ActTypes.Any())
            {
                string ActTypeIds = string.Empty;
                foreach (var item in dto.ActTypes)
                {
                    if (string.IsNullOrEmpty(ActTypeIds))
                    {
                        ActTypeIds = item.ToString();
                    }
                    else
                    {
                        ActTypeIds += "," + item.ToString();
                    }
                }
                if (!string.IsNullOrEmpty(ActTypeIds))
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and ArtistId in (select ArtistId from ArtistActType with(nolock) where ActTypeId in (" + ActTypeIds + ")) ");
                    }
                    else
                    {
                        sb.Append(" ArtistId in (select ArtistId from ArtistActType with(nolock) where ActTypeId in (" + ActTypeIds + ")) ");
                    }
                }
            }

            if (dto.GenreTypes != null && dto.GenreTypes.Any())
            {
                string GenreTypeIds = string.Empty;
                foreach (var item in dto.GenreTypes)
                {
                    if (string.IsNullOrEmpty(GenreTypeIds))
                    {
                        GenreTypeIds = item.ToString();
                    }
                    else
                    {
                        GenreTypeIds += "," + item.ToString();
                    }
                }
                if (!string.IsNullOrEmpty(GenreTypeIds))
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and ArtistId in (select ArtistId from ArtistGenreType with(nolock) where GenreTypeId in (" + GenreTypeIds + ")) ");
                    }
                    else
                    {
                        sb.Append(" ArtistId in (select ArtistId from ArtistGenreType with(nolock) where GenreTypeId in (" + GenreTypeIds + ")) ");
                    }
                }
            }

            if (dto.EventTypes != null && dto.EventTypes.Any())
            {
                string EventTypeIds = string.Empty;
                foreach (var item in dto.EventTypes)
                {
                    if (string.IsNullOrEmpty(EventTypeIds))
                    {
                        EventTypeIds = item.ToString();
                    }
                    else
                    {
                        EventTypeIds += "," + item.ToString();
                    }
                }
                if (!string.IsNullOrEmpty(EventTypeIds))
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and ArtistId in (select ArtistId from ArtistEventType with(nolock) where EventTypeId in (" + EventTypeIds + ")) ");
                    }
                    else
                    {
                        sb.Append(" ArtistId in (select ArtistId from ArtistEventType with(nolock) where EventTypeId in (" + EventTypeIds + ")) ");
                    }
                }
            }

            if (dto.ArtistType.HasValue)
            {
                switch (dto.ArtistType.Value)
                {
                    case 0: // Non-Exclusive
                        if (sb.Length > 0)
                        {
                            sb.Append(" and IsExclusive=0 ");
                        }
                        else
                        {
                            sb.Append(" IsExclusive=0 ");
                        }
                        break;

                    case 1: // Exclusive
                        if (sb.Length > 0)
                        {
                            sb.Append(" and IsExclusive=1 ");
                        }
                        else
                        {
                            sb.Append(" IsExclusive=1 ");
                        }
                        break;

                    case 2: // Touring

                        if (sb.Length > 0)
                        {
                            sb.Append(" and ArtistId in (select ArtistId from ArtistActType with(nolock) where ActTypeId=" + ((int)ActType.PerformingArtsTheater).ToString() + " ) ");
                        }
                        else
                        {
                            sb.Append(" ArtistId in (select ArtistId from ArtistActType with(nolock) where ActTypeId=" + ((int)ActType.PerformingArtsTheater).ToString() + " ) ");
                        }
                        break;

                    default:
                        break;
                }
            }

            if (dto.AssignedAgent.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and AgentId =" + dto.AssignedAgent.Value.ToString() + " ");
                }
                else
                {
                    sb.Append(" AgentId =" + dto.AssignedAgent.Value.ToString() + " ");
                }
            }

            if (dto.Status.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and IsActive ='" + dto.Status.ToString() + "' ");
                }
                else
                {
                    sb.Append(" IsActive ='" + dto.Status.ToString() + "' ");
                }
            }

            if (dto.IsW9OnFile.HasValue)
            {
                if (dto.IsW9OnFile == true)
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and IsExclusive=1 and IsW9OnFile=1 and IsNational=0 ");
                    }
                    else
                    {
                        sb.Append(" IsExclusive=1 and IsW9OnFile=1 and IsNational=0 ");
                    }
                }
                else
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(@" and ((IsActive = 1 and IsExclusive = 1 and IsW9OnFile = 0 and IsNational = 0) or(IsActive = 1 and IsExclusive = 0 and IsW9OnFile = 0 and IsNational = 0 and name not like '%EASTCOAST'  and name not like '%ECE' and
   
    ArtistId in (select ArtistId from ContractArtist ca with(nolock) inner join Contract c  with(nolock) on ca.ContractId = c.ContractId where ContractStatusId != " + ((int)ContractStatus.Canceled).ToString() + " and ContractStatusId != " + ((int)ContractStatus.PartiallyCanceled).ToString() + " and Convert(Date, IssueDate) > '" + NonExclusiveW9Limit.ToString("yyyy/MM/dd") + "'))) ");
                    }
                    else
                    {
                        sb.Append(@"  ((IsActive = 1 and IsExclusive = 1 and IsW9OnFile = 0 and IsNational = 0) or(IsActive = 1 and IsExclusive = 0 and IsW9OnFile = 0 and IsNational = 0 and name not like '%EASTCOAST'  and name not like '%ECE' and
   
    ArtistId in (select ArtistId from ContractArtist ca with(nolock) inner join Contract c  with(nolock) on ca.ContractId = c.ContractId where ContractStatusId != " + ((int)ContractStatus.Canceled).ToString() + " and ContractStatusId != " + ((int)ContractStatus.PartiallyCanceled).ToString() + " and Convert(Date, IssueDate) > '" + NonExclusiveW9Limit.ToString("yyyy/MM/dd") + "'))) ");
                    }

                }
            }

            if (dto.Is1099Exempt.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and Is1099Exempt='" + dto.Is1099Exempt.Value.ToString() + "' ");
                }
                else
                {
                    sb.Append(" Is1099Exempt='" + dto.Is1099Exempt.Value.ToString() + "' ");
                }
            }

            if (dto.BasePriceMaximum.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and ArtistId in (select ArtistId from ArtistPrice with(nolock) where IsBasePrice=1 and  Price <=" + dto.BasePriceMaximum.Value.ToString() + ") ");
                }
                else
                {
                    sb.Append(" ArtistId in (select ArtistId from ArtistPrice with(nolock) where IsBasePrice=1 and  Price <=" + dto.BasePriceMaximum.Value.ToString() + ") ");
                }
            }

            if (dto.BasePriceMinimum.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and ArtistId in (select ArtistId from ArtistPrice with(nolock) where IsBasePrice=1 and  Price >=" + dto.BasePriceMinimum.Value.ToString() + ") ");
                }
                else
                {
                    sb.Append(" ArtistId in (select ArtistId from ArtistPrice with(nolock) where IsBasePrice=1 and  Price >=" + dto.BasePriceMinimum.Value.ToString() + ") ");
                }
            }

            if (dto.Distance.HasValue && !string.IsNullOrEmpty(dto.NearbyCity) && !string.IsNullOrEmpty(dto.NearbyState))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and (geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.CityStateLat.ToString() + ", " + dto.CityStateLng.ToString() + ", 4326))<= " + ((double)dto.Distance.Value * DaoHelper.MilesToMetersRatio).ToString() + " ");
                }
                else
                {
                    sb.Append(" (geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.CityStateLat.ToString() + ", " + dto.CityStateLng.ToString() + ", 4326))<= " + ((double)dto.Distance.Value * DaoHelper.MilesToMetersRatio).ToString() + " ");
                }

                getMileLatLong = "iif(PhysicalGeoLatitude is null or PhysicalGeoLatitude=0,0,ROUND((geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.CityStateLat.ToString() + ", " + dto.CityStateLng.ToString() + ", 4326))/1609.344, 2))";
            }

            if (dto.Distance.HasValue)
            {
                if (dto.Latitude.HasValue && dto.Longitude.HasValue)
                {


                    if (sb.Length > 0)
                    {
                        sb.Append(" and (geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.Latitude.Value.ToString() + ", " + dto.Longitude.Value.ToString() + ", 4326))<= " + ((double)dto.Distance.Value * DaoHelper.MilesToMetersRatio).ToString() + " ");
                    }
                    else
                    {
                        sb.Append(" (geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.Latitude.Value.ToString() + ", " + dto.Longitude.Value.ToString() + ", 4326))<= " + ((double)dto.Distance.Value * DaoHelper.MilesToMetersRatio).ToString() + " ");
                    }

                    getMileLatLong = "iif(PhysicalGeoLatitude is null or PhysicalGeoLatitude=0,0,ROUND((geography::Point(isnull(PhysicalGeoLatitude,0), isnull(PhysicalGeoLongitude,0), 4326)).STDistance(geography::Point(" + dto.Latitude.Value.ToString() + ", " + dto.Longitude.Value.ToString() + ", 4326))/1609.344, 2))";

                }
            }

            if (!string.IsNullOrEmpty(dto.TaxIdentificationNumber))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and TINHashed='" + dto.TaxIdentificationNumber + "' ");
                }
                else
                {
                    sb.Append(" TINHashed='" + dto.TaxIdentificationNumber + "' ");
                }
            }

            if (!string.IsNullOrEmpty(dto.Agency))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and (AgencyName like  '%" + dto.Agency.ToString().Replace("'", "''") + "%' or NationalAgencyId in (select NationalAgencyId from NationalAgency with(nolock) where name like  '%" + dto.Agency.Replace("'", "''") + "%'  )");
                }
                else
                {
                    sb.Append(" (AgencyName like  '%" + dto.Agency.ToString().Replace("'", "''") + "%' or NationalAgencyId in (select NationalAgencyId from NationalAgency with(nolock) where name like  '%" + dto.Agency.Replace("'", "''") + "%'  )");
                }
            }

            if (dto.IsArchived.HasValue)
            {
                if (!dto.IsArchived.Value)
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and  ArchiveDate  is  null ");
                    }
                    else
                    {
                        sb.Append(" ArchiveDate  is  null ");
                    }
                }
                else
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and  ArchiveDate  is not null ");
                    }
                    else
                    {
                        sb.Append(" ArchiveDate  is not  null ");
                    }
                }
            }

            return (sb.ToString(), getMileLatLong);
        }

        public async Task<string> GetNationalArtistsByCriteriaWhereClause(NationalArtistSearchCriteriaDto criteria)
        {
            StringBuilder sb = new StringBuilder();
            // Ensure only national artists appear in this search

            sb.Append(" IsNational=1 ");

            if (!string.IsNullOrEmpty(criteria.Name))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and Name like '%" + criteria.Name.Replace("'", "''") + "%' ");
                }
                else
                {
                    sb.Append(" Name like '%" + criteria.Name.Replace("'", "''") + "%' ");
                }
            }

            if (!string.IsNullOrEmpty(criteria.Agency))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and NationalAgencyId in (select NationalAgencyId from NationalAgency with(nolock) where Name like '%" + criteria.Agency.ToString().Replace("'", "''") + "%') ");
                }
                else
                {
                    sb.Append(" NationalAgencyId in (select NationalAgencyId from NationalAgency with(nolock) where Name like '%" + criteria.Agency.ToString().Replace("'", "''") + "%') ");
                }
            }

            if (criteria.GenreTypes != null && criteria.GenreTypes.Any())
            {
                string genreTypeIds = string.Empty;
                foreach (var item in criteria.GenreTypes)
                {
                    if (string.IsNullOrEmpty(genreTypeIds))
                    {
                        genreTypeIds = item.ToString();

                    }
                    else
                    {
                        genreTypeIds += "," + item.ToString();
                    }
                }

                if (!string.IsNullOrEmpty(genreTypeIds))
                {
                    if (sb.Length > 0)
                    {
                        sb.Append(" and ArtistId in (select ArtistId from ArtistGenreType with(nolock) where GenreTypeId in (" + genreTypeIds + ")) ");
                    }
                    else
                    {
                        sb.Append(" ArtistId in (select ArtistId from ArtistGenreType with(nolock) where GenreTypeId in (" + genreTypeIds + ")) ");
                    }
                }
            }

            if (criteria.Status.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and IsActive='" + criteria.Status.Value.ToString() + "' ");
                }
                else
                {
                    sb.Append(" IsActive='" + criteria.Status.Value.ToString() + "' ");
                }
            }

            if (!string.IsNullOrEmpty(criteria.AgentFirstName))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and ArtistId in ( select ArtistId from NationalArtistContact with(nolock) where ContactId in (select ContactId from Contact with(nolock) where FirstName like '%" + criteria.AgentFirstName + "%' )) ");
                }
                else
                {
                    sb.Append(" ArtistId in ( select ArtistId from NationalArtistContact with(nolock) where ContactId in (select ContactId from Contact with(nolock) where FirstName like '%" + criteria.AgentFirstName + "%' )) ");
                }
            }

            if (!string.IsNullOrEmpty(criteria.AgentLastName))
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and ArtistId in ( select ArtistId from NationalArtistContact with(nolock) where ContactId in (select ContactId from Contact with(nolock) where LastName like '%" + criteria.AgentLastName + "%' )) ");
                }
                else
                {
                    sb.Append(" ArtistId in ( select ArtistId from NationalArtistContact with(nolock) where ContactId in (select ContactId from Contact with(nolock) where LastName like '%" + criteria.AgentLastName + "%' )) ");
                }
            }

            if (criteria.OneOffPriceFrom.HasValue && !criteria.OneOffPriceTo.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and isnull( NationalOneOffPrice,0) >= " + criteria.OneOffPriceFrom.Value.ToString() + " ");
                }
                else
                {
                    sb.Append(" isnull( NationalOneOffPrice,0) >= " + criteria.OneOffPriceFrom.Value.ToString() + " ");
                }
            }
            else if (!criteria.OneOffPriceFrom.HasValue && criteria.OneOffPriceTo.HasValue)
            {


                if (sb.Length > 0)
                {
                    sb.Append(" and isnull( NationalOneOffPrice,0) <= " + criteria.OneOffPriceTo.Value.ToString() + " ");
                }
                else
                {
                    sb.Append("  isnull( NationalOneOffPrice,0) <= " + criteria.OneOffPriceTo.Value.ToString() + " ");
                }
            }
            else if (criteria.OneOffPriceFrom.HasValue && criteria.OneOffPriceTo.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and isnull( NationalOneOffPrice,0) between " + criteria.OneOffPriceFrom.Value.ToString() + " and " + criteria.OneOffPriceTo.Value.ToString() + " ");
                }
                else
                {
                    sb.Append(" isnull( NationalOneOffPrice,0) between " + criteria.OneOffPriceFrom.Value.ToString() + " and " + criteria.OneOffPriceTo.Value.ToString() + " ");
                }
            }

            if (criteria.NationalNetPriceFrom.HasValue && !criteria.NationalNetPriceTo.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and  NationalNetPriceLowerBound >= " + criteria.NationalNetPriceFrom.Value.ToString() + " ");
                }
                else
                {
                    sb.Append("  NationalNetPriceLowerBound >= " + criteria.NationalNetPriceFrom.Value.ToString() + " ");
                }
            }
            else if (!criteria.NationalNetPriceFrom.HasValue && criteria.NationalNetPriceTo.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and  NationalNetPriceUpperBound <= " + criteria.NationalNetPriceTo.Value.ToString() + " ");
                }
                else
                {
                    sb.Append("   NationalNetPriceUpperBound <= " + criteria.NationalNetPriceTo.Value.ToString() + " ");
                }
            }
            else if (criteria.NationalNetPriceFrom.HasValue && criteria.NationalNetPriceTo.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and NationalNetPriceLowerBound >= " + criteria.NationalNetPriceFrom.Value.ToString() + " and  NationalNetPriceUpperBound <=" + criteria.NationalNetPriceTo.Value.ToString() + " ");
                }
                else
                {
                    sb.Append("  NationalNetPriceLowerBound >= " + criteria.NationalNetPriceFrom.Value.ToString() + " and  NationalNetPriceUpperBound <=" + criteria.NationalNetPriceTo.Value.ToString() + " ");
                }
            }

            if (criteria.InquiryId.HasValue)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" and ArtistId in  (select ArtistId from InquiryRequestedArtist with(nolock) where InquiryId=" + criteria.InquiryId.Value.ToString() + ") ");
                }
                else
                {
                    sb.Append(" ArtistId in  (select ArtistId from InquiryRequestedArtist with(nolock) where InquiryId=" + criteria.InquiryId.Value.ToString() + ") ");
                }
            }


            return sb.ToString();
        }
    }
}
