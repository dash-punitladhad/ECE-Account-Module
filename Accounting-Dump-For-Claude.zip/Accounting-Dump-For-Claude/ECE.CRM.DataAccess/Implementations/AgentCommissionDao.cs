﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using LinqKit;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class AgentCommissionDao : BaseDataAccessObject, IAgentCommissionDao
    {
        public AgentCommissionDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IEnumerable<CommissionManagementSearchResultDto>> GetAgentCommissionsByCriteriaAsync(CommissionManagementSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var predicate = PredicateBuilder.New<vwAgentCommission>();

            predicate = predicate.And(x => x.AgentId > 0);

            if (criteria.CommissionType.HasValue)
            {
                predicate = predicate.And(x => x.AgentCommissionTypeId == criteria.CommissionType.Value);
            }

            if (criteria.Status.HasValue)
            {
                predicate = predicate.And(x => x.StatusId == criteria.Status);
            }

            if (criteria.AgentId.HasValue && criteria.AgentId > 0)
            {
                predicate = predicate.And(x => x.AgentId == criteria.AgentId);
            }

            if (criteria.OfficeId.HasValue && criteria.OfficeId > 0)
            {
                predicate = predicate.And(x => x.OfficeId == criteria.OfficeId);
            }

            var maxResults = MobiusConfiguration.GetInt32("Search.MaxResults");

            var results = await Context.vwAgentCommissions
                .AsExpandable()
                .Where(predicate)
                .Take(maxResults + 1)
                .ToListAsync();

            var searchResults = Mapper.Map<IList<CommissionManagementSearchResultDto>>(results);

            return searchResults;
        }

        public async Task<AgentCommissionDto> GetByAgentIdAsync(int id)
        {
            var agentCommission = await this.Context.vwAgentCommissions.FirstOrDefaultAsync(x => x.AgentId == id);
            if (agentCommission == null)
            {
                return null;
            }

            var dto = Mapper.Map<AgentCommissionDto>(agentCommission);

            return dto;
        }

        public async Task<IEnumerable<AgentCommissionTypeDataDto>> GetCommissionInstanceRates()
        {
            var query = this.Context.LuCommissionInstanceRates
                .Where(x => x.IsActive)
                .Select(x => new AgentCommissionTypeDataDto { AgentCommissionId = x.CommissionInstanceRateId, LowerNumeric = x.LowerBound, UpperNumeric = x.UpperBound, Percentage = x.AgentPercent })
                .OrderBy(x => x.LowerNumeric);

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<AgentCommissionTypeDataDto>> GetTypeDataByAgentCommissionIdAsync(int id)
        {
            var query = this.Context.AgentCommissionTypeDatas
                .Where(x => x.AgentCommissionId == id
                    && x.IsDeleted == false);

            var results = await query.ToListAsync();

            var searchResults = Mapper.Map<IList<AgentCommissionTypeDataDto>>(results);

            return searchResults;
        }

        public async Task<IEnumerable<AgentCommissionProgramDto>> GetPresenterTransfersByAgentIdAsync(int id)
        {
            var presenterTransferProgram = (int)CommissionProgram.PresenterTransfer;

            var programsQuery = this.Context.AgentCommissionPrograms
                .Where(x => x.ToAppUserId == id
                    && x.CommissionProgramId == presenterTransferProgram
                    && x.IsDeleted == false);

            var query = from acp in programsQuery
                        join p in this.Context.Presenters on acp.FromEntityId equals p.PresenterId
                        select new AgentCommissionProgramDto
                        {
                            AgentCommissionProgramId = acp.AgentCommissionProgramId,
                            CommissionProgramId = acp.CommissionProgramId,
                            FromEntityTypeId = acp.FromEntityTypeId,
                            FromEntityId = acp.FromEntityId,
                            FromEntityName = p.AccountName + " (" + p.OrganizationName + ")",
                            ToAppUserId = acp.ToAppUserId,
                            SplitPercentage = acp.SplitPercentage,
                            SplitAmount = acp.SplitAmount,
                            StartDate = acp.StartDate,
                            EndDate = acp.EndDate,
                            PresenterAppUserId = p.AppUser.AppUserId,
                            PresenterAppUserFullName = p.AppUser.FirstName + " " + p.AppUser.LastName,
                        };

            IEnumerable<AgentCommissionProgramDto> results = await query.OrderByDescending(x => x.StartDate).ToListAsync();

            results = results.Select(x =>
            {
                if (x.FromEntityName.EndsWith(" ()"))
                {
                    x.FromEntityName = x.FromEntityName.Replace(" ()", string.Empty);
                }

                return x;
            });

            return results;
        }

        public async Task<AgentCommissionProgramDto> GetPresenterTransferAsync(int presenterId)
        {
            var presenterTransferProgram = (int)CommissionProgram.PresenterTransfer;

            var programsQuery = this.Context.AgentCommissionPrograms
                .Where(x => x.FromEntityId == presenterId
                    && x.CommissionProgramId == presenterTransferProgram
                    && x.IsDeleted == false);

            var query = from acp in programsQuery
                        join p in this.Context.Presenters on acp.FromEntityId equals p.PresenterId
                        select new AgentCommissionProgramDto
                        {
                            AgentCommissionProgramId = acp.AgentCommissionProgramId,
                            CommissionProgramId = acp.CommissionProgramId,
                            FromEntityTypeId = acp.FromEntityTypeId,
                            FromEntityId = acp.FromEntityId,
                            FromEntityName = p.AccountName + " (" + p.OrganizationName + ")",
                            ToAppUserId = acp.ToAppUserId,
                            SplitPercentage = acp.SplitPercentage,
                            SplitAmount = acp.SplitAmount,
                            StartDate = acp.StartDate,
                            EndDate = acp.EndDate,
                            PresenterAppUserId = p.AppUser.AppUserId,
                            PresenterAppUserFullName = p.AppUser.FirstName + " " + p.AppUser.LastName
                        };

            AgentCommissionProgramDto program = await query.FirstOrDefaultAsync();

            if (program != null && program.FromEntityName.EndsWith(" ()"))
            {
                program.FromEntityName = program.FromEntityName.Replace(" ()", string.Empty);
            }

            return program;
        }

        public async Task<AgentCommissionProgramDto> GetMentorByAgentIdAsync(int id)
        {
            var mentorProgram = (int)CommissionProgram.Mentor;
            var agentEntity = (int)EntityType.Agent;

            var programsQuery = this.Context.AgentCommissionPrograms
                .Where(x => x.FromEntityId == id
                    && x.FromEntityTypeId == agentEntity
                    && x.CommissionProgramId == mentorProgram
                    && x.IsDeleted == false);

            var query = from acp in programsQuery
                        join au in this.Context.AppUsers on acp.FromEntityId equals au.AppUserId
                        select new AgentCommissionProgramDto
                        {
                            AgentCommissionProgramId = acp.AgentCommissionProgramId,
                            CommissionProgramId = acp.CommissionProgramId,
                            FromEntityTypeId = acp.FromEntityTypeId,
                            FromEntityId = acp.FromEntityId,
                            FromEntityName = au.FirstName + " " + au.LastName,
                            ToAppUserId = acp.ToAppUserId,
                            SplitPercentage = acp.SplitPercentage,
                            SplitAmount = acp.SplitAmount,
                            StartDate = acp.StartDate,
                            EndDate = acp.EndDate,
                        };

            return await query.FirstOrDefaultAsync();
        }

        public async Task CreateAgentCommissionAsync(AgentCommissionDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newAgentCommission = new AgentCommission();

            newAgentCommission.AppUserId = dto.AgentId;
            newAgentCommission.AgentCommissionTypeId = dto.AgentCommissionTypeId.Value;
            newAgentCommission.IsDeleted = false;
            newAgentCommission.CreatedById = dto.CreatedById;
            newAgentCommission.CreatedDate = dto.CreatedDate;

            this.Context.AgentCommissions.Add(newAgentCommission);

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAgentCommissionAsync(AgentCommissionDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (dto.AgentCommissionId == null)
            {
                throw new ArgumentException("AgentCommissionId is missing.");
            }

            var query = this.Context.AgentCommissions
                .Where(x => !x.IsDeleted &&
                    x.AgentCommissionId == dto.AgentCommissionId.Value);
            var agentCommission = await query.FirstOrDefaultAsync();
            if (agentCommission == null)
            {
                throw new ArgumentException($"AgentCommission {dto.AgentCommissionId} not found.");
            }

            agentCommission.IsDeleted = true;
            agentCommission.UpdatedById = dto.UpdatedById;
            agentCommission.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task AddAgentCommissionTypeDataAsync(AgentCommissionTypeDataDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newTypeData = Mapper.Map<AgentCommissionTypeData>(dto);

            newTypeData.IsDeleted = false;

            this.Context.AgentCommissionTypeDatas.Add(newTypeData);

            await this.Context.SaveChangesAsync();
        }

        public async Task UpdateAgentCommissionTypeDataAsync(AgentCommissionTypeDataDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var query = this.Context.AgentCommissionTypeDatas
                .Where(x => !x.IsDeleted &&
                    x.AgentCommissionTypeDataId == dto.AgentCommissionTypeDataId);
            var agentCommissionTypeData = await query.FirstOrDefaultAsync();
            if (agentCommissionTypeData == null)
            {
                throw new ArgumentException($"AgentCommissionTypeData {dto.AgentCommissionTypeDataId} not found.");
            }

            agentCommissionTypeData.LowerDate = dto.LowerDate;
            agentCommissionTypeData.LowerNumeric = dto.LowerNumeric;
            agentCommissionTypeData.UpperDate = dto.UpperDate;
            agentCommissionTypeData.UpperNumeric = dto.UpperNumeric;
            agentCommissionTypeData.Percentage = dto.Percentage;

            agentCommissionTypeData.UpdatedById = dto.UpdatedById;
            agentCommissionTypeData.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAgentCommissionTypeDataAsync(AgentCommissionTypeDataDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var query = this.Context.AgentCommissionTypeDatas
                .Where(x => !x.IsDeleted &&
                    x.AgentCommissionTypeDataId == dto.AgentCommissionTypeDataId);
            var agentCommissionTypeData = await query.FirstOrDefaultAsync();
            if (agentCommissionTypeData == null)
            {
                throw new ArgumentException($"AgentCommissionTypeData {dto.AgentCommissionTypeDataId} not found.");
            }

            agentCommissionTypeData.IsDeleted = true;
            agentCommissionTypeData.UpdatedById = dto.UpdatedById;
            agentCommissionTypeData.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task CreateAgentCommissionProgramAsync(AgentCommissionProgramDto dto)
        {
            var newProgram = Mapper.Map<AgentCommissionProgram>(dto);

            this.Context.AgentCommissionPrograms.Add(newProgram);

            await this.Context.SaveChangesAsync();

            dto.AgentCommissionProgramId = newProgram.AgentCommissionProgramId;
        }

        public async Task UpdateAgentCommissionProgramAsync(AgentCommissionProgramDto dto)
        {
            var query = this.Context.AgentCommissionPrograms
                .Where(x => !x.IsDeleted &&
                    x.AgentCommissionProgramId == dto.AgentCommissionProgramId);
            var program = await query.FirstOrDefaultAsync();
            if (program == null)
            {
                throw new ArgumentException($"AgentCommissionProgram {dto.AgentCommissionProgramId} not found.");
            }

            program.ToAppUserId = dto.ToAppUserId;
            program.SplitPercentage = dto.SplitPercentage;
            program.StartDate = dto.StartDate;
            program.EndDate = dto.EndDate;

            program.UpdatedById = dto.UpdatedById;
            program.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAgentCommissionProgramAsync(AgentCommissionProgramDto dto)
        {
            var query = this.Context.AgentCommissionPrograms
                .Where(x => !x.IsDeleted &&
                    x.AgentCommissionProgramId == dto.AgentCommissionProgramId);
            var program = await query.FirstOrDefaultAsync();
            if (program == null)
            {
                throw new ArgumentException($"AgentCommissionProgram {dto.AgentCommissionProgramId} not found.");
            }

            program.IsDeleted = true;
            program.UpdatedById = dto.UpdatedById;
            program.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }
    }
}
