﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistSongDao : BaseDataAccessObject, IArtistSongDao
    {
        public ArtistSongDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<ArtistSongDto>> GetArtistSongsAsync(int artistId)
        {
            var songResults = await this.Context.ArtistSongs.Where(x => x.ArtistId == artistId).ToListAsync();

            var songs = Mapper.Map<IList<ArtistSongDto>>(songResults);

            return songs;
        }

        public async Task<IList<ArtistSongDto>> GetApprovedArtistSongsAsync(int artistId)
        {
            var songResults = await this.Context.ArtistSongs.Where(x => x.ArtistId == artistId && x.IsApproved).ToListAsync();

            var songs = Mapper.Map<IList<ArtistSongDto>>(songResults);

            return songs;
        }

        public async Task<IList<ArtistSongDto>> GetPendingArtistSongsAsync(int artistId)
        {
            var songResults = await this.Context.ArtistSongs.Where(x => x.ArtistId == artistId && !x.IsApproved).ToListAsync();

            var songs = Mapper.Map<IList<ArtistSongDto>>(songResults);

            return songs;
        }

        public async Task<ArtistSongDto> GetArtistSongByIdAsync(int artistSongId)
        {
            var songResult = await this.Context.ArtistSongs.FirstOrDefaultAsync(x => x.ArtistSongId == artistSongId);

            var song = Mapper.Map<ArtistSongDto>(songResult);

            return song;
        }

        public async Task CreateAsync(ArtistSongDto song)
        {
            if (song == null)
            {
                throw new ArgumentNullException(nameof(song));
            }

            var newItem = Mapper.Map<ArtistSongDto, ArtistSong>(song);

            this.Context.ArtistSongs.Add(newItem);

            await this.Context.SaveChangesAsync();
        }

        public async Task UpdateAsync(ArtistSongDto song)
        {
            var songRecord = this.Context.ArtistSongs.FirstOrDefault(x => x.ArtistSongId == song.ArtistSongId);
            if (songRecord == null)
            {
                throw new ArgumentNullException(nameof(song));
            }

            songRecord.SongName = song.SongName;
            songRecord.ArtistName = song.ArtistName;
            songRecord.Genre = song.Genre;
            songRecord.UpdatedById = song.UpdatedById;
            songRecord.UpdatedDate = song.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAsync(ArtistSongDto song)
        {
            var songRecord = this.Context.ArtistSongs.FirstOrDefault(x => x.ArtistSongId == song.ArtistSongId);
            if (songRecord == null)
            {
                throw new ArgumentNullException(nameof(song));
            }

            this.Context.ArtistSongs.Remove(songRecord);

            await this.Context.SaveChangesAsync();
        }

        public async Task ApproveAsync(ArtistSongDto song)
        {
            var songRecord = this.Context.ArtistSongs.FirstOrDefault(x => x.ArtistSongId == song.ArtistSongId);
            if (songRecord == null)
            {
                throw new ArgumentNullException(nameof(song));
            }

            songRecord.IsApproved = true;
            songRecord.UpdatedById = song.UpdatedById;
            songRecord.UpdatedDate = song.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }
    }
}
