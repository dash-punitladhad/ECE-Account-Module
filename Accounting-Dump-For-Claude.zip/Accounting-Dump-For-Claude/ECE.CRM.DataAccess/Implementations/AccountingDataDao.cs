﻿namespace ECE.CRM.DataAccess
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using Dapper;
    using System.Data;

    public class AccountingDataDao : BaseDataAccessObject, IAccountingDataDao
    {
        public AccountingDataDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<BasicAgentSalesStatsDto>> GetBasicAgentSalesStatsAsync(DateTime fromDate, DateTime toDate)
        {
            var fromPostedDate = fromDate.Date;
            var toPostedDate = toDate.AddDays(1).Date;

            var bookedContracts = new List<BookedReport>();
            var cancelledContracts = new List<CancelledReport>();
            var netSales = new List<SalesReport>();

            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"FromDate",fromPostedDate.Date},
                    {"ToDate",toPostedDate.Date}
                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    var multi = await conn.QueryMultipleAsync("Sp_Get_AgentSalesReport", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);


                    bookedContracts = (await multi.ReadAsync<BookedReport>()).ToList();
                    cancelledContracts =(await multi.ReadAsync<CancelledReport>()).ToList();
                    netSales = (await multi.ReadAsync<SalesReport>()).ToList();
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
            }



            var uniqueStats = bookedContracts.Select(c => new { AgentId = c.AgentId, c.LineOfBusinessId }).Distinct()
                .Union(cancelledContracts.Select(c => new { AgentId = c.AgentId, c.LineOfBusinessId }).Distinct())
                .Union(netSales.Where(x => x.NetSales != decimal.Zero).Select(c => new { AgentId = c.AgentId, c.LineOfBusinessId }).Distinct())
                .OrderBy(x => x.AgentId)
                .ThenBy(x => x.LineOfBusinessId);

            var uniqueAgents = uniqueStats.Select(x => x.AgentId).Distinct();

            var agents = this.Context.vwAgentOffices.Where(x => uniqueAgents.Contains(x.AppUserId));

            var data = new List<BasicAgentSalesStatsDto>();

            var agentLookup = agents.ToDictionary(x => x.AppUserId);

            foreach (var item in uniqueStats)
            {
                var newElement = new BasicAgentSalesStatsDto();
                vwAgentOffice vwA;
                if (agentLookup.TryGetValue(item.AgentId, out vwA))
                {
                    if (vwA != null)
                    {
                        var officeId = agentLookup[item.AgentId].OfficeId;
                        newElement.OfficeId = officeId;
                    }
                }

                newElement.AgentId = item.AgentId;

                newElement.LineOfBusinessId = item.LineOfBusinessId;
                newElement.BookedCount = bookedContracts.FirstOrDefault(x => x.AgentId == item.AgentId && x.LineOfBusinessId == item.LineOfBusinessId)?.BookedCount ?? 0;
                newElement.CancelledCount = cancelledContracts.FirstOrDefault(x => x.AgentId == item.AgentId && x.LineOfBusinessId == item.LineOfBusinessId)?.CancelledCount ?? 0;
                newElement.NetSales = netSales.FirstOrDefault(x => x.AgentId == item.AgentId && x.LineOfBusinessId == item.LineOfBusinessId)?.NetSales ?? decimal.Zero;

                data.Add(newElement);
            }

            var orderedData = data
                .OrderBy(x => x.OfficeId)
                .ThenBy(x => x.AgentId)
                .ThenBy(x => x.LineOfBusinessId)
                .ToList();

            return orderedData;
        }

        public async Task<IList<CollectionsByOfficeDto>> GetCollectionsByOfficeAsync(DateTime fromDate, DateTime toDate,IPrincipal User)
        {
            if (User.IsInRole(ECERole.SysAdmin) || User.IsInRole(ECERole.Accounting) || User.IsInRole(ECERole.Owner) || User.IsInRole(ECERole.AccountingAdmin))
            {
                var fromPostedDate = fromDate.Date;
                var toPostedDate = toDate.AddDays(1).Date;

                var query =
                    from glj in this.Context.GeneralLedgerJournals
                    join c in this.Context.Contracts on glj.ContractId equals c.ContractId
                    where glj.PostedDate >= fromPostedDate
                    && glj.PostedDate < toPostedDate
                    && glj.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Revenue ||
                    glj.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.AdminRevenueAccount
                    group glj by new { glj.AgentId, c.LineOfBusinessId, glj.OfficeId } into g
                    select new CollectionsByOfficeDto
                    {
                        AgentId = g.Key.AgentId,
                        LineOfBusinessId = g.Key.LineOfBusinessId,
                        PostedAmount = g.Sum(x => x.ChangeType == "C" ? x.PostedAmount : -x.PostedAmount),
                        OfficeId = g.Key.OfficeId
                    };

                var data = await query.ToListAsync();

                var uniqueAgents = data.Where(x => x.AgentId.HasValue).Select(x => x.AgentId).Distinct();

                var agents = this.Context.vwAgentOffices.Where(x => uniqueAgents.Contains(x.AppUserId));

                var agentLookup = agents.ToDictionary(x => x.AppUserId);

                foreach (var item in data)
                {
                    if (item.AgentId.HasValue)
                    {
                        vwAgentOffice vwA;
                        if (agentLookup.TryGetValue(item.AgentId.Value, out vwA))
                        {
                            if (vwA != null)
                            {
                                var officeId = agentLookup[item.AgentId.Value].OfficeId;

                                item.OfficeId = officeId;
                            }
                        }
                    }
                }

                var orderedData = data
                    .Where(x => x.AgentId != null)
                    .OrderBy(x => x.OfficeId)
                    .ThenBy(x => x.AgentId)
                    .ThenBy(x => x.LineOfBusinessId)
                    .ToList();

                return orderedData;
            }
            else
            {
                var fromPostedDate = fromDate.Date;
                var toPostedDate = toDate.AddDays(1).Date;

                var query =
                    from glj in this.Context.GeneralLedgerJournals
                    join c in this.Context.Contracts on glj.ContractId equals c.ContractId
                    where glj.PostedDate >= fromPostedDate
                    && glj.PostedDate < toPostedDate
                    && glj.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Revenue
                    group glj by new { glj.AgentId, c.LineOfBusinessId, glj.OfficeId } into g
                    select new CollectionsByOfficeDto
                    {
                        AgentId = g.Key.AgentId,
                        LineOfBusinessId = g.Key.LineOfBusinessId,
                        PostedAmount = g.Sum(x => x.ChangeType == "C" ? x.PostedAmount : -x.PostedAmount),
                        OfficeId = g.Key.OfficeId
                    };

                var data = await query.ToListAsync();

                var uniqueAgents = data.Where(x => x.AgentId.HasValue).Select(x => x.AgentId).Distinct();

                var agents = this.Context.vwAgentOffices.Where(x => uniqueAgents.Contains(x.AppUserId));

                var agentLookup = agents.ToDictionary(x => x.AppUserId);

                foreach (var item in data)
                {
                    if (item.AgentId.HasValue)
                    {
                        vwAgentOffice vwA;
                        if (agentLookup.TryGetValue(item.AgentId.Value, out vwA))
                        {
                            if (vwA != null)
                            {
                                var officeId = agentLookup[item.AgentId.Value].OfficeId;

                                item.OfficeId = officeId;
                            }
                        }
                    }
                }

                var orderedData = data
                    .Where(x => x.AgentId != null)
                    .OrderBy(x => x.OfficeId)
                    .ThenBy(x => x.AgentId)
                    .ThenBy(x => x.LineOfBusinessId)
                    .ToList();

                return orderedData;
            }
        }

        public async Task<IList<FeesBreakdownDto>> GetFeesBreakdownAsync(ExportDataCriteriaDto criteria, IList<int> accounts)
        {
            var fromDate = criteria.FromDate.Date;
            var toDate = criteria.ToDate.AddDays(1).Date;

            var query =
                from glj in this.Context.GeneralLedgerJournals
                join c in this.Context.Contracts on glj.ContractId equals c.ContractId
                join gla in this.Context.GeneralLedgerAccounts on glj.GeneralLedgerAccountId equals gla.GeneralLedgerAccountId
                where glj.PostedDate >= fromDate
                && glj.PostedDate < toDate
                && accounts.Contains(glj.GeneralLedgerAccountId)
                group glj by new { OfficeId = glj.OfficeId ?? c.OfficeId, glj.GeneralLedgerAccountId, gla.AccountName, glj.ChangeType } into g
                select new FeesBreakdownDto
                {
                    OfficeId = g.Key.OfficeId,
                    GeneralLedgerAccountId = g.Key.GeneralLedgerAccountId,
                    AccountName = g.Key.AccountName,
                    ChangeType = g.Key.ChangeType,
                    PostedAmount = g.Sum(x => x.PostedAmount)
                };

            var data = await query.ToListAsync();

            var orderedData = data
                .Where(x => x.OfficeId != null)
                .OrderBy(x => x.GeneralLedgerAccountId)
                .ThenBy(x => x.OfficeId)
                .ThenBy(x => x.ChangeType)
                .ToList();

            return orderedData;
        }

        public async Task<IList<UnpaidCommissionDto>> GetUnpaidCommissionsAsync(DateTime asOfDate)
        {
            decimal smallestAllowedCommission = ECEBusinessConstants.CommissionConstants.SmallestAllowedCommission;

            var asOfDateLimit = asOfDate.AddDays(1).Date;
            var inactiveDateLimit = asOfDateLimit.AddMonths(-6);

            var sql = @"
SELECT o.OfficeId
     , gl.ContractId
     , (gl.CollectedAmount - isnull(gl.PaidAmount, 0)) as RequiredAmount
	 , gl.AgentId
	 , au.FirstName + ' ' + au.LastName as AgentName
	 , (select convert(date, max(EventDate)) from ContractEventDate ed where ed.ContractId = gl.ContractId) as [MaxEventDate]
	 , isnull(gl.PaidAmount, 0) as GLPaidAmount
	 , isnull(gl.UnpaidAmount, 0) as GLUnpaidAmount
	 , iif(c.ContractStatusId >= 6, 'CANCELLED', '') as [Status]
	 , iif(c.CancellationDate is null OR c.CancellationDate >= {0}, NULL, c.CancellationDate) as [Cancellation Date]
	 , c.OfficeId as ContractOfficeId
FROM  fncContractAgent({0}) gl
JOIN Contract c on c.ContractId = gl.ContractId
JOIN vwContractMoney m on m.ContractId = gl.ContractId
LEFT JOIN vwAgentOffice auo
     ON auo.AppUserId = gl.AgentId
LEFT JOIN LuOffice o
     ON auo.OfficeId = o.OfficeId
JOIN AppUser au ON au.AppUserId = gl.AgentId
where (gl.PaidAmount is null or gl.PaidAmount <> gl.CollectedAmount)
and gl.CollectedAmount > 0
and (gl.UnpaidAmount is null or gl.UnpaidAmount <> 0)
and not exists (select 1 from fncPaidContract({0}, gl.ContractId))
and (c.ContractStatusId < 6 OR c.CancellationDate >= {0})
and (c.CancellationDate is null OR c.CancellationDate >= {0})
and m.CommissionAmount >= {1}
and (o.OfficeId is not null or (au.IsActive = 0 and au.UpdatedDate >= {2}))
order by 4, 2
";
            var parameters = new object[]
            {
                asOfDateLimit,
                smallestAllowedCommission,
                inactiveDateLimit
            };

            var data = await this.Context.SqlQueryAsync<UnpaidCommissionDto>(sql, parameters);

            return data;
        }

        public async Task<IList<FeesBreakdownDto>> GetGLBreakdownAsync(ExportDataCriteriaDto criteria)
        {
            var fromDate = criteria.FromDate;
            var toDate = criteria.ToDate.AddDays(1).Date;

            var query =
                from glj in this.Context.GeneralLedgerJournals
                join gla in this.Context.GeneralLedgerAccounts on glj.GeneralLedgerAccountId equals gla.GeneralLedgerAccountId
                where glj.PostedDate >= fromDate
                && glj.PostedDate < toDate
                group glj by new { glj.GeneralLedgerAccountId, gla.AccountName, glj.ChangeType } into g
                select new FeesBreakdownDto
                {
                    GeneralLedgerAccountId = g.Key.GeneralLedgerAccountId,
                    AccountName = g.Key.AccountName,
                    ChangeType = g.Key.ChangeType,
                    PostedAmount = g.Sum(x => x.PostedAmount)
                };

            var data = await query.ToListAsync();

            var orderedData = data
                .OrderBy(x => x.GeneralLedgerAccountId)
                .ThenBy(x => x.ChangeType)
                .ToList();

            return orderedData;
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLCommissionContractsAsync(object[] parameters)
        {
            var sql = @"select 'Commission' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId = 8
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4010)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLIncomeContractsAsync(object[] parameters)
        {
            var sql = @"select 'Income' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'C' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(RequiredAmount - PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.IsExpense = 0) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (1390, 1391, 1392)
	group by ContractId, LineItemAmount
) y
join Contract c on c.ContractId = y.ContractId
where y.PostedAmount + y.LineItemAmount <> 0
and (c.ContractStatusId < 6 or PostedAmount <> 0)
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLReserveAllowanceContractsAsync(object[] parameters)
        {
            var sql = @"select 'Reserve Allowance' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId in (14,15)
				and ct.ContractEntityTypeId <> 2
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4098)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLSharedBonusContractsAsync(object[] parameters)
        {
            var sql = @"select 'Shared Bonus' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId = 7
				and ct.ContractEntityTypeId <> 2
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4095)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLContractFeeContractsAsync(object[] parameters)
        {
            var sql = @"select 'Contract Fee' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId = 6
				and ct.ContractEntityTypeId <> 2
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4099)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLNonExclContractFeeContractsAsync(object[] parameters)
        {
            var sql = @"select 'Non-Excl Contract Fee' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId = 25
				and ct.ContractEntityTypeId <> 2
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4100)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLAgentWorkingContractsAsync(object[] parameters)
        {
            var sql = @"select 'Agent Working' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.ContractTransactionTypeId = 51
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (4011)
	group by ContractId, LineItemAmount
) y
where y.PostedAmount + y.LineItemAmount <> 0
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLLiabilityContractsAsync(object[] parameters)
        {
            var sql = @"select 'Liability' as InconsistencyType, y.*, abs(y.LineItemAmount + y.PostedAmount) as DifferenceAmount, case when (y.LineItemAmount + y.PostedAmount > 0) then 'I' else 'D' end as Direction
from
(
	select x.ContractId, sum(case when ChangeType = 'D' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
	from
	(
		select ContractId
			 , GeneralLedgerAccountId
			 , ChangeType
			 , sum(PostedAmount) as PostedAmount
			 , (select isnull(sum(RequiredAmount - PaidAmount), 0) 
				from ContractTransaction ct
				where ct.ContractId = gl.ContractId
				and ct.IsExpense = 1) as LineItemAmount
		from GeneralLedgerJournal gl
 		where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
		group by ContractId, GeneralLedgerAccountId, ChangeType
	) x
	where GeneralLedgerAccountId in (2211)
	group by ContractId, LineItemAmount
) y
join vwContractMoney m on m.ContractId = y.ContractId
where y.PostedAmount + y.LineItemAmount <> 0
and y.PostedAmount + y.LineItemAmount + m.IncomeAmount - m.ExpenseAmount <> 0
and y.Contractid not in (
	select y.ContractId
	from
	(
		select x.ContractId, sum(case when ChangeType = 'C' then PostedAmount else -PostedAmount end) as PostedAmount, x.LineItemAmount
		from
		(
			select ContractId
				 , GeneralLedgerAccountId
				 , ChangeType
				 , sum(PostedAmount) as PostedAmount
				 , (select isnull(sum(RequiredAmount - PaidAmount), 0) 
					from ContractTransaction ct
					where ct.ContractId = gl.ContractId
					and ct.IsExpense = 0) as LineItemAmount
			from GeneralLedgerJournal gl
   		    where ContractId in (select sgl.ContractId from GeneralLedgerJournal sgl where PostedDate >= {0} and PostedDate < {1})
			group by ContractId, GeneralLedgerAccountId, ChangeType
		) x
		where GeneralLedgerAccountId in (1390, 1391, 1392)
		group by ContractId, LineItemAmount
	) y
	where y.PostedAmount + y.LineItemAmount <> 0
)
order by 1, abs((y.LineItemAmount + y.PostedAmount)) desc 
";

            return await this.Context.SqlQueryAsync<InconsistentGLDto>(sql, parameters);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLContractsAsync(ExportDataCriteriaDto criteria)
        {
            var fromDate = criteria.FromDate;
            var toDate = criteria.ToDate.AddDays(1).Date;

            var data = new List<InconsistentGLDto>();

            var parameters = new object[]
            {
                fromDate,
                toDate
            };

            var commissions = await this.GetInconsistentGLCommissionContractsAsync(parameters);
            data.AddRange(commissions);

            var income = await this.GetInconsistentGLIncomeContractsAsync(parameters);
            data.AddRange(income);

            var reserveAllowance = await this.GetInconsistentGLReserveAllowanceContractsAsync(parameters);
            data.AddRange(reserveAllowance);

            var sharedBonus = await this.GetInconsistentGLSharedBonusContractsAsync(parameters);
            data.AddRange(sharedBonus);

            var contractFee = await this.GetInconsistentGLContractFeeContractsAsync(parameters);
            data.AddRange(contractFee);

            var nonExclContractFee = await this.GetInconsistentGLNonExclContractFeeContractsAsync(parameters);
            data.AddRange(nonExclContractFee);

            var agentWorking = await this.GetInconsistentGLNonExclContractFeeContractsAsync(parameters);
            data.AddRange(agentWorking);

            var liability = await this.GetInconsistentGLLiabilityContractsAsync(parameters);
            data.AddRange(liability);

            data = data
                .OrderBy(x => x.InconsistencyType)
                .ThenBy(x => x.ContractId)
                .ToList();

            return data;
        }
    }
}
