﻿namespace ECE.CRM.DataAccess
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class AgentCommissionProgramDao : BaseDataAccessObject, IAgentCommissionProgramDao
    {
        public AgentCommissionProgramDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByMenteeIdAsync(int menteeId)
        {
            var query = await (from acp in this.Context.AgentCommissionPrograms
                               join au in this.Context.AppUsers on acp.ToAppUserId equals au.AppUserId
                               join lcp in this.Context.LuCommissionPrograms on acp.CommissionProgramId equals
                                   lcp.CommissionProgramId
                               where acp.FromEntityId == menteeId && acp.CommissionProgramId == (int)CommissionProgram.Mentor
                               select new AgentCommissionProgramsDto()
                               {
                                   AgentId = menteeId,
                                   BonusAgentId = au.AppUserId,
                                   BonusAgentFirstName = au.FirstName,
                                   BonusAgentLastName = au.LastName,
                                   Description = lcp.Description,
                                   SplitAmount = acp.SplitAmount,
                                   SplitPercentage = acp.SplitPercentage,
                                   StartDate = acp.StartDate,
                                   EndDate = acp.EndDate
                               }).ToListAsync();

            return query;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByAppUserAsync(int appUserId)
        {
            var query = await (from acp in this.Context.AgentCommissionPrograms
                               join au in this.Context.AppUsers on acp.FromEntityId equals au.AppUserId
                               join lcp in this.Context.LuCommissionPrograms on acp.CommissionProgramId equals
                               lcp.CommissionProgramId
                               where (acp.FromEntityId == appUserId || acp.ToAppUserId == appUserId)
                                     && acp.CommissionProgramId == (int)CommissionProgram.Mentor
                                     && acp.FromEntityTypeId == (int)EntityType.Agent
                               select new AgentCommissionProgramsDto()
                               {
                                   AgentId = appUserId,
                                   BonusAgentId = au.AppUserId,
                                   BonusAgentFirstName = au.FirstName,
                                   BonusAgentLastName = au.LastName,
                                   Description = lcp.Description,
                                   SplitAmount = acp.SplitAmount,
                                   SplitPercentage = acp.SplitPercentage,
                                   StartDate = acp.StartDate,
                                   EndDate = acp.EndDate
                               }).ToListAsync();

            return query;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramByPresenterAsync(int presenterId)
        {
            var query = await (from acp in this.Context.AgentCommissionPrograms
                               join lcp in this.Context.LuCommissionPrograms on acp.CommissionProgramId equals lcp.CommissionProgramId
                               join p in this.Context.Presenters on acp.FromEntityId equals p.PresenterId
                               join au in this.Context.AppUsers on acp.ToAppUserId equals au.AppUserId
                               where acp.CommissionProgramId == 2 && acp.FromEntityTypeId == 1
                                                                  && acp.FromEntityId == presenterId
                                                                  && acp.IsDeleted == false
                               select new AgentCommissionProgramsDto()
                               {
                                   AgentId = p.AgentId,
                                   BonusAgentId = au.AppUserId,
                                   BonusAgentFirstName = au.FirstName,
                                   BonusAgentLastName = au.LastName,
                                   Description = lcp.Description,
                                   SplitAmount = acp.SplitAmount,
                                   SplitPercentage = acp.SplitPercentage,
                                   StartDate = acp.StartDate,
                                   EndDate = acp.EndDate
                               }).ToListAsync();

            return query;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramsByAppUserAsync(int appUserId, int presenterId)
        {
            var query = await (from acp in this.Context.AgentCommissionPrograms
                               join lcp in this.Context.LuCommissionPrograms on acp.CommissionProgramId equals lcp.CommissionProgramId
                               join p in this.Context.Presenters on acp.FromEntityId equals p.PresenterId
                               join au in this.Context.AppUsers on p.AgentId equals au.AppUserId
                               where acp.ToAppUserId == appUserId
                                     && acp.CommissionProgramId == (int)CommissionProgram.PresenterTransfer
                                     && acp.FromEntityTypeId == (int)EntityType.Presenter && acp.FromEntityId == presenterId
                                     && acp.StartDate <= DateTime.Now
                                     && acp.EndDate >= DateTime.Now
                               select new AgentCommissionProgramsDto()
                               {
                                   AgentId = appUserId,
                                   BonusAgentId = au.AppUserId,
                                   BonusAgentFirstName = au.FirstName,
                                   BonusAgentLastName = au.LastName,
                                   Description = lcp.Description,
                                   SplitAmount = acp.SplitAmount,
                                   SplitPercentage = acp.SplitPercentage,
                                   StartDate = acp.StartDate,
                                   EndDate = acp.EndDate
                               }).ToListAsync();
            return query;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetMentorshipProgramsForCommissionByAppUserAsync(int appUserId)
        {
            var query = await (from acp in this.Context.AgentCommissionPrograms
                               join au in this.Context.AppUsers on acp.FromEntityId equals au.AppUserId
                               join lcp in this.Context.LuCommissionPrograms on acp.CommissionProgramId equals
                               lcp.CommissionProgramId
                               where acp.ToAppUserId == appUserId
                                  && acp.CommissionProgramId == (int)CommissionProgram.Mentor
                               select new AgentCommissionProgramsDto()
                               {
                                   AgentId = appUserId,
                                   BonusAgentId = au.AppUserId,
                                   BonusAgentFirstName = au.FirstName,
                                   BonusAgentLastName = au.LastName,
                                   Description = lcp.Description,
                                   SplitAmount = acp.SplitAmount,
                                   SplitPercentage = acp.SplitPercentage,
                                   StartDate = acp.StartDate,
                                   EndDate = acp.EndDate
                               }).ToListAsync();

            return query;
        }
    }
}
