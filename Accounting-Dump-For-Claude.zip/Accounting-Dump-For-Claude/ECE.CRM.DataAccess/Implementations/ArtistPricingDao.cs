﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistPricingDao : BaseDataAccessObject, IArtistPricingDao
    {
        public ArtistPricingDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<ArtistPricingDto>> GetPricingsByIdAsync(int id)
        {
            var results = await (from ap in this.Context.ArtistPrices
                                 where ap.ArtistId == id
                                 select new ArtistPricingDto
                                 {
                                     ArtistPriceId = ap.ArtistPriceId,
                                     ArtistId = ap.ArtistId,
                                     Description = ap.Description,
                                     Price = ap.Price,
                                     IsBasePrice = ap.IsBasePrice,
                                     CreatedDate = ap.CreatedDate,
                                     UpdatedDate = ap.UpdatedDate
                                 }).OrderByDescending(x => x.IsBasePrice).ThenBy(x=>x.CreatedDate).ToListAsync();

            return results;
        }

        public async Task<List<ArtistPriceHistoryDto>> GetPriceHistoryByArtistAndYearAsync(int id, int year)
        {
            var result = new List<ArtistPriceHistoryDto>();

            var results = from c in Context.Contracts
                          join ca in Context.ContractArtists on c.ContractId equals ca.ContractId
                          join caed in Context.ContractArtistEventDates on ca.ContractArtistId equals caed.ContractArtistId
                          where ca.ArtistId == id
                          && caed.ContractEventDate.EventDate.Year == year
                          && ca.Contract.IssueDate != null
                          && ca.Contract.ContractStatusId != (int)ECE.CRM.DataTransferObjects.ContractStatus.Canceled
                          && ca.Contract.ContractStatusId != (int)ECE.CRM.DataTransferObjects.ContractStatus.PartiallyCanceled
                          && ca.Contract.ContractStatusId != (int)ECE.CRM.DataTransferObjects.ContractStatus.InProgress
                          && ca.Contract.ContractStatusId != (int)ECE.CRM.DataTransferObjects.ContractStatus.Created
                          group new { ca, caed } by new { caed.ContractEventDate.EventDate.Month, ca.ContractId, ca.Gross } into grp
                          select new
                          {
                              Month = grp.Key.Month,
                              Gross = grp.Key.Gross
                          };

            result = await results.GroupBy(x => new { Month = x.Month })
                            .Select(y => new ArtistPriceHistoryDto
                            {
                                Month = y.Key.Month,
                                Year = year,
                                AverageGross = (int)y.Average(z => z.Gross)
                            })
                            .OrderBy(x => x.Month)
                            .ToListAsync();

            return result;
        }

        public async Task<ArtistPricingDto> GetPricingByIdAsync(int id)
        {
            var pricing = await this.Context.ArtistPrices.FirstOrDefaultAsync(x => x.ArtistPriceId == id);
            if (pricing == null)
            {
                return null;
            }

            var dto = Mapper.Map<ArtistPricingDto>(pricing);

            return dto;
        }

        public async Task CreateAsync(ArtistPricingDto pricing)
        {
            if (pricing == null)
            {
                throw new ArgumentNullException(nameof(pricing));
            }

            if (pricing.IsBasePrice)
            {
                ArtistPrice result = (from ap in Context.ArtistPrices
                                      where ap.ArtistId == pricing.ArtistId
                                             && ap.IsBasePrice
                                      select ap).SingleOrDefault();

                if (result != null)
                {
                    result.UpdatedById = pricing.UpdatedById;
                    result.UpdatedDate = pricing.UpdatedDate;
                    result.IsBasePrice = false;

                    await this.Context.SaveChangesAsync();
                }
            }

            var newItem = Mapper.Map<ArtistPricingDto, ArtistPrice>(pricing);

            this.Context.ArtistPrices.Add(newItem);

            await this.Context.SaveChangesAsync();
        }

        public async Task UpdateAsync(ArtistPricingDto pricing)
        {
            if (pricing.IsBasePrice)
            {
                ArtistPrice result = (from ap in Context.ArtistPrices
                                      where ap.ArtistId == pricing.ArtistId
                                             && ap.IsBasePrice
                                      select ap).SingleOrDefault();
                if (result != null)
                {
                    result.UpdatedById = pricing.UpdatedById;
                    result.UpdatedDate = pricing.UpdatedDate;
                    result.IsBasePrice = false;

                    await this.Context.SaveChangesAsync();
                }
            }

            var priceRecord = this.Context.ArtistPrices.FirstOrDefault(x => x.ArtistPriceId == pricing.ArtistPriceId);
            if (priceRecord == null)
            {
                throw new ArgumentNullException(nameof(pricing));
            }

            priceRecord.Description = pricing.Description;
            priceRecord.Price = pricing.Price;
            priceRecord.IsBasePrice = pricing.IsBasePrice;
            priceRecord.UpdatedById = pricing.UpdatedById;
            priceRecord.UpdatedDate = pricing.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAsync(ArtistPricingDto pricing)
        {
            var priceRecord = this.Context.ArtistPrices.FirstOrDefault(x => x.ArtistPriceId == pricing.ArtistPriceId);
            if (priceRecord == null)
            {
                throw new ArgumentNullException(nameof(pricing));
            }

            this.Context.ArtistPrices.Remove(priceRecord);

            await this.Context.SaveChangesAsync();
        }
    }
}
