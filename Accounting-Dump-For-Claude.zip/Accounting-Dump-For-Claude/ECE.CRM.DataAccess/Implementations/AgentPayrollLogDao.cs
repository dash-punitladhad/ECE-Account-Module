﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataAccess.Utilities;
    using ECE.CRM.DataTransferObjects;
    using LinqKit;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AgentPayrollLogDao : BaseDataAccessObject, IAgentPayrollLogDao
    {
        public AgentPayrollLogDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<AgentPayrollLogViewDto>> GetByPayrollPaymentIdAsync(int payrollPaymentId)
        {
            var query = from ap in this.Context.vwAgentPayrolls.AsExpandable()
                        join c in this.Context.Contracts on ap.ContractId equals c.ContractId
                        join plt in this.Context.LuPayrollLogTypes on ap.PayrollLogTypeId equals plt.PayrollLogTypeId
                        join lob in this.Context.LuLineOfBusinesses on ap.LineOfBusinessId equals lob.LineOfBusinessId
						where ap.PayrollPaymentId == payrollPaymentId && (c.IsSalaried.HasValue ? !c.IsSalaried.Value : true)
                        orderby ap.ReceivedDate descending
                        select new AgentPayrollLogViewDto
                        {
                            AgentId = ap.AgentId,
                            ContractId = ap.ContractId,
                            ReceivedDate = ap.ReceivedDate,
                            GrossAmount = ap.GrossAmount,
                            NetAmount = ap.NetAmount,
                            CommissionRate = ap.CommissionRate,
                            PayrollLogType = plt.Name,
                            ContractType = lob.Name,
                            LastEventDate = ap.LastEventDate,
                            AgentPayrollLogId = ap.AgentPayrollLogId,
                            ContractTransactionId = ap.ContractTransactionId,
                            LineOfBusinessId = ap.LineOfBusinessId,
                            PayrollLogTypeId = ap.PayrollLogTypeId,
                            PayrollPaymentId = ap.PayrollPaymentId,
                            PostDate = ap.PostDate,
                            PresenterId = ap.PresenterId,
                            RequiredAmount = ap.RequiredAmount,
                            ResponsibleAgentId = ap.ResponsibleAgentId,
                            IsExclude = ap.IsExclude,
                            ExcludeDate = ap.ExcludeDate
                        };

            return await query.ToListAsync();
        }

        public async Task<IList<AgentPayrollLogDto>> GetByPayrollBatchIdAsync(int payrollBatchId)
        {
            var query = from ap in this.Context.AgentPayrollLogs
                        where ap.PayrollPayment.PayrollBatchId == payrollBatchId && !ap.PayrollPayment.IsDeleted
                        orderby ap.ReceivedDate descending
                        select new AgentPayrollLogDto
                        {
                            AgentId = ap.AgentId,
                            ContractId = ap.ContractId,
                            ReceivedDate = ap.ReceivedDate,
                            GrossAmount = ap.GrossAmount,
                            NetAmount = ap.NetAmount,
                            CommissionRate = ap.CommissionRate,
                            AgentPayrollLogId = ap.AgentPayrollLogId,
                            ContractTransactionId = ap.ContractTransactionId,
                            LineOfBusinessId = ap.LineOfBusinessId,
                            PayrollLogTypeId = ap.PayrollLogTypeId,
                            PayrollPaymentId = ap.PayrollPaymentId,
                            PostDate = ap.PostDate,
                            CreatedById = ap.CreatedById,
                            CreatedDate = ap.CreatedDate,
                            UpdatedById = ap.UpdatedById,
                            UpdatedDate = ap.UpdatedDate,
                            IsExclude = ap.IsExclude,
                            ExcludeDate = ap.ExcludeDate
                        };

            return await query.ToListAsync();
        }

        public async Task<IList<AgentPayrollLogDto>> GetByContractIdAsync(int contractId)
        {
            var query = from apl in this.Context.vwAgentPayrolls.Where(x => x.ContractId == contractId)
                        join au in this.Context.AppUsers on apl.AgentId equals au.AppUserId
                        join l in this.Context.LuPayrollLogTypes on apl.PayrollLogTypeId equals l.PayrollLogTypeId
                        orderby apl.ReceivedDate, apl.AgentId, apl.AgentPayrollLogId
                        select new AgentPayrollLogDto
                        {
                            AgentPayrollLogId = apl.AgentPayrollLogId,
                            AgentId = apl.AgentId,
                            CommissionRate = apl.CommissionRate,
                            ContractId = apl.ContractId,
                            ContractTransactionId = apl.ContractTransactionId,
                            GrossAmount = apl.GrossAmount,
                            LastEventDate = apl.LastEventDate,
                            LineOfBusinessId = apl.LineOfBusinessId,
                            LuPayrollLogType = new PayrollLogTypeDto
                            {
                                PayrollLogTypeId = l.PayrollLogTypeId,
                                Name = l.Name
                            },
                            NetAmount = apl.NetAmount,
                            PayrollLogTypeId = apl.PayrollLogTypeId,
                            PayrollPaymentId = apl.PayrollPaymentId,
                            PostDate = apl.PostDate,
                            PresenterId = apl.PresenterId,
                            ReceivedDate = apl.ReceivedDate,
                            RequiredAmount = apl.RequiredAmount,
                            AgentFullName = au.FirstName + " " + au.LastName,
							IsSalaried = apl.IsSalaried.Value
						};

            var results = await query.ToListAsync();

            return results;
        }

        public async Task<AgentPayrollLogDto> GetByContractTransactionIdAsync(int contractTransactionId)
        {
            var result = await this.Context.AgentPayrollLogs.FirstOrDefaultAsync(x => x.ContractTransactionId == contractTransactionId);

            var dto = Mapper.Map<AgentPayrollLogDto>(result);

            return dto;
        }

        public async Task<AgentPayrollLogDto> GetByIdAsync(int agentPayrollLogId)
        {
            var result = await this.Context.vwAgentPayrolls.FirstOrDefaultAsync(x => x.AgentPayrollLogId == agentPayrollLogId);

            var dto = Mapper.Map<AgentPayrollLogDto>(result);

            return dto;
        }

        public async Task<IList<AgentPayrollLogDto>> GetByExpenseAsync(int contractTransactionId)
        {
            var query = this.Context.AgentPayrollLogs.Where(x => x.ContractTransactionId == contractTransactionId);

            var result = await query.ToListAsync();

            return Mapper.Map<IList<AgentPayrollLogDto>>(result);
        }

        public async Task CreateAsync(AgentPayrollLogDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newItem = Mapper.Map<AgentPayrollLog>(dto);

            this.Context.AgentPayrollLogs.Add(newItem);

            await this.Context.SaveChangesAsync();

            dto.AgentPayrollLogId = newItem.AgentPayrollLogId;
        }

        public async Task UpdateAsync(AgentPayrollLogDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var match = await this.Context.AgentPayrollLogs.FirstOrDefaultAsync(x => x.AgentPayrollLogId == dto.AgentPayrollLogId);
            if (match == null)
            {
                throw new ArgumentException($"AgentPayrollLog {dto.AgentPayrollLogId} not found.");
            }

            match.AgentId = dto.AgentId;
            match.PayrollLogTypeId = dto.PayrollLogTypeId;
            match.GrossAmount = dto.GrossAmount;
            match.NetAmount = dto.NetAmount;
            match.CommissionRate = dto.CommissionRate;
            match.ReceivedDate = dto.ReceivedDate;
            match.PostDate = dto.PostDate;
            match.PayrollPaymentId = dto.PayrollPaymentId;
            match.LineOfBusinessId = dto.LineOfBusinessId;
            match.ContractId = dto.ContractId;
            match.ContractTransactionId = dto.ContractTransactionId;

            match.UpdatedDate = dto.UpdatedDate;
            match.UpdatedById = dto.UpdatedById;
            match.IsExclude = dto.IsExclude;
            match.UpdatedDate = dto.UpdatedDate;
            match.PayrollPaymentId = dto.PayrollPaymentId;
            match.ExcludeDate = dto.ExcludeDate;
            await this.Context.SaveChangesAsync();
        }

        public async Task SetPayrollPaymentAsync(AgentPayrollLogDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var match = await this.Context.AgentPayrollLogs.FirstOrDefaultAsync(x => x.AgentPayrollLogId == dto.AgentPayrollLogId);
            if (match == null)
            {
                throw new ArgumentException($"AgentPayrollLog {dto.AgentPayrollLogId} not found.");
            }

            match.CommissionRate = dto.CommissionRate;
            match.NetAmount = dto.NetAmount;
            match.PayrollPaymentId = dto.PayrollPaymentId;
            match.IsExclude = dto.IsExclude;
            match.ExcludeDate = dto.ExcludeDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var agentPayrollLog = await this.Context.AgentPayrollLogs.FirstOrDefaultAsync(x => x.AgentPayrollLogId == id);
            if (agentPayrollLog != null)
            {
                this.Context.AgentPayrollLogs.Remove(agentPayrollLog);
                await this.Context.SaveChangesAsync();
            }
        }

        public async Task<IList<AgentPayrollLogDto>> GetUnpaidByAgentAsync(int agentId, DateTime startDate, DateTime endDate)
        {
            return await this.GetByReceivedDateRangeAsync(startDate, endDate, agentId);
        }

        public async Task<decimal> GetEstimatedCommissionsAsync(DateTime startDate, DateTime endDate)
        {
            var query = this.Context.vwAgentPayrolls
                .Where(x => x.ReceivedDate >= startDate
                    && x.ReceivedDate <= endDate
                    && x.PostDate == null
                    && x.PayrollLogTypeId == (int)PayrollLogType.AgentCommission)
                .Select(x => x.GrossAmount);

            var result = await query.SumAsync();

            return result;
        }

        public async Task<decimal> GetEstimatedAgentWorkingAsync(DateTime startDate, DateTime endDate)
        {
            var query = await this.Context.vwAgentPayrolls.Where(x => x.ReceivedDate >= startDate
                                                           && x.ReceivedDate <= endDate
                                                           && x.PostDate == null
                                                           && x.PayrollLogTypeId == (int)PayrollLogType.AgentWorking).ToListAsync();
            var result = query.Sum(x => x.NetAmount);

            return result;
        }

        public async Task<IList<AgentPayrollLogDto>> GetByReceivedDateRangeAsync(DateTime startDate, DateTime endDate, int? agentId = null, bool newScheme = false, bool isBatch = false)
		{
            decimal smallestAllowedCommission = ECEBusinessConstants.CommissionConstants.SmallestAllowedCommission;

            /*
             * Include all payroll logs where:
             *  - the agent is active (au.IsActive)
             *  - the money was received prior to the end of the pay cutoff (ap.ReceivedDate <= endDate)
             *  - the log is not paid (ap.PostDate == null)
             *  - the log is not included in a payroll batch (ap.PayrollPaymentId == null)
             *  - the log is for a non-zero commission
             *        && ((typesThatMustHaveMoney.Contains(ap.PayrollLogTypeId) && (ap.GrossAmount != 0 || ap.NetAmount != 0)) ||
             *             typesThatCanBeZero.Contains(ap.PayrollLogTypeId))
             *  - the contract commission, is more than $100 (m.CommissionAmount >= smallestAllowedCommission)
             *  - sufficient income has been received on the contract to pay the expense (m.ReleasedAmount <= m.ReceivedAmount)
             *  - all money has been received on the contract (m.DepositAmount >= m.IncomeAmount)
             *  - all the income has been received on the expense (expense.PaidAmount == expense.RequiredAmount)
             */

            var typesThatMustHaveMoney = new int[]
            {
                (int)PayrollLogType.AgentCommission,
                (int)PayrollLogType.MentorshipCommission,
                (int)PayrollLogType.TransferCommission,
                (int)PayrollLogType.AgentWorking,
                (int)PayrollLogType.CafeteriaPlan,
                (int)PayrollLogType.TeamCommission,
            };

            var typesThatCanBeZero = new int[]
            {
                (int)PayrollLogType.NonExclusiveArtistFee,
                (int)PayrollLogType.SharedBonus,
            };
            var isApplyPayroll = await Helper.GetApplyPayroll();

            var eventDate = (isApplyPayroll ? endDate : DateTime.Now.AddYears(40));
            var query = from ap in this.Context.vwAgentPayrolls
                        join au in this.Context.AppUsers on ap.AgentId equals au.AppUserId
						join c in this.Context.Contracts on ap.ContractId equals c.ContractId
						join m in this.Context.vwContractMoneys on ap.ContractId equals m.ContractId
                        join ct in this.Context.ContractTransactions on ap.ContractTransactionId equals ct.ContractTransactionId into g
                        from expense in g.DefaultIfEmpty()
                        where au.IsActive
                        && ap.ReceivedDate <= endDate
                        && ap.LastEventDate <= eventDate
                        && ap.PostDate == null
                        && ((typesThatMustHaveMoney.Contains(ap.PayrollLogTypeId) && (ap.GrossAmount != 0 || ap.NetAmount != 0)) ||
                            typesThatCanBeZero.Contains(ap.PayrollLogTypeId))
                        && (m.CommissionAmount >= smallestAllowedCommission || (expense == null || expense.RequiredAmount < decimal.Zero))
                        && m.ReleasedAmount <= m.ReceivedAmount
                        && m.DueAmount == 0
                        && c.IsSalaried==(c.IsSalaried.HasValue? (startDate.Year == 2023 ? true : false) : c.IsSalaried)
                        && (expense == null || expense.PaidAmount == expense.RequiredAmount)
                        select ap;

            if (agentId != null)
            {
                query = query.Where(x => x.AgentId == agentId.Value);
            }
            else
            {
                query = query.Where(x => x.PayrollPaymentId == null);
            }

            var entries = await
                query.OrderBy(x => x.AgentId)
                .ThenBy(x => x.PayrollLogTypeId)
                .ThenBy(x => x.ReceivedDate)
                .ToListAsync();

            var results = Mapper.Map<IList<AgentPayrollLogDto>>(entries);

            return results;
        }

        public async Task<IList<AgentEarnedCommissionsDto>> GetAgentEarnedCommissionsAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var agentEarnedCommissions = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
                                                join c in this.Context.Contracts on ap.ContractId equals c.ContractId
                                                join et in this.Context.LuEventTypes on c.EventTypeId equals et.EventTypeId into eventTypes
                                                from eventTypesSub in eventTypes.DefaultIfEmpty()
                                                join lob in this.Context.LuLineOfBusinesses on ap.LineOfBusinessId equals lob.LineOfBusinessId
                                                where ap.PayrollPaymentId == payrollPaymentId
                                                && ap.PayrollLogTypeId == (int)PayrollLogType.AgentCommission
												&& (c.IsSalaried.HasValue ? !c.IsSalaried.Value : true)
                                                orderby ap.ReceivedDate descending
                                                select new AgentEarnedCommissionsDto
                                                {
                                                    AgentPayrollLogId = ap.AgentPayrollLogId,
                                                    AgentId = ap.AgentId,
                                                    ContractId = ap.ContractId,
                                                    ReceivedDate = ap.ReceivedDate,
                                                    LastEventDate = ap.LastEventDate,
                                                    GrossCommission = ap.GrossAmount,
                                                    NetCommission = ap.NetAmount,
                                                    Percentage = ap.CommissionRate,
                                                    EventType = eventTypesSub.Name ?? string.Empty,
                                                    ContractType = lob.Name,
                                                    IsExclude = ap.IsExclude, //isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                                    ExcludeDate = ap.ExcludeDate

                                                }).ToListAsync();

            foreach (var row in agentEarnedCommissions)
            {
                var splits = await (from ct in this.Context.ContractTransactions
                                    join au in this.Context.AppUsers on ct.AgentId equals au.AppUserId
                                    where ct.ContractTransactionTypeId == (int)ContractTransactionType.Commission
                                          && ct.ContractEntityTypeId == (int)ContractEntityType.ECE
                                          && ct.ContractId == row.ContractId
                                          && ct.RequiredPercentage != null
                                          && ct.RequiredPercentage > decimal.Zero
                                    select au.FirstName + " " + au.LastName).Distinct().ToListAsync();

                if (splits.Count == 1)
                {
                    row.Split = splits[0];
                }
                else
                {
                    row.Split = string.Join("<br>", splits);
                }
            }

            return agentEarnedCommissions;
        }

        public async Task<IList<MentorshipBonusCommissionsDto>> GetMentorshipBonusCommissionsAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var mentorshipBonusCommissions = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
                                                    join acp in this.Context.AgentCommissionPrograms on ap.AgentId equals acp.ToAppUserId
                                                    join au in this.Context.AppUsers on acp.FromEntityId equals au.AppUserId
                                                    join lob in this.Context.LuLineOfBusinesses on ap.LineOfBusinessId equals lob.LineOfBusinessId
													join ct in this.Context.Contracts on ap.ContractId equals ct.ContractId
													where ap.PayrollPaymentId == payrollPaymentId
                                                    && ap.PayrollLogTypeId == (int)PayrollLogType.MentorshipCommission
                                                    && acp.CommissionProgramId == (int)CommissionProgram.Mentor
                                                    && acp.FromEntityId == ap.ResponsibleAgentId
                                                    && acp.FromEntityTypeId == (int)EntityType.Agent
                                                    && acp.IsDeleted == false
													&& (ct.IsSalaried.HasValue ? !ct.IsSalaried.Value : true)
                                                    orderby ap.ReceivedDate descending
                                                    select new MentorshipBonusCommissionsDto
                                                    {
                                                        AgentPayrollLogId = ap.AgentPayrollLogId,
                                                        ContractId = ap.ContractId,
                                                        Mentee = au.FirstName + " " + au.LastName,
                                                        ReceivedDate = ap.ReceivedDate,
                                                        LastEventDate = ap.LastEventDate,
                                                        Percentage = acp.SplitPercentage ?? acp.SplitAmount ?? 0,
                                                        BonusCommission = ap.NetAmount,
                                                        ContractType = lob.Name,
                                                        IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                                        ExcludeDate = ap.ExcludeDate
                                                    }).ToListAsync();

            return mentorshipBonusCommissions;
        }

        public async Task<IList<PresenterTransferBonusCommissionsDto>> GetPresenterTransferBonusCommissionsAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var presenterTransferBonusCommissions = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
                                                           join acp in this.Context.AgentCommissionPrograms on ap.AgentId equals acp.ToAppUserId
                                                           join p in this.Context.Presenters on ap.PresenterId equals p.PresenterId
                                                           join lob in this.Context.LuLineOfBusinesses on ap.LineOfBusinessId equals lob.LineOfBusinessId
														   join ct in this.Context.Contracts on ap.ContractId equals ct.ContractId
														   where ap.PayrollPaymentId == payrollPaymentId
                                                           && ap.PayrollLogTypeId == (int)PayrollLogType.TransferCommission
                                                           && acp.CommissionProgramId == (int)CommissionProgram.PresenterTransfer
                                                           && acp.IsDeleted == false
                                                           && ap.PresenterId == acp.FromEntityId
														   && (ct.IsSalaried.HasValue ? !ct.IsSalaried.Value : true)
                                                           orderby ap.ReceivedDate descending
                                                           select new PresenterTransferBonusCommissionsDto
                                                           {
                                                               AgentPayrollLogId = ap.AgentPayrollLogId,
                                                               ContractId = ap.ContractId,
                                                               Presenter = p.AccountName,
                                                               ReceivedDate = ap.ReceivedDate,
                                                               LastEventDate = ap.LastEventDate,
                                                               Percentage = acp.SplitPercentage ?? acp.SplitAmount ?? 0,
                                                               BonusCommission = ap.NetAmount,
                                                               ContractType = lob.Name,
                                                               IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                                               ExcludeDate = ap.ExcludeDate
                                                           }).ToListAsync();

            var presenterTransferBonusCommissions2 = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
                                                            join acp in this.Context.AgentCommissionPrograms on new { ToAppUserId = ap.AgentId, CommissionProgramId = (int)CommissionProgram.PresenterTransfer, FromEntityId = ap.PresenterId.Value, IsDeleted = false } equals new { acp.ToAppUserId, acp.CommissionProgramId, acp.FromEntityId, acp.IsDeleted } into g
                                                            from p in g.DefaultIfEmpty()
                                                            join c in this.Context.Contracts on ap.ContractId equals c.ContractId
                                                            join lob in this.Context.LuLineOfBusinesses on ap.LineOfBusinessId equals lob.LineOfBusinessId
                                                            where ap.PayrollPaymentId == payrollPaymentId
                                                            && ap.PayrollLogTypeId == (int)PayrollLogType.TransferCommission
                                                            && p == null
                                                            orderby ap.ReceivedDate descending
                                                            select new PresenterTransferBonusCommissionsDto
                                                            {
                                                                AgentPayrollLogId = ap.AgentPayrollLogId,
                                                                ContractId = ap.ContractId,
                                                                Presenter = c.PresenterAccountName,
                                                                ReceivedDate = ap.ReceivedDate,
                                                                LastEventDate = ap.LastEventDate,
                                                                Percentage = ap.CommissionRate,
                                                                BonusCommission = ap.NetAmount,
                                                                ContractType = lob.Name,
                                                                IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                                                ExcludeDate = ap.ExcludeDate
                                                            }).ToListAsync();

            presenterTransferBonusCommissions.AddRange(presenterTransferBonusCommissions2);

            return presenterTransferBonusCommissions;
        }

        public async Task<IList<SharedBonusDto>> GetSharedBonusAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var sharedBonus = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
									 join ct in this.Context.Contracts on ap.ContractId equals ct.ContractId
									 where ap.PayrollPaymentId == payrollPaymentId
                                     && ap.PayrollLogTypeId == (int)PayrollLogType.SharedBonus
									 && (ct.IsSalaried.HasValue ? !ct.IsSalaried.Value : true)
                                     orderby ap.ReceivedDate descending
                                     select new SharedBonusDto
                                     {
                                         AgentPayrollLogId = ap.AgentPayrollLogId,
                                         ContractId = ap.ContractId,
                                         ReceivedDate = ap.ReceivedDate,
                                         LastEventDate = ap.LastEventDate,
                                         Amount = ap.NetAmount,
                                         IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                         ExcludeDate = ap.ExcludeDate
                                     }).ToListAsync();

            return sharedBonus;
        }

        public async Task<IList<NonExclusiveArtistFeeDto>> GetNonExclusiveArtistFeeAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var nonExclusiveArtistFee = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
											   join ct in this.Context.Contracts on ap.ContractId equals ct.ContractId
											   where ap.PayrollPaymentId == payrollPaymentId
                                               && ap.PayrollLogTypeId == (int)PayrollLogType.NonExclusiveArtistFee
											   && (ct.IsSalaried.HasValue ? !ct.IsSalaried.Value : true)
                                               orderby ap.ReceivedDate descending
                                               select new NonExclusiveArtistFeeDto
                                               {
                                                   AgentPayrollLogId = ap.AgentPayrollLogId,
                                                   ContractId = ap.ContractId,
                                                   ReceivedDate = ap.ReceivedDate,
                                                   LastEventDate = ap.LastEventDate,
                                                   Amount = ap.NetAmount,
                                                   IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                                   ExcludeDate = ap.ExcludeDate
                                               }).ToListAsync();

            return nonExclusiveArtistFee;
        }

        public async Task<IList<AgentWorkingDto>> GetAgentWorkingAsync(int payrollPaymentId)
        {
            var isApplyPayroll = await Helper.GetApplyPayroll();
            var releasedPayroll = await Helper.GetReleasedPayroll();
            var agentWorking = await (from ap in this.Context.vwAgentPayrolls.AsExpandable()
									  join ct in this.Context.Contracts on ap.ContractId equals ct.ContractId
									  where ap.PayrollPaymentId == payrollPaymentId
                                      && ap.PayrollLogTypeId == (int)PayrollLogType.AgentWorking
									  && (ct.IsSalaried.HasValue ? !ct.IsSalaried.Value : true)
                                      orderby ap.ReceivedDate descending
                                      select new AgentWorkingDto
                                      {
                                          AgentPayrollLogId = ap.AgentPayrollLogId,
                                          ContractId = ap.ContractId,
                                          ReceivedDate = ap.ReceivedDate,
                                          LastEventDate = ap.LastEventDate,
                                          Amount = ap.NetAmount,
                                          IsExclude = ap.IsExclude,// isApplyPayroll ? (ap.ExcludeDate != null ? ap.IsExclude : !releasedPayroll) : false,
                                          ExcludeDate = ap.ExcludeDate
                                      }).ToListAsync();

            return agentWorking;
        }

        public async Task<bool> SetPayrollPaymentAsync(PayrollPaymentViewModel viewModel, IPrincipal user)
        {
            try
            {
                List<PayrollPaymentModel> payrollPayments = viewModel.PayrollPayments;
                if (payrollPayments.Any() && payrollPayments.Count() > 0)
                {
                    var agentPayrolls = await Context.vwAgentPayrolls.ToListAsync();

                    var result = (from ap in agentPayrolls
                                  join pp in payrollPayments on ap.PayrollPaymentId equals pp.PayrollPaymentId
                                  select new PayrollPaymentLogDto
                                  {
                                      AgentPayrollLogId = ap.AgentPayrollLogId,
                                      ContractId = ap.ContractId,
                                      IsExclude = pp.IsExclude
                                  }).ToList().ToDataTable();

                    result.TableName = "PayRollInEx";
                    var payrollPaymentsDt = payrollPayments.ToDataTable();
                    payrollPaymentsDt.TableName = "PayrollPaymentInEx";

                    Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
                    keyValuePairsParams.Add("@PayRollInEx", result);
                    keyValuePairsParams.Add("@PayrollPaymentInEx", payrollPaymentsDt);
                    keyValuePairsParams.Add("@BatchId", viewModel.payrollBatchId);
                    keyValuePairsParams.Add("@UserId", user.GetUserId());
                    await DaoHelper.GetExecuteStoreProcedureParticular("Sp_Set_Include_Exclude_Contract_Payroll", keyValuePairsParams);
                }
                return true;
            }
            catch(Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                return false;
            }

        }

        public async Task<bool> ExcludePayrollPaymentAsync(int payrollBatchId, IPrincipal user)
        {
            try
            {

                if (payrollBatchId > 0)
                {
                    Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
                    keyValuePairsParams.Add("@PayRollInEx", null);
                    keyValuePairsParams.Add("@PayrollPaymentInEx", null);
                    keyValuePairsParams.Add("@BatchId", payrollBatchId);
                    keyValuePairsParams.Add("@UserId", user.GetUserId());
                    await DaoHelper.GetExecuteStoreProcedureParticular("Sp_Set_Include_Exclude_Contract_Payroll_skip_Contract", keyValuePairsParams);
                }
                return true;
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                return false;
            }

        }
        public async Task<bool> SetAgentPayrollLogAsync(AgentPayrollPaymentLogViewModel viewModel, IPrincipal user)
        {
            try
            {
                List<AgentPayrollLogModel> agentPayrollLogs = viewModel.AgentPayrollLogs;
                if (agentPayrollLogs.Any() && agentPayrollLogs.Count() > 0)
                {
                    var agentPayrolls = await Context.vwAgentPayrolls.ToListAsync();

                    var result = (from ap in agentPayrolls
                                  join pp in agentPayrollLogs on ap.AgentPayrollLogId equals pp.AgentPayrollLogId
                                  select new PayrollPaymentLogDto
                                  {
                                      AgentPayrollLogId = ap.AgentPayrollLogId,
                                      ContractId = ap.ContractId,
                                      IsExclude = pp.IsExclude
                                  }).ToList().ToDataTable();

                    result.TableName = "PayRollInEx";
                    Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
                    keyValuePairsParams.Add("@PayRollInEx", result);
                    keyValuePairsParams.Add("@BatchId", viewModel.payrollBatchId);
                    keyValuePairsParams.Add("@UserId", user.GetUserId());
                    await DaoHelper.GetExecuteStoreProcedureParticular("Sp_Set_Include_Exclude_Contract_Payroll", keyValuePairsParams);
                }
                return true;
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                return false;
            }
        }
    }
}
