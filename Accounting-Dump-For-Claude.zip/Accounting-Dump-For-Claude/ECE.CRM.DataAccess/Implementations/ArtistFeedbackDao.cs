﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    public class ArtistFeedbackDao : BaseDataAccessObject, IArtistFeedbackDao
    {
        public static Expression<Func<ArtistFeedback, ArtistFeedbackDetailsDto>> MapArtistFeedbackDetails = (x) => new ArtistFeedbackDetailsDto
        {
            ArtistFeedbackId = x.ArtistFeedbackId,
            PresenterAccountName = x.Contract.PresenterAccountName,
            PresenterOrganizationName = x.Contract.PresenterOrganizationName,
            VenueName = x.Contract.VenueName,
            VenuePhysicalAddress1 = x.Contract.VenuePhysicalAddress1,
            VenuePhysicalAddress2 = x.Contract.VenuePhysicalAddress2,
            VenuePhysicalCity = x.Contract.VenuePhysicalCity,
            VenuePhysicalStateId = x.Contract.VenuePhysicalStateId,
            VenuePhysicalZip = x.Contract.VenuePhysicalZip,
            VenuePhysicalCountryId = x.Contract.VenuePhysicalCountryId,
            EventDate = x.Contract.ContractEventDates.OrderBy(y => y.EventDate).FirstOrDefault().EventDate,
            AgentId = x.AgentId,
            PresenterType = x.Contract.Presenter.LuPresenterType.Name,
            ArtistId = x.ArtistId,
            ArtistName = x.Artist.Name,
            ContractId = x.ContractId,
            Feedback = x.Feedback,
            IsNegative = x.IsNegative,
            PresenterId = x.Contract.PresenterId,
            Response = x.Response,
            ResponseDate = x.ResponseDate,
            ReviewDate = x.ReviewDate,
        };

        public static Expression<Func<ArtistFeedback, ArtistFeedbackDto>> MapArtistFeedback = (x) => new ArtistFeedbackDto
        {
            ArtistFeedbackId = x.ArtistFeedbackId,
            PresenterName = x.Contract.PresenterAccountName,
            EventDate = x.Contract.ContractEventDates.OrderBy(y => y.EventDate).FirstOrDefault().EventDate,
            AgentId = x.AgentId,
            ArtistId = x.ArtistId,
            ArtistName = x.Artist.Name,
            ContractId = x.ContractId,
            Feedback = x.Feedback,
            IsNegative = x.IsNegative,
            PresenterId = x.Contract.PresenterId ?? 0,
            Response = x.Response,
            ResponseDate = x.ResponseDate,
            ReviewDate = x.ReviewDate,
        };

        public ArtistFeedbackDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<ArtistFeedbackDto> GetFeedbackByIdAsync(int id)
        {
            var feedback = await this.Context.ArtistFeedbacks
                .Where(x => x.ArtistFeedbackId == id)
                .FirstOrDefaultAsync();

            var result = Mapper.Map<ArtistFeedbackDto>(feedback);

            return result;
        }

        public async Task<IList<ArtistFeedbackDto>> GetAllFeedbackByArtistAsync(int artistId)
        {
            var maxResults = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Typeahead.MaxResults"]);

            var query = this.Context.ArtistFeedbacks
                        .Where(x => x.ArtistId == artistId
                                    && !x.Contract.ArchiveDate.HasValue)
                        .OrderByDescending(x => x.ReviewDate)
                        .Take(maxResults + 1)
                        .Select(MapArtistFeedback);

            var results = await query.ToListAsync();

            return results;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetAllFeedbackByPresenterAsync(int presenterId)
        {
            var maxResults = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Typeahead.MaxResults"]);

            var query = this.Context.ArtistFeedbacks
                .Where(x => x.Contract.PresenterId == presenterId
                            && !x.Contract.ArchiveDate.HasValue)
                .OrderByDescending(x => x.ReviewDate)
                .Take(maxResults + 1)
                .Select(MapArtistFeedbackDetails);

            var results = await query.ToListAsync();

            return results;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetMostRecentFeedbackByArtistAsync(int artistId, TimeSpan duration, int maxResults)
        {
            var limit = DateTime.Today.Add(-duration);

            var query = this.Context.ArtistFeedbacks
                        .Where(x => x.ArtistId == artistId
                                    && !x.Contract.ArchiveDate.HasValue)
                        .Select(MapArtistFeedbackDetails)
                        .Where(x => x.EventDate > limit)
                        .OrderByDescending(x => x.ReviewDate)
                        .Take(maxResults);

            var results = await query.ToListAsync();

            return results;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetDetailsByArtistAsync(int artistId)
        {
            var maxResults = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Typeahead.MaxResults"]);

            var query = this.Context.ArtistFeedbacks
                        .Where(x => x.ArtistId == artistId
                                    && !x.Contract.ArchiveDate.HasValue)
                        .OrderByDescending(x => x.ReviewDate)
                        .Take(maxResults + 1)
                        .Select(MapArtistFeedbackDetails);

            var results = await query.ToListAsync();

            return results;
        }

        public async Task<ArtistFeedbackDetailsDto> GetDetailsByIdAsync(int id)
        {
            var query = this.Context.ArtistFeedbacks
                        .Where(x => x.ArtistFeedbackId == id)
                        .Select(MapArtistFeedbackDetails);

            var result = await query.FirstOrDefaultAsync();

            return result;
        }

        public async Task CreateAsync(ArtistFeedbackDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var artistFeedback = Mapper.Map<ArtistFeedback>(dto);

            this.Context.ArtistFeedbacks.Add(artistFeedback);

            await this.Context.SaveChangesAsync();

            dto.ArtistFeedbackId = artistFeedback.ArtistFeedbackId;
        }

        public async Task UpdateAsync(ArtistFeedbackDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var artistFeedback = this.Context.ArtistFeedbacks.Find(dto.ArtistFeedbackId);
            if (artistFeedback == null)
            {
                throw new ArgumentException($"Artist Feedback {dto.ArtistFeedbackId} not found");
            }

            artistFeedback.Response = dto.Response;
            artistFeedback.UpdatedById = dto.UpdatedById;
            artistFeedback.UpdatedDate = dto.UpdatedDate;
            artistFeedback.AgentId = dto.AgentId;
            artistFeedback.ResponseDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }
    }
}