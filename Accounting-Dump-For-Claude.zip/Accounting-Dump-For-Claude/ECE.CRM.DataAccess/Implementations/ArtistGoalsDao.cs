﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistGoalsDao : BaseDataAccessObject, IArtistGoalsDao
    {
        public ArtistGoalsDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<ArtistGoalDto>> GetArtistGoalsAsync(int artistId, int numOfYears)
        {
            var currentYear = DateTime.Now.Year;
            var futureYear = currentYear + numOfYears;
            var oldestYear = currentYear - numOfYears;

            var results =
                await this.Context.ArtistGoals.Where(
                    x => x.ArtistId == artistId && x.Year <= futureYear && x.Year >= oldestYear).ToListAsync();

            var goals = Mapper.Map<IList<ArtistGoalDto>>(results);

            return goals;
        }

        public async Task CreateArtistGoalAsync(ArtistGoalDto goal)
        {
            var artistGoal = Mapper.Map<ArtistGoal>(goal);
            this.Context.ArtistGoals.Add(artistGoal);
            await this.Context.SaveChangesAsync();
        }

        public async Task UpdateArtistGoalAsync(ArtistGoalDto goal)
        {
            var artistGoal = this.Context.ArtistGoals.FirstOrDefault(x => x.ArtistGoalId == goal.ArtistGoalId);

            if (artistGoal == null)
            {
                throw new ArgumentException($"Artist Goal {goal.ArtistGoalId} not found.");
            }

            artistGoal.ArtistGoalId = goal.ArtistGoalId;
            artistGoal.ArtistId = goal.ArtistId;
            artistGoal.BookingNumber = goal.BookingNumber;
            artistGoal.Year = goal.Year;
            artistGoal.UpdatedById = goal.UpdatedById;
            artistGoal.UpdatedDate = goal.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task<IList<ArtistBookingsDto>> GetArtistBookingsAsync(int id, int year)
        {
            var results = await (from ca in this.Context.ContractArtists
                                 join c in this.Context.Contracts on ca.ContractId equals c.ContractId
                                 where ca.ArtistId == id
                                 && c.ContractStatusId != (int)ContractStatus.Canceled
                                 && c.ContractStatusId != (int)ContractStatus.PartiallyCanceled
                                 && c.ContractStatusId != (int)ContractStatus.Created
                                 && c.ContractStatusId != (int)ContractStatus.InProgress
                                 && c.IssueDate != null
                                 && c.IssueDate.Value.Year == year
                                 group new { c } by new { c.IssueDate.Value.Month } into grp
                                 select new ArtistBookingsDto
                                 {
                                     ArtistId = id,
                                     Month = grp.Key.Month,
                                     NumberOfBookings = grp.Count()
                                 }).ToListAsync();

            return results;
        }

        public async Task<IList<ArtistYtdAgentBookingsDto>> GetAgentBookingsForArtist(int id, int year)
        {
            var results = new List<ArtistYtdAgentBookingsDto>();

            var allContractArtistsYTD = await (from ca in this.Context.ContractArtists
                                               join c in this.Context.Contracts on ca.ContractId equals c.ContractId
                                               where ca.ArtistId == id
                                               && c.ContractStatusId != (int)ContractStatus.Canceled
                                               && c.ContractStatusId != (int)ContractStatus.PartiallyCanceled
                                               && c.ContractStatusId != (int)ContractStatus.Created
                                               && c.ContractStatusId != (int)ContractStatus.InProgress
                                               && c.IssueDate != null
                                               && c.IssueDate.Value.Year == year
                                               select c).ToListAsync();

            var agentIds = new List<int>();

            foreach (var c in allContractArtistsYTD)
            {
                if (!agentIds.Contains(c.AgentId))
                {
                    agentIds.Add(c.AgentId);
                }
            }

            foreach (var agentId in agentIds)
            {
                var bookingCount = allContractArtistsYTD.Where(x => x.AgentId == agentId).Count();

                var agent = this.Context.AppUsers.FirstOrDefault(x => x.AppUserId == agentId);
                var agentName = $"{agent.FirstName} {agent.LastName}";

                results.Add(new ArtistYtdAgentBookingsDto
                {
                    AgentId = agentId,
                    AgentName = agentName,
                    ArtistId = id,
                    YearToDateBookings = bookingCount
                });
            }

            return results;
        }
    }
}
