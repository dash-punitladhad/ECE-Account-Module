﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistBlockedDateDao : BaseDataAccessObject, IArtistBlockedDateDao
    {
        public ArtistBlockedDateDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<ArtistBlockedDateDto> GetByIdAsync(int id)
        {
            var result = await (from abd in this.Context.ArtistBlockedDates
                                join au in this.Context.AppUsers on abd.CreatedById equals au.AppUserId
                                where abd.ArtistBlockedDateId == id
                                && !abd.IsDeleted
                                select new ArtistBlockedDateDto
                                {
                                    BlockedDate = abd.BlockedDate,
                                    ArtistBlockedDateId = abd.ArtistBlockedDateId,
                                    ArtistId = abd.ArtistId,
                                    CreatedById = abd.CreatedById,
                                    CreatedBy = au.FirstName + " " + au.LastName,
                                    CreatedDate = abd.CreatedDate,
                                    IsMovable = abd.IsMovable,
                                    Notes = abd.Notes,
                                    PhysicalAddressCity = abd.PhysicalAddressCity,
                                    PhysicalAddressCountryId = abd.PhysicalAddressCountryId,
                                    PhysicalAddressStateId = abd.PhysicalAddressStateId,
                                    PhysicalStateAbbreviation = abd.LuState.Abbreviation,
                                }).FirstOrDefaultAsync();

            return result;
        }

        public async Task<IList<ArtistBlockedDateDto>> GetByArtistIdAsync(int id)
        {
            var result = await (from abd in this.Context.ArtistBlockedDates
                                join au in this.Context.AppUsers on abd.CreatedById equals au.AppUserId
                                where abd.ArtistId == id
                                && !abd.IsDeleted
                                select new ArtistBlockedDateDto
                                {
                                    BlockedDate = abd.BlockedDate,
                                    ArtistBlockedDateId = abd.ArtistBlockedDateId,
                                    ArtistId = abd.ArtistId,
                                    CreatedById = abd.CreatedById,
                                    CreatedBy = au.FirstName + " " + au.LastName,
                                    CreatedDate = abd.CreatedDate,
                                    IsMovable = abd.IsMovable,
                                    Notes = abd.Notes,
                                    PhysicalAddressCity = abd.PhysicalAddressCity,
                                    PhysicalAddressCountryId = abd.PhysicalAddressCountryId,
                                    PhysicalAddressStateId = abd.PhysicalAddressStateId,
                                    PhysicalStateAbbreviation = abd.LuState.Abbreviation,
                                }).ToListAsync();

            return result;
        }

        public async Task<IList<ArtistBlockedDateDto>> GetUpcomingByArtistIdAsync(int id, DateTime today)
        {
            var result = await (from abd in this.Context.ArtistBlockedDates
                                join au in this.Context.AppUsers on abd.CreatedById equals au.AppUserId
                                where abd.ArtistId == id
                                && !abd.IsDeleted
                                && abd.BlockedDate >= today
                                select new ArtistBlockedDateDto
                                {
                                    BlockedDate = abd.BlockedDate,
                                    ArtistBlockedDateId = abd.ArtistBlockedDateId,
                                    ArtistId = abd.ArtistId,
                                    CreatedById = abd.CreatedById,
                                    CreatedBy = au.FirstName + " " + au.LastName,
                                    CreatedDate = abd.CreatedDate,
                                    IsMovable = abd.IsMovable,
                                    Notes = abd.Notes,
                                    PhysicalAddressCity = abd.PhysicalAddressCity,
                                    PhysicalAddressCountryId = abd.PhysicalAddressCountryId,
                                    PhysicalAddressStateId = abd.PhysicalAddressStateId,
                                    PhysicalStateAbbreviation = abd.LuState.Abbreviation,
                                }).ToListAsync();

            return result;
        }

        public async Task DeleteAsync(int id)
        {
            var blockedDate = await this.Context.ArtistBlockedDates.FirstOrDefaultAsync(x => x.ArtistBlockedDateId == id);
            if (blockedDate == null)
            {
                throw new Exception($"Artist Blocked Date {id} Not Found.");
            }

            blockedDate.IsDeleted = true;

            await this.Context.SaveChangesAsync();
        }

        public async Task CreateAsync(ArtistBlockedDateDto dto)
        {
            var artistBlockedDate = Mapper.Map<ArtistBlockedDate>(dto);

            this.Context.ArtistBlockedDates.Add(artistBlockedDate);

            await this.Context.SaveChangesAsync();

            dto.ArtistBlockedDateId = artistBlockedDate.ArtistBlockedDateId;
        }

        public async Task UpdateAsync(ArtistBlockedDateDto dto)
        {
            var artistBlockedDate = await this.Context.ArtistBlockedDates.FirstOrDefaultAsync(x => x.ArtistBlockedDateId == dto.ArtistBlockedDateId);
            if (artistBlockedDate == null)
            {
                throw new ArgumentException($"ArtistBlockedDate {dto.ArtistBlockedDateId} not found.");
            }

            artistBlockedDate.BlockedDate = dto.BlockedDate;
            artistBlockedDate.IsDeleted = dto.IsDeleted;
            artistBlockedDate.IsMovable = dto.IsMovable;
            artistBlockedDate.PhysicalAddressCity = dto.PhysicalAddressCity;
            artistBlockedDate.PhysicalAddressCountryId = dto.PhysicalAddressCountryId;
            artistBlockedDate.PhysicalAddressStateId = dto.PhysicalAddressStateId;
            artistBlockedDate.Notes = dto.Notes;

            artistBlockedDate.UpdatedById = dto.UpdatedById;
            artistBlockedDate.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }
    }
}
