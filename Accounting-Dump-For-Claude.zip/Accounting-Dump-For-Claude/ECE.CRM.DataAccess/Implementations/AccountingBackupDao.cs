﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Core.Objects;

namespace ECE.CRM.DataAccess.Implementations
{
    public class AccountingBackupDao
    {
        private readonly EceCrmEntities _context;

        
        public AccountingBackupDao(EceCrmEntities context)
        {
            _context = context;
        }


        public async Task SaveChangesWithBackupAsync(List<DbEntityEntry> changes)
        {            

            foreach (var entry in changes)
            {                
                string entityName = ObjectContext.GetObjectType(entry.Entity.GetType()).Name;

                if (IsAccountingTable(entityName))
                {
                    int contractId = ExtractContractId(entry);

                    if (contractId > 0)
                    {
                        await CallBackupProcedureAsync(contractId, entityName);
                    }
                }
            }
        }

        private bool IsAccountingTable(string entityName)
        {
            return entityName == AccountingEntities.AgentPayrollLog ||
                   entityName == AccountingEntities.ContractTransaction ||
                   entityName == AccountingEntities.ContractTransactionHistory ||
                   entityName == AccountingEntities.GeneralLedgerJournal ||
                   entityName == AccountingEntities.ContractDeposit;
        }
        private int ExtractContractId(DbEntityEntry entry)
        {
            try
            {
                if (entry.CurrentValues.PropertyNames.Contains("ContractId"))
                    return Convert.ToInt32(entry.CurrentValues["ContractId"]);
            }
            catch { }
            try
            { 
            if (entry.OriginalValues.PropertyNames.Contains("ContractId"))
                return Convert.ToInt32(entry.OriginalValues["ContractId"]);
            }
            catch { }
            try
            {
                var entity = entry.Entity;

                var contractIdProp = entity.GetType().GetProperty("ContractId");
                var contractId = contractIdProp?.GetValue(entity)?.ToString();
                return Convert.ToInt32(contractId);
            }
            catch { }
            // For ContractTransactionHistory (navigations)
            if (entry.Entity is ContractTransactionHistory cth &&
                cth.ContractTransaction != null)
            {
                return cth.ContractTransaction.ContractId;
            }

            return 0;
        }


        private async Task CallBackupProcedureAsync(int contractId, string entityName)
        {
            await _context.Database.ExecuteSqlCommandAsync(
                "EXEC [dbo].[Sp_Set_update_AccountingTableToBackup] @ContractId, @EntityName",
                new SqlParameter("@ContractId", contractId),
                new SqlParameter("@EntityName", entityName)
            );
        }
    }

    public static class AccountingEntities
    {
        public const string AgentPayrollLog = "AgentPayrollLog";
        public const string ContractTransaction = "ContractTransaction";
        public const string ContractTransactionHistory = "ContractTransactionHistory";
        public const string GeneralLedgerJournal = "GeneralLedgerJournal";
        public const string ContractDeposit = "ContractDeposit";
    }
}
