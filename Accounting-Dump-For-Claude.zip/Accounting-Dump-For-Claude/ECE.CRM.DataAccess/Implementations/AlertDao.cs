﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using Dapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AlertDao : BaseDataAccessObject, IAlertDao
    {
        public static Expression<Func<Alert, AlertDto>> MapAlertDto = (x) => new AlertDto
        {
            AlertId = x.AlertId,
            AppUserId = x.AppUserId,
            AppEventTypeId = x.AppEventTypeId,
            CreatedById = x.CreatedById,
            CreatedDate = x.CreatedDate,
            Description = x.Description,
            EntityId = x.EntityId,
            EntityTypeId = x.EntityTypeId,
            EntityType = new LookupDto { Value = x.EntityTypeId.ToString(), Text = x.LuEntityType.Name },
            IsRead = x.IsRead,
            ReadDate = x.ReadDate,
            UpdatedById = x.UpdatedById,
            UpdatedDate = x.UpdatedDate
        };

        public AlertDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<List<AlertDto>> GetAlerts(int userId, bool includeDismissed)
        {
            var limit = TimeProvider.Current.Today.AddDays(-30);

            // Select any unread alert OR alerts read in the last 30 days
            var query = this.Context.Alerts
                            .Where(x => (x.AppUserId == userId
                                && (!x.IsRead
                                    || (includeDismissed
                                        && (x.IsRead && x.ReadDate >= limit)))))
                .Select(MapAlertDto)
                .OrderBy(x => x.AlertId);

            return await query.ToListAsync();
        }

        public async Task<List<AlertAdvDto>> GetAlertsAdv(int userId, bool includeDismissed, int? entitytypeid, string search, DateTime? startDate, DateTime? endDate)
        {
            List<AlertAdvDto> alertAdvDtos = new List<AlertAdvDto>();
            SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory();
            var conn = sqlConnectionFactory.CreateConnection();
            try
            {
                var dp = new DynamicParameters();
                dp.Add("@userid", userId);
                dp.Add("@Isread", includeDismissed);
                dp.Add("@entitytypeid", entitytypeid);
                dp.Add("@search", search);
                dp.Add("@startdate", startDate);
                dp.Add("@enddate", endDate);
                alertAdvDtos = (await conn.QueryAsync<AlertAdvDto>("sp_get_alter_read_unread @userid,@Isread,@entitytypeid,@search,@startdate,@enddate", dp)).ToList();
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return alertAdvDtos;
        }

        public async Task<bool> SetReadAlertAsync(AlertViewMode viewModel, IPrincipal user)
        {
            try
            {

                if (viewModel.AlertModels.Any() && viewModel.AlertModels.Count() > 0)
                {

                    var readAltersDt = viewModel.AlertModels.ToDataTable();
                    readAltersDt.TableName = "ReadAlter";

                    Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
                    keyValuePairsParams.Add("@ReadAlter", readAltersDt);
                    keyValuePairsParams.Add("@UserId", user.GetUserId());
                    await DaoHelper.GetExecuteStoreProcedureParticular("Sp_Set_Alter_Read", keyValuePairsParams);
                }
                return true;
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                return false;
            }

        }

        public async Task<AlertDto> GetByIdAsync(int alertId)
        {
            var query = this.Context.Alerts
                .Where(x => x.AlertId == alertId)
                .Select(MapAlertDto);

            return await query.FirstOrDefaultAsync();
        }

        public async Task CreateAsync(AlertDto alert)
        {
            if (alert == null)
            {
                throw new ArgumentNullException(nameof(alert));
            }

            var newItem = Mapper.Map<AlertDto, Alert>(alert);

            this.Context.Alerts.Add(newItem);

            await this.Context.SaveChangesAsync();
        }

        public async Task UpdateAsync(AlertDto alert)
        {
            if (alert == null)
            {
                throw new ArgumentNullException(nameof(alert));
            }

            var match = this.Context.Alerts.Find(alert.AlertId);
            if (match == null)
            {
                throw new ArgumentException($"Alert {alert.AlertId} not found.");
            }

            Mapper.Map(alert, match);

            await this.Context.SaveChangesAsync();
        }

        public async Task<bool> DismissAllAsync(IPrincipal user)
        {
            int userId = user.GetUserId();
            var alerts = this.Context.Alerts.Where(a => a.AppUserId == userId && !a.IsRead);

            foreach (var alert in alerts)
            {
                var readDate = DateTime.UtcNow;
                alert.IsRead = true;
                alert.ReadDate = readDate;
                alert.UpdatedById = userId;
                alert.UpdatedDate = readDate;
            }

            await this.Context.SaveChangesAsync();
            return true;
        }

        public async Task<IList<AlertDto>> GetUnreadByEntityAsync(int entityId, int entityTypeId)
        {
            var query = this.Context.Alerts
                .Where(x => x.EntityId == entityId
                            && x.EntityTypeId == entityTypeId
                            && !x.IsRead)
                .Select(MapAlertDto);

            var results = await query.ToListAsync();

            return results;
        }
    }
}
