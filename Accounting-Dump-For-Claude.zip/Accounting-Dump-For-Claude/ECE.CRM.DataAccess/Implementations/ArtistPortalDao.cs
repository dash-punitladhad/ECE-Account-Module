﻿namespace ECE.CRM.DataAccess
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistPortalDao : BaseDataAccessObject, IArtistPortalDao
    {
        public ArtistPortalDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<List<ArtistPortalBookDateDto>> GetBookedDatesForPortalAsync(int id)
        {
            var excludedContracts = new List<int>
            {
                (int)ContractStatus.InProgress,
                (int)ContractStatus.Created,
                (int)ContractStatus.PartiallyCanceled,
                (int)ContractStatus.Canceled
            };

            var result = await (from c in this.Context.Contracts
                                join ce in this.Context.ContractEventDates on c.ContractId equals ce.ContractId
                                join cae in this.Context.ContractArtistEventDates on ce.ContractEventDateId equals cae.ContractEventDateId
                                join ca in this.Context.ContractArtists on cae.ContractArtistId equals ca.ContractArtistId
                                where ca.ArtistId == id
                                && !c.ArchiveDate.HasValue
                                && (!excludedContracts.Contains(c.ContractStatusId)
                                    || (c.ContractStatusId == (int)ContractStatus.Created
                                        && c.IsNoIssue.Value))
                                select new ArtistPortalBookDateDto
                                {
                                    ContractId = c.ContractId,
                                    EventDate = ce.EventDate,
                                    PresenterId = c.PresenterId ?? 0,
                                    PresenterName = c.PresenterAccountName,
                                    Gross = cae.ContractArtist.Gross,
                                    EventCity = c.VenuePhysicalCity,
                                    EventStateId = c.VenuePhysicalStateId,
                                    VenueName = c.VenueName,
                                    VenueId = c.VenueId,
                                    CityState = c.VenuePhysicalCity + ", " + c.LuState1.Abbreviation,
                                    HasVenue = c.VenueId != null ? true : false,
                                    IsBlocked = false,
                                    Pickup = ca.Pickup
                                })
                               .Union(
                                from b in this.Context.ArtistBlockedDates
                                where b.ArtistId == id
                                && !b.IsDeleted
                                select new ArtistPortalBookDateDto
                                {
                                    ContractId = 0,
                                    EventDate = b.BlockedDate,
                                    PresenterId = 0,
                                    PresenterName = "BLOCKED DATE",
                                    Gross = -1,
                                    EventCity = b.PhysicalAddressCity,
                                    EventStateId = 0,
                                    VenueName = string.Empty,
                                    VenueId = 0,
                                    CityState = b.PhysicalAddressCity + ", " + b.LuState.Abbreviation,
                                    HasVenue = false,
                                    IsBlocked = true,
                                    Pickup = null
                                }).ToListAsync();

            return result;
        }

        public async Task<IList<ArtistPortalActionDto>> GetArtistActionsNeededAsync(int artistId)
        {
            var today = DateTime.Today;
            const int Artist = (int)EntityType.Artist;
            const int Presenter = (int)EntityType.Presenter;

            var results = await
            (
                from c in this.Context.Contracts.VisibleToArtistPortalRouteBook()
                join ce in this.Context.ContractEventDates
                    on c.ContractId equals ce.ContractId
                join cae in this.Context.ContractArtistEventDates
                    on ce.ContractEventDateId equals cae.ContractEventDateId
                join ca in this.Context.ContractArtists
                    on cae.ContractArtistId equals ca.ContractArtistId
                where ca.ArtistId == artistId
                      && ce.EventDate >= today
                      && (c.IsNoIssue == false || c.IsNoIssue == null)
                select new
                {
                    c.ContractId,
                    ce.EventDate,
                    c.IsPandaDoc,
                    ArtistSignature = c.ContractSignatures
                        .Where(s => s.EntityTypeId == Artist && s.EntityId == artistId)
                        .Select(s => new { s.DueDate, s.IsReceived })
                        .FirstOrDefault(),

                    PresenterSigned = c.ContractSignatures
                        .Any(s => s.EntityTypeId == Presenter && s.IsReceived),

                    LatestHistory = c.ContractChangeNoteHistories
                        .OrderByDescending(h => h.ContractChangeNoteHistoryId)
                        .Select(h => new
                        {
                            h.ChangeNote,
                            h.ContractStatusId
                        })
                        .FirstOrDefault()
                }
            )
            .Select(x => new ArtistPortalActionDto
            {
                ContractId = x.ContractId,
                EventDate = x.EventDate,

                DueDate = x.ArtistSignature != null
                    ? x.ArtistSignature.DueDate
                    : (DateTime?)null,

                ArtistSignatureCount = x.ArtistSignature != null && x.ArtistSignature.IsReceived
                    ? 1
                    : 0,

                IsPresenterSignButNoArtistSign =
                    ((x.ArtistSignature != null &&
                    !x.ArtistSignature.IsReceived)|| x.ArtistSignature == null) &&
                    x.PresenterSigned,

                ChangeNote = x.LatestHistory != null
                    ? x.LatestHistory.ChangeNote
                    : null,

                ContractStatusId = x.LatestHistory != null
                    ? x.LatestHistory.ContractStatusId
                    : (int?)null,
                IsPandaDoc=x.IsPandaDoc
            })
            .ToListAsync();

            return results;
        }
    }
}
