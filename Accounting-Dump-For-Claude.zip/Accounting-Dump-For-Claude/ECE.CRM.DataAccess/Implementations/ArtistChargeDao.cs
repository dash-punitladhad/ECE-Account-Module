﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using LinqKit;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistChargeDao : BaseDataAccessObject, IArtistChargeDao
    {
        public ArtistChargeDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public static void RoundAmounts(ArtistCharge artistCharge)
        {
            artistCharge.OriginalAmount = artistCharge.OriginalAmount.ToFixed();
            artistCharge.PaymentAmount = artistCharge.PaymentAmount.ToFixed();
            artistCharge.RemainingBalance = artistCharge.RemainingBalance.ToFixed();
            artistCharge.InterestRate = artistCharge.InterestRate.ToFixed();
            artistCharge.TotalPaymentsReceived = artistCharge.TotalPaymentsReceived.ToFixed();
        }

        public async Task CreateArtistChargeAsync(ArtistChargeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var artistCharge = Mapper.Map<ArtistCharge>(dto);

            RoundAmounts(artistCharge);

            this.Context.ArtistCharges.Add(artistCharge);

            await this.Context.SaveChangesAsync();

            dto.ArtistChargeId = artistCharge.ArtistChargeId;
        }

        public async Task<ArtistChargeDto> GetByIdAsync(int id)
        {
            var artistCharge = await this.Context.ArtistCharges.FirstOrDefaultAsync(x => x.ArtistChargeId == id);

            if (artistCharge == null)
            {
                return null;
            }

            var dto = Mapper.Map<ArtistChargeDto>(artistCharge);

            return dto;
        }

        public async Task<IList<ArtistChargeTransactionDto>> GetArtistChargeTransactionsByArtistChargeIdAsync(int artistChargeId)
        {
            var query = this.Context
                .ArtistChargeTransactions
                .Select(x => new ArtistChargeTransactionDto
                {
                    ArtistChargeId = x.ArtistChargeId,
                    ArtistChargeTransactionId = x.ArtistChargeTransactionId,
                    ArtistChargeTransactionTypeId = x.ArtistChargeTransactionTypeId,
                    ArtistChargeTransactionTypeLabel = x.LuArtistChargeTransactionType.Name,
                    CreatedById = x.CreatedById,
                    CreatedDate = x.CreatedDate,
                    ExpensePaymentId = x.ExpensePaymentId,
                    ExpensePaymentStatusId = x.ExpensePaymentStatusId,
                    ExpensePaymentDatePosted = x.ExpensePayment.DatePosted,
                    IsDeleted = x.IsDeleted,
                    TransactionAmount = x.TransactionAmount,
                    TransactionDate = x.TransactionDate,
                    UpdatedById = x.UpdatedById,
                    UpdatedDate = x.UpdatedDate,
                })
                .Where(x => x.ArtistChargeId == artistChargeId && !x.IsDeleted)
                .OrderByDescending(x => x.TransactionDate)
                .ThenByDescending(x => x.ArtistChargeTransactionId);

            var transactions = await query.ToListAsync();

            return transactions;
        }

        public async Task<IList<ArtistChargeSearchResultDto>> GetArtistChargesByCriteriaAsync(ArtistChargeSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var predicate = PredicateBuilder.New<ArtistCharge>();

            if (criteria.ArtistId > 0)
            {
                predicate = predicate.And(x => x.ArtistId == criteria.ArtistId);
            }

            if (criteria.ArtistChargeTypeId > 0)
            {
                predicate = predicate.And(x => x.ArtistChargeTypeId == criteria.ArtistChargeTypeId);
            }

            if (criteria.ArtistChargeStatusId > 0)
            {
                predicate = predicate.And(x => x.ArtistChargeStatusId == criteria.ArtistChargeStatusId);
            }

            if (criteria.BalanceFrom > 0)
            {
                predicate = predicate.And(x => x.RemainingBalance >= criteria.BalanceFrom);
            }

            if (criteria.BalanceTo > 0)
            {
                predicate = predicate.And(x => x.RemainingBalance <= criteria.BalanceTo);
            }

            if (criteria.OriginalDateFrom.HasValue)
            {
                predicate = predicate.And(x => x.OriginalDate >= criteria.OriginalDateFrom);
            }

            if (criteria.OriginalDateTo.HasValue)
            {
                predicate = predicate.And(x => x.OriginalDate <= criteria.OriginalDateTo);
            }

            var maxResults = MobiusConfiguration.GetInt32("Search.MaxResults");

            var results = await Context.ArtistCharges
                .AsExpandable()
                .Where(predicate)
                .Take(maxResults + 1)
                .ToListAsync();

            var searchResults = results.Select(x => new ArtistChargeSearchResultDto()
            {
                ArtistChargeId = x.ArtistChargeId,
                ArtistId = x.ArtistId,
                ArtistName = x.Artist.Name,
                TypeDisplay = x.LuArtistChargeType.Description,
                StatusDisplay = x.LuArtistChargeStatu.Name,
                OriginalAmount = x.OriginalAmount,
                OriginalDate = x.OriginalDate,
                Balance = x.RemainingBalance,
                PaymentAmount = x.PaymentAmount,
                LastPaymentDate = x.LastPaymentDate,
                InterestCalculated = x.LuInterestCalculatedFrequency.Name,
                InterestRate = x.InterestRate,
                PaymentsReceived = x.TotalPaymentsReceived
            }).ToList();

            return searchResults;
        }

        public async Task CreateArtistChargeTransactionAsync(ArtistChargeTransactionDto artistChargeTransaction)
        {
            if (artistChargeTransaction == null)
            {
                throw new ArgumentNullException(nameof(artistChargeTransaction));
            }

            var newItem = Mapper.Map<ArtistChargeTransactionDto, ArtistChargeTransaction>(artistChargeTransaction);

            this.Context.ArtistChargeTransactions.Add(newItem);

            await this.Context.SaveChangesAsync();
        }

        public async Task<IList<ArtistChargeDto>> GetArtistChargesByArtistIdAsync(int artistId)
        {
            var query = await (from c in this.Context.ArtistCharges
                               where c.ArtistId == artistId
                               && (c.ArtistChargeStatusId == (int)ArtistChargeStatus.Outstanding || c.ArtistChargeStatusId == (int)ArtistChargeStatus.Default)
                               && c.RemainingBalance > decimal.Zero
                               && c.PaymentAmount > decimal.Zero
                               && !c.IsDeleted
                               orderby c.OriginalDate
                               select c).ToListAsync();

            var charges = Mapper.Map<IList<ArtistChargeDto>>(query);

            return charges;
        }

        public async Task UpdateArtistChargeAsync(ArtistChargeDto artistCharge)
        {
            if (artistCharge == null)
            {
                throw new ArgumentNullException(nameof(artistCharge));
            }

            var match = this.Context.ArtistCharges.Find(artistCharge.ArtistChargeId);

            match.ArtistChargeStatusId = artistCharge.ArtistChargeStatusId;
            match.OriginalAmount = artistCharge.OriginalAmount;
            match.OriginalDate = artistCharge.OriginalDate;
            match.InterestCalculatedFrequencyId = artistCharge.InterestCalculatedFrequencyId;
            match.InterestRate = artistCharge.InterestRate;
            match.SuspendInterest = artistCharge.SuspendInterest;
            match.PaymentAmount = artistCharge.PaymentAmount;
            match.TotalPaymentsReceived = artistCharge.TotalPaymentsReceived;
            match.RemainingBalance = artistCharge.RemainingBalance;
            match.LastPaymentDate = artistCharge.LastPaymentDate;
            match.Notes = artistCharge.Notes;
            match.UpdatedDate = artistCharge.UpdatedDate;
            match.UpdatedById = artistCharge.UpdatedById;

            RoundAmounts(match);

            await this.Context.SaveChangesAsync();
        }

        public async Task<IList<ArtistChargeTransactionDto>> GetLoanRepaymentsAsync(int expensePaymentId, bool includeWithheld = false)
        {
            var repayment = (int)ArtistChargeTransactionType.Repayment;

            var query = from c in this.Context.ArtistChargeTransactions
                        where c.ExpensePaymentId == expensePaymentId
                        && !c.IsDeleted
                        && c.ArtistChargeTransactionTypeId == repayment
                        && (includeWithheld || c.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                        orderby c.TransactionDate
                        select c;

            var repayments = Mapper.Map<IList<ArtistChargeTransactionDto>>(await query.ToListAsync());

            return repayments;
        }

        public async Task<IList<ArtistChargeTransactionDto>> GetLoanRepaymentsByExpenseBatchIdAsync(int expenseBatchId)
        {
            var repayment = (int)ArtistChargeTransactionType.Repayment;

            var query = from c in this.Context.ArtistChargeTransactions
                        where c.ExpensePayment.ExpenseBatchId == expenseBatchId
                        && !c.IsDeleted
                        && c.ArtistChargeTransactionTypeId == repayment
                        && c.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold
                        orderby c.TransactionDate
                        select c;

            var repayments = Mapper.Map<IList<ArtistChargeTransactionDto>>(await query.ToListAsync());

            return repayments;
        }

        public async Task<ArtistChargeTransactionDto> GetArtistChargeTransactionAsync(int artistChargeTransactionId)
        {
            var query = from c in this.Context.ArtistChargeTransactions
                        where c.ArtistChargeTransactionId == artistChargeTransactionId
                        && !c.IsDeleted
                        select c;

            var result = await query.FirstOrDefaultAsync();
            if (result == null)
            {
                return null;
            }

            return Mapper.Map<ArtistChargeTransactionDto>(result);
        }

        public async Task UpdateArtistChargeTransactionAsync(ArtistChargeTransactionDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var match = await this.Context.ArtistChargeTransactions.FindAsync(dto.ArtistChargeTransactionId);
            if (match == null)
            {
                throw new ArgumentException($"Artist Charge Transaction {dto.ArtistChargeTransactionId} not found.");
            }

            match.ExpensePaymentId = dto.ExpensePaymentId;
            match.ExpensePaymentStatusId = dto.ExpensePaymentStatusId;
            match.IsDeleted = dto.IsDeleted;
            match.TransactionAmount = dto.TransactionAmount;
            match.TransactionDate = dto.TransactionDate;

            match.UpdatedById = dto.UpdatedById;
            match.UpdatedDate = dto.UpdatedDate;

            await this.Context.SaveChangesAsync();
        }

        public async Task<IList<MiscArtistPaymentDto>> GetMiscArtistPaymentsAsync(DateTime fromDate, DateTime toDate)
        {
            var fromTransactionDate = fromDate.Date;
            var toTransactionDate = toDate.AddDays(1).Date;

            var query = Context.ArtistChargeTransactions
               .Where(x => x.IsDeleted == false
                   && x.TransactionDate >= fromTransactionDate
                   && x.TransactionDate < toTransactionDate
                   && (x.ExpensePaymentId == null || x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid))
               .Select(x => new MiscArtistPaymentDto()
               {
                   ArtistChargeId = x.ArtistChargeId,
                   ArtistId = x.ArtistCharge.ArtistId,
                   ArtistName = x.ArtistCharge.Artist.Name,
                   InterestRate = x.ArtistCharge.InterestRate,
                   OriginalAmount = x.ArtistCharge.OriginalAmount,
                   OriginalDate = x.ArtistCharge.OriginalDate,
                   TypeDisplay = x.ArtistCharge.LuArtistChargeType.Description,
                   ArtistChargeTransactionTypeId = x.ArtistChargeTransactionTypeId,
                   TransactionAmount = x.TransactionAmount,
                   TransactionDate = DbFunctions.TruncateTime(x.TransactionDate).Value,
                   ReferenceNumber = x.ExpensePayment.ReferenceNumber
               })
               .OrderBy(x => x.TransactionDate)
               .ThenBy(x => x.ReferenceNumber)
               .ThenBy(x => x.ArtistName);

            return await query.ToListAsync();
        }

        public async Task<IList<OutstandingEscrowLoanDto>> GetEscrowLoanBalancesAsync(DateTime fromDate, DateTime toDate)
        {
            var fromTransactionDate = fromDate.Date;
            var toTransactionDate = toDate.AddDays(1).Date;


            // Get all loans created during the time period
            var artistChargeTransactions = Context.ArtistChargeTransactions.Where(x => x.TransactionDate >= fromTransactionDate
                      && x.TransactionDate < toTransactionDate).Select(a => a.ArtistChargeId).ToList();


            // Get all loans created during the time period
            var query1 = Context.ArtistCharges
                .Where(x => x.IsDeleted == false
                    && x.ArtistChargeTypeId == (int)ArtistChargeType.EscrowLoan
                    && x.OriginalDate >= fromTransactionDate
                    && x.OriginalDate < toTransactionDate)
                .Select(x => x.ArtistChargeId);

            var subQuery = Context.ArtistChargeTransactions
                .Where(x => x.IsDeleted == false
                    && x.TransactionDate < toTransactionDate
                    && (x.ExpensePaymentId == null || x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid));

            // Get all loans not paid in full on the last day of the time period
            var query2 = Context.ArtistCharges
                .Where(x => x.IsDeleted == false
                    && x.ArtistChargeTypeId == (int)ArtistChargeType.EscrowLoan
                    && x.ArtistChargeStatusId != (int)ArtistChargeStatus.Settled
                    && x.OriginalDate < toTransactionDate
                    && subQuery
                        .Where(y => y.ArtistChargeId == x.ArtistChargeId)
                        .Select(y => -y.TransactionAmount)
                        .DefaultIfEmpty(decimal.Zero)
                        .Sum() + x.OriginalAmount > decimal.Zero)
                .Select(x => x.ArtistChargeId);

            // Get all loans with any activity during the time period
            var query3 = Context.ArtistChargeTransactions
                .Where(x => x.IsDeleted == false
                    && x.ArtistCharge.IsDeleted == false
                    && x.ArtistCharge.ArtistChargeTypeId == (int)ArtistChargeType.EscrowLoan
                    && artistChargeTransactions.Contains(x.ArtistChargeId)
                    && (x.ExpensePaymentId == null || x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid))
                .Select(x => x.ArtistChargeId);


            var selectedLoans = query1.Union(query2).Union(query3);

            var query =
                from ac in Context.ArtistCharges
                where selectedLoans.Contains(ac.ArtistChargeId)
                let activityBefore =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let repayments =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Repayment
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let currentrepayments =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.TransactionDate >= fromTransactionDate
                    && act.TransactionDate < toTransactionDate
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Repayment
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let adjustments =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.TransactionDate >= fromTransactionDate
                    && act.TransactionDate <= toTransactionDate
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Adjustment
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let totalAdjustment =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Adjustment
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let totalInterestCharges =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Interest
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let currentInterestCharges =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                     && act.TransactionDate >= fromTransactionDate
                    && act.TransactionDate < toTransactionDate
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && act.ArtistChargeTransactionTypeId == (int)ArtistChargeTransactionType.Interest
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                let activityDuring =
                (
                    from act in this.Context.ArtistChargeTransactions
                    where act.IsDeleted == false
                    && act.ArtistChargeId == ac.ArtistChargeId
                    && (act.ExpensePaymentId == null || act.ExpensePaymentStatusId == (int)ExpensePaymentStatus.FullyPaid)
                    select -act.TransactionAmount
                ).DefaultIfEmpty(decimal.Zero).Sum()
                orderby ac.Artist.Name
                select new OutstandingEscrowLoanDto
                {
                    ArtistId = ac.ArtistId,
                    ArtistName = ac.Artist.Name,
                    ArtistChargeId = ac.ArtistChargeId,
                    OriginalAmount = ac.OriginalAmount,
                    OriginalDate = ac.OriginalDate,
                    InterestRate = ac.InterestRate / 100m,
                    StartingBalance = ac.OriginalAmount,//+ activityBefore,
                    Repayments = ac.TotalPaymentsReceived.Value, //repayments,
                    CurrentRepayments = currentrepayments,
                    Adjustments = adjustments,
                    TotalAdjustment = totalAdjustment,
                    CurrentInterestCharges = currentInterestCharges,
                    InterestCharges = totalInterestCharges,
                    EndingBalance = (ac.RemainingBalance.HasValue ? ac.RemainingBalance.Value : decimal.Zero),
                };

            return await query.Where(a => (a.CurrentRepayments.HasValue ? a.CurrentRepayments.Value : 0) != decimal.Zero || a.CurrentInterestCharges != decimal.Zero || a.Adjustments != decimal.Zero || a.EndingBalance != decimal.Zero).ToListAsync();
        }
    }
}
