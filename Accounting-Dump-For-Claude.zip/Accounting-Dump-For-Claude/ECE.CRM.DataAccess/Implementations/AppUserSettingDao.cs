﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class AppUserSettingDao : BaseDataAccessObject, IAppUserSettingDao
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppUserSettingDao"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public AppUserSettingDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<AppUserSettingDto>> GetAppUserSettingsAsync(int appUserId)
        {
            var query = from x in this.Context.AppUserSettings
                        where x.AppUserId == appUserId
                        && !x.IsDeleted
                        select new AppUserSettingDto
                        {
                            AppUserSettingId = x.AppUserSettingId,
                            AppUserId = x.AppUserId,
                            AppUserSettingKeyId = x.AppUserSettingKeyId,
                            AppUserSettingKey = x.LuAppUserSettingKey.Name,
                            Value = x.Value,
                            IsDeleted = x.IsDeleted,
                            CreatedById = x.CreatedById,
                            CreatedDate = x.CreatedDate,
                            UpdatedById = x.UpdatedById,
                            UpdatedDate = x.UpdatedDate
                        };

            var results = await query.ToListAsync();

            return results;
        }

        public async Task CreateAsync(AppUserSettingDto setting)
        {
            if (setting == null)
            {
                throw new ArgumentNullException(nameof(setting));
            }

            var newItem = Mapper.Map<AppUserSettingDto, AppUserSetting>(setting);

            this.Context.AppUserSettings.Add(newItem);

            await this.Context.SaveChangesAsync();

            setting.AppUserSettingId = newItem.AppUserSettingId;
        }

        public async Task UpdateAsync(AppUserSettingDto setting)
        {
            if (setting == null)
            {
                throw new ArgumentNullException(nameof(setting));
            }

            var match = await this.Context.AppUserSettings.FindAsync(setting.AppUserSettingId);
            if (match == null)
            {
                throw new ArgumentException($"AppUserSetting {setting.AppUserSettingId} not found.");
            }

            Mapper.Map(setting, match);

            await this.Context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int settingId, int deletedById)
        {
            var settingToDelete = await this.Context.AppUserSettings.FindAsync(settingId);
            if (settingToDelete == null)
            {
                return;
            }

            settingToDelete.IsDeleted = true;
            settingToDelete.UpdatedById = deletedById;
            settingToDelete.UpdatedDate = TimeProvider.Current.Now;

            await this.Context.SaveChangesAsync();
        }
    }
}
