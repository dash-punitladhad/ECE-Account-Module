﻿namespace ECE.CRM.DataAccess
{
    using ECE.CRM.DataTransferObjects;
    using LinqKit;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class AppLogDao : BaseDataAccessObject, IAppLogDao
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppLogDao"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public AppLogDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<AppLogDto>> GetByCriteriaAsync(AppLogSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var predicate = BuildCriteriaPredicate(criteria);

            var results = await Context.AppLogs
                .AsExpandable()
                .Where(predicate)
                .OrderByDescending(x => x.LogDate)
                .Select(x => new AppLogDto
                {
                    AppLogId = x.AppLogId,
                    LogDate = x.LogDate.Value,
                    LogLevel = x.LogLevel,
                    UserName = x.UserName,
                    Message = x.Message
                })
                .ToListAsync();

            return results;
        }

        private ExpressionStarter<AppLog> BuildCriteriaPredicate(AppLogSearchCriteriaDto criteria)
        {
            var predicate = PredicateBuilder.New<AppLog>();

            if (!string.IsNullOrWhiteSpace(criteria.LogLevel))
            {
                predicate = predicate.And(e => e.LogLevel == criteria.LogLevel);
            }

            if (!string.IsNullOrWhiteSpace(criteria.UserName))
            {
                predicate = predicate.And(e => e.UserName == criteria.UserName);
            }

            if (criteria.LogDateFrom.HasValue)
            {
                var value = criteria.LogDateFrom.Value.Date;
                value = value.ToUniversalTime();
                predicate = predicate.And(e => e.LogDate >= value);
            }

            if (criteria.LogDateTo.HasValue)
            {
                var value = criteria.LogDateTo.Value.Date.AddDays(1);
                value = value.ToUniversalTime();
                predicate = predicate.And(e => e.LogDate < value);
            }

            if (!string.IsNullOrWhiteSpace(criteria.Message))
            {
                predicate = predicate.And(e => e.Message.Contains(criteria.Message));
            }

            return predicate;
        }
    }
}
