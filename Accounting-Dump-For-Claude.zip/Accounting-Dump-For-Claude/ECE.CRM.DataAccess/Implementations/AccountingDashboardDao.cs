﻿namespace ECE.CRM.DataAccess
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class AccountingDashboardDao : BaseDataAccessObject, IAccountingDashboardDao
    {
        public AccountingDashboardDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<OfficeRevenueDto>> GetOfficeRevenueAsync(DateTime monthToQuery)
        {
            var sql = @"
select t.OfficeId,
       t.Name AS [OfficeName],
       ISNULL(SUM(CASE ChangeType
             WHEN 'C'
             THEN [PostedAmount]
             ELSE [PostedAmount] * -1
           END), 0) AS [Revenue],
        ISNULL(SUM(CASE ChangeType
              WHEN 'C'
              THEN [PostedAmount]
              ELSE 0
            END), 0) AS [Credit],
        ISNULL(SUM(CASE ChangeType
              WHEN 'D'
              THEN [PostedAmount]
              ELSE 0
            END), 0) AS [Debit]

from LuOffice t
left join [GeneralLedgerJournal] j on j.OfficeId = t.OfficeId and [GeneralLedgerAccountId] = 4010
and j.PostedDate >= {0} and j.PostedDate < {1}

group by t.OfficeId, t.Name
order by t.OfficeId
";

            var parameters = new object[]
            {
                monthToQuery,
                monthToQuery.AddMonths(1)
            };

            var query = this.Context.Database.SqlQuery<OfficeRevenueDto>(sql, parameters);

            return await query.ToListAsync();
        }

        public async Task<ContractSummaryDto> GetContractSummaryAsync()
        {
            var query =
                from pc in this.Context.vwProblemContracts
                group pc by 0 into g
                select new ContractSummaryDto
                {
                    MissingDepositsCount = g.Count(x => x.MissingDepositsCount > 0),
                    MissingSignaturesCount = g.Count(x => x.MissingSignaturesCount > 0),
                    OutOfBalanceContractCount = g.Count(x => x.OutOfBalanceContractCount > 0),
                };

            var summary = await query.FirstOrDefaultAsync();

            var underwaterQuery =
                from m in this.Context.vwContractMoneys
                where m.ExpenseAmount == m.IncomeAmount
                && m.ReleasedAmount > m.ReceivedAmount
                select m.ContractId;

            var underwaterCount = await underwaterQuery.CountAsync();

            summary.UnderwaterContractCount = underwaterCount;

            return summary;
        }
    }
}
