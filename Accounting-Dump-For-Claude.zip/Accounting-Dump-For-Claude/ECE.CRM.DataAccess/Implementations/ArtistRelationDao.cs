﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistRelationDao : BaseDataAccessObject, IArtistRelationDao
    {
        public ArtistRelationDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<List<ArtistDto>> GetAsync(int id)
        {
            var matches = await (from a in this.Context.Artists
                                 join ar in this.Context.ArtistRelations on a.ArtistId equals ar.ArtistId
                                 where ar.RelatedArtistId == id
                                 where ar.IsDeleted != true
                                 select a
                                 ).ToListAsync();

            var results = Mapper.Map<List<ArtistDto>>(matches);

            return results;
        }

        public async Task DeleteAllAsync(ArtistRelationDto dto)
        {
            var matches = await (from a in this.Context.ArtistRelations
                                 where a.ArtistId == dto.ArtistId || a.RelatedArtistId == dto.ArtistId
                                 select a).ToListAsync();

            foreach (var match in matches)
            {
                match.IsDeleted = true;
                match.UpdatedById = dto.UpdatedById;
                match.UpdatedDate = dto.UpdatedDate;
            }

            await this.Context.SaveChangesAsync();

            return;
        }

        public async Task CreateAsync(ArtistRelationDto dto)
        {
            var sourceToTarget = new ArtistRelation
            {
                ArtistId = dto.ArtistId,
                RelatedArtistId = dto.RelatedArtistId,
                CreatedById = dto.CreatedById,
                CreatedDate = dto.CreatedDate
            };

            var targetToSource = new ArtistRelation
            {
                ArtistId = dto.RelatedArtistId,
                RelatedArtistId = dto.ArtistId,
                CreatedById = dto.CreatedById,
                CreatedDate = dto.CreatedDate
            };

            this.Context.ArtistRelations.Add(sourceToTarget);
            this.Context.ArtistRelations.Add(targetToSource);

            await this.Context.SaveChangesAsync();
        }
    }
}
