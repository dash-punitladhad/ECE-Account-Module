﻿namespace ECE.CRM.DataAccess
{
    using AutoMapper;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistGenreTypeDao : BaseDataAccessObject, IArtistGenreTypeDao
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ArtistGenreTypeDao"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public ArtistGenreTypeDao(IEceCrmEntities context)
            : base(context)
        {
        }

        public async Task<IList<ArtistGenreTypeDto>> GetChildrenAsync(int id)
        {
            var query = await (from va in this.Context.ArtistGenreTypes
                               join at in this.Context.LuGenreTypes on va.GenreTypeId equals at.GenreTypeId
                               where va.ArtistId == id
                               select new ArtistGenreTypeDto
                               {
                                   ArtistGenreTypeId = va.ArtistGenreTypeId,
                                   ArtistId = va.ArtistId,
                                   GenreTypeId = va.GenreTypeId,
                                   GenreTypeName = at.Name
                               }).ToListAsync();

            return query;
        }

        public async Task<int> CreateChildAsync(ArtistGenreTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var newItem = Mapper.Map<ArtistGenreTypeDto, ArtistGenreType>(dto);

            this.Context.ArtistGenreTypes.Add(newItem);

            await this.Context.SaveChangesAsync();

            return newItem.ArtistId;
        }

        public async Task DeleteChildAsync(ArtistGenreTypeDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }
            var entity = new ArtistGenreType();
            entity = this.Context.ArtistGenreTypes.Find(dto.ArtistGenreTypeId);
            if (entity == null)
            {

                entity = this.Context.ArtistGenreTypes.AsEnumerable().FirstOrDefault(a => a.ArtistId == dto.ArtistId && a.GenreTypeId == dto.GenreTypeId);
                if (entity == null)
                {
                    return;
                }
            }

            this.Context.ArtistGenreTypes.Remove(entity);

            await this.Context.SaveChangesAsync();
        }
    }
}
