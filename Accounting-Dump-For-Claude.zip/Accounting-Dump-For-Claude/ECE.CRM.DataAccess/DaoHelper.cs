﻿namespace ECE.CRM.DataAccess
{
    using ClosedXML.Excel;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Caching;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.Logging;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.Entity.Spatial;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.SessionState;
    using System.Linq;
    using System.Data.Entity;
    using System.Reflection;

    public static class DaoHelper
    {
        public const int CoordinateSystemIdentifier = 4326;

        public const double MilesToMetersRatio = 1609.34F;

        public const double MetersToMilesRatio = 0.000621371192F;
        public static ILogger Logger { get; private set; }
        public static object ToDBNull(object value)
        {
            if (value != null)
            {
                return value;
            }

            return DBNull.Value;
        }

        public static DbGeography CreatePoint(double latitude, double longitude)
        {
            var text = string.Format("POINT({0} {1})", longitude, latitude);

            return DbGeography.PointFromText(text, CoordinateSystemIdentifier);
        }

        public static double ConvertMilesToMeters(double? miles)
        {
            if (!miles.HasValue)
            {
                return 0;
            }

            return miles.Value * MilesToMetersRatio;
        }

        public static double ConvertMetersToMiles(double? meters)
        {
            if (!meters.HasValue)
            {
                return 0;
            }

            return meters.Value * MetersToMilesRatio;
        }

        public static async Task<DataTable> GetDataSet(string query)
        {
            DataTable dt = new DataTable();
            var Connection = MobiusConfiguration.ConnectionString("log4net");
            SqlConnection sqlConnection = new SqlConnection(Connection);
            try
            {

                SqlCommand cmd = new SqlCommand(query, sqlConnection);
                if (sqlConnection.State == ConnectionState.Closed)
                {
                    sqlConnection.Open();
                }
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                // this will query your database and return the result to your datatable
                da.Fill(dt);

                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
                sqlConnection.Dispose();
            }
            catch (Exception ex)
            {
                Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                sqlConnection.Dispose();
            }
            return dt;
        }

        public static async Task<DataSet> GetDataSetStoreProcedure(string Sp, string table, string whereclause, string columns)
        {
            DataSet ds = new DataSet();
            var Connection = MobiusConfiguration.ConnectionString("log4net");
            SqlConnection sqlConnection = new SqlConnection(Connection);
            try
            {

                DataTable table1 = new DataTable();
                using (var con = new SqlConnection(Connection))
                {
                    using (var cmd = new SqlCommand(Sp, con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            cmd.Parameters.AddWithValue("@TableQuery", table);
                            cmd.Parameters.AddWithValue("@Whare", whereclause);
                            cmd.Parameters.AddWithValue("@Columns", columns);
                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                ExceptionLogging.SendErrorToText(ex);
            }
            finally
            {
                sqlConnection.Dispose();
            }

            return ds;
        }
        public static async Task<DataSet> GetDataSetStoreProcedureWithDynamicParameters(string Sp, Dictionary<string, object> keyValuePairs)
        {
            DataSet ds = new DataSet();
            var Connection = MobiusConfiguration.ConnectionString("log4net");
            SqlConnection sqlConnection = new SqlConnection(Connection);
            try
            {

                DataTable table1 = new DataTable();
                using (var con = new SqlConnection(Connection))
                {
                    using (var cmd = new SqlCommand(Sp, con))
                    {
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            if (keyValuePairs != null)
                            {
                                foreach (var item in keyValuePairs)
                                {
                                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                                }
                            }

                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(ds);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                ExceptionLogging.SendErrorToText(ex);
            }
            finally
            {
                sqlConnection.Dispose();
            }

            return ds;
        }
        public static async Task<DataTable> GetDataSetStoreProcedureParticular(string Sp, Dictionary<string, object> keyValuePairs)
        {
            DataTable dt = new DataTable();
            var Connection = MobiusConfiguration.ConnectionString("log4net");
            SqlConnection sqlConnection = new SqlConnection(Connection);
            try
            {


                using (var con = new SqlConnection(Connection))
                {
                    using (var cmd = new SqlCommand(Sp, con))
                    {
                        cmd.CommandTimeout = int.MaxValue;
                        using (var da = new SqlDataAdapter(cmd))
                        {
                            if (keyValuePairs != null)
                            {
                                foreach (var item in keyValuePairs)
                                {
                                    cmd.Parameters.AddWithValue(item.Key, item.Value);
                                }
                            }

                            cmd.CommandType = CommandType.StoredProcedure;
                            da.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                ExceptionLogging.SendErrorToText(ex);
            }
            finally
            {
                sqlConnection.Dispose();
            }

            return dt;
        }
        public static async Task<string> ConvertDatatableToXML(DataTable dt)
        {
            MemoryStream str = new MemoryStream();
            dt.WriteXml(str, true);
            str.Seek(0, SeekOrigin.Begin);
            StreamReader sr = new StreamReader(str);
            string xmlstr;
            xmlstr = sr.ReadToEnd();
            return (xmlstr);
        }


        public static async Task<string> ConvertDatatableToJSON(DataTable table)
        {

            string jsonString = string.Empty;
            try
            {
                var jsonData =
                    table.AsEnumerable()
                .Select(row =>
                {
                    // Handle potential null values or unsupported data types
                    var dictionary = new Dictionary<string, object>();
                    for (int i = 0; i < table.Columns.Count; i++)
                    {
                        object value = row[i];
                        if (value != null)
                        {
                            dictionary.Add(table.Columns[i].ColumnName, value);
                        }
                        else
                        {
                            // Handle null values (e.g., add a placeholder or ignore)
                        }
                    }
                    return dictionary;
                });


                jsonString = JsonConvert.SerializeObject(jsonData);
            }
            catch
            { }

            return jsonString;
        }
        public static async Task GetExecuteStoreProcedureParticular(string Sp, Dictionary<string, object> keyValuePairs)
        {
            var Connection = MobiusConfiguration.ConnectionString("log4net");
            try
            {


                using (var con = new SqlConnection(Connection))
                {
                    using (var cmd = new SqlCommand(Sp, con))
                    {
                        cmd.CommandTimeout = 9999;

                        foreach (var item in keyValuePairs)
                        {
                            cmd.Parameters.AddWithValue(item.Key, item.Value);
                        }

                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        var list = await cmd.ExecuteNonQueryAsync();
                        con.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
                ExceptionLogging.SendErrorToText(ex);
            }
            finally
            {

            }
        }

        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();

            foreach (PropertyDescriptor prop in properties)
            {
                string columnName = prop.DisplayName ?? prop.Name;
                Type columnType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                table.Columns.Add(columnName, columnType);
            }

            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                {
                    string columnName = prop.DisplayName ?? prop.Name;
                    row[columnName] = prop.GetValue(item) ?? DBNull.Value;
                }
                table.Rows.Add(row);
            }

            return table;
        }

        public static async Task<string> GetConfigurationValue(string Key)
        {
            Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
            keyValuePairsParams.Add("@key", Key);
            DataTable dt = await GetDataSetStoreProcedureParticular("Sp_Get_ConfigurationValue", keyValuePairsParams);
            string value = string.Empty;
            if (dt != null && dt.Rows.Count > 0)
            {
                value = Convert.ToString(dt.Rows[0]["Value"]);
            }
            return value;
        }


        public static async Task<DataTable> ImportExceltoDatatable(string filePath, string sheetName, Stream stream)
        {
            // Open the Excel file using ClosedXML.
            // Keep in mind the Excel file cannot be open when trying to read it
            using (XLWorkbook workBook = new XLWorkbook(stream))
            {
                //Read the first Sheet from Excel file.
                IXLWorksheet workSheet = workBook.Worksheet(1);

                //Create a new DataTable.
                DataTable dt = new DataTable();

                //Loop through the Worksheet rows.
                bool firstRow = true;
                foreach (IXLRow row in workSheet.Rows())
                {
                    //Use the first row to add columns to DataTable.
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells())
                        {
                            dt.Columns.Add(cell.Value.ToString());
                        }
                        firstRow = false;
                    }
                    else
                    {
                        //Add rows to DataTable.
                        dt.Rows.Add();

                        try
                        {
                            int i = 0;
                            foreach (IXLCell cell in row.Cells(row.FirstCellUsed().Address.ColumnNumber, row.LastCellUsed().Address.ColumnNumber))
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                i++;
                            }
                        }
                        catch
                        { }
                    }
                }


                DataTable dtnew = dt.Clone();


                try
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string emptyVar = string.Empty;
                        foreach (DataColumn dc in dt.Columns)
                        {
                            emptyVar += Convert.ToString(dr[dc.ColumnName]).Trim();
                        }

                        if (!string.IsNullOrEmpty(emptyVar))
                        {
                            dtnew.Rows.Add(dr.ItemArray);
                        }

                    }
                }
                catch
                { }

                return dtnew;
            }
        }

        public static bool GetPermissionForEntityReminder(IPrincipal user)
        {
            bool isPermission = false;

            if (user.IsInRole(ECERole.LMD) || user.IsInRole(ECERole.Owner) || user.IsInRole(ECERole.Agent) || user.IsInRole(ECERole.Assistant) || user.IsInRole(ECERole.ESS))
            {
                isPermission = true;
            }
            return isPermission;
        }
        public static bool GetUpdateIdStatus(string updateId)
        {
            bool status = false;
            DataTable dt = null;
            string query = string.Format("select * from helpupdate with(nolock) where collapseId ='{0}'", updateId);
            Task.Run(async () =>
            {
                dt = await GetDataSet(query);
            }).Wait();

            if (dt != null && dt.Rows.Count > 0)
            {
                status = Convert.ToBoolean(dt.Rows[0]["IsArchived"]);
            }
            return status;
        }
        public static int GetAgentIdForLMDAccess(IPrincipal user)
        {
            int userId = 0;
            object cachedResult = null;
            DataTable dt = null;
            Task.Run(async () =>
            {
                dt = await GetDataSet("select * from UserSession with(nolock) where EntityTypeId=1 and LoginUserId=" + user.GetUserId().ToString() + "");
            }).Wait();

            if (dt != null && dt.Rows.Count > 0)
            {
                //EntityId
                //SessionValidDateTime
                //if(Convert.ToDateTime(dt.Rows[0]["SessionValidDateTime"])>DateTime.Now)
                //{

                //}
            }
            else
            {
                userId = user.GetUserId();
            }
            return userId;
        }

        public static void SetAgentIdForLMDAccess(IPrincipal user, int agentId)
        {

        }

        public static void RemoveAgentIdForLMDAccess(IPrincipal user)
        {

        }

        public static bool check_for_session_key(string SessionKey, HttpContextBase httpContext)
        {
            if (httpContext.Session != null)
            {
                foreach (var key in httpContext.Session.Keys)
                {
                    if (key.ToString() == SessionKey) return true;
                }
            }
            return false;
        }

        public static (bool, bool) GetIsSendPandaDoc(int contractId)
        {
            bool isPermission = true;
            bool isAddendum = false;

            var connectionString = MobiusConfiguration.ConnectionString("EceCrmEntities");
            using (var eceCrmEntities = new EceCrmEntities(connectionString))
            {
                // Check for a pending addendum
                var addendumDocument = eceCrmEntities.AddendumDocument
                    .Where(a => a.ContractId == contractId && !a.IsDeleted && a.Status == "Pending")
                    .OrderByDescending(a => a.CreatedDate)
                    .FirstOrDefault();

                if (addendumDocument != null)
                {
                    isPermission = false;
                }

                // Check if any primary addendum exists
                var addendumDocumentAvailable = eceCrmEntities.AddendumDocument
                    .Where(a => a.ContractId == contractId && !a.IsDeleted && a.IsPrimary)
                    .OrderByDescending(a => a.CreatedDate)
                    .FirstOrDefault();

                if (addendumDocumentAvailable != null)
                {
                    isAddendum = true;
                }
            }

            return (isPermission, isAddendum);
        }

        public static bool GetIsPandaDocApplyAndPandaDoc(int contractId)
        {
            bool isPermission = false;
            var connectionString = MobiusConfiguration.ConnectionString("EceCrmEntities");
            EceCrmEntities eceCrmEntities = new EceCrmEntities(connectionString);
            Task.Run(async () =>
            {
                var valuePandaDoc = await GetConfigurationValue("PandaDocEffectiveDate");

                var contract = await eceCrmEntities.Contracts.FirstOrDefaultAsync(a => a.ContractId == contractId);
                if (contract != null)
                {
                    DateTime dateTimePandaDoc = contract.CreatedDate.AddDays(10);
                    try
                    {
                        if (!string.IsNullOrEmpty(valuePandaDoc))
                        {
                            dateTimePandaDoc = Convert.ToDateTime(valuePandaDoc);
                        }
                    }
                    catch { }

                    if (dateTimePandaDoc.Date <= contract.CreatedDate.Date && contract.IsPandaDoc)
                    {
                        isPermission = true;
                    }
                }
            }).Wait();



            return isPermission;
        }


        public static void BulkInsertKeepIdentity<T>(
      SqlConnection conn,
      SqlTransaction tran,
      string tableName,
      params T[] items) where T : class
        {
            if (items == null || items.Length == 0)
                throw new ArgumentNullException(nameof(items));

            using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran))
            {
                bulk.DestinationTableName = tableName;

                // Auto map all public properties
                foreach (var prop in typeof(T).GetProperties())
                {
                    bulk.ColumnMappings.Add(prop.Name, prop.Name);
                }

                using (var reader = new ObjectDataReader<T>(items))
                {
                    bulk.WriteToServer(reader);
                }
            }
        }






        public class ObjectDataReader<T> : IDataReader
        {
            private readonly IEnumerator<T> _data;
            private readonly PropertyInfo[] _properties;
            private bool _closed;

            public ObjectDataReader(IEnumerable<T> data)
            {
                _data = data?.GetEnumerator() ?? throw new ArgumentNullException(nameof(data));
                _properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            }

            // ================= IDataReader =================
            public bool Read() => _data.MoveNext();

            public int FieldCount => _properties.Length;

            public void Close() => _closed = true;

            public bool IsClosed => _closed;

            public int RecordsAffected => -1;

            public DataTable GetSchemaTable() => null;

            public bool NextResult() => false;

            public int Depth => 0;

            public void Dispose()
            {
                Close();
                _data.Dispose();
            }

            // ================= IDataRecord =================
            public object GetValue(int i)
                => _properties[i].GetValue(_data.Current) ?? DBNull.Value;

            public string GetName(int i) => _properties[i].Name;

            public int GetOrdinal(string name)
                => Array.FindIndex(_properties, p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

            public Type GetFieldType(int i) => _properties[i].PropertyType;

            public string GetDataTypeName(int i) => GetFieldType(i).Name;

            public bool IsDBNull(int i) => GetValue(i) == DBNull.Value;

            public int GetValues(object[] values)
            {
                int count = Math.Min(values.Length, FieldCount);
                for (int i = 0; i < count; i++)
                    values[i] = GetValue(i);
                return count;
            }

            // ===== Strongly typed getters =====
            public bool GetBoolean(int i) => (bool)GetValue(i);
            public byte GetByte(int i) => (byte)GetValue(i);

            public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
            {
                var data = (byte[])GetValue(i);
                if (buffer == null) return data.Length;

                Array.Copy(data, fieldOffset, buffer, bufferoffset, length);
                return length;
            }

            public char GetChar(int i) => (char)GetValue(i);

            public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
            {
                var data = GetString(i).ToCharArray();
                if (buffer == null) return data.Length;

                Array.Copy(data, fieldoffset, buffer, bufferoffset, length);
                return length;
            }

            public Guid GetGuid(int i) => (Guid)GetValue(i);
            public short GetInt16(int i) => Convert.ToInt16(GetValue(i));
            public int GetInt32(int i) => Convert.ToInt32(GetValue(i));
            public long GetInt64(int i) => Convert.ToInt64(GetValue(i));
            public float GetFloat(int i) => Convert.ToSingle(GetValue(i));
            public double GetDouble(int i) => Convert.ToDouble(GetValue(i));
            public string GetString(int i) => Convert.ToString(GetValue(i));
            public decimal GetDecimal(int i) => Convert.ToDecimal(GetValue(i));
            public DateTime GetDateTime(int i) => Convert.ToDateTime(GetValue(i));

            public IDataReader GetData(int i) => throw new NotSupportedException();

            // ===== Indexers =====
            public object this[int i] => GetValue(i);
            public object this[string name] => GetValue(GetOrdinal(name));
        }

    }
}
