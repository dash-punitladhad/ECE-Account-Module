﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataTransferObjects;
    using EO.Pdf;
    using EO.Pdf.Acm;
    using System;
    using System.Drawing;

    public class Unofficial1099Generator
    {
        private const string WatermarkText = "UNOFFICIAL";

        private int _year;
        private Ten99EntityDto _entity;
        private Ten99PayerDto _payer;

        public Unofficial1099Generator(int year, Ten99EntityDto entity, Ten99PayerDto payer = null)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            _year = year;
            _entity = entity;
            _payer = payer ?? GetPayer();
        }

        public string DocumentFileName
        {
            get
            {
                var fileName = $"Unofficial 1099 {_year} {(ContractEntityType)_entity.EntityTypeId} {_entity.EntityId}.pdf";

                return fileName.Replace(" ", "_");
            }
        }

        public static Ten99PayerDto GetPayer()
        {
            // TODO: Move these hard-coded details to a config file, or database lookup table.
            var payer = new Ten99PayerDto
            {
                EntityName = "EastCoast Entertainment, Inc.",
                MailingAddress1 = "P.O. Box 73210",
                MailingCity = "Richmond",
                MailingState = "VA",
                MailingZip = "23235",
                PhoneNumber = "(804)-355-2178",
                TaxIdentificationNumber = "54-1024623",
            };

            return payer;
        }

        public byte[] CreateDocument()
        {
            PdfDocument doc = new PdfDocument();

            AcmPageLayout pageLayout = new AcmPageLayout(new AcmPadding(19.25f / 64f, 36.5f / 64f, 19f / 64f, 36f / 64f));

            AcmRender render = new AcmRender(doc, pageLayout);

            render.BeforeRenderPage += new AcmPageEventHandler(UnofficialWatermarkHandler);

            var root = new AcmBlock();

            root.Style.FontName = "Arial";
            root.Style.FontSize = 10;
            root.Style.FontStyle = FontStyle.Regular;
            root.Style.LineHeight = 10f / 64f;

            var topBlock = new AcmBlock();
            topBlock.Style.Top = 0f;
            topBlock.Style.Left = 0f;
            root.Children.Add(topBlock);

            AddFormData(root, topBlock, _entity);

            var bottomBlock = new AcmBlock();
            bottomBlock.Style.Top = 5.625f;
            bottomBlock.Style.Left = 0f;
            root.Children.Add(bottomBlock);

            AddFormData(root, bottomBlock, new Ten99EntityDto { EntityId = 0, CompensationAmount = decimal.Zero });

            render.Render(root);

            byte[] bytes = null;

            using (var ms = new System.IO.MemoryStream())
            {
                doc.Save(ms);

                bytes = ms.ToArray();
            }

            return bytes;
        }

        public void AddFormData(AcmBlock root, AcmBlock parent, Ten99EntityDto entity)
        {
            //// ************************************************************
            //// ********** PAYER BLOCK
            //// ************************************************************
            var payerBlock = new AcmBlock();
            payerBlock.Style.Top = 0f;
            parent.Children.Add(payerBlock);

            payerBlock.Children.Add(new AcmBlock(new AcmText(_payer.EntityName)));
            payerBlock.Children.Add(new AcmBlock(new AcmText(_payer.MailingAddress1)));
            if (!string.IsNullOrWhiteSpace(_payer.MailingAddress2))
            {
                payerBlock.Children.Add(new AcmBlock(new AcmText(_payer.MailingAddress2)));
            }

            payerBlock.Children.Add(new AcmBlock(new AcmText($"{_payer.MailingCity}, {_payer.MailingState} {_payer.MailingZip}")));
            payerBlock.Children.Add(new AcmBlock(new AcmText(" ")));
            payerBlock.Children.Add(new AcmBlock(new AcmText(_payer.PhoneNumber)));

            //// ************************************************************
            //// ********** TAX DATA BLOCK
            //// ************************************************************
            var taxDataBlock = new AcmBlock();
            taxDataBlock.Style.Top = 1f + (27f / 64f);
            taxDataBlock.Style.Height = root.Style.LineHeight;
            parent.Children.Add(taxDataBlock);

            AcmBlock payerIdBlock = new AcmBlock(new AcmText(_payer.TaxIdentificationNumber));
            payerIdBlock.Style.Top = 0f;
            payerIdBlock.Style.Left = 0f;
            taxDataBlock.Children.Add(payerIdBlock);

            AcmBlock recipientIdBlock = new AcmBlock(new AcmText(entity.TaxIdentificationNumber));
            recipientIdBlock.Style.Top = 0f;
            recipientIdBlock.Style.Left = 2.375f;
            taxDataBlock.Children.Add(recipientIdBlock);

            //// ************************************************************
            //// ********** RECIPIENT DATA BLOCK
            //// ************************************************************
            var recipientDataBlock = new AcmBlock();
            recipientDataBlock.Style.Top = 1.9375f;
            parent.Children.Add(recipientDataBlock);

            AcmBlock nameBlock = new AcmBlock(new AcmText(entity.EntityName));
            nameBlock.Style.Top = 0f;
            recipientDataBlock.Children.Add(nameBlock);

            AcmBlock recipientNameBlock = new AcmBlock(new AcmText(entity.RecipientName));
            recipientNameBlock.Style.Top = root.Style.LineHeight;
            recipientDataBlock.Children.Add(recipientNameBlock);

            //// ********** COMPENSATION BLOCK
            AcmBlock compensationBlock = new AcmBlock(new AcmText($"{entity.CompensationAmount:N2}"));
            compensationBlock.Style.Top = root.Style.LineHeight * 2f;
            compensationBlock.Style.Left = 3.5f;
            compensationBlock.Style.Width = 1f;
            compensationBlock.Style.HorizontalAlign = AcmHorizontalAlign.Right;
            recipientDataBlock.Children.Add(compensationBlock);

            //// ********** ADDRESS BLOCK
            AcmBlock mailingAddress1Block = new AcmBlock(new AcmText(entity.MailingAddress1));
            mailingAddress1Block.Style.Top = 0.625f;
            mailingAddress1Block.Style.Left = 0f;
            recipientDataBlock.Children.Add(mailingAddress1Block);

            if (!string.IsNullOrWhiteSpace(entity.MailingAddress2))
            {
                AcmBlock mailingAddress2Block = new AcmBlock(new AcmText(entity.MailingAddress2));
                mailingAddress2Block.Style.Top = mailingAddress1Block.Style.Top + root.Style.LineHeight;
                mailingAddress2Block.Style.Left = 0f;
                recipientDataBlock.Children.Add(mailingAddress2Block);
            }

            var cityState = $"{entity.MailingCity}, {entity.MailingState} {entity.MailingZip}";
            if (cityState.Trim() != ",")
            {
                //// ********** CITY/STATE BLOCK
                AcmBlock recipientCityStateBlock = new AcmBlock(new AcmText(cityState));
                recipientCityStateBlock.Style.Top = 1f + (3f / 64f);
                recipientCityStateBlock.Style.Left = 0f;
                recipientDataBlock.Children.Add(recipientCityStateBlock);
            }

            //// ********** ACCOUNT NUMBER BLOCK
            AcmBlock accountNumberBlock = new AcmBlock(new AcmText($"{entity.EntityId}"));
            accountNumberBlock.Style.Top = 1.5f;
            accountNumberBlock.Style.Left = 0.25f;
            recipientDataBlock.Children.Add(accountNumberBlock);
        }

        private void UnofficialWatermarkHandler(object sender, AcmPageEventArgs e)
        {
            var textLayer = new EO.Pdf.Contents.PdfTextLayer();

            textLayer.Font = new EO.Pdf.Drawing.PdfFont("Arial", 75);
            textLayer.NonStrokingColor = Color.LightGray;
            textLayer.GfxMatrix.Rotate(45);

            var textContent = new EO.Pdf.Contents.PdfTextContent(WatermarkText);
            textContent.PositionMode = EO.Pdf.Contents.PdfTextPositionMode.Offset;
            textContent.Offset = new EO.Pdf.Drawing.PdfPoint(300, 50);

            textLayer.Contents.Add(textContent);

            e.Page.Contents.Add(textLayer);
        }
    }
}
