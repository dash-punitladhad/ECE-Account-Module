﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataTransferObjects;
    using System.Linq;
    using System.Net.Mail;

    public class TemplateMailMessage : MailMessage
    {
        public TemplateMailMessage(int emailTemplateId)
            : base()
        {
            this.EmailTemplateId = emailTemplateId;
        }

        public TemplateMailMessage(EmailTemplate emailTemplate)
            : this((int)emailTemplate)
        {
        }

        public int EmailTemplateId { get; set; }

        public int? EmailQueueId { get; set; }

        public bool HasRecipient
        {
            get { return this.To.Any(); }
        }

        public void SetFrom(string emailAddress)
        {
            this.SetFrom(emailAddress, null);
        }

        public void SetFrom(string emailAddress, string displayName)
        {
            if (string.IsNullOrWhiteSpace(emailAddress))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(displayName))
            {
                this.From = new MailAddress(emailAddress);
            }
            else
            {
                // Encode quotation marks as single quotes to avoid format
                // violations when constructing messages
                this.From = new MailAddress(emailAddress, displayName.Replace("\"", "'"));
            }
        }

        public void AddRecipient(string emailAddress, string displayName)
        {
            if (string.IsNullOrWhiteSpace(emailAddress))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(displayName))
            {
                this.To.Add(new MailAddress(emailAddress));
            }
            else
            {
                // Encode quotation marks as single quotes to avoid format
                // violations when constructing messages
                this.To.Add(new MailAddress(emailAddress, displayName.Replace("\"", "'")));
            }
        }

        public void AddRecipient(string emailAddress)
        {
            this.AddRecipient(emailAddress, null);
        }

        public void AddRecipient(ContactDto contact)
        {
            if (contact == null)
            {
                return;
            }

            this.AddRecipient(contact.EmailAddress, contact.FullName);
        }
    }
}
