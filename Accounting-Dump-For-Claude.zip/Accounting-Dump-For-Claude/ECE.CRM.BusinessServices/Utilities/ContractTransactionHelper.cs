namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public static class ContractTransactionHelper
    {
        public static void SynchronizePaidDate(ContractTransactionDto dto, DateTime? paidDate = null)
        {
            if (dto == null) return;

            var required = dto.RequiredAmount.GetValueOrDefault();
            var paid = dto.PaidAmount.GetValueOrDefault();

            if (required == paid)
            {
                if (dto.PaidDate == null)
                {
                    dto.PaidDate = paidDate ?? DateTime.Today;
                }
            }
            else if (required > paid)
            {
                dto.PaidDate = null;
            }
        }
    }
}
