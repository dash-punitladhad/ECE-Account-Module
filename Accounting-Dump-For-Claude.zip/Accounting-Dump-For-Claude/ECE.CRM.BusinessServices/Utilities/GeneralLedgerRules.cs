﻿namespace ECE.CRM.BusinessServices.Utilities
{
    public static class GeneralLedgerRules
    {
        public static readonly char IncreaseChangeDirection = 'I';

        public static readonly char DecreaseChangeDirection = 'D';

        public static char GetChangeDirection(int accountId, char changeType)
        {
            var debitDirectionIncreasing = accountId / 1000 == 1;

            var creditDirectionIncreasing = !debitDirectionIncreasing;

            var directionIncreasing = changeType == GeneralLedgerService.DebitChangeType
                ? debitDirectionIncreasing
                : creditDirectionIncreasing;

            return directionIncreasing
                ? IncreaseChangeDirection
                : DecreaseChangeDirection;
        }
    }
}
