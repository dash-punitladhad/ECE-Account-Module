﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using EO.Pdf;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class ArtistSummaryFileGenerator
    {
        public ArtistSummaryFileGenerator(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public string GenerateSummaryFileContents(ExpenseBatchDto batch, IList<ContractTransactionDto> batchTransactions)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("<pre>");
            sb.Append("<div style='text-align: center'>");
            sb.Append($"<p><b>ARTIST STATEMENT SUMMARY {batch.DatePosted:MM/dd/yyyy}</b></p>");
            sb.Append("</div>");

            this.GenerateSummaryTable(sb, batch);

            sb.Append("<div>");
            sb.Append("<hr />");
            sb.Append("</div>");

            this.GenerateDetailsTable(sb, batch, batchTransactions);

            sb.Append("</pre>");

            return sb.ToString();
        }

        public void GenerateSummaryTable(StringBuilder sb, ExpenseBatchDto batch)
        {
            sb.Append("<table width='100%'>");
            sb.Append("<caption style='text-align: left; font-weight: bold'>ARTIST STATEMENT PAYMENTS</caption>");
            sb.Append("<thead>");
            sb.Append("<tr>");
            sb.Append("<th align='left'>Artist #</th>");
            sb.Append("<th align='left'>Artist</th>");
            sb.Append("<th align='left'>Reference #</th>");
            sb.Append("<th align='right'>Amount</th>");
            sb.Append("</tr>");
            sb.Append("</thead>");

            sb.Append("<tbody>");

            foreach (var payment in batch.ExpensePayments.OrderBy(x => x.ReferenceNumber))
            {
                sb.Append("<tr>");
                sb.Append($"<td>{payment.ContractEntityId}</td>");
                sb.Append($"<td>{payment.Artist?.Name}</td>");
                sb.Append($"<td>{payment.ReferenceNumber}</td>");
                sb.Append($"<td align='right'>{payment.PaymentAmount:C}</td>");
                sb.Append("</tr>");
            }

            sb.Append("</tbody>");

            sb.Append("</table>");
        }

        public void AddSeparatorLine(StringBuilder sb)
        {
            sb.Append($"   ");
            sb.Append($"{"------".PadRight(7, ' ')}");
            sb.Append($"{"-------------------".PadRight(20, ' ')}");
            sb.Append($"{"-----------------------------".PadRight(30, ' ')}");
            sb.Append($"{"--------------".PadLeft(15, ' ')}");
            sb.Append($"{"---------".PadLeft(10, ' ')}");
            sb.AppendLine(string.Empty);
        }

        public void GenerateDetailsTable(StringBuilder sb, ExpenseBatchDto batch, IList<ContractTransactionDto> batchTransactions)
        {
            sb.AppendLine("<span style='text-align: left; font-weight: bold'>ARTIST PAYMENT DETAILS</span>");

            foreach (var payment in batch.ExpensePayments.OrderBy(x => x.Artist?.Name))
            {
                sb.Append($"{payment.ContractEntityId}".PadLeft(6, ' '));
                sb.AppendLine($" - {payment.Artist?.Name}");

                AddSeparatorLine(sb);

                var transactions = batchTransactions
                    .Where(x => x.ExpensePaymentId == payment.ExpensePaymentId)
                    .OrderBy(x => x.ContractId)
                    .ThenBy(x => x.DueDate)
                    .ThenBy(x => x.ContractTransactionTypeId)
                    .ThenBy(x => x.ContractTransactionId)
                    .ToList();

                foreach (var transaction in transactions)
                {
                    sb.Append($"   ");

                    var contractId = transaction.ContractId == 0
                        ? (int?)null
                        : transaction.ContractId;

                    sb.Append($"{contractId}".PadRight(7, ' '));
                    sb.Append($"{transaction.Office?.Name}".PadRight(20, ' '));
                    sb.Append(transaction.ContractTransactionTypeName.PadRight(30, ' '));
                    sb.AppendLine(transaction.RequiredAmount.Value.ToString("C").PadLeft(15, ' '));
                }

                AddSeparatorLine(sb);

                sb.Append(payment.PaymentAmount.ToString("C").PadLeft(75, ' '));
                sb.Append($"{payment.ReferenceNumber}".PadLeft(10, ' '));
                sb.AppendLine(string.Empty);
            }
        }

        public DocumentDto GenerateSummaryFile(ExpenseBatchDto batch, IList<ContractTransactionDto> batchTransactions)
        {
            var batchType = (ExpenseBatchType)batch.ExpenseBatchTypeId;

            string fileName = AccountingFileGenerators.GenerateFileName(batchType, "SUMMARY");

            var ms = new MemoryStream();

            var html = this.GenerateSummaryFileContents(batch, batchTransactions);

            PdfDocument doc = new PdfDocument();

            var options = new EO.Pdf.HtmlToPdfOptions
            {
                HeaderHtmlFormat = $"<pre>{DateTime.Now:MM/dd/yyyy HH:mm:ss} Page: {{page_number}}</pre>",
                RepeatTableHeaderAndFooter = true,
                UsePrintMedia = true,
                OutputArea = new RectangleF(0.5f, 0.5f, 7.5f, 10f),
            };

            EO.Pdf.HtmlToPdf.ConvertHtml(html, doc, options);

            doc.Save(ms);

            ms.Position = 0;

            var documentDto = new DocumentDto()
            {
                OriginalFileName = fileName,
                Description = "Artist Summary File",
                DocumentExtensionId = (int)DocumentExtension.PDF,
                DocumentExtension = new LookupDto() { Text = "pdf" },
                DocumentTypeId = (int)DocumentType.PDF,
                IsDeleted = false,
                Contents = ms
            };

            return documentDto;
        }
    }
}
