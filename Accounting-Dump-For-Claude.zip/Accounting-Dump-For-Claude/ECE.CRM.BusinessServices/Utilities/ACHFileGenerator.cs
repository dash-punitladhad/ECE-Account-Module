﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ACHFileGenerator
    {
        public ACHFileGenerator(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public static DateTime AddBusinessDays(DateTime date, int days)
        {
            if (days < 0)
            {
                throw new ArgumentException("days cannot be negative", "days");
            }

            if (days == 0)
            {
                return date;
            }

            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                date = date.AddDays(2);
                days -= 1;
            }
            else if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(1);
                days -= 1;
            }

            date = date.AddDays(days / 5 * 7);
            int extraDays = days % 5;

            if ((int)date.DayOfWeek + extraDays > 5)
            {
                extraDays += 2;
            }

            return date.AddDays(extraDays);
        }

        public async Task<int> GetNextSequenceByEntityAsync(string entity)
        {
            var nextNumber = -1;

            try
            {
                nextNumber = await this.Context.EntitySequences.GetNextSequenceByEntityAsync(entity);
            }
            catch (Exception ex)
            {
                throw new UnhandledBusinessException(ex);
            }

            return nextNumber;
        }

        public async Task<DocumentDto> GenerateACHFileAsync(ExpenseBatchType batchType, List<ExpensePaymentDto> payments)
        {
            string fileName = AccountingFileGenerators.GenerateFileName(batchType, "ACH");

            var ms = new MemoryStream();

            var sw = new StreamWriter(ms);

            StringBuilder sb = new StringBuilder();

            var batchSeqNumber = await GetNextSequenceByEntityAsync(ECEBusinessConstants.EntitySequenceConstants.ACHBatchNumber);

            sb.AppendLine(BuildACHFileHeader());

            sb.AppendLine(BuildACHBatchHeader(batchSeqNumber));

            sb.Append(await BuildACHRecordsAsync(payments));

            sb.AppendLine(BuildBatchControl(batchSeqNumber, payments));

            sb.AppendLine(BuildFileControl(payments));

            sw.Write(sb.ToString());

            sw.Flush();
            ms.Position = 0;

            var documentDto = new DocumentDto()
            {
                OriginalFileName = fileName,
                Description = "ACH File",
                DocumentExtensionId = (int)DocumentExtension.TXT,
                DocumentExtension = new LookupDto() { Text = "txt" },
                DocumentTypeId = (int)DocumentType.ACH,
                IsDeleted = false,
                Contents = ms
            };

            return documentDto;
        }

        public string BuildACHFileHeader()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("1");                                                                                 // Field 1, fixed
            sb.Append("01");                                                                                // Field 2, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHRoutingNumber.PadLeft(10, ' '));                 // Field 3, routing number for bank
            sb.Append(ECEBusinessConstants.ACHConstants.ACHTaxId.PadLeft(10, ' '));                         // Field 4, IRS Tax Id
            sb.Append(DateTime.Now.ToString("yyMMdd"));                                                     // Field 5, file create date
            sb.Append(DateTime.Now.ToString("HHmm"));                                                       // Field 6, file create time
            sb.Append("A");                                                                                 // Field 7, file ID modifier.  "A" SINCE ONLY SENDING ONE PER DAY!
            sb.Append("094");                                                                               // Field 8, fixed
            sb.Append("10");                                                                                // Field 9, fixed
            sb.Append("1");                                                                                 // Field 10, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankName.PadRight(23, ' '));                     // Field 11
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyName.Substring(0, 23).PadRight(23, ' ')); // Field 12
            sb.Append(string.Empty.PadRight(8, ' '));                                                       // Field 13, reference code (optional)

            return sb.ToString();
        }

        public string BuildACHBatchHeader(int batchSeqNumber)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("5");                                                                                 // Field 1, fixed
            sb.Append("220");                                                                               // Field 2, Service Class Code = 220
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyName.Substring(0, 16).PadRight(16, ' ')); // Field 3, Company Name
            sb.Append(string.Empty.PadRight(20, ' '));                                                      // Field 4, Company Discretionary Data
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyId.PadLeft(10, ' '));                     // Field 5, Company Id
            sb.Append("CCD");                                                                               // Field 6, entry class code (PPD,CCD,WEB)
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyEntryDesc.PadRight(10, ' '));             // Field 7, Company Entry Desc
            sb.Append(string.Empty.PadRight(6, ' '));                                                       // Field 8, Company descriptive date
            sb.Append(AddBusinessDays(DateTime.Now, 2).ToString("yyMMdd"));                                 // Field 9, Effective Entry date. 2 business days from now.
            sb.Append(string.Empty.PadRight(3, ' '));                                                       // Field 10, Settlement Date (3 blanks)
            sb.Append("1");                                                                                 // Field 11, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId.PadLeft(8, ' '));                         // Field 12, originating DFI id
            sb.Append(batchSeqNumber.ToString().PadLeft(7, '0'));                                           // Field 13, batch Number

            return sb.ToString().ToUpper();
        }

        public async Task<string> BuildACHRecordsAsync(List<ExpensePaymentDto> payments)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var payment in payments)
            {
                var amount = payment.PaymentAmount.ToString("0.00").Replace(".", string.Empty);

                var traceNumber = await GetNextSequenceByEntityAsync(ECEBusinessConstants.EntitySequenceConstants.ACHItemNumber);

                sb.Append("6");                                                                         // Field 1, Record Type Code
                sb.Append("22");                                                                        // Field 2 - Transaction Code
                sb.Append(payment.Artist.RoutingNumber.Substring(0, 8));                                // Field 3, Receiving DFI ID. (routing number)
                sb.Append(payment.Artist.RoutingNumber.Substring(8, 1));                                // Field 4, Check Digit
                sb.Append(payment.Artist.AccountNumber.PadRight(17, ' '));                              // Field 5, DFI Account Number
                sb.Append(amount.PadLeft(10, '0'));                                                     // Field 6, Amount
                sb.Append(payment.Artist.Name.ToString().PadRight(15, ' ').Substring(0, 15));           // Field 7, Identification Number
                sb.Append(payment.PayeeName.PadRight(22, ' ').Substring(0, 22));                        // Field 8, Receiving Company Name
                sb.Append(string.Empty.PadRight(2, ' '));                                               // Field 9, Discretionary Data
                sb.Append("0");                                                                         // Field 10, Addenda Record Indicator... no addenda!
                sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId);                                 // Field 11, Trace Number 15 chars, first 8 ODFI
                sb.AppendLine(traceNumber.ToString().PadLeft(7, '0').Substring(0, 7));                  // Field 12, Trace Number last 7 chars must be ascending, not necessarily sequential
            }

            return sb.ToString().ToUpper();
        }

        public string BuildBatchControl(int batchSeqNumber, List<ExpensePaymentDto> payments)
        {
            var routingSum = payments.Select(x => int.Parse(x.Artist.RoutingNumber.ToString().Substring(0, 8))).Sum();

            var entryHash = routingSum.ToString();

            if (entryHash.Length > 10)
            {
                entryHash.Substring(0, 10);
            }

            var totalCredit = payments.Sum(x => x.PaymentAmount).ToString("0.00").Replace(".", string.Empty);

            StringBuilder sb = new StringBuilder();

            sb.Append("8");                                                                 // Field 1, fixed record type code
            sb.Append("200");                                                               // Field 2, Service Class Code = 200
            sb.Append(payments.Count.ToString().PadLeft(6, '0'));                           // Field 3, Entry/Addenda count
            sb.Append(entryHash.PadLeft(10, '0'));                                          // Field 4, Entry Hash
            sb.Append(string.Empty.PadLeft(12, '0'));                                       // Field 5, total debit dollar amount
            sb.Append(totalCredit.PadLeft(12, '0'));                                        // Field 6, total credit dollar amount
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyId.PadRight(10, ' '));    // Field 7, company id
            sb.Append(string.Empty.PadRight(19, ' '));                                      // Field 8, message auth code, optional
            sb.Append(string.Empty.PadRight(6, ' '));                                       // Field 9, reserved (blank)
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId.PadRight(8, ' '));        // Field 10, originating dfi id
            sb.Append(batchSeqNumber.ToString().PadLeft(7, '0'));                           // Field 11, batch Number

            return sb.ToString().ToUpper();
        }

        public string BuildFileControl(List<ExpensePaymentDto> payments)
        {
            StringBuilder sb = new StringBuilder();

            int lineCount = payments.Count + 4;

            int blockCount = (int)(Math.Ceiling((decimal)lineCount / 10) * 10) / 10;

            var routingSum = payments.Select(x => int.Parse(x.Artist.RoutingNumber.ToString().Substring(0, 8))).Sum();

            var entryHash = routingSum.ToString();

            if (entryHash.Length > 10)
            {
                entryHash.Substring(0, 10);
            }

            var totalCredit = payments.Sum(x => x.PaymentAmount).ToString("0.00").Replace(".", string.Empty);

            sb.Append("9");                                                  // Field 1, fixed record type code
            sb.Append("1".PadLeft(6, '0'));                                  // Field 2, Batch Count
            sb.Append(blockCount.ToString().PadLeft(6, '0'));                // Field 3, Block Count
            sb.Append(payments.Count.ToString().PadLeft(8, '0'));            // Field 4, Entry /Addenda Count
            sb.Append(entryHash.PadLeft(10, '0'));                           // Field 5, entry hash
            sb.Append(string.Empty.PadLeft(12, '0'));                        // Field 6, total debit dollar amount
            sb.Append(totalCredit.PadLeft(12, '0'));                         // Field 7, total credit dollar amount
            sb.Append(string.Empty.PadRight(39, ' '));                       // Field 8, reserved (blank)

            return sb.ToString().ToUpper();
        }
    }
}
