﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.Cryptography;
    using System;
    using System.Security.Cryptography;

    /// <summary>
    /// Security Helper.
    /// </summary>
    public static class SecurityHelper
    {
        /// <summary>
        /// The system account identifier
        /// </summary>
        public const int SystemAccountId = 999999;

        /// <summary>
        /// The system email account identifier
        /// </summary>
        public const int SystemEmailAccountId = 999997;

        /// <summary>
        /// Default Min Password Length
        /// </summary>
        private static int defaultMinPasswordLength = 8;

        /// <summary>
        /// Default Max Password Length
        /// </summary>
        private static int defaultMaxPasswordLength = 10;

        // Define supported password characters divided into groups.
        // You can add (or remove) characters to (from) these groups.

        /// <summary>
        /// List of lowercase characters for generating random strings
        /// </summary>
        private static string passwordCharsLowerCase = "abcdefgijkmnopqrstwxyz";

        /// <summary>
        /// List of uppercase characters for generating random strings
        /// </summary>
        private static string passwordCharsUpperCase = "ABCDEFGHJKLMNPQRSTWXYZ";

        /// <summary>
        /// List of numeric characters for generating random strings
        /// </summary>
        private static string passwordCharsNumeric = "23456789";

        /// <summary>
        /// List of special characters for generating random strings
        /// </summary>
        private static string passwordCharsSpecial = "*$?_&%"; // "*$-+?_&=!%{}/";

        /// <summary>
        /// Generates a random password.
        /// </summary>
        /// <param name="useSpecial">if set to <c>true</c> [use special].</param>
        /// <returns>Randomly generated password.</returns>
        /// <remarks>
        /// The length of the generated password will be determined at
        /// random. It will be no shorter than the minimum default and
        /// no longer than maximum default.
        /// </remarks>
        public static string GenerateRandomPassword(bool useSpecial)
        {
            return GenerateRandomPassword(defaultMinPasswordLength, defaultMaxPasswordLength, useSpecial);
        }

        /// <summary>
        /// Generates a random password of the exact length.
        /// </summary>
        /// <param name="length">Exact password length.</param>
        /// <param name="useSpecial">if set to <c>true</c> [use special].</param>
        /// <returns>Randomly generated password.</returns>
        public static string GenerateRandomPassword(int length, bool useSpecial)
        {
            return GenerateRandomPassword(length, length, useSpecial);
        }

        /// <summary>
        /// Generates a random password.
        /// </summary>
        /// <param name="minLength">Minimum password length.</param>
        /// <param name="maxLength">Maximum password length.</param>
        /// <param name="useSpecial">if set to <c>true</c> [use special].</param>
        /// <returns>Randomly generated password.</returns>
        /// <remarks>
        /// The length of the generated password will be determined at
        /// random and it will fall with the range determined by the
        /// function parameters.
        /// </remarks>
        public static string GenerateRandomPassword(int minLength, int maxLength, bool useSpecial)
        {
            // Make sure that input parameters are valid.
            if (minLength <= 0 ||
                    maxLength <= 0 ||
                    minLength > maxLength)
            {
                return null;
            }

            char[][] charGroups;

            // Create a local array containing supported password characters
            // grouped by types. You can remove character groups from this
            // array, but doing so will weaken the password strength.
            if (useSpecial)
            {
                charGroups = new char[][]
                {
                    passwordCharsLowerCase.ToCharArray(),
                    passwordCharsUpperCase.ToCharArray(),
                    passwordCharsNumeric.ToCharArray(),
                    passwordCharsSpecial.ToCharArray()
                };
            }
            else
            {
                charGroups = new char[][]
                {
                    passwordCharsLowerCase.ToCharArray(),
                    passwordCharsUpperCase.ToCharArray(),
                    passwordCharsNumeric.ToCharArray()
                };
            }

            // Use this array to track the number of unused characters in each
            // character group.
            int[] charsLeftInGroup = new int[charGroups.Length];

            // Initially, all characters in each group are not used.
            for (int i = 0; i < charsLeftInGroup.Length; i++)
            {
                charsLeftInGroup[i] = charGroups[i].Length;
            }

            // Use this array to track (iterate through) unused character groups.
            int[] leftGroupsOrder = new int[charGroups.Length];

            // Initially, all character groups are not used.
            for (int i = 0; i < leftGroupsOrder.Length; i++)
            {
                leftGroupsOrder[i] = i;
            }

            // Because we cannot use the default randomizer, which is based on the
            // current time (it will produce the same "random" number within a
            // second), we will use a random number generator to seed the
            // randomizer.

            // Use a 4-byte array to fill it with random bytes and convert it then
            // to an integer value.
            byte[] randomBytes = new byte[4];

            // Generate 4 random bytes.
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(randomBytes);

            // Convert 4 bytes into a 32-bit integer value.
            int seed = (randomBytes[0] & 0x7f) << 24 |
                        randomBytes[1] << 16 |
                        randomBytes[2] << 8 |
                        randomBytes[3];

            Random random = new Random(seed);

            char[] password = null;

            if (minLength < maxLength)
            {
                password = new char[random.Next(minLength, maxLength + 1)];
            }
            else
            {
                password = new char[minLength];
            }

            // Index of the next character to be added to password.
            int nextCharIndex;

            // Index of the next character group to be processed.
            int nextGroupIndex;

            // Index which will be used to track not processed character groups.
            int nextLeftGroupsOrderIndex;

            // Index of the last non-processed character in a group.
            int lastCharIndex;

            // Index of the last non-processed group.
            int lastLeftGroupsOrderIndex = leftGroupsOrder.Length - 1;

            // Generate password characters one at a time.
            for (int i = 0; i < password.Length; i++)
            {
                // If only one character group remained unprocessed, process it;
                // otherwise, pick a random character group from the unprocessed
                // group list. To allow a special character to appear in the
                // first position, increment the second parameter of the Next
                // function call by one, i.e. lastLeftGroupsOrderIdx + 1.
                if (lastLeftGroupsOrderIndex == 0)
                {
                    nextLeftGroupsOrderIndex = 0;
                }
                else
                {
                    nextLeftGroupsOrderIndex = random.Next(0, lastLeftGroupsOrderIndex);
                }

                // Get the actual index of the character group, from which we will
                // pick the next character.
                nextGroupIndex = leftGroupsOrder[nextLeftGroupsOrderIndex];

                // Get the index of the last unprocessed characters in this group.
                lastCharIndex = charsLeftInGroup[nextGroupIndex] - 1;

                // If only one unprocessed character is left, pick it; otherwise,
                // get a random character from the unused character list.
                if (lastCharIndex == 0)
                {
                    nextCharIndex = 0;
                }
                else
                {
                    nextCharIndex = random.Next(0, lastCharIndex + 1);
                }

                // Add this character to the password.
                password[i] = charGroups[nextGroupIndex][nextCharIndex];

                // If we processed the last character in this group, start over.
                if (lastCharIndex == 0)
                {
                    charsLeftInGroup[nextGroupIndex] = charGroups[nextGroupIndex].Length;
                }
                else
                {
                    // There are more unprocessed characters left.
                    // Swap processed character with the last unprocessed character
                    // so that we don't pick it until we process all characters in
                    // this group.
                    if (lastCharIndex != nextCharIndex)
                    {
                        char temp = charGroups[nextGroupIndex][lastCharIndex];

                        charGroups[nextGroupIndex][lastCharIndex] = charGroups[nextGroupIndex][nextCharIndex];
                        charGroups[nextGroupIndex][nextCharIndex] = temp;
                    }

                    // Decrement the number of unprocessed characters in this group.
                    charsLeftInGroup[nextGroupIndex]--;
                }

                // If we processed the last group, start all over.
                if (lastLeftGroupsOrderIndex == 0)
                {
                    lastLeftGroupsOrderIndex = leftGroupsOrder.Length - 1;
                }
                else
                {
                    // There are more unprocessed groups left.
                    // Swap processed group with the last unprocessed group
                    // so that we don't pick it until we process all groups.
                    if (lastLeftGroupsOrderIndex != nextLeftGroupsOrderIndex)
                    {
                        int temp = leftGroupsOrder[lastLeftGroupsOrderIndex];

                        leftGroupsOrder[lastLeftGroupsOrderIndex] = leftGroupsOrder[nextLeftGroupsOrderIndex];
                        leftGroupsOrder[nextLeftGroupsOrderIndex] = temp;
                    }

                    // Decrement the number of unprocessed groups.
                    lastLeftGroupsOrderIndex--;
                }
            }

            // Convert password characters into a string and return the result.
            return new string(password);
        }

        /// <summary>
        /// Generates a new salt value.
        /// </summary>
        /// <returns>
        /// A new salt value.
        /// </returns>
        public static string GenerateSalt()
        {
            return Hash.GenerateSalt();
        }

        /// <summary>
        /// Encrypts the password.
        /// </summary>
        /// <param name="password">The password.</param>
        /// <param name="salt">The salt.</param>
        /// <returns>
        /// An encrypted password based on a salt value.
        /// </returns>
        public static string EncryptPassword(string password, string salt)
        {
            HashAlgorithmType algorithm = MobiusConfiguration.Current.AppSettings.GetEnum<HashAlgorithmType>("Crypto.OneWayAlgorithm", HashAlgorithmType.SHA256);

            // Encrypt the password with the given salt
            using (var hash = new Hash(algorithm))
            {
                return hash.ComputeHash(password, salt);
            }
        }

        /// <summary>
        /// Encrypts the value without salt.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>A hashed value.</returns>
        public static string EncryptValueWithoutSalt(string value)
        {
            HashAlgorithmType algorithm = MobiusConfiguration.Current.AppSettings.GetEnum<HashAlgorithmType>("Crypto.OneWayAlgorithm", HashAlgorithmType.SHA256);

            // Encrypt the password with the given salt
            using (var hash = new Hash(algorithm))
            {
                return hash.ComputeHash(value);
            }
        }

        /// <summary>
        /// Generates a password token.
        /// </summary>
        /// <returns>A randomly generated password token.</returns>
        public static string GeneratePasswordToken()
        {
            // N - generate without dashes
            return Guid.NewGuid().ToString("N");
        }

        /// <summary>
        /// Generates a secret key.
        /// </summary>
        /// <returns>A secret key.</returns>
        public static byte[] GenerateSecretKey()
        {
            var algorithm = MobiusConfiguration.GetEnum<SymmetricAlgorithmType>("Crypto.TwoWayAlgorithm");

            using (var a = Symmetric.CreateSymmetricAlgorithm(algorithm))
            {
                a.GenerateKey();

                return a.Key;
            }
        }

        /// <summary>
        /// Hides the tax identification number.
        /// </summary>
        /// <param name="taxIdentificationNumber">The tax identification number.</param>
        /// <returns>The tax number, with all but the last 4 digits replaced with '*' characters.</returns>
        public static string HideTaxIdentificationNumber(string taxIdentificationNumber)
        {
            if (string.IsNullOrWhiteSpace(taxIdentificationNumber))
            {
                return null;
            }

            var hiddenTIN = System.Text.RegularExpressions.Regex.Replace(taxIdentificationNumber, "[0-9]", "*");

            if (hiddenTIN.Length == 0)
            {
                return null;
            }

            return hiddenTIN;
        }

        public static void EncryptFederalTINCriteria(IFederalTINCriteriaDto criteria)
        {
            if (criteria == null)
            {
                return;
            }

            var federalTIN = TextHelper.OnlyNumericValue(criteria.FederalTIN);

            if (!string.IsNullOrEmpty(federalTIN))
            {
                criteria.FederalTIN = SecurityHelper.EncryptValueWithoutSalt(federalTIN);
            }
        }

        public static void EncryptFederalTIN(IFederalTINDto dto)
        {
            if (dto == null)
            {
                return;
            }

            // Generate the secret key, if necessary.
            if (dto.SecretKey == null)
            {
                dto.SecretKey = SecurityHelper.GenerateSecretKey();
            }

            // Encrypt the TIN
            var federalTIN = TextHelper.OnlyNumericValue(dto.TaxIdentificationNumber);

            if (!string.IsNullOrEmpty(federalTIN))
            {
                dto.TINHashed = SecurityHelper.EncryptValueWithoutSalt(federalTIN);
            }
        }

        public static bool TINHasChanged(IFederalTINDto original, IFederalTINDto modified)
        {
            if (original == null || modified == null)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(original.TINHashed))
            {
                return false;
            }

            return original.TINHashed != modified.TINHashed;
        }
    }
}
