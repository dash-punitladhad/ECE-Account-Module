﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using DataTransferObjects;
    using ECE.CRM.DataAccess;
    using System;

    public static class TimeZoneInfoHelper
    {
        public static TimeSpan EncodeTime(this TimeZoneInfo timeZoneInfo, string date, string time)
        {
            var parsedTime = DateTime.Parse($"{date} {time}");

            DateTime.SpecifyKind(parsedTime, DateTimeKind.Local);

            var timeSpan = TimeZoneInfo.ConvertTimeToUtc(parsedTime, timeZoneInfo).TimeOfDay;

            return timeSpan;
        }

        public static DateTime? DecodeTime(this TimeZoneInfo timeZoneInfo, DateTime? date, TimeSpan? time)
        {
            if (date == null || time == null)
            {
                return null;
            }

            var year = date.Value.Year;
            var month = date.Value.Month;
            var day = date.Value.Day;

            // Noon should always be beyond the switch time (usual 2:00 AM)
            var testDate = date.Value.AddHours(12);

            if (timeZoneInfo.IsDaylightSavingTime(testDate))
            {
                // Use July 1st, since it should always be in daylight saving time.
                month = 7;
                day = 1;
            }
            else
            {
                // Use January 1st, since it should always be in standard time.
                month = 1;
                day = 1;
            }

            var decodedDate = new DateTime(
                year,
                month,
                day,
                time.Value.Hours,
                time.Value.Minutes,
                time.Value.Seconds,
                DateTimeKind.Unspecified);

            var correctTime = TimeZoneInfo.ConvertTimeFromUtc(decodedDate, timeZoneInfo);

            decodedDate = new DateTime(
                date.Value.Year,
                date.Value.Month,
                date.Value.Day,
                correctTime.Hour,
                correctTime.Minute,
                correctTime.Second,
                DateTimeKind.Unspecified);

            return decodedDate;
        }

        public static void EncodeEventTimes(this TimeZoneInfo timeZoneInfo, ArtistEventTimeDto aed, int contractId)
        {
            string sql = string.Format(" select top 1 * from Contract with(nolock) where Contractid={0} ", contractId.ToString());

            var dt = DaoHelper.GetDataSet(sql).GetAwaiter().GetResult();

            var value = DaoHelper.GetConfigurationValue("BypassDaylightLogic").GetAwaiter().GetResult();

            DateTime contractDate = DateTime.Now.AddYears(-10);
            if (dt != null && dt.Rows.Count > 0)
            {
                contractDate = Convert.ToDateTime(dt.Rows[0]["CreatedDate"]);
            }
            DateTime dateTime = contractDate.AddDays(10);
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    dateTime = Convert.ToDateTime(value);
                }
            }
            catch { }

            //If Part:Timezoneinfo decodetime convert is not set and does include direct database values.
            //Else Part:Timezoneinfo decodetime convert is set.
            if (contractDate.Date >= dateTime.Date)
            {
                aed.EndcodedStartTime = DateTime.Parse($"{aed.EventDate} {aed.StartTime}").TimeOfDay;
                aed.EncodedEndTime = DateTime.Parse($"{aed.EventDate} {aed.EndTime}").TimeOfDay;
            }
            else
            {

                var eventStartTimeComponent = DateTime.Parse($"{aed.EventDate} {aed.StartTime}");
                DateTime.SpecifyKind(eventStartTimeComponent, DateTimeKind.Local);

                aed.EndcodedStartTime = TimeZoneInfo.ConvertTimeToUtc(eventStartTimeComponent, timeZoneInfo).TimeOfDay;

                var parseEndDate = DateTime.Parse($"{aed.EventDate}");
                DateTime.SpecifyKind(parseEndDate, DateTimeKind.Unspecified);

                var parseEndTime = DateTime.Parse($"{aed.EndTime}").TimeOfDay;

                var eventEndTimeComponent = parseEndDate.Add(parseEndTime);

                var delta = eventEndTimeComponent.Subtract(eventStartTimeComponent);
                if (delta.Ticks < 0)
                {
                    eventEndTimeComponent = eventEndTimeComponent.AddDays(1);
                }

                if (timeZoneInfo.IsInvalidTime(eventEndTimeComponent) ||
                    timeZoneInfo.IsAmbiguousTime(eventEndTimeComponent))
                {
                    // This step handle cases where the time is skipped or repeated
                    // during a daylight-saving time transition. Moving ahead one hour removes
                    // any problems.
                    eventEndTimeComponent = eventEndTimeComponent.AddHours(1);
                }

                aed.EncodedEndTime = TimeZoneInfo.ConvertTimeToUtc(eventEndTimeComponent, timeZoneInfo).TimeOfDay;
            }
        }
    }
}
