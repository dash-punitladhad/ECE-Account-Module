﻿namespace ECE.CRM.BusinessServices.Utilities
{
    public enum SendMessageMode
    {
        Directly,

        Queued
    }
}
