﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using System;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Web;

    public static class TextHelper
    {
        public static string OnlyNumericValue(string input)
        {
            if (input == null)
            {
                return null;
            }

            Regex regexObj = new Regex(@"[^\d]");
            var output = regexObj.Replace(input, string.Empty);

            return output;
        }

        public static string AppendLine(this string s, string value)
        {
            if (!string.IsNullOrWhiteSpace(s))
            {
                return s + Environment.NewLine + value;
            }
            else
            {
                return value;
            }
        }

        public static string RemoveHtml(this string html)
        {
            if (string.IsNullOrWhiteSpace(html)) return string.Empty;
            var doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(html);

            foreach (var node in doc.DocumentNode.SelectNodes("//script|//style") ?? new HtmlAgilityPack.HtmlNodeCollection(null))
                node.Remove();

            return HttpUtility.HtmlDecode(doc.DocumentNode.InnerText ?? string.Empty).Trim();
        }

        public static string GetTimeZoneName(DateTime value, string timeZoneName)
        {
            try
            {
                var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZoneName);

                var lookupName = timeZoneInfo.IsDaylightSavingTime(value)
                    ? timeZoneInfo.DaylightName
                    : timeZoneInfo.StandardName;

                return lookupName;
            }
            catch (TimeZoneNotFoundException)
            {
                return null;
            }
        }

        public static bool IsValidEmail(string email)
        {
            const string pattern = @"^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$";

            var regex = new Regex(pattern);

            var match = regex.Match(email);

            return match.Length > 0;
        }

        public static DateTime CalcReleaseDateNoWeekend(DateTime releaseDate)
        {
            var dayOfWeek = releaseDate.DayOfWeek;

            switch (dayOfWeek)
            {
                case DayOfWeek.Saturday:
                    releaseDate = releaseDate.AddHours(48);
                    break;

                case DayOfWeek.Sunday:
                    releaseDate = releaseDate.AddHours(24);
                    break;
            }

            return releaseDate;
        }
    }

    public static class Extensions
    {
        public static string ConvertToBase64(this Stream stream)
        {
            byte[] bytes;
            using (var memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                bytes = memoryStream.ToArray();
            }

            string base64 = Convert.ToBase64String(bytes);
            return base64;
        }
    }
}
