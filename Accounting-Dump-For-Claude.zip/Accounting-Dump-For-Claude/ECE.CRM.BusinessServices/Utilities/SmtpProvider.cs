﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Specialized;
    using System.Net;
    using System.Net.Mail;
    using System.Net.Mime;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    using System.Threading.Tasks;

    /// <summary>
    /// SmtpProvider Class.
    /// </summary>
    public class SmtpProvider
    {
        /// <summary>
        /// The email settings
        /// </summary>
        private NameValueCollection settings = null;

        /// <summary>
        /// The attachment collection
        /// </summary>
        private AttachmentCollection attachmentCollection = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="SmtpProvider" /> class.
        /// </summary>
        public SmtpProvider()
            : this(MobiusConfiguration.Current.AppSettings)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SmtpProvider" /> class.
        /// </summary>
        /// <param name="settings">The settings.</param>
        public SmtpProvider(NameValueCollection settings)
        {
            if (settings == null)
            {
                throw new ArgumentNullException(nameof(settings));
            }

            this.settings = settings;

            this.ToAddress = string.Empty;
            this.CCAddress = string.Empty;
            this.BCCAddress = string.Empty;
            this.ReplyTo = string.Empty;
            this.FromAddress = string.Empty;
        }

        /// <summary>
        /// Gets or sets to address. Accepts comma delimited string.
        /// </summary>
        /// <value>To address.</value>
        public string ToAddress { get; set; }

        /// <summary>
        /// Gets or sets the CC address. Accepts comma delimited string.
        /// </summary>
        /// <value>The CC address.</value>
        public string CCAddress { get; set; }

        /// <summary>
        /// Gets or sets the BCC address. Accepts comma delimited string.
        /// </summary>
        /// <value>The BCC address.</value>
        public string BCCAddress { get; set; }

        /// <summary>
        /// Gets or sets from address. Accepts a single address.
        /// </summary>
        /// <value>From address.</value>
        public string FromAddress { get; set; }

        /// <summary>
        /// Gets or sets from name.
        /// </summary>
        /// <value>From name.</value>
        public string FromName { get; set; }

        /// <summary>
        /// Gets or sets the reply to.
        /// </summary>
        /// <value>The reply to address.</value>
        public string ReplyTo { get; set; }

        /// <summary>
        /// Gets or sets the subject.
        /// </summary>
        /// <value>The subject.</value>
        public string Subject { get; set; }

        /// <summary>
        /// Gets or sets the plain-text body.
        /// </summary>
        /// <value>The email body.</value>
        public string BodyPlain { get; set; }

        /// <summary>
        /// Gets or sets the HTML body.
        /// </summary>
        /// <value>The body HTML.</value>
        public string BodyHtml { get; set; }

        /// <summary>
        /// Gets or sets the attachment path.
        /// </summary>
        /// <value>The attachment path.</value>
        public string AttachmentPath { get; set; }

        /// <summary>
        /// Gets a value indicating whether to send email messages.
        /// </summary>
        /// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
        public bool Enabled
        {
            get
            {
                return this.GetSettingBoolean("Email.Enabled");
            }
        }

        /// <summary>
        /// Sends the email message as an asynchronous operation.
        /// </summary>
        /// <returns>The Task for the asynchronous operation.</returns>
        public async Task SendAsync()
        {
            SmtpClient client = null;

            MailMessage message = null;

            try
            {
                message = this.BuildMessage();

                if (this.Enabled)
                {
                    client = SmtpClientHelper.CreateSmtpClient(this.settings);

                    ServicePointManager.ServerCertificateValidationCallback =
                        (object s,
                         X509Certificate certificate,
                         X509Chain chain,
                         SslPolicyErrors sslPolicyErrors) =>
                        {
                            return true;
                        };

                    await client.SendMailAsync(message);
                }
            }
            finally
            {
                SmtpClientHelper.CleanupSmtpClient(client);

                if (message != null)
                {
                    message.Dispose();
                }
            }
        }

        public void AddAttachments(AttachmentCollection attachmentCollection)
        {
            this.attachmentCollection = attachmentCollection;
        }

        /// <summary>
        /// Sends the email message.
        /// </summary>
        public void Send()
        {
            SmtpClient client = null;

            MailMessage message = null;

            try
            {
                message = this.BuildMessage();


                if (!string.IsNullOrEmpty(this.ToAddress))
                {
                    foreach (var i in this.ToAddress.Split(','))
                    {
                        message.To.Add(new MailAddress(i));
                    }
                }

                if (!string.IsNullOrEmpty(this.CCAddress))
                {
                    foreach (var i in this.CCAddress.Split(','))
                    {
                        message.CC.Add(new MailAddress(i));
                    }
                }

                if (!string.IsNullOrEmpty(this.BCCAddress))
                {
                    foreach (var i in this.BCCAddress.Split(','))
                    {
                        message.Bcc.Add(new MailAddress(i));
                    }
                }


                if (this.attachmentCollection != null)
                {
                    foreach (var attachment in this.attachmentCollection)
                    {
                        message.Attachments.Add(attachment);
                    }
                }

                if (this.Enabled)
                {
                    client = SmtpClientHelper.CreateSmtpClient(this.settings);

                    ServicePointManager.ServerCertificateValidationCallback =
                        (object s,
                         X509Certificate certificate,
                         X509Chain chain,
                        SslPolicyErrors sslPolicyErrors) =>
                        {
                            return true;
                        };
                    try
                    {
                        client.Send(message);
                    }
                    catch (Exception ex) { }
                }
            }
            finally
            {
                SmtpClientHelper.CleanupSmtpClient(client);

                if (message != null)
                {
                    message.Dispose();
                }
            }
        }

        /// <summary>
        /// Adds a list of addresses to an address collection.
        /// </summary>
        /// <param name="collection">The collection.</param>
        /// <param name="addresses">The addresses.</param>
        private static void AddArrayToCollection(MailAddressCollection collection, string[] addresses)
        {
            if (addresses == null || collection == null)
            {
                return;
            }

            for (int i = 0; i < addresses.Length; i++)
            {
                if (!string.IsNullOrEmpty(addresses[i]))
                {
                    collection.Add(addresses[i]);
                }
            }
        }

        /// <summary>
        /// Adds a list of addresses to an address collection.
        /// </summary>
        /// <param name="collection">The collection.</param>
        /// <param name="addresses">The addresses.</param>
        private static void AddArrayToCollection(MailAddressCollection collection, MailAddressCollection addresses)
        {
            if (addresses == null || collection == null)
            {
                return;
            }

            for (int i = 0; i < addresses.Count; i++)
            {
                collection.Add(addresses[i]);
            }
        }

        /// <summary>
        /// Parses the addresses into a string array.
        /// </summary>
        /// <param name="addresses">The addresses to parse.</param>
        /// <returns>A addresses.</returns>
        private static MailAddressCollection ParseAddresses(string addresses)
        {
            var addressCollection = new MailAddressCollection();

            if (!string.IsNullOrWhiteSpace(addresses))
            {
                addressCollection.Add(addresses);
            }

            return addressCollection;
        }

        /// <summary>
        /// Builds the message.
        /// </summary>
        /// <returns>A populated mail message object.</returns>
        private MailMessage BuildMessage()
        {
            // Declare variables
            MailAddressCollection toAddressList = SmtpProvider.ParseAddresses(this.ToAddress);
            MailAddressCollection ccAddressList = SmtpProvider.ParseAddresses(this.CCAddress);
            MailAddressCollection bccAddressList = SmtpProvider.ParseAddresses(this.BCCAddress);
            MailAddressCollection replyToAddressList = SmtpProvider.ParseAddresses(this.ReplyTo);

            var message = new MailMessage();

            // Set the body
            if (!string.IsNullOrWhiteSpace(this.BodyPlain) && !string.IsNullOrWhiteSpace(this.BodyHtml))
            {
                message.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(this.BodyPlain, null, MediaTypeNames.Text.Plain));
                message.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(this.BodyHtml, null, MediaTypeNames.Text.Html));
            }
            else if (!string.IsNullOrWhiteSpace(this.BodyHtml))
            {
                message.Body = this.BodyHtml;
                message.IsBodyHtml = true;
            }
            else
            {
                message.Body = this.BodyPlain;
                message.IsBodyHtml = false;
            }

            var internalOnly = this.GetSettingBoolean("Email.InternalOnly", true);
            if (internalOnly)
            {
                var externalAddressFound = false;

                var internalDomainsList = this.settings["Email.InternalDomains"];

                if (!string.IsNullOrWhiteSpace(internalDomainsList))
                {
                    string[] internalDomains = internalDomainsList.Split(';');

                    // Loop through each email address
                    foreach (var item in toAddressList)
                    {
                        var isValidAddress = false;

                        // Test each email address against the list of valid domains
                        foreach (var internalDomain in internalDomains)
                        {
                            // If a match, set flag and don't bother checking the rest of the valid domains
                            if (item.Address.EndsWith(internalDomain, StringComparison.CurrentCultureIgnoreCase))
                            {
                                isValidAddress = true;
                                break;
                            }
                        }

                        // If we find an address that isn't on the allowed list, stop testing
                        if (!isValidAddress)
                        {
                            externalAddressFound = true;
                            break;
                        }
                    }
                }
                else
                {
                    // When no internal domains are listed, then redirect all messages.
                    externalAddressFound = true;
                }

                if (externalAddressFound)
                {
                    // Keep track of the original recipients
                    var sb = new System.Text.StringBuilder();

                    sb.Append("<b>ORIGINAL RECIPIENTS:</b>");
                    foreach (var item in toAddressList)
                    {
                        sb.AppendFormat("<br/>{0}", WebUtility.HtmlEncode(item.ToString()));
                    }

                    sb.Append("<br/><br/>");

                    if (ccAddressList != null && ccAddressList.Count > 0)
                    {
                        sb.Append("<b>ORIGINAL CC LIST:</b>");
                        foreach (var item in ccAddressList)
                        {
                            sb.AppendFormat("<br/>{0}", WebUtility.HtmlEncode(item.ToString()));
                        }

                        sb.Append("<br/><br/>");
                    }

                    if (bccAddressList != null && bccAddressList.Count > 0)
                    {
                        sb.Append("<b>ORIGINAL BCC LIST:</b>");
                        foreach (var item in bccAddressList)
                        {
                            sb.AppendFormat("<br/>{0}", WebUtility.HtmlEncode(item.ToString()));
                        }

                        sb.Append("<br/><br/>");
                    }

                    if (replyToAddressList != null && replyToAddressList.Count > 0)
                    {
                        sb.Append("<b>ORIGINAL REPLY TO LIST:</b>");
                        foreach (var item in replyToAddressList)
                        {
                            sb.AppendFormat("<br/>{0}", WebUtility.HtmlEncode(item.ToString()));
                        }

                        sb.Append("<br/><br/>");
                    }

                    sb.Append(message.Body);

                    message.Body = sb.ToString();

                    message.To.Add(this.settings["Email.InternalRedirectAddress"]);
                }
                else
                {
                    SmtpProvider.AddArrayToCollection(message.To, toAddressList);
                }
            }
            else
            {
                SmtpProvider.AddArrayToCollection(message.To, toAddressList);

                SmtpProvider.AddArrayToCollection(message.CC, ccAddressList);

                SmtpProvider.AddArrayToCollection(message.Bcc, bccAddressList);

                SmtpProvider.AddArrayToCollection(message.ReplyToList, replyToAddressList);
            }

            if (!string.IsNullOrEmpty(this.FromAddress))
            {
                // Set the from name and address
                try
                {
                    message.From = new MailAddress(this.FromAddress, this.FromName);
                }
                catch (FormatException)
                {
                    message.From = new MailAddress(
                        this.settings["Email.FromAddress"],
                        this.settings["Email.FromName"]);
                }

                message.Sender = message.From;
            }
            else
            {
                // Use the default setting from name and address
                message.From = new MailAddress(
                    this.settings["Email.FromAddress"],
                    this.settings["Email.FromName"]);
                message.Sender = new MailAddress(
                    this.settings["Email.FromAddress"],
                    this.settings["Email.FromName"]);
            }

            var includeSubjectPrefix = this.GetSettingBoolean("Email.IncludeSubjectPrefix");

            // Set the subject
            if (includeSubjectPrefix)
            {
                message.Subject = string.Format(
                    "{0} - {1}",
                    this.settings["Email.SubjectPrefix"],
                    this.Subject);
            }
            else
            {
                message.Subject = this.Subject;
            }

            if (!string.IsNullOrWhiteSpace(this.AttachmentPath))
            {
                message.Attachments.Add(new Attachment(this.AttachmentPath, "text/html"));
            }

            // Turn off notifications
            message.DeliveryNotificationOptions = DeliveryNotificationOptions.Never;

            var unsubscribeEmail = MobiusConfiguration.GetString("Email.UnsubscribeAddress");

            // https://www.rfc-editor.org/rfc/rfc8058.txt
            var unsubHeader = $"<mailto:{unsubscribeEmail}?subject=Unsubscribe>";

            message.Headers.Add("List-Unsubscribe", unsubHeader);

            return message;
        }

        /// <summary>
        /// Gets the setting as a boolean type.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns><c>true</c> or <c>false</c> if the value exists and is a value boolean; otherwise <c>false</c>.</returns>
        private bool GetSettingBoolean(string key)
        {
            return this.GetSettingBoolean(key, false);
        }

        /// <summary>
        /// Gets the setting as a boolean type.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns><c>true</c> or <c>false</c> if the value exists and is a value boolean; otherwise <c>false</c>.</returns>
        private bool GetSettingBoolean(string key, bool defaultValue)
        {
            var value = this.settings[key];

            bool result;

            if (bool.TryParse(value, out result))
            {
                return result;
            }

            return defaultValue;
        }
    }
}
