﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Specialized;
    using System.Net;
    using System.Net.Mail;

    public static class SmtpClientHelper
    {
        /// <summary>
        /// Creates the SMTP client. If delivery method is SpecifiedPickupDirectory,
        /// the directory is created if it does not exist.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <returns>The SmtpClient instance.</returns>
        public static SmtpClient CreateSmtpClient(NameValueCollection settings)
        {
            var client = new SmtpClient();

            var deliveryMethod = settings.GetEnum(KeyName("DeliveryMethod"), client.DeliveryMethod);

            client.DeliveryMethod = deliveryMethod;

            if (client.DeliveryMethod == SmtpDeliveryMethod.SpecifiedPickupDirectory)
            {
                InitializePickupDirectory(client, settings);
            }
            else if (client.DeliveryMethod == SmtpDeliveryMethod.Network)
            {
                InitializeNetworkSettings(client, settings);
            }

            return client;
        }

        public static void InitializePickupDirectory(SmtpClient client, NameValueCollection settings)
        {
            var pickupDirectoryLocation = settings[KeyName("PickupDirectoryLocation")];
            if (string.IsNullOrWhiteSpace(pickupDirectoryLocation))
            {
                pickupDirectoryLocation = client.PickupDirectoryLocation;
            }

            pickupDirectoryLocation = Environment.ExpandEnvironmentVariables(pickupDirectoryLocation);
            if (!System.IO.Directory.Exists(pickupDirectoryLocation))
            {
                System.IO.Directory.CreateDirectory(pickupDirectoryLocation);
            }

            client.PickupDirectoryLocation = pickupDirectoryLocation;
        }

        public static void InitializeNetworkSettings(SmtpClient client, NameValueCollection settings)
        {
            var host = settings[KeyName("SmtpHost")];
            if (!string.IsNullOrWhiteSpace(host))
            {
                client.Host = host;
            }

            var enableSsl = settings.GetBoolean(KeyName("EnableSsl"), client.EnableSsl);
            var port = settings.GetInt32(KeyName("Port"), client.Port);
            var timeout = settings.GetInt32(KeyName("Timeout"), 100000); // 100 seconds

            client.EnableSsl = enableSsl;
            client.Port = port;
            client.Timeout = timeout;

            var targetName = settings[KeyName("TargetName")];
            if (!string.IsNullOrWhiteSpace(targetName))
            {
                client.TargetName = targetName;
            }

            var useDefaultCredentials = settings.GetBoolean(KeyName("UseDefaultCredentials"));
            if (useDefaultCredentials)
            {
                client.UseDefaultCredentials = useDefaultCredentials;
            }
            else
            {
                var userName = settings[KeyName("Username")];
                var password = settings[KeyName("Password")];

                client.Credentials = new NetworkCredential(userName, password);
            }
        }

        public static string KeyName(string value)
        {
            return $"MailSettings.{value}";
        }

        /// <summary>
        /// Cleans up the SMTP client.
        /// </summary>
        /// <param name="client">The client.</param>
        public static void CleanupSmtpClient(SmtpClient client)
        {
            //// See http://msdn.microsoft.com/en-us/library/ee706941.aspx for more details
            //// on proper disposal of client resources.
            if (client == null)
            {
                return;
            }

            if (client.DeliveryMethod == SmtpDeliveryMethod.Network)
            {
                /*
                 * When disposing of the client, an exception is raised if the
                 * Host property is missing. So it is checked for a non-missing value prior
                 * to calling Dispose() to prevent the exception.
                 */

                if (!string.IsNullOrWhiteSpace(client.Host))
                {
                    client.Dispose();
                }
            }
            else
            {
                client.Dispose();
            }
        }
    }
}
