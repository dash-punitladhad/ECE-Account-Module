﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.BusinessServices;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using EO.Pdf;
    using EO.Pdf.Contents;
    using EO.Pdf.Drawing;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Text;

    public static class AccountingFileGenerators
    {
        // Summary Table
        // Contract - Contract Id or payment date if no contract
        public const int SummaryTableContractColumnLength = 10;

        // Agent - Name of agent
        public const int SummaryTableAgentColumnLength = 20;

        // Location - Contract.VenuePhysicalCity & VenuePhysicalState
        public const int SummaryTableLocationColumnLength = 25;

        // Play date - due date on the AREF
        public const int SummaryTablePlayDateColumnLength = 9;

        // Amount - amount of payment
        public const int SummaryTableAmountColumnLength = 10;

        public static DocumentDto GenerateCheckReportFile(int batchNumber, ExpenseBatchType batchType, List<ExpensePaymentDto> payments)
        {
            string fileName = GenerateFileName(batchType, "Check-Report");

            var ms = new MemoryStream();

            var sw = new StreamWriter(ms);

            foreach (var payment in payments)
            {
                if (payment.ExpensePaymentTypeId == (int)ExpensePaymentType.Check)
                {
                    StringBuilder sb = new StringBuilder();

                    sb.Append(ECEBusinessConstants.CheckReportConstants.CheckReportAccountNumber);

                    var seqNumString = payment.ReferenceNumber.ToString().PadLeft(ECEBusinessConstants.CheckReportConstants.CheckReportCheckNumberWidth, '0');

                    sb.Append(seqNumString);

                    var amountString = payment.PaymentAmount.ToString("0.00").Replace(".", string.Empty).PadLeft(ECEBusinessConstants.CheckReportConstants.CheckReportAmountWidth, '0');

                    sb.Append(amountString);

                    sb.Append(DateTime.Now.ToString("MMddyy").PadRight(ECEBusinessConstants.CheckReportConstants.CheckReportDateWidth));

                    sb.Append(payment.PayeeName.PadRight(ECEBusinessConstants.CheckReportConstants.CheckReportPayeeNameWidth));

                    sw.WriteLine(sb.ToString());
                }
            }

            sw.Flush();
            ms.Position = 0;

            var documentDto = new DocumentDto()
            {
                OriginalFileName = fileName,
                Description = "Check File",
                DocumentExtensionId = (int)DocumentExtension.TXT,
                DocumentExtension = new LookupDto() { Text = "txt" },
                DocumentTypeId = (int)DocumentType.CheckReport,
                IsDeleted = false,
                Contents = ms
            };

            return documentDto;
        }

        public static DocumentDto GenerateACHFile(ExpenseBatchType batchType, List<ExpensePaymentDto> payments)
        {
            string fileName = GenerateFileName(batchType, "ACH");

            var ms = new MemoryStream();

            var sw = new StreamWriter(ms);

            StringBuilder sb = new StringBuilder();

            var batchSeqNumber = GetNextSequenceByEntity(ECEBusinessConstants.EntitySequenceConstants.ACHBatchNumber);

            sb.AppendLine(BuildACHFileHeader());

            sb.AppendLine(BuildACHBatchHeader(batchSeqNumber));

            sb.Append(BuildACHRecords(payments));

            sb.AppendLine(BuildBatchControl(batchSeqNumber, payments));

            sb.AppendLine(BuildFileControl(payments));

            sw.Write(sb.ToString());

            sw.Flush();
            ms.Position = 0;

            var documentDto = new DocumentDto()
            {
                OriginalFileName = fileName,
                Description = "ACH File",
                DocumentExtensionId = (int)DocumentExtension.TXT,
                DocumentExtension = new LookupDto() { Text = "txt" },
                DocumentTypeId = (int)DocumentType.ACH,
                IsDeleted = false,
                Contents = ms
            };

            return documentDto;
        }

        public static DocumentDto GenerateCheckListFile(ExpenseBatchType batchType, IList<CheckPrintDto> checks)
        {
            string fileName = GenerateFileName(batchType, "Check-List");

            var ms = new MemoryStream();

            var checkContents = new List<PdfDocument>();

            try
            {
                foreach (var check in checks)
                {
                    PdfDocument doc = GetCheckContents(check);

                    checkContents.Add(doc);
                }

                var contents = PdfDocument.Merge(checkContents.ToArray());

                contents.Save(ms);

                ms.Position = 0;
            }
            catch (Exception ex)
            {
                if (ms != null)
                {
                    ms.Dispose();
                }

                throw new UnhandledBusinessException(ex);
            }

            var documentDto = new DocumentDto()
            {
                OriginalFileName = fileName,
                Description = "Check List",
                DocumentExtensionId = (int)DocumentExtension.PDF,
                DocumentExtension = new LookupDto() { Text = "pdf" },
                DocumentTypeId = (int)DocumentType.Check,
                IsDeleted = false,
                Contents = ms
            };

            return documentDto;
        }

        public static MemoryStream GenerateOneCheck(CheckPrintDto payment)
        {
            var ms = new MemoryStream();

            try
            {
                PdfDocument doc = GetCheckContents(payment);

                doc.Save(ms);

                ms.Position = 0;
            }
            catch (Exception ex)
            {
                if (ms != null)
                {
                    ms.Dispose();
                }

                throw new UnhandledBusinessException(ex);
            }

            return ms;
        }

        public static PdfDocument GetCheckContents(CheckPrintDto payment)
        {
            PdfDocument doc = new PdfDocument();

            PdfPage page = doc.Pages.Add();

            PdfTextLayer textLayer = new PdfTextLayer();
            textLayer.Font = new PdfFont("Courier New", 10, FontStyle.Bold);

            // Check # title & value
            PdfTextContent checkNumberTitle = new PdfTextContent("Check#");
            checkNumberTitle.PositionMode = PdfTextPositionMode.Offset;
            checkNumberTitle.Offset = new PdfPoint(232, 730);
            PdfTextContent checkNumberText = new PdfTextContent(payment.CheckNumber);
            checkNumberText.PositionMode = PdfTextPositionMode.Offset;
            checkNumberText.Offset = new PdfPoint(7, -12);

            // Date
            PdfTextContent dateText = new PdfTextContent(payment.CheckDate.ToString("MMM d, yyyy"));
            dateText.PositionMode = PdfTextPositionMode.Offset;
            dateText.Offset = new PdfPoint(110, 0);

            // Amount
            PdfTextContent amountText = new PdfTextContent(payment.Amount.ToString("C").PadLeft(12, '*'));
            amountText.PositionMode = PdfTextPositionMode.Offset;
            amountText.Offset = new PdfPoint(130, 0);

            // Pay line
            PdfTextContent payLineText = new PdfTextContent(NumberToCurrencyText(payment.Amount, MidpointRounding.ToEven).PadRight(77, '*'));
            payLineText.PositionMode = PdfTextPositionMode.Offset;
            payLineText.Offset = new PdfPoint(-400, -25);

            // To The Order Of Line
            PdfTextContent orderOfText = new PdfTextContent(payment.PayeeName);
            orderOfText.PositionMode = PdfTextPositionMode.Offset;
            orderOfText.Offset = new PdfPoint(-10, -35);

            textLayer.Contents.AddRange(new List<PdfTextContent>()
            {
                checkNumberTitle,
                checkNumberText,
                dateText,
                amountText,
                payLineText,
                orderOfText
            });

            // Payee Address
            PdfTextContent payeeNameText = new PdfTextContent(payment.EntityName);
            payeeNameText.PositionMode = PdfTextPositionMode.Offset;
            payeeNameText.Offset = new PdfPoint(0, -25);

            PdfTextContent artistAddress1Text = new PdfTextContent(payment.EntityMailingAddress1);
            artistAddress1Text.PositionMode = PdfTextPositionMode.Offset;
            artistAddress1Text.Offset = new PdfPoint(0, -12);

            textLayer.Contents.AddRange(new List<PdfTextContent>()
            {
                payeeNameText,
                artistAddress1Text
            });

            if (!string.IsNullOrEmpty(payment.EntityMailingAddress2))
            {
                PdfTextContent payeeAddress2Text = new PdfTextContent(payment.EntityMailingAddress2);
                payeeAddress2Text.PositionMode = PdfTextPositionMode.Offset;
                payeeAddress2Text.Offset = new PdfPoint(0, -12);
                textLayer.Contents.Add(payeeAddress2Text);
            }

            PdfTextContent payeeCityStateText = new PdfTextContent(payment.EntityCityStateZip);
            payeeCityStateText.PositionMode = PdfTextPositionMode.Offset;
            payeeCityStateText.Offset = new PdfPoint(0, -12);
            textLayer.Contents.Add(payeeCityStateText);

            var offsetForSummary = -94;

            if (!string.IsNullOrEmpty(payment.EntityMailingCountry))
            {
                PdfTextContent payeeCountry = new PdfTextContent(payment.EntityMailingCountry);
                payeeCountry.PositionMode = PdfTextPositionMode.Offset;
                payeeCountry.Offset = new PdfPoint(0, -12);
                textLayer.Contents.Add(payeeCountry);
                offsetForSummary = -82;
            }

            // Summary below check
            string summaryTitle = $"{payment.EntityType}: {payment.EntityId}-{payment.EntityName}";
            PdfTextContent summaryTitleText = new PdfTextContent(summaryTitle);
            summaryTitleText.PositionMode = PdfTextPositionMode.Offset;
            summaryTitleText.Offset = new PdfPoint(-35, offsetForSummary);

            string summaryHeader = $"{"Contract".PadRight(SummaryTableContractColumnLength, ' ')}{"Agent".PadRight(SummaryTableAgentColumnLength, ' ')}{"Location".PadRight(SummaryTableLocationColumnLength, ' ')}{"Due Date".PadRight(SummaryTablePlayDateColumnLength, ' ')}{"Amount".PadLeft(SummaryTableAmountColumnLength, ' ')}";
            PdfTextContent summaryHeaderText = new PdfTextContent(summaryHeader);
            summaryHeaderText.PositionMode = PdfTextPositionMode.Offset;
            summaryHeaderText.Offset = new PdfPoint(0, -20);

            textLayer.Contents.AddRange(new List<PdfTextContent>()
            {
                summaryTitleText,
                summaryHeaderText
            });

            foreach (var row in payment.SummaryTable)
            {
                string rowValue = FormatSummaryRow(row);

                PdfTextContent rowText = new PdfTextContent(rowValue);
                rowText.PositionMode = PdfTextPositionMode.Offset;
                rowText.Offset = new PdfPoint(0, -12);
                textLayer.Contents.Add(rowText);
            }

            page.Contents.Add(textLayer);

            return doc;
        }

        public static string FormatSummaryRow(CheckPrintSummaryDto row)
        {
            var contractId = row.ContractId.PadRight(SummaryTableContractColumnLength, ' ');
            var agentName = (row.AgentName ?? string.Empty).PadRight(SummaryTableAgentColumnLength, ' ');
            var location = row.Location.PadRight(SummaryTableLocationColumnLength, ' ');
            var playDate = $"{row.PlayDate:MM/dd/yy}".PadRight(SummaryTablePlayDateColumnLength, ' ');
            var amount = Math.Abs(row.Amount).ToString("N2").PadLeft(SummaryTableAmountColumnLength, ' ');
            var plusMinus = row.Amount < decimal.Zero ? "-" : "+";

            var transType = row.ContractTransactionType;

            var rowValue = $"{contractId}{agentName}{location}{playDate}{amount}{plusMinus} {transType}";

            return rowValue;
        }

        public static TemplateMailMessage CreateACHNotificationMessage(EmailTemplateDto bodyTemplate, CheckPrintDto directDeposit)
        {
            string appName = MobiusConfiguration.GetString("Application.Name");

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            var subject = bodyTemplate.Subject
                .Replace("{AppName}", appName)
                .Replace("{Name}", directDeposit.EntityName)
                .Replace("{Date}", directDeposit.CheckDate.ToShortDateString()).ToString();

            var content = AccountingFileGenerators.CreateACHNotificationAttachmentContent(directDeposit);

            var bodyBuilder = new StringBuilder(bodyTemplate.Body);

            //// Currently, attachments are not supported. Embedding the content in the message instead.

            ////var contentType = new System.Net.Mime.ContentType();
            ////contentType.MediaType = System.Net.Mime.MediaTypeNames.Text.Plain;
            ////contentType.Name = $"{directDeposit.EntityType[0]}{directDeposit.EntityId}DD{directDeposit.CheckDate:MMddyyyy}.txt";

            ////var attachment = Attachment.CreateAttachmentFromString(content, contentType);

            ////email.Attachments.Add(attachment);

            bodyBuilder.AppendLine($"<hr />");
            bodyBuilder.AppendLine($"<br />");
            bodyBuilder.AppendLine($"<pre>{content}</pre>");
            bodyBuilder.AppendLine($"<br />");
            bodyBuilder.AppendLine($"<hr />");
            bodyBuilder.AppendLine($"<br />");
            bodyBuilder.AppendLine($"<br />");

            var body = bodyBuilder
                .Replace("{PayeeName}", directDeposit.EntityName)
                .Replace("''", "'").ToString();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;

            return email;
        }

        public static string CreateACHNotificationAttachmentContent(CheckPrintDto directDeposit)
        {
            var sb = new StringBuilder();

            sb.AppendLine("TO:");
            sb.AppendLine(directDeposit.EntityName);
            sb.AppendLine(directDeposit.EntityMailingAddress1);
            if (!string.IsNullOrWhiteSpace(directDeposit.EntityMailingAddress2))
            {
                sb.AppendLine(directDeposit.EntityMailingAddress2);
            }

            sb.AppendLine(directDeposit.EntityCityStateZip);
            sb.AppendLine(directDeposit.EntityMailingCountry ?? string.Empty);

            sb.AppendLine(string.Empty);
            sb.AppendLine($"Deposit Date  : {directDeposit.CheckDate:MM/dd/yyyy}");
            sb.AppendLine($"Deposit Amount: {directDeposit.Amount:C2}");
            sb.AppendLine(new string('-', 15));
            sb.AppendLine(string.Empty);
            sb.AppendLine(string.Empty);

            // Add the header
            sb.Append($"{"Contract".PadRight(AccountingFileGenerators.SummaryTableContractColumnLength, ' ')}");
            sb.Append($"{"Agent".PadRight(AccountingFileGenerators.SummaryTableAgentColumnLength, ' ')}");
            sb.Append($"{"Location".PadRight(AccountingFileGenerators.SummaryTableLocationColumnLength, ' ')}");
            sb.Append($"{"Due Date".PadRight(AccountingFileGenerators.SummaryTablePlayDateColumnLength, ' ')}");
            sb.Append($"{"Amount".PadLeft(AccountingFileGenerators.SummaryTableAmountColumnLength, ' ')}");
            sb.AppendLine(string.Empty);

            // Add the header separator
            sb.Append($"{"--------".PadRight(AccountingFileGenerators.SummaryTableContractColumnLength, ' ')}");
            sb.Append($"{"-----".PadRight(AccountingFileGenerators.SummaryTableAgentColumnLength, ' ')}");
            sb.Append($"{"--------".PadRight(AccountingFileGenerators.SummaryTableLocationColumnLength, ' ')}");
            sb.Append($"{"--------".PadRight(AccountingFileGenerators.SummaryTablePlayDateColumnLength, ' ')}");
            sb.Append($"{"------".PadLeft(AccountingFileGenerators.SummaryTableAmountColumnLength, ' ')}");
            sb.AppendLine(string.Empty);

            foreach (var row in directDeposit.SummaryTable)
            {
                string rowValue = AccountingFileGenerators.FormatSummaryRow(row);
                sb.AppendLine(rowValue);
            }

            return sb.ToString();
        }

        public static int GetNextSequenceByEntity(string entity)
        {
            var nextNumber = -1;

            try
            {
                using (var context = new EceCrmEntities())
                {
                    var dao = new EntitySequenceDao(context);

                    nextNumber = dao.GetNextSequenceByEntity(entity);
                }
            }
            catch (Exception ex)
            {
                throw new UnhandledBusinessException(ex);
            }

            return nextNumber;
        }

        public static string GenerateFileName(ExpenseBatchType batchType, string fileType)
        {
            string fileDate = DateTime.Now.ToString("yyyyMMddHHmmss");

            string fileSubtype = string.Empty;

            if (batchType == ExpenseBatchType.Artist)
            {
                fileSubtype = "Artist";
            }
            else if (batchType == ExpenseBatchType.OtherExpenses)
            {
                fileSubtype = "Other";
            }

            string fileName = $"{fileDate}-{fileSubtype}-{fileType}";

            return fileName;
        }

        private static string BuildACHFileHeader()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("1");                                                                                 // Field 1, fixed
            sb.Append("01");                                                                                // Field 2, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHRoutingNumber.PadLeft(10, ' '));                 // Field 3, routing number for bank
            sb.Append(ECEBusinessConstants.ACHConstants.ACHTaxId.PadLeft(10, ' '));                         // Field 4, IRS Tax Id
            sb.Append(DateTime.Now.ToString("yyMMdd"));                                                     // Field 5, file create date
            sb.Append(DateTime.Now.ToString("HHmm"));                                                       // Field 6, file create time
            sb.Append("A");                                                                                 // Field 7, file ID modifier.  "A" SINCE ONLY SENDING ONE PER DAY!
            sb.Append("094");                                                                               // Field 8, fixed
            sb.Append("10");                                                                                // Field 9, fixed
            sb.Append("1");                                                                                 // Field 10, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankName.PadRight(23, ' '));                     // Field 11
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyName.Substring(0, 23).PadRight(23, ' ')); // Field 12
            sb.Append(string.Empty.PadRight(8, ' '));                                                       // Field 13, reference code (optional)

            return sb.ToString().ToUpper();
        }

        private static string BuildACHBatchHeader(int batchSeqNumber)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("5");                                                                                 // Field 1, fixed
            sb.Append("220");                                                                               // Field 2, Service Class Code = 220
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyName.Substring(0, 16).PadRight(16, ' ')); // Field 3, Company Name
            sb.Append(string.Empty.PadRight(20, ' '));                                                      // Field 4, Company Discretionary Data
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyId.PadLeft(10, ' '));                     // Field 5, Company Id
            sb.Append("CCD");                                                                               // Field 6, entry class code (PPD,CCD,WEB)
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyEntryDesc.PadRight(10, ' '));             // Field 7, Company Entry Desc
            sb.Append(string.Empty.PadRight(6, ' '));                                                       // Field 8, Company descriptive date
            sb.Append(AddBusinessDays(DateTime.Now, 2).ToString("yyMMdd"));                                 // Field 9, Effective Entry date. 2 business days from now.
            sb.Append(string.Empty.PadRight(3, ' '));                                                       // Field 10, Settlement Date (3 blanks)
            sb.Append("1");                                                                                 // Field 11, fixed
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId.PadLeft(8, ' '));                         // Field 12, originating DFI id
            sb.Append(batchSeqNumber.ToString().PadLeft(7, '0'));                                           // Field 13, batch Number

            return sb.ToString().ToUpper();
        }

        private static string BuildACHRecords(List<ExpensePaymentDto> payments)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var payment in payments)
            {
                var amount = payment.PaymentAmount.ToString("0.00").Replace(".", string.Empty);

                var traceNumber = GetNextSequenceByEntity(ECEBusinessConstants.EntitySequenceConstants.ACHItemNumber);

                sb.Append("6");                                                                         // Field 1, Record Type Code
                sb.Append("22");                                                                        // Field 2 - Transaction Code
                sb.Append(payment.Artist.RoutingNumber.Substring(0, 8));                                // Field 3, Receiving DFI ID. (routing number)
                sb.Append(payment.Artist.RoutingNumber.Substring(8, 1));                                // Field 4, Check Digit
                sb.Append(payment.Artist.AccountNumber.PadRight(17, ' '));                              // Field 5, DFI Account Number
                sb.Append(amount.PadRight(10, ' '));                                                    // Field 6, Amount
                sb.Append(payment.Artist.Name.ToString().PadRight(15, ' ').Substring(0, 15));           // Field 7, Identification Number
                sb.Append(payment.PayeeName.PadRight(22, ' ').Substring(0, 22));                        // Field 8, Receiving Company Name
                sb.Append(string.Empty.PadRight(2, ' '));                                               // Field 9, Discretionary Data
                sb.Append("0");                                                                         // Field 10, Addenda Record Indicator... no addenda!
                sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId);                                 // Field 11, Trace Number 15 chars, first 8 ODFI
                sb.AppendLine(traceNumber.ToString().PadLeft(7, '0').Substring(0, 7));                  // Field 12, Trace Number last 7 chars must be ascending, not necessarily sequential
            }

            return sb.ToString().ToUpper();
        }

        private static string BuildBatchControl(int batchSeqNumber, List<ExpensePaymentDto> payments)
        {
            var routingSum = payments.Select(x => int.Parse(x.Artist.RoutingNumber.ToString().Substring(0, 8))).Sum();

            var entryHash = routingSum.ToString();

            if (entryHash.Length > 10)
            {
                entryHash.Substring(0, 10);
            }

            var totalCredit = payments.Sum(x => x.PaymentAmount).ToString("0.00").Replace(".", string.Empty);

            StringBuilder sb = new StringBuilder();

            sb.Append("8");                                                                 // Field 1, fixed record type code
            sb.Append("200");                                                               // Field 2, Service Class Code = 200
            sb.Append(payments.Count.ToString().PadLeft(6, '0'));                           // Field 3, Entry/Addenda count
            sb.Append(entryHash.PadLeft(10, '0'));                                          // Field 4, Entry Hash
            sb.Append(string.Empty.PadLeft(12, '0'));                                       // Field 5, total debit dollar amount
            sb.Append(totalCredit.PadLeft(12, '0'));                                        // Field 6, total credit dollar amount
            sb.Append(ECEBusinessConstants.ACHConstants.ACHCompanyId.PadRight(10, ' '));    // Field 7, company id
            sb.Append(string.Empty.PadRight(19, ' '));                                      // Field 8, message auth code, optional
            sb.Append(string.Empty.PadRight(6, ' '));                                       // Field 9, reserved (blank)
            sb.Append(ECEBusinessConstants.ACHConstants.ACHBankId.PadRight(8, ' '));        // Field 10, originating dfi id
            sb.Append(batchSeqNumber.ToString().PadLeft(7, '0'));                           // Field 11, batch Number

            return sb.ToString().ToUpper();
        }

        private static string BuildFileControl(List<ExpensePaymentDto> payments)
        {
            StringBuilder sb = new StringBuilder();

            int lineCount = payments.Count + 4;

            int blockCount = (int)(Math.Ceiling((decimal)lineCount / 10) * 10) / 10;

            var routingSum = payments.Select(x => int.Parse(x.Artist.RoutingNumber.ToString().Substring(0, 8))).Sum();

            var entryHash = routingSum.ToString();

            if (entryHash.Length > 10)
            {
                entryHash.Substring(0, 10);
            }

            var totalCredit = payments.Sum(x => x.PaymentAmount).ToString("0.00").Replace(".", string.Empty);

            sb.Append("9");                                                  // Field 1, fixed record type code
            sb.Append("1".PadLeft(6, '0'));                                  // Field 2, Batch Count
            sb.Append(blockCount.ToString().PadLeft(6, '0'));                // Field 3, Block Count
            sb.Append(payments.Count.ToString().PadLeft(8, '0'));            // Field 4, Entry /Addenda Count
            sb.Append(entryHash.PadLeft(10, '0'));                           // Field 5, entry hash
            sb.Append(string.Empty.PadLeft(12, '0'));                        // Field 6, total debit dollar amount
            sb.Append(totalCredit.PadLeft(12, '0'));                         // Field 7, total credit dollar amount
            sb.Append(string.Empty.PadRight(39, ' '));                       // Field 8, reserved (blank)

            return sb.ToString().ToUpper();
        }

        private static DateTime AddBusinessDays(DateTime date, int days)
        {
            if (days < 0)
            {
                throw new ArgumentException("days cannot be negative", "days");
            }

            if (days == 0)
            {
                return date;
            }

            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                date = date.AddDays(2);
                days -= 1;
            }
            else if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(1);
                days -= 1;
            }

            date = date.AddDays(days / 5 * 7);
            int extraDays = days % 5;

            if ((int)date.DayOfWeek + extraDays > 5)
            {
                extraDays += 2;
            }

            return date.AddDays(extraDays);
        }

        private static string NumberToCurrencyText(decimal number, MidpointRounding midpointRounding)
        {
            // Round the value just in case the decimal value is longer than two digits
            number = decimal.Round(number, 2, midpointRounding);

            string wordNumber = string.Empty;

            // Divide the number into the whole and fractional part strings
            string[] arrNumber = number.ToString().Split('.');

            // Get the whole number text
            long wholePart = long.Parse(arrNumber[0]);
            string strWholePart = NumberToText(wholePart);

            // For amounts of zero dollars show 'No Dollars...' instead of 'Zero Dollars...'
            // wordNumber = (wholePart == 0 ? "No" : strWholePart) + (wholePart == 1 ? " Dollar and " : " Dollars and ");
            wordNumber = (wholePart == 0 ? "No" : strWholePart) + " and ";

            // If the array has more than one element then there is a fractional part otherwise there isn't
            // just add 'No Cents' to the end
            if (arrNumber.Length > 1)
            {
                // If the length of the fractional element is only 1, add a 0 so that the text returned isn't,
                // 'One', 'Two', etc but 'Ten', 'Twenty', etc.
                long fractionPart = long.Parse(arrNumber[1].Length == 1 ? arrNumber[1] + "0" : arrNumber[1]);
                string strFarctionPart = NumberToText(fractionPart);

                // wordNumber += (fractionPart == 0 ? " No" : strFarctionPart) + (fractionPart == 1 ? " Cent" : " Cents");
                wordNumber += (fractionPart == 0 ? " No" : strFarctionPart) + "/100 ";
            }
            else
            {
                // wordNumber += "No Cents";
                wordNumber += "No/100 ";
            }

            return wordNumber;
        }

        private static string NumberToText(long number)
        {
            StringBuilder wordNumber = new StringBuilder();

            string[] powers = new string[]
            {
                "Thousand ", "Million ", "Billion "
            };
            string[] tens = new string[]
            {
                "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
            };
            string[] ones = new string[]
            {
                "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                                       "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
            };

            if (number == 0)
            {
                return "Zero";
            }

            if (number < 0)
            {
                wordNumber.Append("Negative ");
                number = -number;
            }

            long[] groupedNumber = new long[] { 0, 0, 0, 0 };
            int groupIndex = 0;

            while (number > 0)
            {
                groupedNumber[groupIndex++] = number % 1000;
                number /= 1000;
            }

            for (int i = 3; i >= 0; i--)
            {
                long group = groupedNumber[i];

                if (group >= 100)
                {
                    wordNumber.Append(ones[(group / 100) - 1] + " Hundred ");
                    group %= 100;

                    if (group == 0 && i > 0)
                    {
                        wordNumber.Append(powers[i - 1]);
                    }
                }

                if (group >= 20)
                {
                    if ((group % 10) != 0)
                    {
                        wordNumber.Append(tens[(group / 10) - 2] + " " + ones[(group % 10) - 1] + " ");
                    }
                    else
                    {
                        wordNumber.Append(tens[(group / 10) - 2] + " ");
                    }
                }
                else if (group > 0)
                {
                    wordNumber.Append(ones[group - 1] + " ");
                }

                if (group != 0 && i > 0)
                {
                    wordNumber.Append(powers[i - 1]);
                }
            }

            return wordNumber.ToString().Trim();
        }
    }
}
