﻿namespace ECE.CRM.BusinessServices.Utilities
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net.Mail;

    public class SmtpManager
    {
        public SmtpManager()
        {
        }

        public SmtpManager(IUnitOfWork context, bool useBulkInserts)
        {
            this.Context = context;
            this.UseBulkInserts = useBulkInserts;
        }

        public SmtpManager(IUnitOfWork context)
            : this(context, false)
        {
        }

        /// <summary>
        /// Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public IUnitOfWork Context { get; private set; }

        /// <summary>
        /// Gets a value indicating whether to use bulk inserts.
        /// </summary>
        /// <value><c>true</c> if using bulk inserts; otherwise, <c>false</c>.</value>
        public bool UseBulkInserts { get; private set; }

        public static MailMessage CreateMailMessage(EmailQueueDto emailQueue)
        {
            MailMessage mailMessage = null;
            if (emailQueue.EmailTemplateId.HasValue)
            {
                mailMessage = new TemplateMailMessage(emailQueue.EmailTemplateId.Value);
            }
            else
            {
                mailMessage = new MailMessage();
            }

            try
            {
                mailMessage.To.Add(emailQueue.ToAddresses);
            }
            catch (FormatException)
            {
                // Do Nothing
            }
            catch (Exception)
            {
                throw;
            }

            mailMessage.Subject = emailQueue.Subject;
            mailMessage.Body = emailQueue.Body;
            mailMessage.IsBodyHtml = emailQueue.IsHtml;

            SmtpManager.AddChangeEmailPreferencesLink(mailMessage);

            mailMessage.Body = mailMessage.Body.Replace("{BaseUrl}", MobiusConfiguration.GetString("Application.Url"));

            return mailMessage;
        }

        public static void AddChangeEmailPreferencesLink(MailMessage message)
        {
            if (message == null || message.To.Count == 0)
            {
                return;
            }

            var optOutUrl = MobiusConfiguration.GetString("Application.OptOutUrl");
            if (string.IsNullOrWhiteSpace(optOutUrl))
            {
                optOutUrl = "optout?email=";
            }

            var optOutText = MobiusConfiguration.GetString("Application.OptOutText");
            if (string.IsNullOrWhiteSpace(optOutText))
            {
                optOutText = "Unsubscribe";
            }

            var applicationUrl = MobiusConfiguration.GetString("Application.Url");

            // Only include the recipient in the link if the message has a single recipient.
            var firstRecipient = message.To.Count == 1
                ? message.To[0].Address
                : string.Empty;

            var url = string.Concat(applicationUrl, optOutUrl, firstRecipient);

            if (message.IsBodyHtml)
            {
                message.Body = message.Body.Replace(
                    "{ChangeEmailPreferences}",
                    $"<div style='text-align: center;'><a href='{url}'>{optOutText}</a></div>");
            }
            else
            {
                message.Body +=
                    Environment.NewLine +
                    $"{optOutText}: {url}";
            }
        }

        public bool SuppressMessageForOffice(int officeId)
        {
            if (officeId == Constants.HoustonOfficeId)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <returns><c>true</c> if the message was sent successfully, <c>false</c> otherwise.</returns>
        public bool SendMessage(MailMessage message)
        {
            if (message == null)
            {
                throw new ArgumentNullException(nameof(message));
            }

            var email = new SmtpProvider();

            email.ToAddress = message.To.ToString();
            email.CCAddress = message.CC.ToString();
            email.BCCAddress = message.Bcc.ToString();

            if (message.From != null)
            {
                email.FromAddress = message.From.Address;
                email.FromName = message.From.DisplayName;
            }

            email.Subject = message.Subject;

            email.AddAttachments(message.Attachments);

            AddChangeEmailPreferencesLink(message);

            if (message.IsBodyHtml)
            {
                email.BodyHtml = message.Body;
            }
            else
            {
                email.BodyPlain = message.Body;
            }

            email.Send();

            return true;
        }

        /// <summary>
        /// Sends the message immediately using the email message queue.
        /// All messages are recorded in the EmailQueue table for logging/audit purposes.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="sentBy">The user identifier of the user who is sending the message.</param>
        /// <returns><c>true</c> if the message was sent successfully, <c>false</c> otherwise.</returns>
        public bool SendMessage(MailMessage message, int sentBy)
        {
            return this.SendMessage(message, sentBy, null, SendMessageMode.Queued);
        }

        /// <summary>
        /// Sends the message immediate release. If using Direct SendMessageMode, the message is sent
        /// directly, rather than being queued for the next time the email queue is processed.
        /// Regardless, all messages are recorded in the EmailQueue table for logging/audit purposes.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="sentBy">The user identifier of the user who is sending the message.</param>
        /// <param name="mode">The mode used to send the message.</param>
        /// <returns><c>true</c> if the message was sent successfully, <c>false</c> otherwise.</returns>
        public bool SendMessage(MailMessage message, int sentBy, SendMessageMode mode, string attachmentEntity = null,string attachmentFileNames=null)
        {
            return this.SendMessage(message, sentBy, null, mode, attachmentEntity, attachmentFileNames);
        }

        /// <summary>
        /// Sends the message immediately, or queues it for release at the specified date/time.
        /// Regardless, messages are recorded in the EmailQueue table for logging/audit purposes.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="sentBy">The user identifier of the user who is sending the message.</param>
        /// <param name="releaseDate">The release date/time.</param>
        /// <returns><c>true</c> if the message was sent successfully, <c>false</c> otherwise.</returns>
        public bool SendMessage(MailMessage message, int sentBy, DateTime releaseDate)
        {
            return this.SendMessage(message, sentBy, releaseDate, SendMessageMode.Queued);
        }

        /// <summary>
        /// Sends the message immediately, or queues it for release at the specified date/time. If
        /// using Direct SendMessageMode, the message is sent directly, rather than being queued.
        /// Regardless, all messages are recorded in the EmailQueue table for logging/audit purposes.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="sentBy">The user identifier of the user who is sending the message.</param>
        /// <param name="releaseDate">The release date/time.</param>
        /// <param name="mode">The mode used to send the message.</param>
        /// <returns><c>true</c> if the message was sent successfully, <c>false</c> otherwise.</returns>
        public bool SendMessage(MailMessage message, int sentBy, DateTime? releaseDate, SendMessageMode mode, string attachmentEntity = null, string attachmentFileNames = null)
        {
            if (message == null)
            {
                throw new ArgumentNullException(nameof(message));
            }

            var result = true;

            this.Context.BeginTransaction();

            try
            {
                var email = new EmailQueueDto
                {
                    AppUserId = sentBy,
                    ToAddresses = message.To.ToString(),
                    Subject = message.Subject,
                    Body = message.Body,
                    IsHtml = message.IsBodyHtml
                };

                bool sendDirectly = MobiusConfiguration.GetBoolean("Email.SendDirectly", true);
                sendDirectly = sendDirectly || mode == SendMessageMode.Directly;

                if (releaseDate == null || sendDirectly)
                {
                    // Release immediately
                    email.ReleaseDate = TimeProvider.Current.Now;
                    email.Status = EmailQueueStatus.Release;
                }
                else
                {
                    // Queue the message for release on the date/time provided
                    email.ReleaseDate = releaseDate.Value;
                    email.Status = EmailQueueStatus.Pending;
                }
                string attachments = string.Empty;

                bool isContractIssue =
                    !string.IsNullOrWhiteSpace(attachmentEntity) &&
                    attachmentEntity.IndexOf("contractissue", StringComparison.OrdinalIgnoreCase) >= 0;

                bool hasMessageAttachments = message?.Attachments != null && message.Attachments.Count > 0;
                bool hasAttachmentFileName = !string.IsNullOrWhiteSpace(attachmentFileNames);

                if (isContractIssue)
                {
                    var attachmentNames = new List<string>();

                    if (hasMessageAttachments && !hasAttachmentFileName)
                    {
                        string attachmentBasePath =
                            MobiusConfiguration.Current.AppSettings["Attachment.PhysicalPath"];

                        foreach (var attachment in message.Attachments)
                        {
                            try
                            {
                                string extension = Path.GetExtension(attachment.Name);
                                string sanitizedName = Path.GetFileNameWithoutExtension(attachment.Name);

                                sanitizedName = new string(sanitizedName.Where(char.IsLetterOrDigit).ToArray());
                                if (sanitizedName.Length > 30)
                                    sanitizedName = sanitizedName.Substring(0, 30);

                                string finalFileName = $"{sanitizedName}-{Guid.NewGuid()}{extension}";
                                string fullPath = Path.Combine(attachmentBasePath, finalFileName);

                                using (var ms = new MemoryStream())
                                {
                                    attachment.ContentStream.CopyTo(ms);
                                    File.WriteAllBytes(fullPath, ms.ToArray());
                                }

                                attachmentNames.Add(finalFileName);
                            }
                            catch (Exception ex)
                            {
                                new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                            }
                        }

                        attachments = string.Join(",", attachmentNames);
                    }
                    else
                    {
                        // Use already generated attachment filename (if any)
                        attachments = attachmentFileNames;
                    }

                    if (hasMessageAttachments && string.IsNullOrWhiteSpace(attachments) && mode == SendMessageMode.Queued)
                    {
                        throw new SendContractEmailException(
                            "Mail messages with attachments cannot be queued.");
                    }
                }

                

                email.Attachments = attachments;

                var templateMessage = message as TemplateMailMessage;
                email.EmailTemplateId = templateMessage?.EmailTemplateId;

                email.SetAsCreated(sentBy);

                if (UseBulkInserts)
                {
                    result = this.Context.EmailQueue.CreateInBulk(email);
                }
                else
                {
                    result = this.Context.EmailQueue.Create(email);
                }

                if (result)
                {
                    if (templateMessage != null && email.EmailQueueId > 0)
                    {
                        templateMessage.EmailQueueId = email.EmailQueueId;
                    }

                    if (sendDirectly)
                    {
                        result = this.SendMessage(message);
                        if (result)
                        {
                            this.UpdateQueueStatus(email, EmailQueueStatus.Sent, sentBy);
                        }
                        else
                        {
                            this.UpdateQueueStatus(email, EmailQueueStatus.Error, sentBy);
                        }
                    }
                }

                this.Context.Commit();

            }
            catch (SendContractEmailException)
            {
                this.Context.Rollback();

                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();

                throw new UnhandledBusinessException(ex);
            }

            return result;
        }

        public bool UpdateQueueStatus(EmailQueueDto email, EmailQueueStatus newStatus, int updatedById)
        {
            if (email == null)
            {
                throw new ArgumentNullException(nameof(email));
            }

            return this.Context.EmailQueue.UpdateStatus(email.EmailQueueId, newStatus, updatedById);
        }
    }
}
