﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Security.Principal;

    public interface ISignatureService
    {
        SignatureDto GetLatestSignature(int accountNumber);

        int UploadSignature(int userId, string signatureImage, string name, IPrincipal user);

        SignatureDto GetSignatureById(int id);
    }
}
