﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IExpenseBatchService
    {
        Task<ExpenseBatchDto> GetByIdAsync(int id, bool includeChildren = true);

        Task<Dictionary<ContractTransactionType, decimal>> GetBatchTransactionTypeTotalsAsync(int id);

        Dictionary<ContractTransactionType, decimal> GetBatchTransactionTypeTotals(IList<ContractTransactionDto> contractTransactions);

        Task UpdateNotesAsync(int id, string notes);

        Task<bool> PostBatchAsync(ExpenseBatchDto batch, int? nextCheckSequenceNumber, IPrincipal user);

        Task<IList<BatchSearchResultDto>> GetBatchesByCriteriaAsync(BatchSearchCriteriaDto criteria);

        Task<string> CheckExpensePaymentForWarningsAsync(int expensePaymentId);

        Task<string> CheckExpensePaymentForWarningsAsync(IList<ContractTransactionDto> contractTransactions);

        Task<IList<ExpensePaymentDto>> GetExpensePaymentsByBatchIdAsync(int id);

        Task<ExpenseBatchDto> GetOrCreateIfNotExistsAsync(ExpenseBatchType batchType, bool isManual, IPrincipal user);

        Task<ExpensePaymentDto> GetExpensePaymentByPayeeAsync(int expenseBatchId, int contractEntityTypeId, int contractEntityId);

        Task<ExpensePaymentDto> GetExpensePaymentByReferenceNumberAsync(string referenceNumber);

        Task<ExpensePaymentDto> GetExpensePaymentByReferenceNumberAndAmountAsync(string referenceNumber, decimal amount);

        Task<List<ContractTransactionDto>> GetBatchTransactionsAsync(ExpenseBatchDto batch);

        Task<List<ContractDto>> GetBatchContractsAsync(int expenseBatchId);

        Task CreateExpensePaymentAsync(ExpensePaymentDto payment, IPrincipal user);

        Task UpdateExpensePaymentAsync(ExpensePaymentDto payment, IPrincipal user);

        Task DeleteExpensePaymentAsync(int id, IPrincipal user);

        Task UpdateAsync(ExpenseBatchDto batch, IPrincipal user);

        Task DeletePendingBatchAsync(int id, IPrincipal user);

        Task<ExpenseBatchDto> ResetPendingBatchAsync(int id, IPrincipal user);

        Task<ExpensePaymentDto> RemoveTransactionFromPaymentAsync(int contractTransactionId, int expensePaymentId, IPrincipal user);

        Task<ExpensePaymentDto> GetExpensePaymentByIdAsync(int id);

        Task<IList<ContractTransactionDto>> GetExpensePaymentTransactionsAsync(int id);

        Task<IList<ContractTransactionDto>> GetExpensePaymentTransactionsAsync(int expensePaymentId, ExpenseBatchDto batch);

        Task<decimal> CheckForDeductionAsync(int entityId, decimal amount);

        Task ResolveEscrowDeficiencyAsync(EscrowDeficiencyAction selectedAction, int contractTransactionId, int expensePaymentId, decimal paidAmount, IPrincipal user);

        Task<ExpenseBatchDto> CreateExpenseBatchAsync(ExpenseBatchType batchType, bool sharedBonusOption, bool gasCardOption, bool payNationalsOption, IPrincipal user);

        Task<ExpenseBatchDto> CreateExpenseBatchAsync(CreatePaymentBatchDto options, IPrincipal user);

        Task<ExpenseBatchDto> CreateExpenseBatchForSelectedExpensesAsync(CreatePaymentBatchDto options, IPrincipal user);

        Task<IList<PaymentSearchResultDto>> GetPaymentsByCriteriaAsync(PaymentSearchCriteriaDto criteria);

        Task<List<ExpensePaymentDto>> ProcessExpenseBatchAsync(int expenseBatchId, IEnumerable<ContractTransactionDto> expenses, IEnumerable<ExpensePaymentDto> existingPayments);

        Task<EntitySequenceDto> GetCheckNumberSequenceAsync();

        Task<DateTime> ResendACHNotificationAsync(int id, IPrincipal user);
    }
}
