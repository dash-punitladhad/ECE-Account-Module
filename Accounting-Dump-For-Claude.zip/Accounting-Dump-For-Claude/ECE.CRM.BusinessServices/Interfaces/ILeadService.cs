﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface ILeadService
    {
        Task CreateAsync(LeadDto dto, IPrincipal user);

        Task<LeadDto> GetLeadByIdAsync(int id);

        Task UpdateAsync(LeadDto dto, IPrincipal user);

        Task AssignLeadAsync(LeadDto dto, IList<AppUserDto> carbonCopyUsers, IPrincipal user);

        Task<IList<LeadSearchResultsDto>> GetByCriteriaAsync(LeadSearchCriteriaDto criteria);

        Task<IList<PotentialReferralResultDto>> GetPotentialReferralsAsync(PotentialReferralCriteriaDto criteria);

        LeadDto GetLeadById(int id);

        Task CloseLeadAsync(int leadId, IPrincipal user);

        void CloseLead(int leadId, IPrincipal user);

        Task CreateLeadFromWebDataAsync(string webData);

        Task<bool> CanView(int userId, int leadId);

        Task ToggleArchiveStatusAsync(int leadId, bool isArchived, int updatedBy);

        Task<string> GetByCriteriaExportAsync(LeadSearchCriteriaDto criteriaDto);

        Task<(bool, string, object)> ImportLead(Stream stream, IPrincipal user);

    }
}
