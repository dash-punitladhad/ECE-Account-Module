﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IBlueCardService
    {
        Task<BlueCardDto> GetBlueCardByIdAsync(int id);

        Task<List<BlueCardArtistDto>> GetBlueCardArtistsAsync(int id);

        Task<List<BlueCardArtistDto>> GetBlueCardArtistsDetailAsync(int id);
        Task<List<ContactEmailDto>> GetContactEmailIdAsync(string id);

        Task<List<OfferDto>> GetOffersListByIdAsync(int id);

        Task<bool> CanEditAsync(int userId, int assignedAgentId);

        Task<bool> CanReassignAsync(int userId, int assignedAgentId);

        Task<bool> CanCreatePromoAsync(int userId, int assignedAgentId);

        Task<bool> CanCreateContractAsync(int userId, int assignedAgentId);

        Task<bool> CanOpenCloseAsync(int userId, int assignedAgentId);

        Task<bool> CanSeeNationalArtistPricesAsync(int userId, int assignedAgentId);

        Task UpdateAsync(BlueCardDto dto, IPrincipal user);

        Task UpdateBlueCardPresenterAsync(int blueCardId, int presenterId);

        Task<IList<BlueCardSearchResultsDto>> GetByCriteriaAsync(BlueCardSearchCriteriaDto criteria);

        Task<BlueCardDetailDto> GetBlueCardSearchDetailAsync(int id);

        Task CreateStep1Async(BlueCardDto dto, IPrincipal user);

        Task ToggleBlueCardStatusAsync(int entityId, bool isClosed, int updatedBy, int? blueCardClosedReasonId);

        Task ReassignBlueCardAgentAsync(int entityId, int agentId, IPrincipal user);

        Task ToggleArchiveStatusAsync(int blueCardId, bool isArchived, int updatedBy);

        Task UpdateWizardAsync(BlueCardDto dto, IPrincipal user);

        Task AddBlueCardArtistAsync(BlueCardArtistDto dto, IPrincipal user);

        Task AddBlueCardArtistsAsync(int blueCardId, IList<BlueCardArtistDto> artists, IPrincipal user);

        Task<List<ArtistPortalDto>> GetBlueCardsByArtistIdAsync(int id);

        Task SaveLeadData(BlueCardDto blueCard, LeadDto lead, IPrincipal user);

        void FilterNationalArtistData(BlueCardArtistDto artist);

        Task<BlueCardArtistDto> GetBlueCardArtistAsync(int blueCardArtistId);

        Task<string> GetByCriteriaExportAsync(BlueCardSearchCriteriaDto criteriaDto);

    }
}
