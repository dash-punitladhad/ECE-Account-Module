﻿using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface IImpersonateLogService
	{
		Task CreateAsync(ImpersonateLogDto impersonateLogDto, IPrincipal user);
		Task<List<ImpersonateUsersDto>> GetImpersonateLogListAsync();

		Task<bool> CheckImpersonateLogExistsAsync(ImpersonateLogDto impersonateUsersDto);

		Task<bool> RevereseImpersonateLogAsync(ImpersonateLogDto impersonateLogDto);

		Task UpdateImpersonateLogAsync(ImpersonateLogDto impersonateLogDto);
	}
}
