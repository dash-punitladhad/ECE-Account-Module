﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractChangeNoteHistoryService
    {
        Task<IList<ContractChangeNoteHistoryDto>> GetByContractIdAsync(int ContractId);
        Task<ContractChangeNoteHistoryDto> GetByAsync(int id);
        Task<int> CreateAsync(ContractChangeNoteHistoryDto dto);
        Task<bool> DeleteAsync(int contractChangeNoteHistoryId);
    }
}