﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IAccountingDataService
    {
        Task<IList<MiscArtistPaymentDto>> GetMiscArtistPaymentsAsync(DateTime fromDate, DateTime toDate);

        Task<IList<OutstandingEscrowLoanDto>> GetEscrowLoanBalancesAsync(DateTime fromDate, DateTime toDate);

        Task<IList<BasicAgentSalesStatsDto>> GetBasicAgentSalesStatsAsync(DateTime fromDate, DateTime toDate);

        Task<IList<CollectionsByOfficeDto>> GetCollectionsByOfficeAsync(DateTime fromDate, DateTime toDate,IPrincipal User);

        Task<IList<FeesBreakdownDto>> GetFeesBreakdownAsync(ExportDataCriteriaDto criteria, IList<int> accounts);

        Task<IList<UnpaidCommissionDto>> GetUnpaidCommissionsAsync(DateTime asOfDate);

        Task<IList<FeesBreakdownDto>> GetGLBreakdownAsync(ExportDataCriteriaDto criteria);

        Task<IList<InconsistentGLDto>> GetInconsistentGLContractsAsync(ExportDataCriteriaDto criteria);
    }
}
