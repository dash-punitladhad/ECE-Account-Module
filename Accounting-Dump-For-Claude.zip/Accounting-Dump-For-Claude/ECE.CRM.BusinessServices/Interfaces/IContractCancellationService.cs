﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractCancellationService
    {
        Task<IList<ContractCancellationDto>> GetByContractIdAsync(int contractId);

        Task<IList<ContractCancellationDto>> GetByCancellationReasonIdAsync(int cancellationReasonId);

        Task<IList<ContractCancellationDto>> GetByReplacementContractIdAsync(int replacementContractId);

        Task<ContractCancellationDto> GetByIdAsync(int id);

        Task CreateAsync(ContractCancellationDto dto, IPrincipal user);

        Task UpdateAsync(ContractCancellationDto dto, IPrincipal user);

        Task DeleteAsync(int id);
    }
}
