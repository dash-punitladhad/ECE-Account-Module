﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    /// <summary>
    /// Roles and Permissions Interface.
    /// </summary>
    public interface IRolePermissionService
    {
        /// <summary>
        /// Gets the permissions for user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of ECEPermissions.</returns>
        Task<IList<ECEPermissions>> GetPermissionsForUserAsync(int userId);

        /// <summary>
        /// Gets the roles for user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of AppUserRoles.</returns>
        Task<IList<AppUserRoleDto>> GetRolesForUserAsync(int userId);

        Task<AppUserRoleDto> GetRoleForUserEntity(int userId, ECERole role, int entityId);

        Task<IList<AppUserRoleDto>> GetRolesForUserAsync(int userId, bool includeDeleted);

        Task ToggleUserRoleDeletedStatusAsync(int appUserId, bool markAsDeleted);

        Task CreateAppUserRoleAsync(AppUserRoleDto appUserRole, IPrincipal user);

        Task<int?> GetEntityIdFromRole(int userId, int roleId);

        Task<List<AppUserRoleDto>> SyncRolesAsync(int appUserId, IEnumerable<AppUserRoleDto> updatesRoles, IPrincipal user);

        Task<IList<AppUserRolePermissionDto>> GetUserRolePermissionsAsync(int userId);

        Task<IList<ECERoleDto>> GetAllRolesAsync(bool? isActive = null);

        Task<IList<AppUserDto>> GetUsersForRoleAsync(int roleId);

        Task<IList<ECEPermissions>> GetPermissionsForRoleAsync(int roleId);

        Task<IList<ECEPermissionDto>> GetAllPermissionsAsync();

        Task<IList<ECERoleDto>> GetRolesForPermissionAsync(int permissionId);

        Task<IList<AppUserDto>> GetUsersForPermissionAsync(int permissionId);

        Task<IList<RolePermissionDto>> GetAllRolePermissionsAsync();
    }
}
