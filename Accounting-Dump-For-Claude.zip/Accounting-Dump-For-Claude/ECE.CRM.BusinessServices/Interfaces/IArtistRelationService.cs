﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistRelationService
    {
        Task<List<ArtistDto>> GetAsync(int id);

        Task CreateAsync(int id, int relatedArtistId, IPrincipal user);

        Task DeleteAllAsync(int id, IPrincipal user);

        Task<List<int>> GetIdsAsync(int id);
    }
}