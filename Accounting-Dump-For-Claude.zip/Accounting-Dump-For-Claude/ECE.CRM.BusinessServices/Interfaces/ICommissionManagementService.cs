﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface ICommissionManagementService
    {
        // Agent Commissions
        Task<IEnumerable<CommissionManagementSearchResultDto>> GetAgentCommissionsByCriteriaAsync(CommissionManagementSearchCriteriaDto criteria);

        Task<AgentCommissionDto> GetAgentCommissionByAgentIdAsync(int id, bool includeChildren = false);

        Task ChangeCommissionTypeAsync(int agentId, AgentCommissionType newCommissionType, IPrincipal user);

        // Mentors
        Task UpdateMentorAsync(AgentCommissionDto data, IPrincipal user);

        // Commission Tiers
        Task<IEnumerable<AgentCommissionTypeDataDto>> GetTypeDataByAgentCommissionIdAsync(int id);

        Task AddTierAsync(int agentId, AgentCommissionTypeDataDto dto, IPrincipal user);

        Task UpdateTierAsync(int agentId, AgentCommissionTypeDataDto dto, IPrincipal user);

        Task DeleteTierAsync(int agentId, int agentCommissionTypeDataId, IPrincipal user);

        // Presenter Transfers
        Task<IEnumerable<AgentCommissionProgramDto>> GetPresenterTransfersByAgentIdAsync(int id);

        Task<AgentCommissionProgramDto> GetPresenterTransferAsync(int presenterId);

        Task AddPresenterTransferAsync(AgentCommissionProgramDto dto, IPrincipal user);

        Task UpdatePresenterTransferAsync(AgentCommissionProgramDto dto, IPrincipal user);

        Task DeletePresenterTransferAsync(int presenterId, IPrincipal user);
    }
}
