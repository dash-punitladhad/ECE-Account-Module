﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IMessageService
    {
        Task<int> CreateAsync(MessageDto dto, IPrincipal user);

        Task<int> CreateAsync(MessageDto dto, int? carbonCopyId, IPrincipal user);

        Task<int> CreateAsync(MessageDto dto, List<int> carbonCopyId, IPrincipal user);

        Task<List<MessageDto>> GetContractMessagesByUserId(int userId, bool unreadOnly = false);

        Task<List<MessageDto>> GetContractMessageHistoryAsync(int contractId);

        Task DeleteAsync(int id, IPrincipal user);

        Task MarkAsReadAsync(int id, IPrincipal user);

        Task<MessageDto> GetByIdAsync(int id);

        Task<IList<AppUserDto>> GetContractMessagesUsersAsync(int contractId);

        Task<MessageDto> GetCarbonCopyAsync(MessageDto dto);

        Task<bool> CreateExclusiveArtistAsync(int artistId, IPrincipal user, bool isExclusive);
    }
}
