﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IVendorService
    {
        Task<VendorDto> GetByIdAsync(int id);

        Task<IList<VendorDto>> GetByCharsAsync(string chars);

        Task<IList<VendorDto>> GetByCriteriaAsync(VendorSearchCriteriaDto criteria);

        Task<bool> CheckForDuplicatesAsync(int vendorId, string vendorName);

        Task CreateAsync(VendorDto dto, IPrincipal user);

        Task UpdateAsync(VendorDto dto, IPrincipal user);

        Task DeleteAsync(int id);

        Task UpdateNotesAsync(int id, string notes);
    }
}
