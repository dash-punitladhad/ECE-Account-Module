namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.DataTransferObjects.ContractDetails;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using System.Web;

    public interface IContractService
    {
        decimal GetRequiredAmount(ContractTransactionType contractTransactionType);

        ContractTransactionDto CreateECEExpense(ContractDto contract, ContractTransactionType contractTransactionType);

        ContractTransactionDto CreateCommission(int appUserId, decimal? percentage = null);

        Task<IEnumerable<ContractDto>> GetByAgentIdAsync(int agentId);

        Task<ContractDto> GetByIdAsync(int id, bool includeChildren = false);

        Task<IEnumerable<ContractSearchResultDto>> GetByCriteriaAsync(ContractSearchCriteriaDto criteria);

        Task<ContractSearchResultDetailDto> GetContractSearchDetailAsync(int id);

        Task CreateAsync(ContractDto dto, IPrincipal user);

        Task<ContractDto> CreateFromBlueCardAsync(int blueCardId, IPrincipal user);

        Task<ContractDto> CreateFromPresenterAsync(int presenterId, IPrincipal user);

        Task UpdateAsync(ContractDto dto, IPrincipal user);

        Task InitializeAsync(int id, IPrincipal user);

        Task<IssueContractResponseDto> IssueAsync(IssueContractDto dto, IPrincipal user, bool isPandadoc = false);

        Task<bool> CheckCanEditAsync(int contractId, int userId);

        Task<bool> CanViewAsync(ContractDto contract, IPrincipal user);

        Task<bool> CanViewDepositsAsync(ContractDto contract, IPrincipal user);

        bool HasEditPermission(int agentId, IPrincipal user);

        bool HasEditableStatus(ContractDto dto);

        bool CanModifyContractFees(IPrincipal user);

        Task<bool> HasEditableStatusAsync(ContractDto dto, int userId);

        bool CanUpdateGross(ContractDto dto, IPrincipal user);

        bool CanUpdateOriginalGross(ContractDto dto, IPrincipal user);

        bool CanFullyCancel(ContractDto dto, IPrincipal user);

        Task<bool> CanPartiallyCancelAsync(ContractDto dto, IPrincipal user);

        bool CanReinstate(ContractDto dto, IPrincipal user);

        bool CanRequestCancellation(ContractDto dto, IPrincipal user);

        Task RequestCancellationAsync(ContractDto dto, string cancellationReason, IPrincipal user);

        ContractDto GetProgressAsync(ContractDto dto);

        Task CompleteCreationAsync(int contractId, IPrincipal user, PandaDocRequestContractInfoDto contractDetailsModel = null,bool onIssue = false);

        ContractDto GetTotalGrossAndCommission(ContractDto contract);

        Task UpdateGrossAsync(ContractDto dto, decimal newGross, decimal? newOriginalGross, IPrincipal user);

        Task UpdateNotesAsync(int contractId, string notes);

        Task UpdateCanceledContractAsync(ContractCancellationDto dto, IPrincipal user);

        Task CancelContractAsync(ContractCancellationDto dto, IPrincipal user);

        Task<ContractDto> CloneContractAsync(int contractId, bool cloneMoney, IPrincipal user);

        Task GenerateRefundAsync(int contractId, IPrincipal user);

        Task<bool> CanIssue(ContractDto contract, IPrincipal user);

        Task CreateTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user);

        Task UpdateTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user);

        Task<bool> CheckArtistNetAsync(ContractTransactionDto dto);

        void SetTransactionPayeeName(ContractDto contract, ContractTransactionDto dto);

        Task DeleteTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user);

        Task<ContractTransactionDto> PrepTransactionForSaveAsync(ContractTransactionDto dto, IPrincipal user, bool update = false);

        Task ReinstateAsync(int contractId, IPrincipal user);

        Task<ContractDto> GetContractByUrlKeyAsync(string key, bool includeChildren = true);

        Task<IList<ContractDocumentDto>> GetAvailableRidersForContractAsync(int contractId);

        Task<string> GetContractEntityName(int entityId, int entityTypeId, ContractDto contract);

        Task<ContractMiniDetailDto> GetContractMiniDetailsAsync(int contractId);

        Task<PresenterPortalDto> CreatePresenterPortalAsync(ContractDto contract, IPrincipal user);

        Task<IList<ContactStatusDto>> GetContractStatusValues(int[] contractIds);

        Task UpdateArtistPickupAmountsAsync(ContractTransactionDto dto, IPrincipal user);

        Task UpdateArtistPickupAmountsAsync(ContractDto dto, IPrincipal user);

        Task<bool> CanReverseReapplyGLEntriesAsync(ContractDto dto);

        Task ReassignAgentAsync(ContractDto dto, int newAgentId, IPrincipal user);

        Task ReassignOfficeLOBAsync(ContractDto dto, bool reverseReapplyGeneralLedger, IPrincipal user);

        Task ToggleArchiveStatusAsync(int contractId, bool isArchived, int updatedBy);

        Task ToggleProblemContractStatusAsync(int contractId, bool status, int updatedBy);
        Task ToggleAgentAttendContractStatusAsync(int contractId, bool status, int updatedBy);

        Task SendArtistGreenCardEmailAsync(ContractDto contract, IList<ContractArtistContactDto> contacts, IPrincipal user);
        Task<string> GetByCriteriaExportAsync(ContractSearchCriteriaDto criteriaDto);

        Task<(bool, bool)> CanViewAgentPayHistoryAsync(ContractDto contract, IPrincipal user);
        Task<bool> ProcessAddendumAsync(int referenceId, string description, bool isResend, IPrincipal user, bool autoApprove = false);
        Task<List<ContractVersionDetailDto>> GetContractVersionDetails(int contractId);
        Task<List<string>> SaveAttachmentFilesAsync(List<HttpPostedFileBase> postedFileBases);
        Task<PresenterPortalDto> GetPresenterPortalAsync(int contractId);
        Task UpdateContractTermsCondition(ContractDto contract);

    }
}
