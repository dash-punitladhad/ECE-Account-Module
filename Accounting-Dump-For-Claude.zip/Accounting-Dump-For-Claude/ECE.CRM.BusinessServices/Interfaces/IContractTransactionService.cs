namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractTransactionService
    {
        Task<IList<ContractTransactionDto>> GetByContractIdAsync(int contractId);

        IList<ContractTransactionDto> FilterAdditionalExpenses(IList<ContractTransactionDto> transactions);

        IList<ContractTransactionDto> FilterDueDeposits(IList<ContractTransactionDto> transactions);

        IList<ContractTransactionDto> FilterDeposits(IList<ContractTransactionDto> transactions, int contractEntityTypeId, int contractEntityId);

        IList<ContractTransactionDto> FilterCommissions(IList<ContractTransactionDto> transactions);

        Task<ContractTransactionDto> GetByIdAsync(int id);

        Task<ContractTransactionDto> GetByIdWithAuditInfoAsync(int id);

        Task<ContractTransactionDto> CreateAsync(ContractTransactionDto dto, IPrincipal user);

        Task UpdateAsync(ContractTransactionDto dto, IPrincipal user);

        Task<IList<ContractTransactionDto>> GetPayableByContractTransactionTypeAsync(ContractTransactionType type);

        Task<IList<ContractTransactionDto>> GetOtherPayableArtistTransactionsAsync();

        Task<IList<ContractTransactionDto>> GetPayableOtherExpensesAsync();

        Task<IList<ContractTransactionDto>> GetByExpenseBatchIdAsync(int id);

        Task<IList<ContractTransactionDto>> GetByExpensePaymentIdAsync(int id);

        Task<IList<ContractTransactionDto>> GetByExpensePaymentIdsAsync(int[] ids);

        Task<IList<ContractTransactionViewDto>> GetViewByExpenseBatchIdAsync(int id);

        Task DeleteAsync(int id, IPrincipal user, bool removeTransaction = false);

        Task RemoveFromPaymentAsync(ContractTransactionDto dto, IPrincipal user);

        Task UpdateExpensePaymentStatusAsync(ContractTransactionDto dto, ExpensePaymentStatus newStatus, IPrincipal user);

        Task<IList<string>> CheckTransactionForWarningAsync(int id);

        Task<IList<string>> CheckTransactionForWarningAsync(ContractTransactionDto contractTransaction);

        Task<ContractTransactionExpensePaymentDto> GetExpensePaymentDataAsync(ContractTransactionDto contractTransaction);

        Task<IList<ContractTransactionExpensePaymentDto>> GetExpensePaymentDataForPaymentAsync(int expensePaymentId);

        Task<IList<ContractTransactionExpensePaymentDto>> GetExpensePaymentDataForBatchAsync(int expenseBatchId);

        Task<EditTransactionsOnMoneyScreen> CanEditTransactionsOnMoneyScreenAsync(ContractDto dto, IPrincipal user, bool includeHasDepositsCheck = true);

        bool HasAtLeastOneDeposit(ContractDto dto);

        Task<bool> HasPermissionAsync(ContractDto dto, IPrincipal user);

        Task<IEnumerable<ContractTransactionDto>> GetByCriteriaAsync(ContractTransactionSearchCriteriaDto dto);

        IList<LookupDto> GetPayeeTypes(ContractDto dto);

        Task MarkToBePaidAsync(IList<int> idsToPay, IPrincipal user, bool setDueDateToToday = true);

        Task ToggleExpenseApprovalAsync(int contractTransactionId, bool canRelease, IPrincipal user);

        Task<IList<ContractTransactionDto>> GetByArtistIdAsync(int artistId, int contractId);

        Task<IList<ContractTransactionDto>> GetEceContractTransactionsAsync(int contractId, List<int> contractTransactionTypes);

        Task ShiftArtistPaymentDueDatesAsync(int contractId, TimeSpan delta, IPrincipal user);

        bool HasUnpaidDeposits(ContractDto contract);
        void SynchronizePaidDate(ContractTransactionDto dto, DateTime? paidDate = null);
    }
}