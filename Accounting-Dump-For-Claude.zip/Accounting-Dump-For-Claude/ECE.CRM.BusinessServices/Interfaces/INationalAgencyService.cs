﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface INationalAgencyService
    {
        Task<List<NationalAgencyDto>> GetByCharsAsync(string chars);

        Task<NationalAgencyDto> GetByIdAsync(int id);

        Task CreateAsync(NationalAgencyDto dto, IPrincipal user);

        Task UpdateAsync(NationalAgencyDto dto, IPrincipal user);

        Task<IList<NationalAgencySearchResultDto>> GetByCriteriaAsync(NationalAgencySearchCriteriaDto criteria);

        Task<IList<NationalAgencyDto>> GetAllAsync();
    }
}
