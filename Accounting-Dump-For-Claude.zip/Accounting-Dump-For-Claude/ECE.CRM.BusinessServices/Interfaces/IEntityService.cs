﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IEntityService
    {
        Task ToggleEntityActiveStatusAsync(int entityId, bool isActive, int updatedBy, EntityType entityType, int? blueCardClosedReasonId);

        Task ReassignEntityAgentAsync(int entityId, int agentId, EntityType entityType, IPrincipal user);

        Task ToggleEntityArchiveStatusAsync(int entityId, bool isArchived, int updatedBy, EntityType entityType);

        Task ToggleProblemContractStatusAsync(int entityId, bool isExcluded, int updatedBy, EntityType entityType);
        Task ToggleAgentAttendContractStatusAsync(int entityId, bool isExcluded, int updatedBy, EntityType entityType);
    }
}
