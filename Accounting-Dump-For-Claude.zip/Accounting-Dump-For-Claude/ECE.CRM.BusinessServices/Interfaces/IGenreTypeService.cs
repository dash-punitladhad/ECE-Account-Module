﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IGenreTypeService<T>
        where T : BaseGenreTypeDto, new()
    {
        Task<IList<T>> GetChildrenAsync(int id);

        Task SyncChildrenAsync(int parentId, IEnumerable<string> selectedChildren);

        Task SyncChildrenAsync(int parentId, IEnumerable<int> selectedChildren);
    }
}
