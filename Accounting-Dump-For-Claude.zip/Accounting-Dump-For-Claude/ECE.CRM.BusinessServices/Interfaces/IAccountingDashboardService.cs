﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IAccountingDashboardService
    {
        Task<IList<OfficeRevenueDto>> GetOfficeRevenueAsync(int year, int month);

        Task<ExpenseSummaryDto> GetExpenseSummaryAsync();

        Task<ArtistsMissingW9Dto> GetArtistsMissingW9Async();

        Task<ContractSummaryDto> GetContractSummaryAsync();
    }
}
