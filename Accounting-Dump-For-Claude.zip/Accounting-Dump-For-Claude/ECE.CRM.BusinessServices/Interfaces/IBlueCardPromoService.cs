﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;


	public interface IBlueCardPromoService
    {
        Task<BlueCardPromoDto> GetBlueCardPromoByIdAsync(int id);

        Task<BlueCardPromoDto> GetBlueCardPromoByUrlKeyAsync(string key,bool trackPageView = false,bool isMobile=false,string browserName="",string ipAddress="");

        Task<int> CreateOrUpdateBlueCardPromoAsync(BlueCardPromoDto dto, IPrincipal user);

        Task<int> SendPromoAsync(BlueCardPromoDto dto, IPrincipal user);

        Task<TemplateMailMessage> GeneratePromoEmailAsync(BlueCardPromoDto dto, BlueCardPromoDto originalDto, bool preview = false);

        string GeneratePromoLinkUrl(string key);

        Task<IList<BlueCardPromoArtistDto>> GetArtistsByUrlKeyAsync(string key);

        Task<IList<WebLinkDto>> GetWebLinksAsync(int artistId, string key);

        Task<IList<DocumentDto>> GetDocumentsAsync(int artistId, string key);

        IList<DocumentDto> FilterDocuments(IList<DocumentDto> documents);

        Task BookArtistAsync(int blueCardPromoId, int artistId);

        Task AddPromoViewDeviceLogAsync(PromoViewDeviceLogDto viewDeviceLogDto);

    }
}