﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistGoalsService
    {
        Task<IList<ArtistGoalDto>> GetArtistGoalsAsync(int artistId, int numOfYears);

        Task CreateArtistGoalAsync(ArtistGoalDto goal);

        Task UpdateArtistGoalAsync(ArtistGoalDto goal);

        Task<IList<ArtistBookingsDto>> GetArtistBookingsAsync(int artistId, int? year);

        Task<IList<ArtistYtdAgentBookingsDto>> GetAgentBookingsForArtistAsync(int artistId);

        Task<bool> VerifyCanEditArtistGoal(IPrincipal user, ArtistGoalDto goal);
    }
}
