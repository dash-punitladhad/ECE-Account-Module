﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IMarketingService
    {
        Task<IList<LineOfBusinessActivityDto>> GetLineOfBusinessActivityAsync(DateTime? startDate = null, DateTime? endDate = null);

        Task<IList<LeadSourceActivityDto>> GetLeadSourceActitvtyAsync(
            DateTime? startDate = null,
            DateTime? endDate = null,
            int? eventTypeId = null);

        Task<IList<EntityActivityDto>> GetOfficeActivityAsync(
            DateTime? startDate = null,
            DateTime? endDate = null,
            int? eventTypeId = null);

        Task<IList<EntityLocationDto>> GetContractVenueActivityAsync(DateTime startDate, DateTime endDate, int? eventTypeId = null);

        Task<IList<ArtistBookingCostStatsDto>> GetArtistPricingFrequencyAsync(
            DateTime startDate,
            DateTime endDate,
            int officeId,
            int eventTypeId,
            bool? isExclusive);
    }
}
