﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Threading.Tasks;

    public interface IUrlKeyAuthService
    {
        Task<bool> EntityIsRelatedToUrlKey(UrlKeyRelatedEntityDto relatedEntity);
    }
}
