﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface ITINHistoryService
    {
        Task CreateTINHistoryAsync(TINHistoryDto history, IPrincipal user);

        Task CreateTINHistoryAsync(ITen99EntityDto dto, IPrincipal user);

        Task<IList<TINHistoryDto>> GetByTen99EntityAsync(ITen99EntityDto dto);
    }
}
