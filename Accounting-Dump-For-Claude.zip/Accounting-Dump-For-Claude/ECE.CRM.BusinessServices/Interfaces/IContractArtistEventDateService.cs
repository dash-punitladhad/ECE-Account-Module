﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IContractArtistEventDateService
    {
        Task<IList<ContractArtistEventDateDto>> GetByContractArtistIdAsync(int contractArtistId);

        Task<IList<ContractArtistEventDateDto>> GetByContractEventDateIdAsync(int contractEventDateId);

        Task<ContractArtistEventDateDto> GetByIdAsync(int id);

        Task CreateAsync(ContractArtistEventDateDto dto);

        Task UpdateAsync(ContractArtistEventDateDto dto);

        Task DeleteAsync(int id);
    }
}
