﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface INationalArtistContactService
    {
        Task<IList<NationalArtistContactDto>> GetByNationalArtistAsync(int nationalArtistId);

        /// <summary>
        /// Returns list of all contacts for a national agency, with associated info for a national artist.</summary>
        /// <returns>List of NationalArtistContacts</returns>
        /// <param name="nationalAgencyId">The id of the national agency.</param>
        /// <param name="nationalArtistId">The id of the national artist.</param>
        Task<IList<NationalArtistContactDto>> GetByAgencyAndArtistAsync(int nationalAgencyId, int? nationalArtistId);

        Task CreateAsync(NationalArtistContactDto dto, IPrincipal user);

        Task UpdateAsync(NationalArtistContactDto dto, IPrincipal user);

        Task HardDeleteAsync(NationalArtistContactDto dto);
    }
}
