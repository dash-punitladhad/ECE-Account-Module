﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IRouteBookService
    {
        Task<List<LocationDto>> GetPresentersWithinDistanceAsync(RouteBookSearchCriteriaDto dto);

        Task<List<LocationDto>> GetVenuesWithinDistanceAsync(RouteBookSearchCriteriaDto dto);

        Task<List<LocationDto>> GetLocationsBetweenDatesAsync(RouteBookSearchCriteriaDto dto);

        Task<List<RouteBookSearchResultsDto>> GetByCriteriaAsync(RouteBookSearchCriteriaDto criteria);

        Task<List<RouteBookSearchResultsDto>> GetRouteBookDatesAsync(List<RouteBookSearchResultsDto> searchResults, DateTime startDate, DateTime endDate);

        Task<IList<EventDetailDto>> GetEventDetailAsync(int id, DateTime eventDate);

        Task<IList<EventDetailDto>> GetEventDetailArtistPortalAsync(int id, DateTime eventDate);

        Task AddArtistItemAsync(RouteBookArtistDto dto, IPrincipal user);

        Task<List<RouteBookGridDto>> GetGridsForAgentAsync(int id);

        Task<List<RouteBookSearchResultsDto>> GetByGridIdAsync(int id);

        Task<List<RouteBookSearchResultsDto>> GetByOfficeIdAsync(int id);

        Task<List<RouteBookSearchResultsDto>> GetExclusiveAsync();

        Task<List<RouteBookSearchResultsDto>> GetMineAsync(int id);

        Task CreateCustomGridAsync(RouteBookGridDto dto, List<RouteBookArtistDto> artistDtos, IPrincipal user);

        Task DeleteCustomGridAsync(int id, IPrincipal user);

        Task AddArtistsToGridAsync(RouteBookArtistDto dto, IPrincipal user);

        Task<RouteBookSearchResultsDto> GetRouteBookDetailsAsync(RouteBookSearchResultsDto artist, int month, int year);

        Task<RouteBookSearchResultsDto> GetRouteBookDetailsArtistPortalAsync(RouteBookSearchResultsDto artist, int month, int year);

        Task<string> GetByCriteriaExportAsync(RouteBookSearchCriteriaDto criteriaDto);
    }
}