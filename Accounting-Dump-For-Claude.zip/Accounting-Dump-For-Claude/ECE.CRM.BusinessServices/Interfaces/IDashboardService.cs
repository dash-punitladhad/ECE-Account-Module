﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IDashboardService
    {
        Task<IList<RankedAgentDto>> GetTopAgentsByTransactionsAsync(
            int transactionType,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<decimal> GetBlueCardConversionRateByAgentAsync(
            int agentId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<decimal> GetAverageContractGrossByAgentAsync(
            int agentId,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<string>> GetTopArtistsByAgentAsync(
            int agentId,
            int numberOfTopArtists,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypeByAgentAsync(
            int agentId,
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<UpcomingEventWidgetDto>> GetEventsByCriteriaAsync(
            int? agentId = null,
            int? officeId = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            bool? isPublic = null,
             List<int> userOffices = null,
            bool includeCreated = false);

        Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypesByOfficeAsync(
            int officeId,
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypesAsync(
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<AgentStatsDto> GetStatsByAgentAsync(int agentId);

        Task<IList<SalesPerformanceDto>> GetSalesPerformanceStatsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            int officeId,
            IList<int> contractStatusesForSales = null,
            IList<int> contractStatusesForCollections = null);

        Task<IList<BusinessPerformanceDto>> GetBusinessPerformanceAsync(
            DateTime startDate,
            DateTime endDate,
            int officeId,
            IList<int> contractStatuses = null);

        Task<IList<SalesPerformanceDto>> GetCompanySalesPerformanceStatsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            IList<int> contractStatusesForSales = null,
            IList<int> contractStatusesForCollections = null);

        Task<IList<BusinessPerformanceDto>> GetCompanyBusinessPerformanceStatsAsync(
            DateTime startDate,
            DateTime endDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate);

        Task<ConversionStatsDto> GetOfficeConversionStatsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<ConversionStatsDto> GetCompanyConversionStatsAsync(DateTime? startDate = null, DateTime? endDate = null);

        Task<ContractStatsDto> GetOfficeContractStatsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<ContractStatsDto> GetCompanyContractStatsAsync(DateTime? startDate = null, DateTime? endDate = null);

        Task<IList<BlueCardClosureReasonDto>> GetOfficeBlueCardClosuresAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<OfficeCollectionDto>> GetOfficeCollectionsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<OfficeCollectionDto>> GetCompanyCollectionsAsync(DateTime? startDate = null, DateTime? endDate = null);

        Task<IList<OfficeCollectionDto>> GetOfficeSalesAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<OfficeCollectionDto>> GetCompanySalesAsync(DateTime? startDate = null, DateTime? endDate = null);

        Task<IList<StalePresenterDto>> GetOfficeStalePresentersAsync(int officeId, DateTime? staleDate = null);

        Task<IList<StalePresenterDto>> GetAgentStalePresentersAsync(int agentId, DateTime? staleDate = null);

        Task<IList<TopAgentDto>> GetTopAgentsSalesAndCollectionsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            int? officeId = null);

        Task<IList<AgentPerformanceStatsResultDto>> GetAgentPerformanceStatsAsync(AgentPerformanceStatsCriteriaDto criteria);

        Task<IList<AgentPerformanceSummaryResultDto>> GetAgentPerformanceSummaryAsync(AgentPerformanceSummaryCriteriaDto criteria);

        Task<IList<AgentPerformanceSummaryResultDto>> GetAgentPerformanceByContractOfficeAsync(AgentPerformanceSummaryCriteriaDto criteria);

        Task<IList<AgentPerformanceRankDto>> GetAgentPerformanceRankAsync(DateTime startDate,
            DateTime endDate);

        Task<IList<SalesCollectionsResultDto>> GetSalesCollectionsAsync(SalesCollectionsCriteriaDto criteria);
        Task<RolesAndUsersDto> GetAllRolesAndUsers();
        Task<RolesAndUsersDashboardWiseDto> GetAllRolesAndUsersDashboardWise(long id);
        Task<string> GetDashboardModifyUrl(long id, IPrincipal user);

        Task<List<EntityReminderModelDto>> GetEntityReminderBothTypeByCriteriaAsync(int userId, int? reminderDate = null, int? entityTypeId = null, int? entityId = null, bool isAssigner = true);

        Task<List<EntityReminderModelDto>> GetEntityReminderEntityWiseByCriteriaAsync(EntityReminderEntityWiseCriteriaDto model);

        Task<string> BuildCriteriaWhereClause(
            int? agentId = null,
            int? officeId = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            bool? isPublic = null,
            List<int> userOffices = null,
            bool includeCreated = false);
        Task<RolesAndUsersBIDashboardDto> GetAllRolesAndUsersBIDashboard();
        Task<RolesAndUsersBIDashboardWiseDto> GetAllRolesAndUsersBIDashboardWise(int id);
        Task<EmbedInfoDto> GetEmbedInfo(Guid workspaceId, Guid reportId, IPrincipal user);

        Task<IEnumerable<UnpaidExpense_ContractDto>> GetAllUnpaidContractExpenses(IPrincipal user,int roleId,int officeId,int agentId);
        Task<IEnumerable<UnpaidExpense_ContractDto>> GetAllUnpaidContractExpensesExport(IPrincipal user, int roleId, int officeId,int agentId);
        Task<List<PresenterWeddingQuestionnaireDto>> GetPresenterWeddingQuestionnaireAsync(int userId);
        Task<UsersFeatureFlagDto> GetAllUsersFeatureFlag();
        Task<UsersFeatureFlagWiseDto> GetAllUsersFeatureFlagWise(int id);
    }
    
}
