﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IExpensePaymentService
    {
        Task<ExpensePaymentDto> GetByIdAsync(int id);

        Task CreateAsync(ExpensePaymentDto payment, IPrincipal user);

        Task DeleteAsync(ExpensePaymentDto payment, IPrincipal user);

        Task UpdateAsync(ExpensePaymentDto payment, IPrincipal user);

        Task UpdatePendingExpensePaymentAsync(ContractTransactionDto dto, IPrincipal user);

        Task UpdatePendingExpensePaymentAsync(
            int expensePaymentId,
            IEnumerable<ContractTransactionDto> paymentTransactions,
            IPrincipal user,
            UpdatePendingExpensePaymentOptions options = UpdatePendingExpensePaymentOptions.Default);

        Task<ExpensePaymentDto> RemoveTransactionFromPaymentAsync(int contractTransactionId, int expensePaymentId, IPrincipal user);

        Task<ExpensePaymentDto> RemoveLoanRepaymentFromPaymentAsync(int artistChargeTransactionId, int expensePaymentId, IPrincipal user);

        Task<ExpensePaymentDto> RemoveCrossDeductionFromPaymentAsync(int contractDepositId, int expensePaymentId, IPrincipal user);

        Task<IList<ExpensePaymentDto>> GetByPayeeAndYearAsync(int contractEntityTypeId, int contractEntityId, int year);

        Task AddOneTimeChargeAsync(ArtistChargeDto artistCharge, int expensePaymentId, IPrincipal user);

        Task UpdatePresenterRefundAsync(PresenterRefundDto refund, int expensePaymentId, IPrincipal user);
    }
}
