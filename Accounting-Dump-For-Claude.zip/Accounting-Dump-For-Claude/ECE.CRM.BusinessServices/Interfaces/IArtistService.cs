﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistService
    {
        Task CreateAsync(ArtistDto dto, IPrincipal user);

        Task<IList<ArtistSearchResultsDto>> GetByCriteriaAsync(ArtistSearchCriteriaDto criteria);

        Task<ArtistDto> GetArtistByIdAsync(int id);

        bool CanUseDirectDeposit(ArtistDto dto);

        Task<List<ArtistDto>> GetArtistsByCharsAsync(string chars);

        Task<List<ArtistDto>> GetArtistsByCharsWithExcludedValuesAsync(string chars, List<int> excludedValues);

        bool CanEdit(IPrincipal user, int? assignedAgentId, bool isExclusive, bool checkAccountingRoles = false);

        Task<bool> CanAddArtistFeedbackAsync(IPrincipal user, int? assignedAgentId, bool checkAccountingRoles = false);

        Task<bool> CanEditAsync(IPrincipal user, int? assignedAgentId, bool isExclusive, bool checkAccountingRoles = false);

        Task<bool> CanEditPricingAsync(ArtistDto artist, IPrincipal user);

        Task<bool> CanEditPricingAsync(int userId, int artistId);

        Task ToggleArtistStatusAsync(int artistId, bool isActive, int updatedBy);

        Task ReassignArtistAgentAsync(int artistId, int agentId, IPrincipal user);

        Task ToggleArchiveStatusAsync(int artistId, bool isArchived, int updatedBy);

        Task<bool> CheckForDuplicates(string artistName);

        Task<ArtistPitchMetricsDto> GetPitchMetricsAsync(int id, DateTime asOfDate);

        Task<IList<ArtistPricingDto>> GetArtistPricingsByIdAsync(int id);

        DateTime? GetPricingLastUpdateDate(IList<ArtistPricingDto> prices);

        Task CreatePricingAsync(ArtistPricingDto pricing, IPrincipal user);

        Task<ArtistPricingDto> GetPricingByIdAsync(int id);

        Task UpdatePricingAsync(ArtistPricingDto pricing, IPrincipal user);

        Task DeletePricingAsync(ArtistPricingDto pricing, IPrincipal user);

        Task AuditUpdatedEntity(ArtistDto original, ArtistDto updated, IPrincipal user, string changePrograms);

        Task UpdateAsync(ArtistDto dto, IPrincipal user, bool canUpdateAccounting = false);

        Task<ICollection<GenreTypeDto>> GetGenreTypesByArtistAsync(int id);

        Task<ICollection<ActTypeDto>> GetActTypesByArtistAsync(int id);

        Task<ICollection<EventTypeDto>> GetEventTypesByArtistAsync(int id);

        Task<ICollection<ProgramDto>> GetProgramsByArtistAsync(int id);

        Task<List<ArtistPriceHistoriesDto>> GetPriceHistoryByArtistAsync(int id);

        Task<IList<NationalArtistSearchResultDto>> GetNationalArtistsByCriteriaAsync(NationalArtistSearchCriteriaDto criteria);

        Task<List<ArtistBookDateDto>> GetBookedDatesAsync(int id);

        Task<List<ArtistBookDateDto>> GetBookedDatesAsync(int id, IList<DateTime> dates);

        Task CreatePortalAccessUserAsync(AppUserDto appUser, int artistId, IPrincipal user);

        Task LinkPortalAccessUserAsync(AppUserDto appUser, int artistId, IPrincipal user);

        Task ResetArtistUserAsync(int artistId, IPrincipal user);

        Task<bool> SendArtistPortalWelcomeEmailAsync(int appUserId);

        Task<IList<ArtistDto>> GetArtistsForUserAsync(int appUserId);

        Task<List<TiersMasterDto>> GetAllTier(string amount, int? contractId = 0);
        Task<(string, string)> GetByCriteriaExportAsync(ArtistSearchCriteriaDto criteria);
        Task<string> GetNationalArtistsByCriteriaExportAsync(NationalArtistSearchCriteriaDto criteria);
    }
}