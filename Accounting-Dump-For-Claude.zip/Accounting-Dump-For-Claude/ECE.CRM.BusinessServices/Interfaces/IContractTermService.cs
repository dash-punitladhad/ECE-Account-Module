﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractTermService
    {
        Task<IList<ContractTermDto>> GetByContractIdAsync(int contractId, bool isActive = true);

        Task<IList<ContractTermDto>> GetByTermIdAsync(int termId);

        Task<ContractTermDto> GetByIdAsync(int id);

        Task CreateAsync(ContractTermDto dto, IPrincipal user);

        Task UpdateAsync(ContractTermDto dto, IPrincipal user);

        Task DeleteAsync(int id);
    }
}
