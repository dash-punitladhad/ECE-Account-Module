﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IArtistPortalService
    {
        Task<bool> CanReadAsync(int userId, int artistId);

        Task<bool> CanReadContractDocument(ContractDocumentDto contractDocument, int userId);

        Task<List<ArtistPortalBookDateDto>> GetBookedDatesForPortalAsync(int id);

        Task<IList<ArtistPortalActionDto>> GetArtistActionsNeededAsync(int artistId);
    }
}