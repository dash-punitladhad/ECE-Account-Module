﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IVenueService
    {
        Task<int> CreateAsync(VenueDto venue, IPrincipal user);

        Task<List<VenueDto>> GetVenuesByCharsAsync(string chars);

        VenueDto GetVenueById(int id, bool includeChildren);

        Task<List<VenueDescriptionDto>> GetVenueTypesByVenueAsync(int id);

        Task<List<VenueActTypeDto>> GetVenueActTypesByVenueAsync(int id);

        Task<VenueDto> GetVenueByIdAsync(int id, bool includeChildren);

        Task UpdateAsync(VenueDto dto, IPrincipal user);

        Task<bool> CanEditAsync(int userId);

        Task<IList<VenueSearchResultDto>> GetVenueByCriteriaAsync(VenueSearchCriteriaDto criteria);

        Task ToggleVenueStatusAsync(int venueId, bool isActive, int updatedBy);

        Task ReassignVenueAgentAsync(int venueId, int agentId, IPrincipal user);

        Task ToggleArchiveStatusAsync(int venueId, bool isArchived, int updatedBy);

        Task<List<VenueBookDateDto>> GetBookedDatesAsync(int venueId);

        Task<ICollection<VenueGenreTypeDto>> GetVenueGenreTypesByVenueAsync(int id);

        Task CreateSimilarVenueAlertAsync(int id, IPrincipal user);
        Task<(string, string)> GetVenueByCriteriaExportAsync(VenueSearchCriteriaDto criteria);
        Task<(bool, string, object)> ImportVenue(Stream stream, IPrincipal user);
        Task<int> AddVenueRequirement(int venueId, List<VenueRequirementDto> venueRequirements, IPrincipal user);

        Task<List<VenueApprovalDto>> GetNotApprovedContracts(int agentId);

        Task<bool> ApproveContractVenue(VenueApprovalDto venueApprovalDto);
    }
}
