﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface ICommunicationLogService
    {
        Task<IList<CommunicationLogDto>> GetCommunicationLogs(EntityType entityType, int entityId);

        Task<IList<CommunicationLogSearchResultsDto>> GetByCriteriaAsync(CommunicationLogSearchCriteriaDto criteria);

        Task<IList<CommunicationLogDto>> GetEmailQueuedCommunicationLogsAsync(int emailQueuedId);

        Task UpdateAsync(CommunicationLogDto communicationLog);

        void AddCommunicationLog(CommunicationLogDto log, IPrincipal user);
    }
}