﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IProspectingToolsService
    {
        Task<IList<ContractProspectingToolDto>> GetPreviousContractsAsync(
            int? agentId = null,
            DateTime? startDate = null,
            DateTime? endDate = null);

        Task<IList<ContractProspectingToolDto>> GetNewContractsAsync(
            int? officeId,
            DateTime issueDate,
            int numberOfDays);

        Task<IList<ContractProspectingToolDto>> GetCanceledContractsAsync(int numberOfDays, DateTime issueDate);

        Task<IList<PresenterProspectingToolDto>> GetNewPresentersAsync(int numberOfDays, DateTime createDate);

        Task<IList<ContractChangeLogDto>> GetContractChangesAsync(int numberOfDays, DateTime issueDate);
    }
}
