﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistBlockedDateService
    {
        Task<ArtistBlockedDateDto> GetByIdAsync(int id);

        Task<IList<ArtistBlockedDateDto>> GetByArtistIdAsync(int id);

        Task<IList<ArtistBlockedDateDto>> GetUpcomingByArtistIdAsync(int id, DateTime today);

        Task DeleteAsync(ArtistBlockedDateDto dto, IPrincipal user);

        Task CreateAsync(ArtistBlockedDateCreateDto dto, IPrincipal user);

        Task UpdateAsync(ArtistBlockedDateDto dto, IPrincipal user);
    }
}
