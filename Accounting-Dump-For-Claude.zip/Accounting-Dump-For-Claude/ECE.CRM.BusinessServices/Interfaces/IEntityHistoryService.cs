﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IEntityHistoryService
    {
        Task CreateEntityHistoryAsync(EntityHistoryDto history);

        void CreateEntityHistory(EntityHistoryDto history);

        Task<IList<EntityHistoryDto>> GetByEntityAsync(int entityId, EntityType entityType);
        Task<IList<ContractChangesModel>> GetByContractChangesAsync(int contractId);
    }
}
