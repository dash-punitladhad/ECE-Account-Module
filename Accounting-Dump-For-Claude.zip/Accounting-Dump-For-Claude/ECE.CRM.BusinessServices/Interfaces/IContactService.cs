﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContactService
    {
        IList<ContactDto> GetContacts(EntityType entityType, int entityId);

        Task<IList<ContactDto>> GetContactsAsync(EntityType entityType, int entityId);

        void SyncContacts(EntityType entityType, int entityId, IEnumerable<ContactDto> updatedContacts, IPrincipal user);

        ContactDto GetContactById(int id);

        Task<IList<ContactDto>> GetContactsByEmailAddressAsync(string emailAddress);

        Task<int> OptOutByEmailAddressAsync(string emailAddress);
    }
}