﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;

    public interface IIcsFileService
    {
        byte[] GetIcsEventFile(IcsFileDto dto);
    }
}
