﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IResellerService
    {
        Task<ResellerDto> GetByIdAsync(int id);

        Task<IList<ResellerDto>> GetByCharsAsync(string chars);

        Task<IList<ResellerDto>> GetByCriteriaAsync(ResellerSearchCriteriaDto criteria);

        Task<bool> CheckForDuplicatesAsync(int resellerId, string resellerName);

        Task CreateAsync(ResellerDto dto, IPrincipal user);

        Task UpdateAsync(ResellerDto dto, IPrincipal user);

        Task DeleteAsync(int id);

        Task UpdateNotesAsync(int id, string notes);
    }
}
