﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IInquiryGenreTypeService
    {
        Task CreateAsync(InquiryGenreTypeDto dto, IPrincipal user);
    }
}
