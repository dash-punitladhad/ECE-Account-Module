﻿using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface IFutureCommissionService
	{
		Task<IList<FutureCommissionDto>> GetAgentFutureCommission(AgentDrawFilterModel filterModel);
	}
}
