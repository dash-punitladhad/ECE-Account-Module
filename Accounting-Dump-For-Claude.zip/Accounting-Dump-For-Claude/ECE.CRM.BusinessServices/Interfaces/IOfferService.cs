﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IOfferService
    {
        Task CreateAsync(OfferDto dto, IPrincipal user);

        Task CloneAsync(OfferDto dto, IPrincipal user);

        Task<OfferDto> GetOfferByIdAsync(int id);

        Task<OfferPreviewDetailDto> GetOfferPreviewDetailByIdAsync(int id);

        Task<BlueCardOfferDetailDto> GetBlueCardOfferDetailByIdAsync(int id);

        Task<OfferDetailDto> GetOfferDetailByIdAsync(int id);

        Task<OfferTermsDto> GetOfferTermsByIdAsync(int id);

        Task<OfferFinancialDto> GetOfferFinancialByIdAsync(int id);

        Task<List<OfferTicketScaleDto>> GetOfferTicketScalesByIdAsync(int id);

        Task<List<OfferEventDateDto>> GetOfferEventDatesByIdAsync(int id);

        Task<List<OfferVenueDescriptionDto>> GetVenueTypesByOfferAsync(int id);

        Task UpdateStep1Async(OfferDto dto, IPrincipal user);

        Task UpdateStep3Async(OfferTermsDto dto, IPrincipal user);

        Task UpdateStep2Async(OfferDto dto, IPrincipal user);

        Task UpdateStep4Async(OfferEventDateDto dto, IPrincipal user);

        Task UpdateStep5Async(OfferTicketScaleDto dto, IPrincipal user);

        Task UpdateStep6Async(OfferTermsDto dto, IPrincipal user);

        Task UpdateStep7Async(OfferPreviewDetailDto dto, IPrincipal user);

        Task UpdateOfferStatusAsync(int offerId, int offerStatus, IPrincipal user);

        Task UpdateBindingTermsAsync(OfferTermsDto dto, IPrincipal user);

        Task SendOfferLinkEmailAsync(int id, IPrincipal user);

        Task<bool> CanAddAsync(int userId, int assignedAgentId);

        Task<IList<OfferSearchResultDto>> GetOfferByCriteriaAsync(OfferSearchCriteriaDto criteria);

        Task<OfferDto> GetOfferByUrlKeyAsync(string key);

        Task SaveSignatureAsync(int offerId, int signatureId, IPrincipal user);

        Task<string> GetByCriteriaExportAsync(OfferSearchCriteriaDto criteriaDto);
    }
}
