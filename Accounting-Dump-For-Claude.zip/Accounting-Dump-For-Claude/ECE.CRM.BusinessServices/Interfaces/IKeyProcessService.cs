﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Threading.Tasks;
using ECE.CRM.DataTransferObjects;

namespace ECE.CRM.BusinessServices.Interfaces
{
    public interface IKeyProcessService
    {
        Task<IList<KeyProcessDto>> GetAllKeyProcessAsync();
        Task<KeyProcessDto> GetById(int id);
        Task Create(KeyProcessDto keyProcessDto, IPrincipal user);
        Task Edit(KeyProcessDto keyProcessDto, IPrincipal user);
    }
}
