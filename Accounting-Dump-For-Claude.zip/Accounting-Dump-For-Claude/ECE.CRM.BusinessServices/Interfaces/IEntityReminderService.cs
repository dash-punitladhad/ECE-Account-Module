﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IEntityReminderService
    {

        Task<List<AgentsForEntityReminderDto>> GetAgentListLMDwiseAsync(int userId, int entityReminderId,bool isParent = false);
        Task CreateEntityReminderAsync(EntityReminder entityReminder, int userId);
        Task AddNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog);
        Task<(EntityReminderDetailsModelDto, List<EntityReminderCommunicationLogModelDto>)> ShowEntityReminderCommunicationLogModelAsync(int entityReminderId);

        Task acceptEntityReminderModelAsync(int entityReminderId, int userId);
        Task RejectNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid);
        Task CloseNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid);

        Task deleteEntityReminderModelAsync(int entityReminderId, int userId);
        Task AssignToOtherEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int agentId, int userId);
        Task UpdateEntityReminderAsync(EntityReminder entityReminder, int userId, int oldAgentId);
        Task CompleteNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid);
        Task AddAlertAsync(int senderId, int receiverId, string description, int entityId, int entityTypeId, AppEventType appEventType);
    }
}