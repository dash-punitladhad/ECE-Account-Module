﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IAgentCommissionProgramService
    {
        Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByMenteeIdAsync(int menteeId);

        Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByAppUserAsync(int appUserId);

        Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramByPresenterAsync(int presenterId);

        Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramsByAppUserAsync(int appUserId, int presenterId);

        Task<IList<AgentCommissionProgramsDto>> GetMentorshipProgramsForCommissionByAppUserAsync(
            int appUserId);
    }
}
