﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IEmailQueueService
    {
        bool CanViewPresenterPortalLink(EmailQueueDto email, IPrincipal user);

        void HidePresenterPortalLink(EmailQueueDto email);

        bool AddEmailToQueue(EmailQueueDto email);

        bool Update(EmailQueueDto email, IPrincipal user);

        bool Delete(int id);

        Task<bool> DeleteAsync(int id);

        bool Release(int id);

        Task<bool> ReleaseAsync(int id, IPrincipal user);

        IList<EmailQueueDto> GetByCriteria(EmailQueueSearchCriteriaDto criteria);

        Task<IList<EmailQueueDto>> GetByCriteriaAsync(EmailQueueSearchCriteriaDto criteria);

        EmailQueueDto GetById(int id);

        Task<EmailQueueDto> GetByIdAsync(int id);

        Task ResendMessagesAsync(int[] selectedMessages, IPrincipal user);

        Task ResendMessagesAsync(int emailQueueId, bool useOriginalRecipients, bool forwardACopyToSender, bool forwardACopyToUser, string toAddresses, IPrincipal user);
    }
}