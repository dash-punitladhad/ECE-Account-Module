﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IInquiryRequestedArtistService
    {
        Task CreateAsync(InquiryRequestedArtistDto dto, IPrincipal user);
    }
}
