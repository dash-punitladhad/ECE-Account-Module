﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistFeedbackService
    {
        Task<ArtistFeedbackDto> GetFeedbackByIdAsync(int feedbackId);

        Task<IList<ArtistFeedbackDto>> GetAllFeedbackByArtistAsync(int artistId);

        Task<IList<ArtistFeedbackDetailsDto>> GetAllFeedbackByPresenterAsync(int presenterId);

        Task<IList<ArtistFeedbackDetailsDto>> GetMostRecentFeedbackByArtistAsync(int artistId, TimeSpan duration, int maxResults);

        Task<IList<ArtistFeedbackDetailsDto>> GetDetailsByArtistAsync(int artistId);

        Task<ArtistFeedbackDetailsDto> GetDetailsByIdAsync(int feedbackId);

        Task CreateAsync(ArtistFeedbackDto dto, IPrincipal user);

        Task UpdateAsync(ArtistFeedbackDto dto, IPrincipal user);

        Task<List<ContractFeedbackOptionDto>> GetAvailableContracts(int artistId);
    }
}