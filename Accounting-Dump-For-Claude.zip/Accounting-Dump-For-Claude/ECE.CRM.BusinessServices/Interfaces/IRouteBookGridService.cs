﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IRouteBookGridService
    {
        Task<RouteBookGridDto> GetByIdAsync(int id, bool includeArtists = false);

        Task<IList<RouteBookGridArtistDto>> GetArtistsForGridAsync(int routeBookGridId);

        Task<RouteBookGridArtistDto> GetCustomGridArtistAsync(int artistId);

        Task CreateAsync(RouteBookGridDto dto, IPrincipal user);

        Task UpdateAsync(RouteBookGridDto dto, IPrincipal user);
    }
}
