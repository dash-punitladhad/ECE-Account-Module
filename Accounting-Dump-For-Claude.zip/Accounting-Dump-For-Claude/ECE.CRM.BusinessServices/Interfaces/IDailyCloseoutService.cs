﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IDailyCloseoutService
    {
        Task<IDictionary<DailyCloseoutAmounts, decimal>> GetDailyCloseoutAmountsAsync();

        Task<IList<ContractDepositDto>> GetDailyCloseoutContractDepositsAsync(DateTime lastCloseoutDate, DateTime? lastPostedDate);

        Task<DateTime> GetDailyCloseoutLastCloseoutDateAsync();

        Task<IList<DailyCloseoutPendingTransactionsDto>> GetDailyCloseoutPendingTransactionsAsync(DateTime lastCloseoutDate, bool operatingOnly = true);

        Task<ExpenseBatchDto> CreateDailyCloseoutBatchAsync(IPrincipal user);

        Task ProcessDailyCloseoutAsync(IPrincipal user);
    }
}