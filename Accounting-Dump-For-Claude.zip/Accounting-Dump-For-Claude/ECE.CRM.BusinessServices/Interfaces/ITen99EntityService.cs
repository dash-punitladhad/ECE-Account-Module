﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface ITen99EntityService
    {
        Task<IList<Ten99SearchResultDto>> GetByCriteriaAsync(Ten99SearchCriteriaDto criteria);

        Task<Ten99EntityDto> GetByIdAsync(ContractEntityType entityType, int entityId);

        Task<Ten99EntityDto> GetUnofficialByIdAsync(int year, ContractEntityType entityType, int entityId);

        Task<IList<PaymentTransactionDto>> GetExpensePaymentTransactionsAsync(int year, int entityTypeId, int entityId);
    }
}