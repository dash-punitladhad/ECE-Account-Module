﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IVenueActTypeService
    {
        Task<int> CreateAsync(VenueActTypeDto venueActType);

        Task<List<VenueActTypeDto>> GetVenueActTypesByVenueAsync(int id);

        Task SyncVenueActTypes(int venueId, IEnumerable<string> venueActTypes);
    }
}
