﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IPayrollService
    {
        Task<IList<PayrollPaymentDto>> GetPayrollPaymentsByAgentAndYearAsync(int agentId, int year);

        Task<PayrollPaymentDto> GetPayrollPaymentByIdAsync(int id);

        Task<IList<AgentPayrollLogViewDto>> GetAgentPayrollLogsByPayrollPaymentIdAsync(int payrollPaymentId);

        Task<IList<AgentPayrollLogDto>> GetUnpaidByAgentAsync(int agentId, int year);

        Task CalculateNetAmountsAsync(int agentId, IList<AgentPayrollLogDto> logs, PayrollBatchDto batch);

        Task<IList<AgentPayrollLogDto>> GetAgentPayrollLogsByContractIdAsync(int contractId);

        Task<AgentPayrollLogDto> GetAgentPayrollLogByContractTransactionIdAsync(int contractTransactionId);

        Task<AgentPayrollLogDto> GetAgentPayrollLogByIdAsync(int agentPayrollLogId);

        Task UpdateCafeteriaPlanAsync(CafeteriaPlanDto dto, IPrincipal user);

        Task<IList<AgentCafeteriaPlanDto>> GetAgentCafeteriaPlansAsync(int year);

        Task<IList<AgentCafeteriaPlanDto>> GetAgentCafeteriaPlansAsync(int year, DateTime currentDate);

        Task<CafeteriaPlanDto> GetCafeteriaPlanByAgentAsync(int agentId);

        Task SynchronizeAgentPayrollLogAsync(ContractTransactionDto contractTransaction, IPrincipal user);

        Task DeleteAgentPayrollLogAsync(int contractTransactionId, IPrincipal user);

        Task<IList<PayrollBatchLogDto>> GetPayrollLogsAsync(int year);

        DateTime GetNextPayrollDate();

        DateTime GetNextPayrollDate(DateTime asOfDate);

        DateTime GetPayrollStartDate(DateTime payrollDate);

        DateTime GetPayrollStartDate(DateTime asOfDate, DateTime payrollDate);

        DateTime GetPayrollEndDate(DateTime payrollDate);

        DateTime GetPayrollEndDate(DateTime asOfDate, DateTime payrollDate);

        Task<PayrollBatchDto> GetPayrollBatchByPayrollPeriodAsync(DateTime payrollDate);

        Task<PayrollBatchDto> GetPendingPayrollBatchAsync();

        Task<PayrollBatchDto> CalculateNextPayrollBatchAsync(int? agentId = null);

        Task<PayrollBatchDto> CalculateNextPayrollBatchAsync(DateTime asOfDate, int? agentId = null);

        Task<PayrollBatchDto> GetNextPayrollBatchAsync(bool preview, int agentId);

        Task<PayrollBatchDto> RunPayrollAsync(DateTime asOfDate, IPrincipal user);

        Task PostPayrollAsync(PayrollBatchDto batch, IPrincipal user);

        Task<PayrollBatchDto> GetPayrollBatchByIdAsync(int id);

        Task<IList<PayrollDetailsLogDto>> GetPayrollDetailsLogsAsync(int payrollBatchId);
        Task<SettingPayrollDto> GetSettingPayrollAsync(int payrollBatchId);

        Task<AgentPayrollDetailsDto> GetAgentPayrollDetailsAsync(int payrollPaymentId);

        Task<IList<AgentEarnedCommissionsDto>> GetAgentEarnedCommissionsAsync(int payrollPaymentId);

        Task<IList<MentorshipBonusCommissionsDto>> GetMentorshipBonusCommissionsAsync(int payrollPaymentId);

        Task<IList<PresenterTransferBonusCommissionsDto>> GetPresenterTransferBonusCommissionsAsync(int payrollPaymentId);

        Task<IList<SharedBonusDto>> GetSharedBonusAsync(int payrollPaymentId);

        Task<IList<NonExclusiveArtistFeeDto>> GetNonExclusiveArtistFeeAsync(int payrollPaymentId);

        Task<IList<AgentWorkingDto>> GetAgentWorkingAsync(int payrollPaymentId);
        Task<bool> SetPayrollPaymentAsync(PayrollPaymentViewModel viewModel, IPrincipal user);
        Task<bool> SetAgentPayrollLogAsync(AgentPayrollPaymentLogViewModel viewModel, IPrincipal user);
        Task<IList<PayrollContractTransactionDto>> GetCommissionTransactionsAsync(ContractTransactionSearchCriteriaDto criteria);

        Task CreateAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task UpdateAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task RemoveAgentPayrollLogFromPayrollAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task DeleteAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task AddAgentPayrollLogToPayrollAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task AddAgentToPayrollBatchAsync(PayrollBatchDto dto, int agentId, IPrincipal user);

        Task DeletePendingPayrollBatch();

        Task<IList<PayrollPaymentDto>> GetPayrollPaymentsByPayrollBatchIdAsync(PayrollBatchDto dto);

        Task RecalculatePayrollBatchAsync(PayrollBatchDto dto, IPrincipal user);
        Task<bool> ExcludePayrollPaymentAsync(int payrollBatchId, IPrincipal user);
    }
}