﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractArtistService
    {
        Task<IList<ContractArtistDto>> GetByContractIdAsync(int contractId);

        Task<ContractArtistDto> GetByContractAndArtistIdAsync(int contractId, int artistId);

        Task<ContractArtistDto> GetByIdAsync(int id);

        Task CreateAsync(ContractArtistDto dto, IPrincipal user);

        Task UpdateAsync(ContractArtistDto dto, IPrincipal user);

        Task DeleteAsync(int id);

        Task<IList<ContractArtistSearchResultDto>> GetArtistsByCriteria(ContractArtistSearchCriteriaDto criteria);

        Task UpdateArtistEventTimeReasonAsync(int contractArtistId, int eventTimeReasonId, IPrincipal user);

        Task AddArtistRidersAsync(ContractArtistDto artist, IList<ContractDocumentDto> availableRiders, IPrincipal user);

        Task AddArtistRidersAsync(IList<ContractArtistDto> artists, IList<ContractDocumentDto> availableRiders, IPrincipal user);
    }
}
