﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractDepositService
    {
        Task PostContractDepositAsync(ContractDepositDto contractDeposit, IPrincipal user);

        Task PostContractDepositAsync(ContractDepositDto contractDeposit, ExpensePaymentDto payment, IPrincipal user);

        Task UnpostContractDepositAsync(int contractDepositId, IPrincipal user);

        Task<List<ContractDepositDto>> GetContractDepositsByContractIdAsync(int contractId);

        Task<List<ContractDepositDto>> GetByPaymentMethodAndRefAsync(int paymentMethodId, string referenceNumber);

        Task<decimal> GetUnpaidIncomeForContractPayeeAsync(int contractId, int contractEntityTypeId, int contractEntityId);

        Task<PreCreateContractDepositResultDto> PreCreateDepositCheckAsync(ContractDepositDto deposit);
    }
}
