﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IAppLogService
    {
        Task<IList<AppLogDto>> GetByCriteriaAsync(AppLogSearchCriteriaDto criteria);
    }
}
