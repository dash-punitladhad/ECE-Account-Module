﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractDynamicBackupService
    {
        Task<int> CreateBackup(int contractId, int userId);
    }
}
