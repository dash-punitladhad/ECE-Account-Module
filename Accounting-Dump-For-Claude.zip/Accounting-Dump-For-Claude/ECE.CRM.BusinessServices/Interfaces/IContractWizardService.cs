﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractWizardService
    {
        bool ContractHasMoneyReceivedOrReleased(IList<ContractTransactionDto> transactions);

        Task<ContractDto> CreateContractAsync(int entityId, EntityType entityType, IPrincipal principal);

        Task SaveContractEventInfoAsync(ContractDto dto, IList<ContractEventDateDto> contractEventDates, IPrincipal user);

        Task SaveContractPresenterAsync(ContractDto dto, IPrincipal user);

        Task SaveContractVenueAsync(ContractDto dto, IPrincipal user);

        Task SaveContractStandardArtistAsync(
            ContractDto dto,
            ContractArtistDto artist,
            IList<ContractArtistEventDateDto> artistEventDates,
            IPrincipal user);

        Task SaveContractSpecialArtistInfoAsync(ContractDto dto, IList<ContractArtistDto> artists, IPrincipal user);

        Task SaveContractSpecialArtistEventInfoAsync(IList<ContractArtistDto> artists,
            IList<ContractArtistEventDateDto> artistEventDates,
            IPrincipal user);

        Task SaveContractStandardMoneyAsync(int contractId,
            DateTime? initialDepositDueDate,
            decimal eceCommissionRatePercentage,
            decimal contractGross,
            int? contractProgramId,
            int? contractAgentProgramId,
            IPrincipal user,
            ContractArtistDto contractArtist,
            IList<ContractTransactionDto> contractTransactionsForDelete,
            IList<ContractTransactionDto> contractTransactionsForSave);

        Task SaveContractSpecialMoneyAsync(int contractId,
            decimal eceCommissionRate,
            decimal contractGross,
            int? contractProgramId,
            int? contractAgentProgramId,
            DateTime dueDate,
            IPrincipal user,
            IList<ContractArtistDto> contractArtists,
            IList<ContractTransactionDto> contractTransactionsForDelete,
            IList<ContractTransactionDto> contractTransactionsForSave);

        Task SaveContractTermsAndRidersAsync(int contractId,
            string additionalTerms,
            IList<ContractTermDto> contractTermsForSave,
            IList<ContractTermDto> contractTermsForDelete,
            IList<ContractDocumentDto> contractRidersForSave,
            IList<ContractDocumentDto> contractRidersForDelete,
            IPrincipal user);

        Task<bool> VerifyCreateAsync(int entityId, EntityType entityType, IPrincipal principal);

        Task<bool> ValidateFirstArtistEventDateHasChangedAsync(int contractId, DateTime oldEventDate, DateTime? eventDate);

        Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsAsync(int agentId, DateTime? eventDate);

        Task<IList<AgentCommissionProgramsDto>> GetPresentTransfersAsync(int presenterId, DateTime? eventDate);

        Task<ContractCommissionProgramDto> GetContractCommissionProgramAsync(ContractDto contract, DateTime? eventDate);

        Task Step1UpdateEventInfo(ContractDto contractNew, ContractDto contractOld, IPrincipal user);
        Task Step2UpdatePresenter(ContractDto contractNew, ContractDto contractOld, IPrincipal user);
        Task Step3UpdateVenue(ContractDto contractNew, ContractDto contractOld, IPrincipal user);

        Task Step4UpdateArtist(ContractDto contractNew, ContractDto contractOld, IPrincipal user);
        Task Step5UpdateMoney(ContractDto contractNew, ContractDto contractOld, List<ContractTransactionDto> contractTransactionDtoDeletes, IPrincipal user);
        Task Step6UpdateTerms(ContractDto contractNew, ContractDto contractOld, List<ContractTermDto> contractTermsForDeletes, IPrincipal user);

        bool CanMoneyStepEdit(bool HasMoneyTxnOrOriginalGross, ContractDto contract, IPrincipal user);
    }
}
