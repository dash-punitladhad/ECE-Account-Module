﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IInquiryService
    {
        Task<InquiryDto> GetInquiryByIdAsync(int id);

        InquiryDto GetInquiryById(int id);

        Task<IList<InquiryDto>> GetInquiriesByAgentAsync(int agentId);

        Task<IList<InquiryDto>> GetInquiriesByBlueCardAsync(int blueCardId);

        Task<IList<InquirySearchResultDto>> GetInquiriesByCriteriaAsync(InquirySearchCriteriaDto criteria);

        Task CreateAsync(InquiryDto dto, IPrincipal user);

        Task UpdateAsync(InquiryDto dto, IPrincipal user, bool sendAlert = false);

        Task<string> GetByCriteriaExportAsync(InquirySearchCriteriaDto criteriaDto);
    }
}
