namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.DataTransferObjects.ContractDetails;
    using ECE.CRM.DataTransferObjects.PandaDoc;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IPandaDocService
    {
        Task<(bool, string, string)> CreateDocument(PandaDocRequestContractInfoDto contractInfo);
        Task<byte[]> DownloadDocument(string documentId);
        Task<bool> CreateUploadAttachment(string documentId, List<Recipient> recipients, List<Stream> streams = null);
        Task<(bool, string, string, List<Recipient>)> UpdateDocument(string documentId, PandaDocRequestContractInfoDto contractInfo, bool skipDraft = false);
        Task<Tuple<bool, List<string>>> CreateUploadBundle(string documentId, List<Recipient> recipients, List<Stream> streams = null);

        Task<bool> SendDocument(string documentId, string subject = null, string body = null, bool silent = false);
        Task<Tuple<bool, MemoryStream>> GetContractTermsAndCondtion(string termsAndConditonHtml, string contractNumber = null, string agentName = null);
        Task<Tuple<string, MemoryStream>> GetPandaDocTemplateIdAndContractTermsAndCondtion(int contractId);
        Task SetPandaDocTemplateIdAndContractTermsAndCondtion(int contractId);
        Task SetPandaDocSignatureForContractAsync(string pandaDocDocumentId, string emailid);
        Task AddContractPDFBackup(int contractId, string Description = ContractFileLabels.BasicContract, List<string> uploadIds = null);
        Task RemovePandaDocSignatureForContractAsync(string pandaDocDocumentId);

        Task SetPandaDocSentSignatureAndStatusChangeForContractAsync(string pandaDocDocumentId, string presenterEmailid, string artistEmailid);
        Task<Tuple<bool, List<string>>> AddbundleAllDocuementsForPandadocAsync(int contractId, string documentId, List<Recipient> recipients);
        Task<Tuple<bool, List<string>>> UpdatebundleDocumentsForPandadocAsync(int contractId, string documentId, List<Recipient> recipients, List<Stream> ridersAndaddendums);

        Task<Tuple<bool, bool, List<RiderAndAddendumDto>>> GetIsCreateNewContratact(int contractId);
        Task<bool> AddOrUpdateContractPandaDocAsync(PandaDocRequestContractInfoDto contractInfo, string subject = null, string body = null, bool onIssue = false);
        Task SendMailAsPerStatusWiseForPandaDoc(string status, string pandaDocDocumentId, int sendBy, object data = null);
        Task<List<RecipientDatail>> GetRecipientsContractAsync(string documentId);
        Task SyncPandaDocExpirationDateAsync(string pandaDocDocumentId);
        Task<string> CreateSigningSessionAsync(string documentId, string recipientEmail);
        Task<bool> DraftDocument(string documentId);

        Task RemoveSignaturesAndRevertDraftAsync(ContractDto contract, IPrincipal user);
    }
}
