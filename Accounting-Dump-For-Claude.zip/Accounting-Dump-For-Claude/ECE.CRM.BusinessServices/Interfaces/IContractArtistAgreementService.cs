﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractArtistAgreementService
    {
        Task<IList<ContractArtistAgreementDto>> GetByContractIdAsync(int contractId);

        Task<ContractArtistAgreementDto> GetByContractArtistIdAsync(int artistId);

        Task<ContractArtistAgreementDto> GetByIdAsync(int id);

        Task CreateAsync(ContractArtistAgreementDto dto, IPrincipal user);

        Task UpdateAsync(ContractArtistAgreementDto dto, IPrincipal user);

        Task DeleteAsync(ContractArtistAgreementDto dto, IPrincipal user);

        Task<IList<ContractArtistAgreementTermDto>> GetTermsForAgreementAsync(int id);
    }
}
