﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IAgentPayrollLogService
    {
        Task<IList<AgentPayrollLogDto>> GetUnpaidByAgentAsync(int agentId, DateTime startDate, DateTime endDate);

        Task CreateAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task UpdateAsync(AgentPayrollLogDto dto, IPrincipal user);

        Task DeleteAsync(int id);
    }
}
