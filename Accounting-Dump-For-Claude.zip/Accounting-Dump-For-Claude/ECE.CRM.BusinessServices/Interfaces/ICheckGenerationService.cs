﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;

    public interface ICheckGenerationService
    {
        Task<MemoryStream> PrintCheckAsync(ExpensePaymentDto payment, IList<ContractTransactionDto> transactions);

        Task<CheckPrintDto> GetCheckToPrint(ExpensePaymentDto payment, IList<ContractTransactionDto> transactions, IDictionary<int, ContractCheckInfoDto> checkInfo = null);

        Task<IList<CheckPrintDto>> GetChecksToPrint(IList<ExpensePaymentDto> payments, IList<ContractTransactionDto> batchTransactions);

        Task PopulateEntityDetailsAsync(ExpensePaymentDto payment, CheckPrintDto check);
    }
}