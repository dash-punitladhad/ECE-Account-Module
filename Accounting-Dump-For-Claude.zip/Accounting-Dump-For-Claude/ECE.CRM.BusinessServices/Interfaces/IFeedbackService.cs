﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IFeedbackService
    {

        Task AddDocumentTo(FeedbackDto fdto, List<DocumentDto> fdddto, IPrincipal user);

        Task<List<FeedbackModelDto>> GetFeedbackFilterAsync(FeedbackRequestModelDto model);
        Task<FeedbackDisplayViewDto> GetDocumentToAsync(int feedbackId);
    }
}