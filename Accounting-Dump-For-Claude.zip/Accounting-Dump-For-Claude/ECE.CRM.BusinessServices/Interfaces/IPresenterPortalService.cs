﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Threading.Tasks;

    public interface IPresenterPortalService
    {
        Task<WeddingQuestionnaireDataDto> GetWeddingQuestionnaireDataAsync(ContractDto contract);
    }
}
