﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IDocumentService
    {
        Task<DocumentDto> GetByIdAsync(int documentId);

        IList<DocumentDto> GetDocuments(EntityType entityType, int entityId);

        DocumentDto GetGenericRider(int id);

        DocumentDto GetDocument(EntityType entityType, int entityId, int documentId);

        Task<DocumentDto> GetDocumentAsync(EntityType entityType, int entityId, int documentId);

        MemoryStream GetFromStorage(DocumentDto documentDto, string libraryName);
        Task<MemoryStream> GetFromStorageAsync(DocumentDto documentDto, string libraryName);
        IList<DocumentDto> GetRiders(EntityType entityType, int entityId);

        Task<DocumentDto> GetRelatedDocumentAsync(UrlKeyRelatedDocumentDto relatedDocument);

        Task<bool> DocumentIsRelatedToUrlKeyAsync(
            UrlKeyHolderType urlKeyHolder,
            string urlKey,
            int documentId);

        void SyncDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user);

        Task SyncContractDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user);

        void SyncContractInternalDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user);

        void AddGenericRider(DocumentDto dto, IPrincipal user);

        void AddDocumentTo(EntityType entityType, int entityId, DocumentDto dto, int createdById);

        void RemoveDocumentFrom(EntityType entityType, int entityId, int documentId, int removedById);

        Task DeleteDocumentLinkAsync(int documentId, int entityId, EntityType entityTypeId);

        void LinkDocumentTo(EntityType entityType, int entityId, DocumentDto dto, int createdById);

        void RemoveInternalDocuments(EntityType entityType, int documentId, IPrincipal user);

        Task SyncAddendumDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user, List<AppUser> lmds);
        Task<int> SyncSentForApproveAddendumDocuments(int contractId, IPrincipal user, List<AppUser> lmds);
        Task<bool> ReSendForApproveUpdateAddendumDocumentsByAgentAsync(int addendumDocumentId, IPrincipal user, List<AppUser> lmds);
        Task<bool> SetPreIsPrimaryAddendumDocumentsByAgentAsync(int addendumDocumentId, IPrincipal user);
        Task<bool> ResetAllPrimaryAddendumByAgentAsync(int contractId, IPrincipal user);
        IList<DocumentDto> GetContractVersionDocuments(EntityType entityType, int entityId);
    }
}
