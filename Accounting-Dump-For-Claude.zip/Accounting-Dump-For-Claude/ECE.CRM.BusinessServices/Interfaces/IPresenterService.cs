﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IPresenterService
    {
        Task<List<PresenterDto>> GetPresentersByCharsAsync(string chars);

        Task<List<PresenterTypeAheadDto>> GetTypeAheadByCharsAsync(string chars);

        Task<List<PresenterTypeAheadDto>> GetTypeAheadByCharsAsync(string chars, int[] agents);

        Task<PresenterDto> GetPresenterByNameAndOrgAsync(string accountName, string orgName);

        PresenterDto GetPresenterById(int id, bool includeChildren);

        Task<PresenterDto> GetPresenterByIdAsync(int id, bool includeChildren);

        Task CreateAsync(PresenterDto dto, IPrincipal user);

        Task UpdateAsync(PresenterDto dto, IPrincipal user);

        IList<PresenterSearchResultsDto> GetByCriteria(PresenterSearchCriteriaDto criteria);

        Task<IList<PresenterSearchResultsDto>> GetByCriteriaAsync(PresenterSearchCriteriaDto criteria);

        Task<IList<PresenterBulkTransferSearchResultsDto>> GetByPresenterBulkTransferCriteriaAsync(PresenterBulkTransferSearchCriteriaDto criteria);

        Task<bool> ReassignPresenterAgentMultiAsync(ReassignPresenterAgentMultiList criteria, IPrincipal user);

        Task<bool> CanEditAsync(int userId, int assignedAgentId);

        Task<bool> CanCreateContractAsync(int userId, int assignedAgentId);

        Task TogglePresenterStatusAsync(int presenterId, bool isActive, int updatedBy);

        Task ReassignPresenterAgentAsync(int presenterId, int agentId, IPrincipal user);

        Task ReassignPresenterAgentAsync(PresenterDto presenter, int agentId, DateTime endDate, IPrincipal user);

        Task ToggleArchiveStatusAsync(int presenterId, bool isArchived, int updatedBy);

        Task CreateSimilarPresenterAlertAsync(int id, IPrincipal user);

        Task CreateNotResponsibleAgentAlertContractAsync(int id, int presenterId, string agentName, IPrincipal user);

        Task CreateNotResponsibleAgentAlertBlueCardAsync(int id, int presenterId, string agentName, IPrincipal user);

        Task<List<PresenterBookDateDto>> GetBookedDatesAsync(int id);

        Task<ICollection<GenreTypeDto>> GetGenreTypesByPresenterAsync(int id);
        Task<(string, string)> GetByCriteriaExportAsync(PresenterSearchCriteriaDto criteria);

        Task<(bool, string, object)> ImportPresenter(Stream stream, IPrincipal user);
    }
}