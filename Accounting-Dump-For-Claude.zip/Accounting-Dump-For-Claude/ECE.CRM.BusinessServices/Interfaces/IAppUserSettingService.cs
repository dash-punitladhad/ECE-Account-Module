﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IAppUserSettingService
    {
        Task<IList<AppUserSettingDto>> GetAppUserSettingsAsync(int appUserId);

        Task SyncSettingsAsync(int appUserId, IEnumerable<AppUserSettingDto> updatedSettings, IPrincipal user);
    }
}
