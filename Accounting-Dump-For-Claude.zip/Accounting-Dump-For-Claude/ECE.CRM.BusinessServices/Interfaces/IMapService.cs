﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IMapService
    {
        Task<IList<LocationDto>> GetLocationsAtDistanceAsync(LocationsAtDistanceCriteriaDto criteria);

        Task<IList<LocationDto>> GetLocationsAtDistanceAsync(EntityType entityType, decimal originLatitude, decimal originLongitude, string searchTypes, int maxDistance, int minDistance = 0);

        Task<IList<LocationDto>> GetLocationsAlongRouteAsync(EntityType entityType, int[] entityIds);
    }
}
