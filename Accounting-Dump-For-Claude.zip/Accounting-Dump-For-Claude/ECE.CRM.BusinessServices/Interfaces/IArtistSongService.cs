﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistSongService
    {
        Task<IList<ArtistSongDto>> GetArtistSongsAsync(int artistId);

        Task<IList<ArtistSongDto>> GetApprovedArtistSongsAsync(int artistId);

        Task<IList<ArtistSongDto>> GetPendingArtistSongsAsync(int artistId);

        Task<ArtistSongDto> GetArtistSongByIdAsync(int artistSongId);

        Task<bool> CanEditAsync(int userId, int artistId);

        Task CreateSongAsync(ArtistSongDto song, IPrincipal user);

        Task UpdateSongAsync(ArtistSongDto song, IPrincipal user);

        Task DeleteSongAsync(ArtistSongDto song, IPrincipal user);

        Task ApproveSongAsync(ArtistSongDto song, IPrincipal user);
    }
}