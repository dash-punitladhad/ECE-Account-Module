﻿using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface IEntityHistoryLMDLogService
	{
		Task CreateAsync(EntityHistoryLMDLogDto entityHistoryLMDLogDto, IPrincipal user);
		Task<List<EntityHistoryLMDLogUserDto>> GetEntityHistoryLMDLogListAsync(int lMdId, bool isSystemAdmin);
	}
}
