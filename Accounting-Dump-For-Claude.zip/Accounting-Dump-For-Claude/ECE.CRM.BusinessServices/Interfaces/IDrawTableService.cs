﻿using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface IDrawTableService
	{
		Task<List<LuQuarterDto>> GetAllQuarters();
		List<int> GetYears();
		Task<bool> AddDrawData(DrawTableDto drawTableDto, IPrincipal user);
		Task<List<AgentDrawTableDTO>> GetAgentDrawData(AgentDrawFilterModel filterModel);
		Task<decimal> GetAgentQuarterlyCommission(AgentDrawFilterModel filterModel);
		Task<decimal> GetAgentStartingAmount(AgentDrawFilterModel filterModel);
		Task<PreviousDrawDto> GetAgentPreviousQuarterlyCommission(AgentDrawFilterModel filterModel);
		Task<bool> SettleTransaction(DrawTableDto drawTableDto, IPrincipal user);
		Task<AgentDrawTableDTO> CheckDrawData(AgentDrawFilterModel filterModel);
		Task<List<AgentYearlyDrawDTO>> GetAgentYearlyDrawData(AgentDrawFilterModel filterModel);

		Task<bool> DeleteDrawData(int drawID, IPrincipal user);
	}
}
