﻿using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface IVenueRequirementService
	{
		Task<int> AddVenueRequirement(int venueId,List<VenueRequirementDto> venueRequirements,IPrincipal user);
		Task<List<VenueRequirementDto>> GetVenueRequirements(int venueId);

		Task<int> AddVenueRequirementNotification(VenueRequirementNotificationDto venueRequirementNotificationDto,IPrincipal user);
		Task<bool> IsVenueNotificationRecordExists(int contractId);
		Task<bool> IsAgentAcknowledged(int contractId,int agentId);
		Task<int> UpdateAgentAcknowledge(VenueRequirementNotificationDto venueRequirementNotificationDto);

		Task<List<VenueRequirementDto>> GetAllVenueRequirements(int venueId);
	}
}
