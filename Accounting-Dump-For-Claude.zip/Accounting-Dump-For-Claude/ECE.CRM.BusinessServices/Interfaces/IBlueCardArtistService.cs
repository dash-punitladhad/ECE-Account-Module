﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;

    public interface IBlueCardArtistService
    {
        List<BlueCardArtistDto> GetBlueCardArtistsById(int id);
    }
}