﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;

    public interface IWebLinkService
    {
        IList<WebLinkDto> GetWebLinks(EntityType entityType, int entityId);

        void SyncWebLinks(EntityType entityType, int entityId, IEnumerable<WebLinkDto> updatedWebLinks, IPrincipal user);
    }
}