﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface ICheckbookService
    {
        Task<IList<CheckSearchResultDto>> GetChecksByCriteriaAsync(CheckSearchCriteriaDto dto);

        Task<ReconciliationBatchDto> GetReconciliationBatchByIdAsync(int id);

        Task<ReconciliationItemDto> GetReconciliationItemByIdAsync(int id);

        Task<ReconciliationItemDto> GetReconciliationItemByExpensePaymentIdAsync(int id);

        Task<bool> GetIsReconciledByExpensePaymentIdAsync(int id);

        Task UpdateNotesAsync(int id, string notes);

        Task UnreconcileCheckAsync(ExpensePaymentDto check, IPrincipal user);

        Task ReconcileCheckAsync(ExpensePaymentDto check, IPrincipal user);

        Task VoidCheckAsync(VoidCheckDto voidCheck, IPrincipal user);

        Task<MemoryStream> PrintCheckAsync(ExpensePaymentDto check);

        Task<ReconciliationBatchDto> GetExistingReconciliationBatchAsync(IPrincipal user, bool includeItems = true);

        Task<ReconciliationBatchDto> CreateReconciliationBatchAsync(IPrincipal user);

        Task CreateReconciliationItemsAsync(int reconciliationBatchId, IList<ReconciliationItemDto> items, IPrincipal user);

        Task CreateReconciliationItemAsync(int reconciliationBatchId, ReconciliationItemDto item, IPrincipal user);

        IList<string> GetReconciliationItemWarnings(ReconciliationItemDto reconciliationItem);

        void SetReconciliationItemWarnings(IList<ReconciliationItemDto> reconciliationItems);

        bool HasReconciliationItemWarnings(IList<ReconciliationItemDto> reconciliationItems);

        Task<IList<string>> CheckReconciliationItemForWarningAsync(int id);

        Task DeleteReconciliationItemAsync(int id, IPrincipal user);

        Task DeleteAllReconciliationItemsAsync(IPrincipal user);

        Task UpdateBatchDetailsAsync(int id, IPrincipal user);

        Task UpdateReconciliationBatchAsync(ReconciliationBatchDto batch);

        Task CloseReconciliationBatchAsync(ReconciliationBatchDto batch, IPrincipal user);
    }
}
