﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    /// <summary>
    /// Lookup Service Interface.
    /// </summary>
    public interface ILookupService
    {
        /// <summary>
        /// Get all states.
        /// </summary>
        /// <param name="activeStatus">if set to <c>true</c> [active status].</param>
        /// <returns>A collection of all states.</returns>
        IList<StateDto> GetAllStates(bool? activeStatus);

        /// <summary>
        /// Get all states.
        /// </summary>
        /// <param name="activeStatus">if set to <c>true</c> [active status].</param>
        /// <returns>A collection of all states.</returns>
        Task<IList<StateDto>> GetAllStatesAsync(bool? activeStatus);

        Task<StateDto> GetStateByIdAsync(int id);

        /// <summary>
        /// Get all states using the specified country identifier.
        /// </summary>
        /// <param name="countryId">The country identifier.</param>
        /// <returns>A collection of all states.</returns>
        IList<StateDto> GetAllStatesByCountry(int countryId);

        IList<LookupDto> GetAllCancelledReasons();

        IList<LookupDto> GetAllClosedReasons();

        IList<LookupDto> GetAllAgentCommissionTypes();

        IList<LookupDto> GetAllTerms();

        /// <summary>
        /// Gets all venue settings.
        /// </summary>
        /// <returns>A collection of all venue settings.</returns>
        IList<VenueSettingDto> GetAllSettings();

        IList<LookupDto> GetAllVenueTypes();

        IList<VenueTypeDto> GetAllVenueTypes(bool includeDeleted);

        Task CreateVenueTypeAsync(VenueTypeDto dto);

        Task UpdateVenueTypeAsync(VenueTypeDto dto);

        Task<bool> DeleteVenueTypeAsync(VenueTypeDto dto);

        /// <summary>
        /// Gets all countries.
        /// </summary>
        /// <returns>A list of all countries.</returns>
        IList<CountryDto> GetAllCountries();

        /// <summary>
        /// Gets all countries asynchronous.
        /// </summary>
        /// <returns>A list of all countries.</returns>
        Task<IList<CountryDto>> GetAllCountriesAsync();

        /// <summary>
        /// Gets the email template.
        /// </summary>
        /// <param name="templateId">The template identifier.</param>
        /// <returns>An Email Template object.</returns>
        Task<EmailTemplateDto> GetEmailTemplateAsync(int templateId);

        /// <summary>
        /// Gets all email templates.
        /// </summary>
        /// <returns>A list of all templates.</returns>
        Task<IList<EmailTemplateDto>> GetAllEmailTemplatesAsync();

        /// <summary>
        /// Gets all the landing pages.
        /// </summary>
        /// <returns>A list of landing pages.</returns>
        IList<LandingPageDto> GetAllLandingPages();

        /// <summary>
        /// Gets all the landing pages.
        /// </summary>
        /// <returns>A list of landing pages.</returns>
        Task<IList<LandingPageDto>> GetAllLandingPagesAsync();

        /// <summary>
        /// Gets the landing page by criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A LandingPageDto if found.</returns>
        Task<IList<LandingPageDto>> GetLandingPagesByCriteriaAsync(LandingPageDto criteria);

        /// <summary>
        /// Gets all act types.
        /// </summary>
        /// <returns>A list of all active act types.</returns>
        IList<LookupDto> GetAllActTypes();

        IList<ActTypeDto> GetAllActTypes(bool includeDeleted);

        Task CreateActTypeAsync(ActTypeDto dto);

        Task UpdateActTypeAsync(ActTypeDto dto);

        Task<bool> DeleteActTypeAsync(ActTypeDto dto);

        /// <summary>
        /// Gets all event types.
        /// </summary>
        /// <param name="includeDeleted">if set to <c>true</c> include deleted.</param>
        /// <returns>A list of all active event types.</returns>
        IList<EventTypeDto> GetAllEventTypes(bool includeDeleted = false);

        Task CreateEventTypeAsync(EventTypeDto dto);

        Task UpdateEventTypeAsync(EventTypeDto dto);

        Task<bool> DeleteEventTypeAsync(EventTypeDto dto);

        /// <summary>
        /// Gets all terms.
        /// </summary>
        /// <param name="includeDeleted">if set to <c>true</c> include deleted.</param>
        /// <returns>A list of all active terms.</returns>
        IList<TermDto> GetAllTerms(bool includeDeleted = false);

        Task CreateTermAsync(TermDto dto);

        Task UpdateTermAsync(TermDto dto);

        Task<bool> DeleteTermAsync(TermDto dto);

        /// <summary>
        /// Gets all genre types.
        /// </summary>
        /// <param name="includeDeleted">if set to <c>true</c> include deleted.</param>
        /// <returns>A list of all the active genre types.</returns>
        IList<GenreTypeDto> GetAllGenreTypes(bool includeDeleted = false);

        Task CreateGenreTypeAsync(GenreTypeDto dto);

        Task UpdateGenreTypeAsync(GenreTypeDto dto);

        Task<bool> DeleteGenreTypeAsync(GenreTypeDto dto);

        Task UpdateEmailTemplateAsync(EmailTemplateDto dto);

        /// <summary>
        /// Gets all offer binding types.
        /// </summary>
        /// <returns>A list of all the active offer binding types.</returns>
        IList<OfferBindingTypeDto> GetAllOfferBindingTypes();

        Task<OfferBindingTypeDto> GetOfferBindingTypeAsync(int id);

        IList<OfferStatusDto> GetAllOfferStatuses();

        /// <summary>
        /// Gets all programs.
        /// </summary>
        /// <returns>A list of all active programs.</returns>
        IList<ProgramDto> GetAllPrograms();

        /// <summary>
        /// Gets all commission programs.
        /// </summary>
        /// <returns>A list of all active commission programs.</returns>
        IList<LookupDto> GetAllCommissionPrograms();

        /// <summary>
        /// Gets all Presenter Types, both active and inactive.
        /// </summary>
        /// <param name="active">Option to get active, inactive, or both types</param>
        /// <returns>A collection of PresenterTypeDto</returns>
        IList<PresenterTypeDto> GetAllPresenterTypes(bool? active = true);

        Task CreatePresenterTypeAsync(PresenterTypeDto dto);

        Task UpdatePresenterTypeAsync(PresenterTypeDto dto);

        Task<bool> DeletePresenterTypeAsync(PresenterTypeDto dto);

        /// <summary>
        /// Get all Offices.
        /// </summary>
        /// <returns>A collection of OfficeDto</returns>
        IList<OfficeDto> GetAllOffices();

        Task<OfficeDto> GetOfficeByIdAsync(int id);

        Task UpdateOfficeAsync(OfficeDto dto, IPrincipal user);

        IList<ContactTypeDto> GetContactTypes(bool includeDeleted = false);

        Task CreateContactTypeAsync(ContactTypeDto dto);

        Task UpdateContactTypeAsync(ContactTypeDto dto);

        Task<bool> DeleteContactTypeAsync(ContactTypeDto dto);

        /// <summary>
        /// Gets active contact methods
        /// </summary>
        /// <returns>A collection of PreferredContactMethodDto.</returns>
        IList<PreferredContactMethodDto> GetPreferredContactMethods();

        /// <summary>
        /// Gets active phone number types.
        /// </summary>
        /// <returns>A collection of PhoneNumberTypeDto.</returns>
        IList<PhoneNumberTypeDto> GetPhoneNumberTypes();

        /// <summary>
        /// Gets active web link types.
        /// </summary>
        /// <returns>A collection of WebLinkTypeDto.</returns>
        IList<WebLinkTypeDto> GetWebLinkTypes();

        IList<WebLinkTypeDto> GetAllWebLinkTypes(bool includeDeleted = false);

        Task CreateWebLinkTypeAsync(WebLinkTypeDto dto);

        Task UpdateWebLinkTypeAsync(WebLinkTypeDto dto);

        Task<bool> DeleteWebLinkTypeAsync(WebLinkTypeDto dto);

        /// <summary>
        /// Gets active document types.
        /// </summary>
        /// <returns>A collection of DocumentTypeDto.</returns>
        IList<DocumentTypeDto> GetDocumentTypes();

        IList<DocumentTypeDto> GetAllDocumentTypes(bool includeDeleted = false);

        Task CreateDocumentTypeAsync(DocumentTypeDto dto);

        Task UpdateDocumentTypeAsync(DocumentTypeDto dto);

        Task<bool> DeleteDocumentTypeAsync(DocumentTypeDto dto);

        /// <summary>
        /// Gets active document extensions.
        /// </summary>
        /// <returns>A collection of DocumentExtensionDto.</returns>
        IList<DocumentExtensionDto> GetDocumentExtensions();

        /// <summary>
        /// Gets the zip code geography.
        /// </summary>
        /// <param name="zipCode">The zip code.</param>
        /// <returns>A Zip Code Geography if found.</returns>
        Task<ZipCodeGeographyDto> GetZipCodeGeographyAsync(string zipCode);

        /// <summary>
        /// Gets the application event type asynchronous.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>An App Event Type if found.</returns>
        Task<LookupDto> GetAppEventTypeAsync(AppEventType type);

        IList<TicketTypeDto> GetAllTicketTypes();

        IList<EventTicketTypeDto> GetEventTicketTypes();

        IList<OfferTicketTypeDto> GetOfferTicketTypes();

        IList<OfferRateTypeDto> GetOfferRateTypes();

        IList<LineOfBusinessDto> GetLinesOfBusiness();

        IList<LeadSourceDto> GetLeadSources();

        IList<ContractDueFromDto> GetContractsDueFrom();

        IList<ContractStatusDto> GetContractStatuses();

        IList<TimeZoneDto> GetAllTimeZones();

        IList<ContractTypeDto> GetContractTypes();

        IList<SalesTaxTypeDto> GetAllSalesTaxTypes();

        IList<LookupDto> GetAllContractEntityTypes();

        IList<LookupDto> GetAllContractTransactionTypes();

        IList<LookupDto> GetAllPaymentMethods();

        IList<AppUserDto> GetAllAgents();

        IList<AppUserDto> GetAllActiveAgents();

        IList<LookupDto> GetAllExpenseBatchTypes();

        IList<LookupDto> GetAllExpensePaymentTypes();

        IList<LookupDto> GetAllContractTransactionExpenseTypes();

        IList<GenericRiderDto> GetGenericRiders();

        Task<IList<GenericRiderDto>> GetGenericRidersAsync();

        Task<IList<GenericRiderDto>> GetAllGenericRidersAsync(bool includeInactive);

        Task<IList<GenericRiderDto>> GetGenericRidersAsync(int eventTypeId);

        IList<GenericRiderDto> GetGenericRidersByEventType(int eventTypeId);

        Task<GenericRiderDto> GetGenericRiderAsync(int genericRiderId);

        Task CreateGenericRiderAsync(GenericRiderDto dto, DocumentDto document, IPrincipal user);

        Task UpdateGenericRiderAsync(GenericRiderDto dto, DocumentDto document, IPrincipal user);

        IList<LookupDto> GetAllLeadParticipantTypes();

        IList<LeadSourceDto> GetAllLeadSubmissionSources();

        IList<LookupDto> GetArtistChargeStatuses();

        IList<LookupDto> GetArtistChargeTypes();

        IList<LookupDto> GetArtistChargeTransactionTypes();

        IList<LookupDto> GetInterestCalculatedFrequencies();

        IList<LookupDto> GetAllRoles();

        IList<ContractWizardStepDto> GetContractWizardSteps();

        IList<LookupDto> GetAllGeneralLedgerEvents();

        IList<LookupDto> GetAllGeneralLedgerAccounts();

        IList<LookupDto> GetActiveGeneralLedgerAccounts();

        IList<EventTimeReasonDto> GetAllEventTimeReasons();

        IList<PayrollLogTypeDto> GetAllPayrollLogTypes();
        IList<TiersMasterDto> GetAllTiersMasters(bool includeDeleted = false);
        Task CreateTiersMasterAsync(TiersMasterDto dto);
        Task UpdateTiersMasterAsync(TiersMasterDto dto);
        Task<bool> DeleteTiersMasterAsync(TiersMasterDto dto);

        Task<TiersMasterValidateDto> GetValidTiersMaster();
        IList<DashboardDto> GetAllDashboard(bool includeDeleted);
        Task CreateDashboardAsync(DashboardDto dto, IPrincipal principal);
        Task UpdateDashboardAsync(DashboardDto dto, IPrincipal principal);
        Task<bool> DeleteDashboardAsync(DashboardDto dto);
        IList<BIDashboardDto> GetAllBIDashboard(bool includeDeleted);
        Task<(string, string)> CreateBIDashboardAsync(BIDashboardDto dto, IPrincipal principal);
        Task<(string, string)> UpdateBIDashboardAsync(BIDashboardDto dto, IPrincipal principal);
        Task<(string, string)> DeleteBIDashboardAsync(BIDashboardDto dto, IPrincipal principal);

        IList<FeatureFlagDto> GetAllFeatureFlag(bool includeDeleted);
        Task<(string, string)> CreateFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal);
        Task<(string, string)> UpdateFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal);
        Task<(string, string)> DeleteFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal);
        IList<FeatureFlagAndUserDto> GetAllFeatureAndUserFlags();
        Task<UsersFeatureFlagDto> GetAllUsersFeatureFlag();
        Task<UsersFeatureFlagWiseDto> GetAllUsersFeatureFlagWise(int id);
        Task<List<LuKeyTypeDto>> GetAllLuKeyTypes();
        IList<OfficeDto> GetRestrictedOffices();

        Task<IList<MainTermsandConditionDto>> GetMainTermsandCondition(bool includeDeleted);

        Task CreateMainTermsandConditionAsync(MainTermsandConditionDto dto);
        Task UpdateMainTermsandConditionAsync(MainTermsandConditionDto dto);
        Task<bool> DeleteMainTermsandConditionAsync(MainTermsandConditionDto dto);

        Task<IList<PandaDocTemplateDto>> GetPandaDocTemplate(bool includeDeleted);
        Task CreatePandaDocTemplateAsync(PandaDocTemplateDto dto);
        Task UpdatePandaDocTemplateAsync(PandaDocTemplateDto dto);
        Task<bool> DeletePandaDocTemplateAsync(PandaDocTemplateDto dto);
       
    }
}
