﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IGeneralLedgerService
    {
        Task<IList<GeneralLedgerAccountDto>> GetAccountsAsync();

        Task<IList<GeneralLedgerJournalActivityDto>> GetJournalActivityAsync();

        Task<IList<GeneralLedgerJournalDto>> GetJournalActivityByContractTransactionIdAsync(int id);

        Task<GeneralLedgerAccountDto> GetGLAccountByIdAsync(int id);

        Task<IList<GeneralLedgerJournalActivityDto>> GetGLJournalDetailsByCriteriaAsync(GLJournalDetailsSearchCriteriaDto criteria);

        Task<bool> ContractIsInitializedAsync(int id);

        Task<IList<GLJournalSearchResultDto>> GetGLJournalEntriesByCriteriaAsync(GLJournalSearchCriteriaDto criteria);

        Task<IList<ExpenseManagementSearchResultDto>> GetExpenseManagementByCriteriaAsync(ExpenseManagementSearchCriteriaDto criteria);

        GeneralLedgerEvent GetEventForPayingNonEceExpense(ContractTransactionDto transaction);

        GeneralLedgerEvent GetEventForPayingIncome(ContractTransactionDto transaction);

        Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId);

        Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId);

        Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber);

        Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, int? expenseBatchId);

        Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user);

        Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber);

        Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, int? expenseBatchId);

        Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user);

        Task PayEceExpensesForContractAsync(int contractId, IPrincipal user);

        Task<decimal> PayEceExpenseAsync(ContractTransactionDto expense, decimal amountToPay, IPrincipal user,bool isConverted = false);

        Task UnpayEceExpensesForContractAsync(decimal amountToUnpay, int contractId, IPrincipal user);

        GeneralLedgerEvent GetReversedGlEvent(GeneralLedgerEvent generalLedgerEvent);

        Task<GeneralLedgerTransactionTypeDto> GetGLTransactionTypeByIdAsync(int id);

        Task<List<GeneralLedgerTransactionTypeDto>> GetTransactionTypesByEventIdAsync(int id, int? contractEntityTypeId);

        Task AddManualJournalEntriesAsync(IList<GeneralLedgerJournalDto> entries, IPrincipal user);

        Task UpdateGeneralLedgerJournalAsync(GeneralLedgerJournalDto dto);

        Task<bool> HasGeneralLedgerJournalEntriesAsync(int contractId);

        Task<IList<GeneralLedgerJournalDto>> GetSelectedTransactionsAsync(int[] selectedEntries);

        Task ReverseReapplyOfficeLOBChangeAsync(ContractDto dto, IPrincipal user);

        Task<decimal> PayEceExpense_UCE_Async(ContractTransactionDto expense, decimal amountToPay,bool isGLReverse,IPrincipal user);

        Task<UCEGLLogsDTO> FetchLastLogDetailAsync(int contractTransactionId);

        Task CreateUCEGLLogAsync(UCEGLLogsDTO logsDTO);

        Task Create_UCE_GeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId,bool isGLReverse);

    }
}