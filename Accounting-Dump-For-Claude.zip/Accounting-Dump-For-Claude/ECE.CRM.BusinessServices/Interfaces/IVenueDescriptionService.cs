﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IVenueDescriptionService
    {
        Task<int> CreateAsync(VenueDescriptionDto venueDescription);

        Task<List<VenueDescriptionDto>> GetVenueTypesByVenueAsync(int id);

        Task SyncVenueDescriptionsAsync(int venueId, IEnumerable<string> venueTypes);
    }
}
