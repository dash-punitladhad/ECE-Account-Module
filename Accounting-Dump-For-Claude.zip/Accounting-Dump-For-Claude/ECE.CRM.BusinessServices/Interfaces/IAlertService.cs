﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IAlertService
    {
        Task CreateAsync(AlertDto alert, IPrincipal user);

        Task DismissAsync(int alertId, IPrincipal user);

        Task<List<AlertDto>> GetAlerts(int userId, bool includeDismissed);

        Task<bool> DismissAllAsync(IPrincipal user);
        Task<bool> SetReadAlertAsync(AlertViewMode viewModel, IPrincipal user);
        Task<List<AlertAdvDto>> GetAlertsAdv(int userId, bool includeDismissed, int? entitytypeid, string search, DateTime? startDate, DateTime? endDate);
    }
}
