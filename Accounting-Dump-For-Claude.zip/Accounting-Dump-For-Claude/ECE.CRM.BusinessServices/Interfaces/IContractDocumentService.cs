﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractDocumentService
    {
        Task<IList<ContractDocumentDto>> GetByContractIdAsync(int contractId);

        IList<ContractDocumentDto> GetByDocumentId(int documentId);

        Task<IList<ContractDocumentDto>> GetByOriginalEntityIdAndEntityTypeIdAsync(
            int contractId,
            int originalEntityId,
            int originalEntityTypeId);

        Task<ContractDocumentDto> GetByIdAsync(int id);

        Task CreateAsync(ContractDocumentDto dto, IPrincipal user);

        Task UpdateAsync(ContractDocumentDto dto, IPrincipal user);

        Task DeleteAsync(int id);

        Task DeleteAsync(ContractDocumentDto dto);

        Task<DocumentDto> GetContractDocumentAsync(
            int contractId,
            int contractDocumentId,
            int documentId,
            bool? isRider = null);

        Task<IList<ContractDocumentDto>> GetContractDocumentsAsync(int contractId, bool? isRider = null);
        Task<IList<ContractDocumentDto>> GetByContractIdForContractVersionAsync(int contractId);
        Task<IList<ContractDocumentDto>> GetContractDocumentsForArtistAsync(int contractId, int artistId);

        Task<IList<ContractDocumentDto>> GetContractDocumentsForPresenterAsync(int contractId);

        Task<IList<ContractDocumentDto>> GetContractRidersAsync(int contractId);

        Task<IList<ContractDocumentDto>> GetContractInternalDocumentsAsync(int contractId);
        Task<IList<AddendumDocumentDto>> GetAddendumDocumentsAsync(int contractId);
        Task<IList<AddendumDocumentDto>> GetAddendumDocumentsByLMDAsync(int userId);
        Task UpdateAddendumDocumentsByLMDAsync(int addendumDocumentId, string status, IPrincipal user, MessageDto messageDto);
        Task<Tuple<MemoryStream, string>> GetContractPdfMemoryStreamAsync(int contractId);
        Task<bool> SetTemplateHistoryPDFChangesAsync(int contractId, IPrincipal user,bool IsPDFChanges);
    }
}
