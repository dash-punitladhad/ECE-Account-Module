﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IArtistChargeService
    {
        Task CreateAsync(ArtistChargeDto dto, IPrincipal user);

        Task UpdateAsync(ArtistChargeDto dto, IPrincipal user);

        Task<IList<ArtistChargeDto>> GetArtistChargesByArtistIdAsync(int artistId);

        Task<ArtistChargeDto> GetArtistChargeByIdAsync(int id);

        Task<IList<ArtistChargeTransactionDto>> GetArtistChargeTransactionsByArtistChargeIdAsync(int artistCharge);

        Task<IList<ArtistChargeSearchResultDto>> GetArtistChargesByCriteriaAsync(ArtistChargeSearchCriteriaDto criteria);

        Task SaveArtistChargePaymentAsync(int artistChargeId, int expensePaymentId, IPrincipal user);

        Task<ArtistChargeTransactionDto> CreateArtistChargeRepaymentAsync(ArtistChargeDto artistCharge, int expensePaymentId, IPrincipal user);

        Task PostArtistChargeRepaymentsAsync(int expensePaymentId, IPrincipal user);

        Task SaveArtistChargeAdjustmentAsync(int artistChargeId, decimal amount, IPrincipal user);
    }
}
