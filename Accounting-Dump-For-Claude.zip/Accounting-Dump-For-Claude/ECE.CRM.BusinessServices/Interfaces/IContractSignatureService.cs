﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IContractSignatureService
    {
        Task<IEnumerable<ContractSignatureDto>> GetByContractIdAsync(int contractId);

        Task<IEnumerable<ContractSignatureDto>> GetByEntityIdAndEntityTypeAsync(int contractId, int entityId, int entityType);

        Task<ContractSignatureDto> GetByIdAsync(int id);

        Task CreateAsync(ContractSignatureDto dto, IPrincipal user);

        Task UpdateAsync(ContractSignatureDto dto, int updatedById);

        Task RejectSignatureAsync(int contractId, int contractSignatureId, IPrincipal user);

        Task GenerateSignatureAlertAsync(int agentId, int contractId, string signedByName, IPrincipal user);

        Task MarkAsReceivedAsync(ContractSignatureDto contractSignatureDto, DocumentDto documentDto, IPrincipal user);

        Task<bool> SendContractAsync(ContractSignatureDto contractSignatureDto, ContactDto contact, IPrincipal user, HttpClient httpClient, Uri url);

        Task DeleteAsync(int contractSignatureId);

        Task UpdateContractStatusAsync(ContractDto contract, IPrincipal user);

        Task<ContactDto> GetContractSignerAsync(int contractId);

        Task<ContactDto> GetPrimaryContactAsync(int contractId);

        Task<ContractSignatureDto> SaveSignatureAsync(SaveSignatureDto saveSignature, IPrincipal user);

        Task<ContractSignatureDto> SaveSignatureAsync(SaveSignatureDto saveSignature, IPrincipal user, HttpClient httpClient, Uri url);
        Task SendContractEmailForArtistPortalUserAsync(string firstName, string emailAddress, ContractDto contract, IPrincipal user);
        Task<TemplateMailMessage> SendContractEmailWithAttachmentAsync(string emailAddress, string firstName, ContractDto contract, DocumentDto doc);

        Task SendAllSignaturesReceivedEmailForPresenterPortalUserAsync(ContactDto contact, PresenterPortalDto portal, IPrincipal user, int agentId);
        Task<TemplateMailMessage> SendContractEmailWithAttachmentPandaDocAsync(string emailAddress, string firstName, ContractDto contract, DocumentDto doc, int artistId);

    }
}