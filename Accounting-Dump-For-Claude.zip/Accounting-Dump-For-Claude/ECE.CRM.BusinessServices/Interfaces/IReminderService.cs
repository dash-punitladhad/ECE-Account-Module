﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IReminderService
    {
        bool AddReminder(ReminderDto reminder);

        List<ReminderDto> GetReminders(int userId);

        Task<IList<ReminderDto>> GetUpcomingRemindersAsync(int userId);
        Task<IList<ReminderDto>> GetUpcomingRemindersFilterAsync(int userId, int entityId, int entityTypeId);
    }
}
