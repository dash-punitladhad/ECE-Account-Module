﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IOfferVenueDescriptionService
    {
        Task<int> CreateAsync(OfferVenueDescriptionDto venueDescription);

        Task<List<OfferVenueDescriptionDto>> GetVenueTypesByOfferAsync(int id);

        Task SyncVenueDescriptionsAsync(int offerId, IEnumerable<string> venueTypes);
    }
}
