﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IContractEventDateService
    {
        TimeSpan? SingleEventDateChangeDelta(IEnumerable<ContractEventDateDto> oldDates, IEnumerable<ContractEventDateDto> newDates);

        Task<IEnumerable<ContractEventDateDto>> GetByContractIdAsync(int contractId);

        Task<ContractEventDateDto> GetByIdAsync(int id);

        Task CreateAsync(ContractEventDateDto dto);

        Task UpdateAsync(ContractEventDateDto dto);

        Task DeleteAsync(ContractEventDateDto dto);

        Task<bool> CheckArefDueDateAsync(ContractTransactionDto dto);
    }
}
