﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    /// <summary>
    /// User Service Interface.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Authenticates the user.
        /// </summary>
        /// <param name="userName">The username.</param>
        /// <param name="password">The password.</param>
        /// <returns>An authentication status representing the result.</returns>
        Task<AuthenticationStatus> AuthenticateUserAsync(string userName, string password);

        /// <summary>
        /// Unlocks the user.
        /// </summary>
        /// <param name="userToUnlockId">The user identifier.</param>
        /// <param name="user">The user.</param>
        /// <returns><c>true</c> if user is unlocked, <c>false</c> otherwise.</returns>
        Task<bool> UnlockUserAsync(int userToUnlockId, IPrincipal user);

        /// <summary>
        /// Initiate the forgot password process.
        /// </summary>
        /// <param name="userToProcess">The user to process.</param>
        /// <param name="user">The user.</param>
        /// <returns><c>true</c> if successful, <c>false</c> otherwise.</returns>
        Task<bool> InitiateForgotPasswordAsync(AppUserDto userToProcess, IPrincipal user);

        /// <summary>
        /// Resets the user's password.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns><c>true</c> if reset was successful, <c>false</c> otherwise.</returns>
        Task<bool> ResetPasswordAsync(int userId, string newPassword);

        /// <summary>
        /// Changes the user's password.
        /// </summary>
        /// <param name="username">The user name.</param>
        /// <param name="oldPassword">The old password.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns><c>true</c> if successful, <c>false</c> otherwise.</returns>
        Task<bool> ChangePasswordAsync(string username, string oldPassword, string newPassword);

        /// <summary>
        /// Generates the password change notification.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        Task GeneratePasswordChangeNotificationAsync(AppUserDto user);

        /// <summary>
        /// Determines whether the specified token is valid.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns><c>true</c> if the specified token is valid; otherwise, <c>false</c>.</returns>
        Task<bool> IsValidPasswordTokenAsync(string token);

        /// <summary>
        /// Determines whether the specified password is valid.
        /// </summary>
        /// <param name="password">The password.</param>
        /// <returns><c>true</c> if password is valid; otherwise, <c>false</c>.</returns>
        bool IsValidPassword(string password);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <param name="includeRolesPermissions">if set to <c>true</c> then include roles and permissions.</param>
        /// <param name="includeSettings">if set to <c>true</c> then include settings.</param>
        /// <returns>The application user data if found; otherwise null.</returns>
        Task<AppUserDto> GetUserAsync(AppUserDto criteria, bool includeRolesPermissions = false, bool includeSettings = false);

        /// <summary>
        /// Gets the agent's LMD
        /// </summary>
        /// <param name="agentId">the criteria</param>
        /// <returns>The LMD user for given agent</returns>
        Task<List<AppUserDto>> GetLMDByAgentAsync(int agentId);

        /// <summary>
        /// Updates the user details.
        /// </summary>
        /// <param name="updatedUser">The updated user.</param>
        /// <param name="user">The user performing the update.</param>
        /// <param name="isAdminUpdate">if set to <c>true</c> [updated performed by admin].</param>
        /// <returns><c>true</c> if update successful, <c>false</c> otherwise.</returns>
        Task<bool> UpdateDetailsAsync(AppUserDto updatedUser, IPrincipal user, bool isAdminUpdate = false);

        /// <summary>
        /// Determines the landing page.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The landing page for the user.</returns>
        Task<LandingPage?> DetermineLandingPageAsync(AppUserDto user);

        /// <summary>
        /// Determines the dashboard.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The dashboard for the user.</returns>
        Task<LandingPage?> DetermineDashboardAsync(AppUserDto user);

        /// <summary>
        /// Gets the user's last X password history.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of AppUserPasswordHistoryDtos.</returns>
        Task<IList<AppUserPasswordHistoryDto>> GetPasswordHistoryAsync(int userId);

        /// <summary>
        /// Validates the new password against the password history.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="newPassword">The new (unencrypted) password.</param>
        /// <returns><c>true</c> if password does not match any in history, <c>false</c> otherwise.</returns>
        Task<bool> ValidatePasswordAgainstHistoryAsync(int userId, string newPassword);

        /// <summary>
        /// Gets the users by role.
        /// </summary>
        /// <param name="roleId">The role identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> include deleted users.</param>
        /// <returns>A list containing matching users.</returns>
        IList<AppUserDto> GetUsersByRole(int roleId, bool? isDeleted = null);

        /// <summary>
        /// Returns a flag indicating if the user is in the role.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="role">The role.</param>
        /// <returns><c>true</c> if the user is in the role, <c>false</c> otherwise.</returns>
        bool UserInRole(int userId, ECERole role);

        /// <summary>
        /// Checks the user has role asynchronous.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="role">The role.</param>
        /// <returns><c>true</c> if the user has the role; otherwise <c>false</c>.</returns>
        Task<bool> CheckUserHasRoleAsync(int userId, ECERole role);

        /// <summary>
        /// Gets the user by entity and role asynchronously.
        /// </summary>
        /// <param name="entityId">The entity identifier.</param>
        /// <param name="role">The role.</param>
        /// <param name="isActive">The isActive.</param>
        /// <returns>The user data if found; otherwise null.</returns>
        Task<AppUserDto> GetUserByEntityAsync(int entityId, ECERole role, bool? isActive = null);

        /// <summary>
        /// Creates an application user asynchronously.
        /// </summary>
        /// <param name="appUser">The application user to create.</param>
        /// <param name="user">The user creating the new application user.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        Task CreateUserAsync(AppUserDto appUser, IPrincipal user);

        /// <summary>
        /// Loads the audit information asynchronously.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        Task LoadAuditInfoAsync(BaseDto dto);

        IList<AppUserDto> GetAllActive(bool excludeArtistUsers = false);

        Task<IList<OfficeDto>> GetOfficesForUser(int userId, int? roleId = null);

        Task<IList<AppUserDto>> GetOfficeCoworkersAsync(int userId, int? roleId = null);

        Task<AppUserDto> GetUserByIdAsync(int id, bool includeRolesPermissions = false);

        IList<AppUserDto> GetByCriteria(UserSearchCriteriaDto criteria);

        Task<IList<AppUserDto>> GetByCriteriaAsync(UserSearchCriteriaDto criteria);

        Task<bool> CheckForDuplicatesAsync(int appUserId, string userName, string initials);

        Task CreateAsync(AppUserDto dto, IPrincipal user);

        Task UpdateAsync(AppUserDto dto, IPrincipal user);

        Task<AppUserDto> GetNonPortalUserAsync(string userName, bool? isActive = null);

        Task<(bool, string)> GeneratNewPassword(int appUserId);

        Task<bool> ChangeAgentStatus(UserAgentDto userAgentDto,IPrincipal user);

        Task<List<UserPermissionDto>> GetUserPermission(int appUserId);
        Task SetUsersAndPermissions(string userList, string permissionList, int createdById);
        Task SetUserRoleWisePermissions(string roleList, int userId, int createdById);

        Task<List<PermissionUserDto>> GetPermissionUser(int appUserId, int permissionId, int roleId);

        Task<List<PermissionUserOfficeDto>> GetUserPermissionsAnsHisOffices(int UserId);

        Task<List<HelpUpdateDto>> GetHelpUpdates();

        Task<List<HelpUpdateHtmlDto>> GetHelpUpdatesHtml();
        Task<HelpUpdateHtmlDto> GetByIdHelpUpdatesHtml(int helpUpdatesHtmlId);

        Task UpdatedHelpUpdatesHtml(HelpUpdateHtmlDto model);
    }
}
