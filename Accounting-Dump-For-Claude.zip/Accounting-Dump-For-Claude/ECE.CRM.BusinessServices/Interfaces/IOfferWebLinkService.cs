﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IOfferWebLinkService
    {
        Task<List<WebLinkDto>> GetOfferWebLinksAsync(EntityType entityType, int entityId, int context);

        Task SyncOfferWebLinksAsync(EntityType entityType, int entityId, IEnumerable<WebLinkDto> updatedWebLinks, IPrincipal user, int originalEntityTypeId = 0);
    }
}