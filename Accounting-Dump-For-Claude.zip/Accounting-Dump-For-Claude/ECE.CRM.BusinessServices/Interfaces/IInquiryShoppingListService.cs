﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public interface IInquiryShoppingListService
    {
        Task<IList<InquiryShoppingListDto>> GetByInquiryIdAsync(int inquiryId);

        Task AddShoppingListItemAsync(InquiryShoppingListDto dto, IPrincipal user);

        Task UpdateShoppingListItemAsync(int id, InquiryShoppingListDto dto, IPrincipal user);

        Task DeleteShoppingListItemAsync(int id);
    }
}
