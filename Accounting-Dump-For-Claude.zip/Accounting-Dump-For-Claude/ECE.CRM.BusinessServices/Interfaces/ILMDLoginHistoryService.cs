﻿using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Interfaces
{
	public interface ILMDLoginHistoryService
	{
		Task CreateAsync(LMDLoginHistoryDto lMDLoginHistoryDto, IPrincipal user);
		Task<List<LMDLoginHistoryUserDto>> GetLMDLoginHistoryListAsync(int lMdId, bool isSystemAdmin);
		Task<bool> CheckLMDLoginHistoryExistsAsync(LMDLoginHistoryDto lMDLoginHistoryDto);
		Task<bool> RevereseLMDLoginHistoryAsync(LMDLoginHistoryDto lMDLoginHistoryDto);
	}
}
