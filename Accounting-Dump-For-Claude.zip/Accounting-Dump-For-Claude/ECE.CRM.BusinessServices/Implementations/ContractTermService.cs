﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractTermService : IContractTermService
    {
        public ContractTermService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ContractTermDto>> GetByContractIdAsync(int contractId, bool isActive = true)
        {
            return await this.Context.ContractTerms.GetByContractIdAsync(contractId, isActive);
        }

        public Task<IList<ContractTermDto>> GetByTermIdAsync(int termId)
        {
            throw new NotImplementedException();
        }

        public Task<ContractTermDto> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task CreateAsync(ContractTermDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.ContractTerms.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractTermDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.ContractTerms.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(int id)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractTerms.DeleteAsync(id);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }
    }
}
