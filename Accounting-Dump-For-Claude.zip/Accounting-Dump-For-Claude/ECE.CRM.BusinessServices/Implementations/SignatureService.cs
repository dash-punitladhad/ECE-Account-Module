﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Security.Principal;

    public class SignatureService : ISignatureService
    {
        public SignatureService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public SignatureDto GetLatestSignature(int accountNumber)
        {
            var dto = new SignatureDto
            {
                AppUserId = accountNumber,
                IsCurrent = true
            };

            return Context.Signatures.GetLatestSignature(dto);
        }

        public int UploadSignature(int userId, string signatureImage, string name, IPrincipal user)
        {
            var dto = new SignatureDto
            {
                AppUserId = userId,
                SignatureImage = signatureImage,
                SignerName = name,
                IsCurrent = true
            };

            dto.SetAsCreated(user);

            // if the user is not logged (PresenterPortal), we assume the createById should be the presenterId for the contract
            // TODO: apply this to offer controller logic as well?
            if (user.GetUserId() != userId)
            {
                dto.CreatedById = userId;
            }

            try
            {
                this.Context.BeginTransaction();
                var newSignatureId = Context.Signatures.Create(dto);
                this.Context.Commit();

                return newSignatureId;
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public SignatureDto GetSignatureById(int id)
        {
            return Context.Signatures.GetSignatureById(id);
        }
    }
}