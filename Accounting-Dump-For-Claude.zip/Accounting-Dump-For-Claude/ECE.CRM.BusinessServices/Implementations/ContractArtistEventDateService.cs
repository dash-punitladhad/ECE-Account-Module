﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ContractArtistEventDateService : IContractArtistEventDateService
    {
        public ContractArtistEventDateService(IUnitOfWork context, ILogger logger = null)
        {
            this.Context = context;
            this.Logger = logger;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<IList<ContractArtistEventDateDto>> GetByContractArtistIdAsync(int contractArtistId)
        {
            if (contractArtistId <= 0)
            {
                throw new ArgumentException(nameof(contractArtistId));
            }

            var results = await this.Context.ContractArtistEventDates.GetByContractArtistIdAsync(contractArtistId);

            return results;
        }

        public async Task<IList<ContractArtistEventDateDto>> GetByContractEventDateIdAsync(int contractEventDateId)
        {
            if (contractEventDateId <= 0)
            {
                throw new ArgumentException(nameof(contractEventDateId));
            }

            var results = await this.Context.ContractArtistEventDates.GetByContractEventDateIdAsync(contractEventDateId);

            return results;
        }

        public Task<ContractArtistEventDateDto> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task CreateAsync(ContractArtistEventDateDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractArtistEventDates.CreateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractArtistEventDateDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            this.Context.BeginTransaction();

            try
            {
                this.Logger.LogDebug($"dto.EventStartTimeSpan = {dto.EventStartTimeSpan}");
                this.Logger.LogDebug($"dto.EventEndTimeSpan = {dto.EventEndTimeSpan}");
                await this.Context.ContractArtistEventDates.UpdateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractArtistEventDates.DeleteAsync(id);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }
    }
}
