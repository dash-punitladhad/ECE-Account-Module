﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;

    public class ExpensePaymentAmounts
    {
        public decimal GrossAmount { get; set; }

        public decimal DeductionAmount { get; set; }

        public decimal PaymentAmount { get; set; }

        public int TransactionCount { get; set; }

        public IEnumerable<ArtistChargeDto> LoansToRepay { get; set; }

        public IEnumerable<ContractTransactionDto> DepositsToPay { get; set; }
    }
}
