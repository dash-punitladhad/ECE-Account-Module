﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class AppLogService : IAppLogService
    {
        public AppLogService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<AppLogDto>> GetByCriteriaAsync(AppLogSearchCriteriaDto criteria)
        {
            return await this.Context.AppLogs.GetByCriteriaAsync(criteria);
        }
    }
}
