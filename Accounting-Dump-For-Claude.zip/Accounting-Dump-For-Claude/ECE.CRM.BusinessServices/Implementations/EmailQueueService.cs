﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;

    public class EmailQueueService : IEmailQueueService
    {
        private ICommunicationLogService _communicationLogService;

        public EmailQueueService(IUnitOfWork context, ICommunicationLogService communicationLogService)
        {
            this.Context = context;
            this._communicationLogService = communicationLogService;
        }

        public IUnitOfWork Context { get; private set; }

        public void HidePresenterPortalLink(EmailQueueDto email)
        {
            var body = email.Body;

            // Hide the URL Key by replacing it with a series of 'X' characters.
            body = Regex.Replace(
                body,
                @"[0-9A-Fa-f]{32}",
                "XXXXXXXXXXXXXXXX",
                RegexOptions.IgnoreCase);

            email.Body = body;
        }

        public bool CanViewPresenterPortalLink(EmailQueueDto email, IPrincipal user)
        {
            if (email == null)
            {
                throw new ArgumentNullException(nameof(email));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var hidePresenterPortalEmails = MobiusConfiguration.GetBoolean("Application.HidePresenterPortalEmails", true);
            if (hidePresenterPortalEmails == false)
            {
                return true;
            }

            switch (email.EmailTemplateId)
            {
                // These are the templates agent's are not allowed to view since they contain a link
                // to the presenter portal.
                case (int)EmailTemplate.IssueContract:
                case (int)EmailTemplate.SendContractToPresenterWithPortalLink:
                case (int)EmailTemplate.SendSignatureDepositNotification:
                case (int)EmailTemplate.SendAllSignaturesReceived:
                case (int)EmailTemplate.FollowupMessage:
                case (int)EmailTemplate.SendPresenterAdvanceNotification:
                    break;

                default:
                    return true;
            }

            if (user.IsInRole(ECERole.SysAdmin))
            {
                return true;
            }

            return false;
        }

        public IList<EmailQueueDto> GetByCriteria(EmailQueueSearchCriteriaDto criteria)
        {
            return this.Context.EmailQueue.GetByCriteria(criteria);
        }

        public async Task<IList<EmailQueueDto>> GetByCriteriaAsync(EmailQueueSearchCriteriaDto criteria)
        {
            return await this.Context.EmailQueue.GetByCriteriaAsync(criteria);
        }

        public EmailQueueDto GetById(int id)
        {
            return this.Context.EmailQueue.GetById(id);
        }

        public async Task<EmailQueueDto> GetByIdAsync(int id)
        {
            return await this.Context.EmailQueue.GetByIdAsync(id);
        }

        public bool Update(EmailQueueDto email, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                if (this.CanViewPresenterPortalLink(email, user) == false)
                {
                    // Replace the hidden URL Key with the original value.
                    var original = this.Context.EmailQueue.GetById(email.EmailQueueId);

                    var match = Regex.Match(
                        original.Body,
                        @"([0-9A-Fa-f]{32})",
                        RegexOptions.IgnoreCase);

                    if (match.Success)
                    {
                        var originalUrlKey = match.Groups[1].Value;

                        email.Body = email.Body.Replace("XXXXXXXXXXXXXXXX", originalUrlKey);
                    }
                }

                email.SetAsUpdated(user);

                var result = this.Context.EmailQueue.Update(email);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public bool Delete(int id)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = this.Context.EmailQueue.Delete(id);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var result = false;

            this.Context.BeginTransaction();

            try
            {
                var emailToRelease = await this.Context.EmailQueue.GetByIdAsync(id);

                if (emailToRelease.Status != EmailQueueStatus.Sent)
                {
                    var commLogs = await this._communicationLogService.GetEmailQueuedCommunicationLogsAsync(id);

                    if (commLogs.Any())
                    {
                        foreach (var cl in commLogs)
                        {
                            if (cl.EmailQueueId.HasValue)
                            {
                                cl.EmailQueueId = null;
                                await this._communicationLogService.UpdateAsync(cl);
                            }
                        }
                    }

                    result = await this.Context.EmailQueue.DeleteAsync(id);
                }

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public bool Release(int id)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = this.Context.EmailQueue.Release(id);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> ReleaseAsync(int id, IPrincipal user)
        {
            var result = false;

            this.Context.BeginTransaction();

            try
            {
                var emailToRelease = await this.Context.EmailQueue.GetByIdAsync(id);

                if (emailToRelease.Status == EmailQueueStatus.Pending)
                {
                    result = await this.Context.EmailQueue.UpdateStatusAsync(id, EmailQueueStatus.Release, user.GetUserId());
                }

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public bool AddEmailToQueue(EmailQueueDto email)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = this.Context.EmailQueue.Create(email);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task ResendMessagesAsync(int[] selectedMessages, IPrincipal user)
        {
            if (selectedMessages == null)
            {
                throw new ArgumentNullException(nameof(selectedMessages));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var updatedById = user.GetUserId();

                foreach (var selectedMessage in selectedMessages)
                {
                    await this.Context.EmailQueue.UpdateStatusAsync(selectedMessage, EmailQueueStatus.Release, updatedById);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task AddResendCommLogAsync(EmailQueueDto message, int oldEmailQueueId, IPrincipal user)
        {
            if (message.EntityId.HasValue)
            {
                var criteria = new CommunicationLogSearchCriteriaDto
                {
                    EmailQueueId = oldEmailQueueId,
                    EntityId = message.EntityId.Value,
                    EntityTypeId = message.EntityTypeId.Value
                };

                var commLogs = await this.Context.CommunicationLogs.GetByCriteriaAsync(criteria);
                foreach (var commLog in commLogs)
                {
                    if (commLog.ContactId.HasValue)
                    {
                        var resendCommLog = new CommunicationLogDto
                        {
                            CommunicationMethodId = (int)CommunicationMethod.Email,
                            ContactId = commLog.ContactId.GetValueOrDefault(),
                            EntityId = commLog.EntityId,
                            EntityTypeId = (int)EntityType.Contract,
                            EmailQueueId = message.EmailQueueId,
                            LogDate = DateTime.Now,
                            LogTime = DateTime.Now.ToShortTimeString(),
                        };
                        resendCommLog.Notes = "RESEND: " + commLog.Notes;
                        resendCommLog.SetAsCreated(user);

                        this.Context.CommunicationLogs.Create(resendCommLog);
                    }
                }
            }
        }

        public async Task ResendMessagesAsync(int emailQueueId, bool useOriginalRecipients, bool forwardACopyToSender, bool forwardACopyToUser, string toAddresses, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var updatedById = user.GetUserId();

                var message = await this.Context.EmailQueue.GetByIdAsync(emailQueueId);

                var attachments = this.Context.Documents.GetDocuments(EntityType.EmailQueue, message.EmailQueueId);

                var oldEmailQueueId = message.EmailQueueId;

                message.EmailQueueId = 0;

                if (useOriginalRecipients)
                {
                    // Release a copy of the message in 24 hours.
                    message.ReleaseDate = DateTime.Now.AddDays(1);
                    message.SentDate = null;
                    await this.Context.EmailQueue.CreateAsync(message);

                    foreach (var item in attachments)
                    {
                        this.Context.Documents.LinkDocumentTo(EntityType.EmailQueue, message.EmailQueueId, item, user.GetUserId());
                    }

                    await AddResendCommLogAsync(message, oldEmailQueueId, user);

                    await this.Context.EmailQueue.UpdateStatusAsync(message.EmailQueueId, EmailQueueStatus.Pending, user.GetUserId());
                }

                if (!string.IsNullOrWhiteSpace(toAddresses))
                {
                    message.ToAddresses = toAddresses;

                    // Release a copy of the message in 24 hours.
                    message.ReleaseDate = DateTime.Now.AddDays(1);
                    message.SentDate = null;
                    await this.Context.EmailQueue.CreateAsync(message);

                    foreach (var item in attachments)
                    {
                        this.Context.Documents.LinkDocumentTo(EntityType.EmailQueue, message.EmailQueueId, item, user.GetUserId());
                    }

                    //// await AddResendCommLogAsync(message, oldEmailQueueId, user);

                    await this.Context.EmailQueue.UpdateStatusAsync(message.EmailQueueId, EmailQueueStatus.Pending, user.GetUserId());
                }

                if (forwardACopyToSender)
                {
                    // Release a copy of the message now.
                    var sentBy = await this.Context.Users.GetByIdAsync(message.AppUserId.Value);

                    message.ToAddresses = sentBy.Username;
                    message.ReleaseDate = DateTime.Now;
                    message.SentDate = null;
                    await this.Context.EmailQueue.CreateAsync(message);

                    foreach (var item in attachments)
                    {
                        this.Context.Documents.LinkDocumentTo(EntityType.EmailQueue, message.EmailQueueId, item, user.GetUserId());
                    }

                    await this.Context.EmailQueue.UpdateStatusAsync(message.EmailQueueId, EmailQueueStatus.Release, user.GetUserId());
                }

                if (forwardACopyToUser)
                {
                    // Release a copy of the message now.
                    message.ToAddresses = user.Identity.Name;
                    message.ReleaseDate = DateTime.Now;
                    message.SentDate = null;
                    await this.Context.EmailQueue.CreateAsync(message);

                    foreach (var item in attachments)
                    {
                        this.Context.Documents.LinkDocumentTo(EntityType.EmailQueue, message.EmailQueueId, item, user.GetUserId());
                    }

                    await this.Context.EmailQueue.UpdateStatusAsync(message.EmailQueueId, EmailQueueStatus.Release, user.GetUserId());
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
