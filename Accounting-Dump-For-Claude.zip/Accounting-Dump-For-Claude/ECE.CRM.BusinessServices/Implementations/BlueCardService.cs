﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class BlueCardService : IBlueCardService
    {
        private readonly IAlertService _alertService;
        private readonly IArtistService _artistService;
        private readonly IContactService _contactService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ILeadService _leadService;
        private readonly ILookupService _lookupService;
        private readonly IUserService _userService;
        private readonly IEceCrmEntities _eceCrmEntities;
        private AppUserDto _user = null;
        private AppUserDto _assignedAgent = null;

        public BlueCardService(
            IUnitOfWork context,
            IAlertService alertService,
            IArtistService artistService,
            IContactService contactService,
            IEntityHistoryService entityHistoryService,
            ILeadService leadService,
            ILookupService lookupService,
            IUserService userService,
            IEceCrmEntities eceCrmEntities)
        {
            this.Context = context;

            this._alertService = alertService;
            this._artistService = artistService;
            this._contactService = contactService;
            this._entityHistoryService = entityHistoryService;
            this._leadService = leadService;
            this._lookupService = lookupService;
            this._userService = userService;
            this._eceCrmEntities = eceCrmEntities;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<BlueCardDto> GetBlueCardByIdAsync(int id)
        {
            var blueCard = await this.Context.BlueCards.GetBlueCardByIdAsync(id);
            if (blueCard != null)
            {
                var eventDates = await this.Context.BlueCards.GetEventDatesAsync(id);
                var eventDatesList = new List<DateTime>();
                foreach (var eventDate in eventDates)
                {
                    eventDatesList.Add(eventDate.EventDate);
                }

                eventDatesList.Sort((a, b) => a.CompareTo(b));
                blueCard.EventDates = eventDatesList;

                var promo = await this.Context.BlueCardPromos.GetBlueCardPromoPageViewDataAsync(id);
                if (promo != null)
                {
                    blueCard.LastViewDate = promo.LastViewDate;
                    blueCard.PageViewCount = promo.PageViewCount;
                    blueCard.UrlKey = promo.UrlKey;
                    blueCard.UrlFriendlyName = promo.UrlFriendlyName;
                }

                blueCard.MobileCount = this._eceCrmEntities.PromoViewDeviceLogs.Count(_=>_.BlueCardId == blueCard.BlueCardId && _.DeviceType == "Mobile");
                blueCard.DesktopCount = this._eceCrmEntities.PromoViewDeviceLogs.Count(_ => _.BlueCardId == blueCard.BlueCardId && _.DeviceType == "Desktop");
                await this._userService.LoadAuditInfoAsync(blueCard);
            }

            return blueCard;
        }

        public void FilterNationalArtistData(BlueCardArtistDto artist)
        {
            if (artist.IsNational)
            {
                // Hide the artist's price information.
                artist.Net = null;
                artist.Gross = null;
            }
        }

        public async Task<List<BlueCardArtistDto>> GetBlueCardArtistsAsync(int id)
        {
            var artists = await this.Context.BlueCards.GetBlueCardArtistsAsync(id);

            foreach (var artist in artists)
            {
                this.FilterNationalArtistData(artist);
            }

            return artists;
        }

        // This version of the function hides price information for national artists.
        public async Task<List<BlueCardArtistDto>> GetBlueCardArtistsDetailAsync(int id)
        {
            var result = await this.Context.BlueCards.GetBlueCardArtistsAsync(id);

            foreach (var b in result)
            {
                var artist = await this._artistService.GetArtistByIdAsync(b.ArtistId);
                b.Name = artist.Name;
                b.IsExclusive = artist.IsExclusive;

                if (artist.IsNational)
                {
                    // Hide the artist's price information.
                    b.Net = null;
                    b.Gross = null;
                }
            }

            return result;
        }

        public async Task<List<ContactEmailDto>> GetContactEmailIdAsync(string id)
        {
            var result = await this.Context.Contacts.GetContactsByEmailAddressLikeAsync(id);


            return result.ToList();
        }

        public async Task UpdateAsync(BlueCardDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var original = await this.GetBlueCardByIdAsync(dto.BlueCardId);

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.BlueCards.UpdateAsync(dto);

                await UpdateEventDates(dto);

                // Updating associated artists
                var currentArtists = await this.Context.BlueCards.GetArtistsAsync(dto.BlueCardId);
                var currentArtistIds = currentArtists.Select(x => x.ArtistId).ToList();
                var newArtistIds = dto.BlueCardArtists.Select(x => x.ArtistId).ToList();

                // Update and/or delete existing artists.
                foreach (var k in dto.BlueCardArtists)
                {
                    var currentArtist = currentArtists.FirstOrDefault(x => x.ArtistId == k.ArtistId);

                    // delete artists that need deleting
                    if (k.IsDeleted == true && currentArtist != null)
                    {
                        k.SetAsUpdated(user);

                        await this.Context.BlueCards.DeleteBlueCardArtistAsync(k);

                        var addArtistHistory = new EntityHistoryDto
                        {
                            EntityId = dto.BlueCardId,
                            Type = EntityType.BlueCard,
                            Event = AuditEvent.BlueCardArtistRemoved,
                            Description = $"Blue card artist {currentArtist.Name} removed.",
                            CreatedDate = DateTime.Now,
                            CreatedById = user.GetUserId()
                        };

                        await this._entityHistoryService.CreateEntityHistoryAsync(addArtistHistory);
                    }

                    // find artists that need updating, then update them
                    if (k.IsDeleted == false && currentArtist != null)
                    {
                        if (currentArtist.Gross != k.Gross || currentArtist.Net != k.Net || currentArtist.Notes != k.Notes)
                        {
                            k.SetAsUpdated(user);

                            await this.Context.BlueCards.UpdateBlueCardArtistAsync(k);
                        }
                    }
                }

                // Add ones not in the old batch but in the new batch
                var artistsToAdd = dto.BlueCardArtists.Where(x => !currentArtistIds.Contains(x.ArtistId)).ToList();
                foreach (var l in artistsToAdd)
                {
                    l.SetAsCreated(user);

                    await this.Context.BlueCards.AddBlueCardArtistAsync(l);

                    var addArtistHistory = new EntityHistoryDto
                    {
                        EntityId = dto.BlueCardId,
                        Type = EntityType.BlueCard,
                        Event = AuditEvent.BlueCardArtistAdded,
                        Description = $"Blue card artist {l.Name} added.",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(addArtistHistory);
                }

                // Syncing Contacts
                this._contactService.SyncContacts(EntityType.BlueCard, dto.BlueCardId, dto.Contacts, user);

                await this.AuditUpdatedEntity(original, dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, dto.BlueCardId, ex);
            }
        }

        public async Task UpdateBlueCardPresenterAsync(int blueCardId, int presenterId)
        {
            if (blueCardId <= 0)
            {
                throw new ArgumentException(nameof(blueCardId));
            }

            if (presenterId <= 0)
            {
                throw new ArgumentException(nameof(presenterId));
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.BlueCards.UpdateBlueCardPresenterAsync(blueCardId, presenterId);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, blueCardId, ex);
            }
        }

        public async Task UpdateWizardAsync(BlueCardDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);
                dto.IsInProgress = false;

                await this.Context.BlueCards.UpdateAsync(dto);

                await UpdateEventDates(dto);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, dto.BlueCardId, ex);
            }
        }

        public async Task<IList<BlueCardSearchResultsDto>> GetByCriteriaAsync(BlueCardSearchCriteriaDto criteria)
        {
            var results = await this.Context.BlueCards.GetByCriteriaAsync(criteria);

            return results;
        }

        public async Task<BlueCardDetailDto> GetBlueCardSearchDetailAsync(int id)
        {
            var results = await this.Context.BlueCards.GetBlueCardSearchDetailAsync(id);

            results.Contacts = this._contactService.GetContacts(EntityType.BlueCard, id);

            results.Artists = await this.Context.BlueCards.GetArtistsForBlueCardAsync(id);

            results.EventDates = await this.Context.BlueCards.GetEventDatesForBlueCardAsync(id);

            return results;
        }

        public async Task<List<OfferDto>> GetOffersListByIdAsync(int id)
        {
            var result = await this.Context.BlueCards.GetOffersListByIdAsync(id);

            return result;
        }

        public async Task LoadBlueCardUsersAsync(int userId, int assignedAgentId)
        {
            if (_user == null)
            {
                _user = await this._userService.GetUserByIdAsync(userId, true);
            }

            if (_assignedAgent == null)
            {
                _assignedAgent = await this._userService.GetUserByIdAsync(assignedAgentId, true);
            }
        }

        public async Task<bool> HasBaseUpdatePermissionsAsync(int userId, int assignedAgentId)
        {
            await LoadBlueCardUsersAsync(userId, assignedAgentId);

            if (_user != null && _assignedAgent != null && _user.AppUserId == _assignedAgent.AppUserId)
            {
                return true;
            }

            var hasLmdRole = _user.IsInRole(ECERole.LMD);
            if (hasLmdRole)
            {
                return _user.IsLmdForAgent(_assignedAgent);
            }

            return false;
        }

        public async Task<bool> CanReassignAsync(int userId, int assignedAgentId)
        {
            return await CanEditAsync(userId, assignedAgentId);
        }

        public async Task<bool> CanCreatePromoAsync(int userId, int assignedAgentId)
        {
            return await CanEditAsync(userId, assignedAgentId);
        }

        public async Task<bool> CanCreateContractAsync(int userId, int assignedAgentId)
        {
            await LoadBlueCardUsersAsync(userId, assignedAgentId);

            if (_user != null && _assignedAgent != null)
            {
                if (_user.AppUserId == _assignedAgent.AppUserId)
                {
                    return true;
                }
            }

            if (_user.IsInRole(ECERole.Assistant))
            {
                return _user.UsersAreInSameOffice(_assignedAgent);
            }

            return false;
        }

        public async Task<bool> CanSeeNationalArtistPricesAsync(int userId, int assignedAgentId)
        {
            await LoadBlueCardUsersAsync(userId, assignedAgentId);

            if (_user != null && _assignedAgent != null)
            {
                if (_user.IsInRole(ECERole.Nationals))
                {
                    return true;
                }

                if (_user.AppUserId == _assignedAgent.AppUserId)
                {
                    return true;
                }
            }

            if (_user.IsInRole(ECERole.Assistant))
            {
                return _user.UsersAreInSameOffice(_assignedAgent);
            }

            return false;
        }

        public async Task<bool> CanEditAsync(int userId, int assignedAgentId)
        {
            await LoadBlueCardUsersAsync(userId, assignedAgentId);

            var hasBasePermissions = await HasBaseUpdatePermissionsAsync(userId, assignedAgentId);
            if (hasBasePermissions)
            {
                return true;
            }

            if (_user.IsInRole(ECERole.Assistant))
            {
                return _user.UsersAreInSameOffice(_assignedAgent);
            }

            return false;
        }

        public async Task<bool> CanOpenCloseAsync(int userId, int assignedAgentId)
        {
            await LoadBlueCardUsersAsync(userId, assignedAgentId);

            var hasBasePermissions = await HasBaseUpdatePermissionsAsync(userId, assignedAgentId);
            if (hasBasePermissions)
            {
                return true;
            }

            return false;
        }

        public async Task CreateStep1Async(BlueCardDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.BlueCards.CreateAsync(dto);

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.BlueCardId,
                    Type = EntityType.BlueCard,
                    Event = AuditEvent.Created,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, dto.BlueCardId, ex);
            }
        }

        public async Task ToggleBlueCardStatusAsync(int blueCardId, bool isClosed, int updatedBy, int? blueCardClosedReasonId)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetBlueCardByIdAsync(blueCardId);
                DateTime? closedDate = null;

                if (isClosed)
                {
                    closedDate = DateTime.Now;
                    await this.DismissAlertsAndReminders(blueCardId, updatedBy);
                }

                await this.Context.BlueCards.ToggleBlueCardStatus(blueCardId, isClosed, updatedBy, blueCardClosedReasonId, closedDate);

                var history = new EntityHistoryDto
                {
                    EntityId = blueCardId,
                    Type = EntityType.BlueCard,
                    Event = AuditEvent.StatusChanged,
                    Description = original.IsClosed ? "Closed" : "Open",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, blueCardId, ex);
            }
        }

        public async Task ReassignBlueCardAgentAsync(int blueCardId, int agentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetBlueCardByIdAsync(blueCardId);
                if (original == null)
                {
                    throw new ArgumentException($"Blue Card {blueCardId} not found.");
                }

                if (original.AgentId != agentId)
                {
                    var originalAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = original.AgentId }, false);

                    await this.Context.BlueCards.ReassignBlueCardAgentAsync(blueCardId, agentId, user.GetUserId());

                    var history = new EntityHistoryDto
                    {
                        EntityId = blueCardId,
                        Type = EntityType.BlueCard,
                        Event = AuditEvent.AgentChanged,
                        Description = $"{originalAgent.FirstName} {originalAgent.LastName}",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);

                    // Create alert
                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.BlueCardAssigned);
                    var alertText = appEvent.Text;

                    var alert = new AlertDto
                    {
                        AppUserId = agentId,
                        Description = alertText,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.BlueCard,
                        EntityId = blueCardId,
                        AppEventTypeId = (int)AppEventType.BlueCardAssigned
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, blueCardId, ex);
            }
        }

        public async Task ToggleArchiveStatusAsync(int blueCardId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetBlueCardByIdAsync(blueCardId);
                DateTime? archiveDate = null;
                bool isClosed = false;
                int? closedReasonId = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;

                    if (!original.IsInProgress)
                    {
                        isClosed = true;

                        closedReasonId = original.ClosedReasonId ?? (int)BlueCardClosedReason.Other;
                    }
                }

                await this.Context.BlueCards.ToggleArchiveStatusAsync(blueCardId, archiveDate, isClosed, closedReasonId, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = blueCardId,
                    Type = EntityType.BlueCard,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<string> GetByCriteriaExportAsync(BlueCardSearchCriteriaDto criteria)
        {
            var results = await Context.BlueCards.GetByCriteriaExportAsync(criteria);

            return results;
        }

        public async Task AddBlueCardArtistsAsync(int blueCardId, IList<BlueCardArtistDto> artists, IPrincipal user)
        {
            if (artists == null)
            {
                throw new ArgumentNullException(nameof(artists));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var currentArtists = await this.Context.BlueCards.GetArtistsAsync(blueCardId);
                var currentArtistIds = currentArtists.Select(x => x.ArtistId);

                // Ensure artists that are already associated with the blue card aren't added twice.
                var newArtists = artists.Where(x => !currentArtistIds.Contains(x.ArtistId));

                foreach (var dto in newArtists)
                {
                    dto.BlueCardId = blueCardId;
                    dto.IsDeleted = false;
                    dto.SetAsCreated(user);

                    await this.Context.BlueCards.AddBlueCardArtistAsync(dto);

                    var addArtistHistory = new EntityHistoryDto
                    {
                        EntityId = blueCardId,
                        Type = EntityType.BlueCard,
                        Event = AuditEvent.BlueCardArtistAdded,
                        Description = $"Blue card artist {dto.Name} added.",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(addArtistHistory);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, blueCardId, ex);
            }
        }

        public async Task AddBlueCardArtistAsync(BlueCardArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.BlueCards.AddBlueCardArtistAsync(dto);

                var addArtistHistory = new EntityHistoryDto
                {
                    EntityId = dto.BlueCardId,
                    Type = EntityType.BlueCard,
                    Event = AuditEvent.BlueCardArtistAdded,
                    Description = $"Blue card artist {dto.Name} added.",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(addArtistHistory);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.BlueCard, dto.BlueCardId, ex);
            }
        }

        public async Task<List<ArtistPortalDto>> GetBlueCardsByArtistIdAsync(int id)
        {
            var result = await this.Context.BlueCards.GetBlueCardsByArtistIdAsync(id);

            return result;
        }

        public async Task<BlueCardArtistDto> GetBlueCardArtistAsync(int blueCardArtistId)
        {
            return await this.Context.BlueCards.GetBlueCardArtistAsync(blueCardArtistId);
        }

        public async Task SaveLeadData(BlueCardDto blueCard, LeadDto lead, IPrincipal user)
        {
            // Step 2 Data
            // Add a contact
            ContactPhoneNumberDto phone = new ContactPhoneNumberDto()
            {
                Value = lead.PhoneNumber.Replace("-", string.Empty),
                PhoneNumberTypeId = lead.CanText ? (int)PhoneNumberType.Mobile : (int)PhoneNumberType.Home,
                ContactId = -1,
                IsPrimaryPhone = true
            };

            ContactDto contact = new ContactDto()
            {
                ContactId = -1,
                ContactTypeId = 999, // Unassigned
                EmailAddress = lead.EmailAddress,
                EntityId = blueCard.BlueCardId,
                EntityTypeId = 0,
                FirstName = lead.FirstName,
                LastName = lead.LastName,
                IsPrimary = true,
                IsSigner = true,
                PreferredContactMethodId = 1 // Phone
            };

            contact.PhoneNumbers.Add(phone);
            contact.SetAsCreated(user);

            var contacts = new List<ContactDto> { contact };

            // Step 3 Data
            // Event Info
            if (lead.EventDate.HasValue)
            {
                blueCard.EventDates.Add(lead.EventDate.Value);
            }

            if (lead.EventTypeId.HasValue && lead.EventTypeId.Value != 99)
            {
                blueCard.EventTypeId = lead.EventTypeId.Value;
            }

            // Venue
            blueCard.VenueName = lead.EventVenueName;
            blueCard.VenuePhysicalCity = lead.EventCity;
            blueCard.VenuePhysicalStateId = lead.EventStateId;
            blueCard.VenuePhysicalCountryId = 1; // USA, USA, USA!!!

            // Artist
            if (lead.ArtistId.HasValue)
            {
                var artist = await this._artistService.GetArtistByIdAsync(lead.ArtistId.Value);

                if (artist != null)
                {
                    var blueCardArtist = new BlueCardArtistDto
                    {
                        ArtistId = artist.ArtistId,
                        Name = artist.Name
                    };

                    blueCard.BlueCardArtists.Add(blueCardArtist);
                }
            }

            try
            {
                this.Context.BeginTransaction();

                blueCard.SetAsUpdated(user);

                // Add data for step 2
                this._contactService.SyncContacts(EntityType.BlueCard, blueCard.BlueCardId, contacts, user);

                // Add data for step 3
                await this.UpdateEventDates(blueCard);

                foreach (var ba in blueCard.BlueCardArtists)
                {
                    ba.BlueCardId = blueCard.BlueCardId;
                    await this.AddBlueCardArtistAsync(ba, user);
                }

                await this.Context.BlueCards.UpdateAsync(blueCard);

                this.Context.Commit();
            }
            catch (Exception e)
            {
                this.Context.Rollback();

                Console.WriteLine(e);
                throw;
            }
        }

        private async Task DismissAlertsAndReminders(int blueCardId, int updatedById)
        {
            // (Hard) Delete all pending reminders
            var reminders = await this.Context.Reminders.GetFutureByEntityAsync(blueCardId, (int)EntityType.BlueCard);

            foreach (var reminder in reminders)
            {
                await this.Context.Reminders.DeleteAsync(reminder.ReminderId);
            }

            // Dismiss all future alerts
            var alerts = await this.Context.Alerts.GetUnreadByEntityAsync(blueCardId, (int)EntityType.BlueCard);

            foreach (var alert in alerts)
            {
                alert.IsRead = true;
                alert.ReadDate = TimeProvider.Current.Now;
                alert.UpdatedById = updatedById;
                alert.UpdatedDate = TimeProvider.Current.Now;

                await this.Context.Alerts.UpdateAsync(alert);
            }
        }

        private async Task UpdateEventDates(BlueCardDto dto)
        {
            // Updating event dates
            var currentEventDates = await this.Context.BlueCards.GetEventDatesAsync(dto.BlueCardId);

            // Delete event dates which are no longer included.
            foreach (var i in currentEventDates)
            {
                if (!dto.EventDates.Contains(i.EventDate))
                {
                    await Context.BlueCards.DeleteEventDateAsync(i);
                }
            }

            // Add event dates which are not already included.
            foreach (var j in dto.EventDates)
            {
                if (!currentEventDates.Where(x => x.EventDate == j).Any())
                {
                    var eventDateDto = new BlueCardEventDateDto
                    {
                        EventDate = j,
                        BlueCardId = dto.BlueCardId
                    };

                    await this.Context.BlueCards.AddEventDateAsync(eventDateDto);
                }
            }

            this.Context.Commit();
        }

        private async Task AuditUpdatedEntity(BlueCardDto original, BlueCardDto updated, IPrincipal user)
        {
            if (!updated.PresenterId.HasValue)
            {
                // Audit Presenter Name change
                if (!string.Equals(updated.AccountName, original.AccountName, StringComparison.OrdinalIgnoreCase))
                {
                    var history = new EntityHistoryDto
                    {
                        EntityId = updated.BlueCardId,
                        Type = EntityType.BlueCard,
                        Event = AuditEvent.PresenterNameChanged,
                        Description = original.AccountName,
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                }

                // Audit Organization Name change
                if (!string.Equals(updated.OrganizationName, original.OrganizationName ?? string.Empty, StringComparison.OrdinalIgnoreCase))
                {
                    if (string.IsNullOrEmpty(original.OrganizationName))
                    {
                        original.OrganizationName = "Added Organization Name";
                    }

                    var history = new EntityHistoryDto
                    {
                        EntityId = updated.BlueCardId,
                        Type = EntityType.BlueCard,
                        Event = AuditEvent.PresenterOrgNameChanged,
                        Description = original.OrganizationName,
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                }
            }
        }


    }
}
