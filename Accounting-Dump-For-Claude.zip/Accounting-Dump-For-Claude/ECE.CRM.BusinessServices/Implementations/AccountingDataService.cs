﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AccountingDataService : IAccountingDataService
    {
        public AccountingDataService(IUnitOfWork context)
        {
            Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<MiscArtistPaymentDto>> GetMiscArtistPaymentsAsync(DateTime fromDate, DateTime toDate)
        {
            return await Context.ArtistCharges.GetMiscArtistPaymentsAsync(fromDate, toDate);
        }

        public async Task<IList<OutstandingEscrowLoanDto>> GetEscrowLoanBalancesAsync(DateTime fromDate, DateTime toDate)
        {
            return await Context.ArtistCharges.GetEscrowLoanBalancesAsync(fromDate, toDate);
        }

        public async Task<IList<BasicAgentSalesStatsDto>> GetBasicAgentSalesStatsAsync(DateTime fromDate, DateTime toDate)
        {
            return await Context.AccountingData.GetBasicAgentSalesStatsAsync(fromDate, toDate);
        }

        public async Task<IList<CollectionsByOfficeDto>> GetCollectionsByOfficeAsync(DateTime fromDate, DateTime toDate,IPrincipal User)
        {
            return await Context.AccountingData.GetCollectionsByOfficeAsync(fromDate, toDate,User);
        }

        public async Task<IList<FeesBreakdownDto>> GetFeesBreakdownAsync(ExportDataCriteriaDto criteria, IList<int> accounts)
        {
            return await Context.AccountingData.GetFeesBreakdownAsync(criteria, accounts);
        }

        public async Task<IList<UnpaidCommissionDto>> GetUnpaidCommissionsAsync(DateTime asOfDate)
        {
            return await Context.AccountingData.GetUnpaidCommissionsAsync(asOfDate);
        }

        public async Task<IList<FeesBreakdownDto>> GetGLBreakdownAsync(ExportDataCriteriaDto criteria)
        {
            return await Context.AccountingData.GetGLBreakdownAsync(criteria);
        }

        public async Task<IList<InconsistentGLDto>> GetInconsistentGLContractsAsync(ExportDataCriteriaDto criteria)
        {
            return await Context.AccountingData.GetInconsistentGLContractsAsync(criteria);
        }
    }
}
