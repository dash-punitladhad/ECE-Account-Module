﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;

    public class BlueCardArtistService : IBlueCardArtistService
    {
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IUserService _userService;
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;
        private readonly IContactService _contactService;

        public BlueCardArtistService(IUnitOfWork context,
                             IEntityHistoryService entityHistoryService,
                             IUserService userService,
                             ILookupService lookupService,
                             IAlertService alertService,
                             IContactService contactService
                             )
        {
            this.Context = context;

            this._entityHistoryService = entityHistoryService;
            this._userService = userService;
            this._lookupService = lookupService;
            this._alertService = alertService;
            this._contactService = contactService;
        }

        public IUnitOfWork Context { get; private set; }

        public List<BlueCardArtistDto> GetBlueCardArtistsById(int id)
        {
            var dto = this.Context.BlueCardArtists.GetBlueCardArtistsById(id);

            return dto;
        }
    }
}
