﻿namespace ECE.CRM.BusinessServices
{
    using Dapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;

    public class EntityReminderService : IEntityReminderService
    {

        private readonly IEceCrmEntities _eceCrmEntities;
        public IBlobStorageProvider StorageProvider { get; private set; }
        private readonly IUserDao _userDao;
        public EntityReminderService(
            IUnitOfWork context,
            ILogger logger,
            IEceCrmEntities eceCrmEntities,
            IBlobStorageProvider storageProvider, IUserDao userDao)
        {
            this.Context = context;
            this.Logger = logger;
            this._eceCrmEntities = eceCrmEntities;
            this.StorageProvider = storageProvider;
            this._userDao = userDao;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }


        public async Task<List<AgentsForEntityReminderDto>> GetAgentListLMDwiseAsync(int userId, int entityReminderId, bool isParent = false)
        {

            List<AgentsForEntityReminderDto> entityReminderModeList = new List<AgentsForEntityReminderDto>();
            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
            {
                var dictionary = new Dictionary<string, object>()
                {
                    {"userId",userId},
                     {"entityReminderid",entityReminderId},
                    {"isParent",isParent}

                };
                var parameters = new DynamicParameters(dictionary);
                var conn = sqlConnectionFactory.CreateConnection();
                entityReminderModeList = (await conn.QueryAsync<AgentsForEntityReminderDto>("Sp_Get_AgentListOfLMD", parameters, commandType: CommandType.StoredProcedure)).ToList();
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return entityReminderModeList;

        }

        public async Task CreateEntityReminderAsync(EntityReminder entityReminder, int userId)
        {
            this._eceCrmEntities.EntityReminders.Add(entityReminder);

            await this._eceCrmEntities.SaveChangesAsync();

            EntityReminderAssign entityReminderAssign = new EntityReminderAssign()
            {
                AssignedId = entityReminder.CurrentAssignedId.Value,
                AssignerId = entityReminder.CurrentAssignerId.Value,
                EntityReminderId = entityReminder.EntityReminderId,
                IsAccept = false,
                IsReject = false,
                NumberOfLevel = 1,
                CreatedById = userId,
                CreatedDate = DateTime.Now
            };
            this._eceCrmEntities.EntityReminderAssigns.Add(entityReminderAssign);

            EntityReminderCommunicationLog entityReminderCommunicationLog = new EntityReminderCommunicationLog()
            {
                Description = entityReminder.Description,
                EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderAssigned,
                EntityReminderId = entityReminder.EntityReminderId,
                CreatedById = userId,
                CreatedDate = DateTime.Now
            };
            this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

            await this._eceCrmEntities.SaveChangesAsync();


            var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).FirstOrDefault(a => a.EntityReminderId == entityReminder.EntityReminderId && (a.AssignedId == userId || a.AssignerId == userId));
            if (entityReminderAssignAlert != null)
            {
                int receverId = 0;
                if (entityReminderAssignAlert.AssignerId == userId)
                {
                    receverId = entityReminderAssignAlert.AssignedId;
                }
                else
                {
                    receverId = entityReminderAssignAlert.AssignerId;
                }

                string description = string.Empty;
                var senderName = await this._userDao.GetNameByUserIDAsync(userId);
                description = "A new reminder has been assigned to you by " + senderName;
                if (userId != receverId)
                {
                    await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAssigned);
                }
            }
            await this._eceCrmEntities.SaveChangesAsync();
        }

        public async Task UpdateEntityReminderAsync(EntityReminder entityReminder, int userId, int oldAgentId)
        {
            bool isModify = true;
            var senderName = await this._userDao.GetNameByUserIDAsync(userId);
            if (entityReminder != null)
            {
                var entityReminderUpdate = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminder.EntityReminderId);
                //this._eceCrmEntities.EntityReminders.Add(entityReminder);
                if (entityReminderUpdate != null)
                {
                    entityReminderUpdate.CurrentAssignedId = entityReminder.CurrentAssignedId;
                    entityReminderUpdate.CurrentAssignerId = entityReminder.CurrentAssignerId;
                    entityReminderUpdate.Description = entityReminder.Description;
                    entityReminderUpdate.IsAssignToOther = entityReminder.IsAssignToOther;
                    entityReminderUpdate.ReminderDate = entityReminder.ReminderDate;
                    entityReminderUpdate.ReminderTime = entityReminder.ReminderTime;
                    if (entityReminder.CurrentAssignedId != oldAgentId)
                    {
                        isModify = false;
                        entityReminderUpdate.IsAccept = false;
                        entityReminderUpdate.IsClosed = false;
                        entityReminderUpdate.IsCompleted = false;
                        entityReminderUpdate.IsReject = false;
                    }
                    else
                    {
                        if (entityReminder.IsReject)
                        {
                            entityReminderUpdate.IsAccept = false;
                            entityReminderUpdate.IsClosed = false;
                            entityReminderUpdate.IsCompleted = false;
                            entityReminderUpdate.IsReject = false;
                        }
                    }

                }
                await this._eceCrmEntities.SaveChangesAsync();

                var entityReminderAssignRejected = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).FirstOrDefault(a => a.EntityReminderId == entityReminder.EntityReminderId && a.AssignerId == userId);
                if (entityReminderAssignRejected != null)
                {
                    if (entityReminderAssignRejected.IsReject)
                    {
                        EntityReminderCommunicationLog entityReminderCommunicationSetLog = new EntityReminderCommunicationLog()
                        {
                            Description = entityReminder.Description,
                            EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderReAssignment,
                            EntityReminderId = entityReminder.EntityReminderId,
                            CreatedById = userId,
                            CreatedDate = DateTime.Now
                        };
                        this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationSetLog);

                        await this._eceCrmEntities.SaveChangesAsync();
                    }
                }

                if (entityReminder.CurrentAssignedId != oldAgentId)
                {
                    var entityReminderAssignAlertForOld = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminder.EntityReminderId && (a.AssignedId == oldAgentId || a.AssignerId == oldAgentId));
                    if (entityReminderAssignAlertForOld != null && entityReminderAssignAlertForOld.Count() > 0)
                    {
                        string description = string.Empty;
                        description = "You are no longer assigned to this reminder.";
                        foreach (var item in entityReminderAssignAlertForOld)
                        {
                            int receverId = 0;
                            if (item.AssignerId == oldAgentId)
                            {
                                receverId = item.AssignedId;
                            }
                            else
                            {
                                receverId = item.AssignerId;
                            }

                            if (receverId != userId)
                            {


                                await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderUpdated);
                            }

                            item.IsReject = true;
                            item.IsDeleted = true;
                        }


                    }

                    EntityReminderAssign entityReminderAssign = new EntityReminderAssign()
                    {
                        AssignedId = entityReminder.CurrentAssignedId.Value,
                        AssignerId = entityReminder.CurrentAssignerId.Value,
                        EntityReminderId = entityReminder.EntityReminderId,
                        IsAccept = false,
                        IsReject = false,
                        NumberOfLevel = 1,
                        CreatedById = userId,
                        CreatedDate = DateTime.Now
                    };
                    this._eceCrmEntities.EntityReminderAssigns.Add(entityReminderAssign);
                    await this._eceCrmEntities.SaveChangesAsync();
                    EntityReminderCommunicationLog entityReminderCommunicationLogReassign = new EntityReminderCommunicationLog()
                    {
                        Description = entityReminder.Description,
                        EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderReAssignment,
                        EntityReminderId = entityReminder.EntityReminderId,
                        CreatedById = userId,
                        CreatedDate = DateTime.Now
                    };
                    this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLogReassign);



                    await this._eceCrmEntities.SaveChangesAsync();

                    var entityReminderAssignAlertData = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).FirstOrDefault(a => a.EntityReminderId == entityReminder.EntityReminderId && (a.AssignedId == userId || a.AssignerId == userId));
                    if (entityReminderAssignAlertData != null)
                    {
                        int receverId = 0;
                        if (entityReminderAssignAlertData.AssignerId == userId)
                        {
                            receverId = entityReminderAssignAlertData.AssignedId;
                        }
                        else
                        {
                            receverId = entityReminderAssignAlertData.AssignerId;
                        }

                        string description = string.Empty;
                        var senderNameData = await this._userDao.GetNameByUserIDAsync(userId);
                        description = "A new reminder has been assigned to you by " + senderNameData;
                        if (userId != receverId)
                        {
                            await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAssigned);
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();

                }
                else
                {
                    string description = string.Empty;

                    description = "Reminder has been Re-assigned to you by " + senderName;
                    var entityReminderAssignAlertReassign = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).FirstOrDefault(a => a.EntityReminderId == entityReminder.EntityReminderId && (a.AssignedId == entityReminder.CurrentAssignedId && a.AssignerId == userId));
                    if (entityReminderAssignAlertReassign != null && entityReminderAssignAlertReassign.IsReject)
                    {
                        entityReminderAssignAlertReassign.IsReject = false;
                        entityReminderAssignAlertReassign.IsAccept = false;
                        entityReminderAssignAlertReassign.IsDeleted = false;
                        entityReminderAssignAlertReassign.NumberOfLevel = 1;
                        int receverId = 0;
                        if (entityReminderAssignAlertReassign.AssignerId == userId)
                        {
                            receverId = entityReminderAssignAlertReassign.AssignedId;
                        }
                        else
                        {
                            receverId = entityReminderAssignAlertReassign.AssignerId;
                        }


                        if (receverId != userId)
                        {
                            await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderReAssignment);
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();
                }



                EntityReminderCommunicationLog entityReminderCommunicationLog = new EntityReminderCommunicationLog()
                {
                    Description = entityReminder.Description,
                    EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderUpdated,
                    EntityReminderId = entityReminder.EntityReminderId,
                    CreatedById = userId,
                    CreatedDate = DateTime.Now
                };
                this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

                await this._eceCrmEntities.SaveChangesAsync();


                var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminder.EntityReminderId && (a.IsReject == false && a.IsDeleted == false));
                if (entityReminderAssignAlert != null && isModify)
                {



                    string description = string.Empty;
                    description = "A reminder you have been assigned to has been updated.";
                    List<int> list = new List<int>();
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                    list = list.Distinct().ToList();
                    foreach (var receverId in list)
                    {

                        if (receverId != userId)
                        {


                            await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderUpdated);
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();
                }
            }
        }

        public async Task acceptEntityReminderModelAsync(int entityReminderId, int userId)
        {
            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderId);

            if (entityReminder != null)
            {
                entityReminder.IsAccept = true;

                await this._eceCrmEntities.SaveChangesAsync();
                var entityReminderAssign = this._eceCrmEntities.EntityReminderAssigns.FirstOrDefault(a => a.EntityReminderId == entityReminderId && a.AssignedId == userId && a.IsDeleted == false);
                if (entityReminderAssign != null)
                {
                    entityReminderAssign.IsAccept = true;
                }
                await this._eceCrmEntities.SaveChangesAsync();
                var user = this._eceCrmEntities.AppUsers.FirstOrDefault(a => a.AppUserId == userId);
                if (user != null)
                {
                    EntityReminderCommunicationLog entityReminderCommunicationLog = new EntityReminderCommunicationLog()
                    {
                        Description = "Your reminder has been accepted by " + user.FirstName + " " + user.LastName + ".",
                        EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderAccepted,
                        EntityReminderId = entityReminder.EntityReminderId,
                        CreatedById = userId,
                        CreatedDate = DateTime.Now
                    };

                    this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);
                }
                await this._eceCrmEntities.SaveChangesAsync();


                var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderId && a.IsReject == false && a.IsDeleted == false);

                if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
                {
                    string description = string.Empty;
                    var senderName = await this._userDao.GetNameByUserIDAsync(userId);

                    List<int> list = new List<int>();
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                    list = list.Distinct().ToList();
                    int count = list.Count;
                    foreach (var receverId in list)
                    {
                        if (userId != receverId)
                        {
                            if (count == 2)
                            {
                                description = "Your reminder has been accepted by " + senderName;
                                await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAccepted);
                            }
                            else
                            {
                                if (entityReminder.CreatedById == receverId)
                                {
                                    int firstAssigneeId = list.Where(a => a != receverId && a != userId).FirstOrDefault();
                                    if (firstAssigneeId != null)
                                    {
                                        var firstAssigneeName = await this._userDao.GetNameByUserIDAsync(firstAssigneeId);
                                        description = "Your reminder reassigned by " + firstAssigneeName + " has been accepted by " + senderName;
                                        await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAccepted);
                                    }
                                }
                                else
                                {
                                    int assignerNameId = entityReminder.CreatedById;
                                    if (assignerNameId != null)
                                    {
                                        var assignerName = await this._userDao.GetNameByUserIDAsync(assignerNameId);
                                        description = "Your reminder from " + assignerName + " reassigned by you has been accepted by " + senderName;
                                        await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAccepted);
                                    }
                                }

                            }
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();
                }
            }
        }

        public async Task deleteEntityReminderModelAsync(int entityReminderId, int userId)
        {
            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderId);

            if (entityReminder != null)
            {
                entityReminder.IsDeleted = true;

                await this._eceCrmEntities.SaveChangesAsync();

                var user = this._eceCrmEntities.AppUsers.FirstOrDefault(a => a.AppUserId == userId);
                if (user != null)
                {
                    EntityReminderCommunicationLog entityReminderCommunicationLog = new EntityReminderCommunicationLog()
                    {
                        Description = "This reminder has been deleted by " + user.FirstName + " " + user.LastName + ".",
                        EntityReminderActionTypeId = (int)EntityReminderActionType.ReminderDeleted,
                        EntityReminderId = entityReminder.EntityReminderId,
                        CreatedById = userId,
                        CreatedDate = DateTime.Now
                    };

                    this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);
                }
                await this._eceCrmEntities.SaveChangesAsync();


                //var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderId && a.IsReject == false && a.IsDeleted == false);

                //if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
                //{
                //    string description = string.Empty;
                //    var senderName = await this._userDao.GetNameByUserIDAsync(userId);
                //    description = "The reminder has been deleted by " + senderName;
                //    List<int> list = new List<int>();
                //    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                //    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                //    list = list.Distinct().ToList();
                //    foreach (var receverId in list)
                //    {
                //        if (receverId != userId)
                //        {
                //            await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderDeleted);
                //        }
                //    }
                //    await this._eceCrmEntities.SaveChangesAsync();
                //}
            }
        }


        public async Task AddNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog)
        {
            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId);

            this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

            await this._eceCrmEntities.SaveChangesAsync();

            var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.IsReject == false && a.IsDeleted == false);


            if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
            {
                var senderName = await this._userDao.GetNameByUserIDAsync(entityReminderCommunicationLog.CreatedById);
                string description = string.Empty;
                description = "A new note has been added to a reminder by " + senderName;
                List<int> list = new List<int>();
                list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                list = list.Distinct().ToList();
                foreach (var receverId in list)
                {
                    if (receverId != entityReminderCommunicationLog.CreatedById && entityReminder != null)
                    {
                        await this.AddAlertAsync(entityReminderCommunicationLog.CreatedById, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAddNote);
                    }
                }
                await this._eceCrmEntities.SaveChangesAsync();
            }
        }

        public async Task AssignToOtherEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int agentId, int userId)
        {
            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId);

            this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

            await this._eceCrmEntities.SaveChangesAsync();

            var entityReminderAssign = this._eceCrmEntities.EntityReminderAssigns.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.AssignerId == userId && a.AssignedId == agentId);
            if (entityReminderAssign != null)
            {
                entityReminderAssign.IsAccept = false;
                entityReminderAssign.IsReject = false;
            }
            else
            {
                entityReminderAssign = new EntityReminderAssign()
                {
                    AssignedId = agentId,
                    AssignerId = userId,
                    EntityReminderId = entityReminderCommunicationLog.EntityReminderId,
                    NumberOfLevel = 2,
                    IsAccept = false,
                    IsReject = false,
                    CreatedById = userId,
                    CreatedDate = DateTime.Now

                };
                this._eceCrmEntities.EntityReminderAssigns.Add(entityReminderAssign);
            }
            await this._eceCrmEntities.SaveChangesAsync();

            var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.IsReject == false && a.IsDeleted == false);
            if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
            {
                string description = string.Empty;
                var senderName = await this._userDao.GetNameByUserIDAsync(userId);
                description = "A note has been added by " + senderName + " to a reminder assigned to you.";
                List<int> list = new List<int>();
                list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                list = list.Distinct().ToList();
                foreach (var receverId in list)
                {
                    if (receverId != userId && entityReminder!=null)
                    {
                        if (entityReminder.CreatedById == receverId)
                        {
                            int secondAssigneeId = list.Where(a => a != receverId && a != userId).FirstOrDefault();
                            if (secondAssigneeId != null )
                            {
                                var secondAssigneeName = await this._userDao.GetNameByUserIDAsync(secondAssigneeId);
                                description = "Your reminder has been reassigned by  " + senderName + " to " + secondAssigneeName;
                                await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderReAssignment);
                            }
                        }
                        else
                        {
                            description = "A new reminder has been assigned to you by " + senderName + ".";
                            await this.AddAlertAsync(userId, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderReAssignment);

                        }
                    }

                }
                await this._eceCrmEntities.SaveChangesAsync();


            }
        }
        public async Task RejectNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid)
        {
            var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.IsReject == false && a.IsDeleted == false).ToList();

            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId);
            if (entityReminder != null)
            {
                entityReminder.IsReject = true;
                var entityReminderAssign = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderId).FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.AssignedId == userid && a.IsReject == false && a.IsDeleted == false);
                if (entityReminderAssign != null)
                {
                    entityReminderAssign.IsReject = true;
                    await this._eceCrmEntities.SaveChangesAsync();
                }

                this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

                await this._eceCrmEntities.SaveChangesAsync();


                if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
                {
                    string description = string.Empty;
                    var senderName = await this._userDao.GetNameByUserIDAsync(userid);
                    description = "Your reminder has been rejected by " + senderName;
                    List<int> list = new List<int>();
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                    list = list.Distinct().ToList();
                    int count = list.Count;

                    foreach (var receverId in list)
                    {
                        if (userid != receverId)
                        {
                            if (count == 2)
                            {
                                description = "Your reminder has been rejected by " + senderName;
                                await this.AddAlertAsync(userid, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderAccepted);
                            }
                            else
                            {
                                if (entityReminder.CreatedById == receverId)
                                {
                                    int firstAssigneeId = list.Where(a => a != receverId && a != userid).FirstOrDefault();
                                    if (firstAssigneeId != null)
                                    {
                                        var firstAssigneeName = await this._userDao.GetNameByUserIDAsync(firstAssigneeId);
                                        description = "Your reminder reassigned by " + firstAssigneeName + " has been rejected by " + senderName;
                                        await this.AddAlertAsync(userid, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderRejected);
                                    }
                                }
                                else
                                {
                                    int assignerNameId = entityReminder.CreatedById;
                                    if (assignerNameId != null)
                                    {
                                        var assignerName = await this._userDao.GetNameByUserIDAsync(assignerNameId);
                                        description = "Your reminder from " + assignerName + " reassigned by you has been rejected by " + senderName;
                                        await this.AddAlertAsync(userid, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderRejected);
                                    }
                                }

                            }
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();
                }
            }
        }


        public async Task CompleteNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid)
        {
            var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.IsReject == false && a.IsDeleted == false);

            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId);
            if (entityReminder != null)
            {
                entityReminder.IsCompleted = true;

                this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

                await this._eceCrmEntities.SaveChangesAsync();


                if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
                {
                    string description = string.Empty;
                    var senderName = await this._userDao.GetNameByUserIDAsync(userid);
                    description = "Your reminder has been marked as completed by " + senderName;
                    List<int> list = new List<int>();
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                    list = list.Distinct().ToList();
                    foreach (var receverId in list)
                    {

                        if (receverId != userid)
                        {
                            await this.AddAlertAsync(entityReminderCommunicationLog.CreatedById, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderCompleted);
                        }
                    }
                    await this._eceCrmEntities.SaveChangesAsync();
                }
            }
        }


        public async Task CloseNoteEntityReminderAsync(EntityReminderCommunicationLog entityReminderCommunicationLog, int userid)
        {
            var entityReminder = this._eceCrmEntities.EntityReminders.FirstOrDefault(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId);
            if (entityReminder != null)
            {
                entityReminder.IsClosed = true;
                await this._eceCrmEntities.SaveChangesAsync();

                this._eceCrmEntities.EntityReminderCommunicationLogs.Add(entityReminderCommunicationLog);

                await this._eceCrmEntities.SaveChangesAsync();


                var entityReminderAssignAlert = this._eceCrmEntities.EntityReminderAssigns.OrderByDescending(a => a.EntityReminderAssignId).Where(a => a.EntityReminderId == entityReminderCommunicationLog.EntityReminderId && a.IsReject == false && a.IsDeleted == false);

                if (entityReminderAssignAlert != null && entityReminderAssignAlert.Count() > 0)
                {
                    string description = string.Empty;
                    var senderName = await this._userDao.GetNameByUserIDAsync(userid);
                    description = "A reminder assigned to you by " + senderName + " has been closed.";
                    List<int> list = new List<int>();
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignedId));
                    list.AddRange(entityReminderAssignAlert.Select(a => a.AssignerId));
                    list = list.Distinct().ToList();
                    foreach (var receverId in list)
                    {

                        if (receverId != entityReminderCommunicationLog.CreatedById)
                        {
                            await this.AddAlertAsync(entityReminderCommunicationLog.CreatedById, receverId, description, entityReminder.EntityId, entityReminder.EntityTypeId, AppEventType.ReminderClosed);
                        }
                    }

                    await this._eceCrmEntities.SaveChangesAsync();

                }
            }
        }
        public async Task<(EntityReminderDetailsModelDto, List<EntityReminderCommunicationLogModelDto>)> ShowEntityReminderCommunicationLogModelAsync(int entityReminderId)
        {

            EntityReminderDetailsModelDto entityReminderDetailsModel = new EntityReminderDetailsModelDto();
            List<EntityReminderCommunicationLogModelDto> entityReminderCommunicationLogModelList = new List<EntityReminderCommunicationLogModelDto>();
            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
            {
                var dictionary = new Dictionary<string, object>()
                {
                    {"entityReminderId",entityReminderId}
                };
                var parameters = new DynamicParameters(dictionary);
                var conn = sqlConnectionFactory.CreateConnection();
                var gridReader = await conn.QueryMultipleAsync("Sp_Get_EntityReminder_CommunicationLog", parameters, commandType: CommandType.StoredProcedure);
                entityReminderDetailsModel = (await gridReader.ReadAsync<EntityReminderDetailsModelDto>()).FirstOrDefault();
                entityReminderCommunicationLogModelList = (await gridReader.ReadAsync<EntityReminderCommunicationLogModelDto>()).ToList();

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return (entityReminderDetailsModel, entityReminderCommunicationLogModelList);
        }

        public async Task AddAlertAsync(int senderId, int receiverId, string description, int entityId, int entityTypeId, AppEventType appEventType)
        {
            Alert alert = new Alert();
            alert.AppEventTypeId = (int)appEventType;
            alert.AppUserId = receiverId;
            alert.CreatedById = senderId;
            alert.CreatedDate = DateTime.Now;
            alert.Description = this.TruncateLongString(description, 500);
            alert.EntityId = entityId;
            alert.EntityTypeId = entityTypeId;
            this._eceCrmEntities.Alerts.Add(alert);

        }
        private string TruncateLongString(string str, int maxLength)
        {
            if (string.IsNullOrEmpty(str)) return str;

            return str.Substring(0, Math.Min(str.Length, maxLength));
        }
    }
}