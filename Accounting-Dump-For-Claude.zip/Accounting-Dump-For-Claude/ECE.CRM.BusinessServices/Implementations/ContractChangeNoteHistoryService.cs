﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ContractChangeNoteHistoryService:IContractChangeNoteHistoryService
    { 
        public IUnitOfWork Context { get; private set; }
        public ContractChangeNoteHistoryService(IUnitOfWork context)
        {
            this.Context = context;

        }
        public Task<IList<ContractChangeNoteHistoryDto>> GetByContractIdAsync(int ContractId)
        {
            return this.Context.ContractChangeNoteHistoryDao.GetByContractIdAsync(ContractId);
        }
        public Task<ContractChangeNoteHistoryDto> GetByAsync(int id)
        {
            return this.Context.ContractChangeNoteHistoryDao.GetByAsync(id);
        }
        public Task<int> CreateAsync(ContractChangeNoteHistoryDto dto)
        {
            return this.Context.ContractChangeNoteHistoryDao.CreateAsync(dto);
        }
        public Task<bool> DeleteAsync(int contractChangeNoteHistoryId)
        {
            return this.Context.ContractChangeNoteHistoryDao.DeleteAsync(contractChangeNoteHistoryId);
        }

    }
}
