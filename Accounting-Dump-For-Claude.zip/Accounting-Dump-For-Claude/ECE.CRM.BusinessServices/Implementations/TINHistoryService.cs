﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class TINHistoryService : ITINHistoryService
    {
        public TINHistoryService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task CreateTINHistoryAsync(ITen99EntityDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                // Save previous TIN
                var history = new TINHistoryDto
                {
                    EntityId = dto.EntityId,
                    EntityTypeId = dto.EntityTypeId,
                    TINHashed = dto.TINHashed,
                    TaxIdentificationNumber = dto.TaxIdentificationNumber,
                    TIN = dto.TIN
                };

                history.SetAsCreated(user);

                await this.Context.TINHistory.CreateAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateTINHistoryAsync(TINHistoryDto history, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                history.SetAsCreated(user);

                await this.Context.TINHistory.CreateAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<TINHistoryDto>> GetByTen99EntityAsync(ITen99EntityDto dto)
        {
            return await this.Context.TINHistory.GetByTen99EntityAsync(dto);
        }
    }
}
