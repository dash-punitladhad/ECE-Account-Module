﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public class InvalidACHPayeeException : Exception
    {
        public InvalidACHPayeeException(string message)
            : base(message)
        {
        }

        public InvalidACHPayeeException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public InvalidACHPayeeException(ArtistDto artist)
            : base(ArtistMessage(artist))
        {
        }

        public static string ArtistMessage(ArtistDto artist)
        {
            if (artist == null)
            {
                return "Invalid ACH Payee";
            }

            return $"Invalid ACH Payee (Artist '{artist.Name}')";
        }
    }
}
