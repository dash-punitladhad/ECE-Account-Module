﻿using Dapper;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using Infinity.Mobius.BlobStorage;
using Infinity.Mobius.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices
{
    public class DocumentService : IDocumentService
    {

        private readonly IEceCrmEntities _eceCrmEntities;
        private readonly IAlertService _alertService;
        private static readonly string spireDocLicenseKey = MobiusConfiguration.Current.AppSettings["Spire.Doc.LicenseKey"];

        public DocumentService(
            IUnitOfWork context,
            IBlobStorageProvider storageProvider,
            IEceCrmEntities eceCrmEntities,
             IAlertService alertService)
        {
            this.Context = context;
            this.StorageProvider = storageProvider;
            this._eceCrmEntities = eceCrmEntities;
            this._alertService = alertService;
        }

        public IUnitOfWork Context { get; private set; }

        public IBlobStorageProvider StorageProvider { get; private set; }

        public async Task<DocumentDto> GetByIdAsync(int documentId)
        {
            /* This was added for obtaining specific documents for contract documents.
            *  Additionally, the DocumentService only had a synchronous way to get a document by id.
            *  Adding this method always us an asynchronous way to get a single document.
            */
            return await this.Context.Documents.GetByIdAsync(documentId);
        }

        public IList<DocumentDto> GetDocuments(EntityType entityType, int entityId)
        {
            return this.Context.Documents.GetDocuments(entityType, entityId);
        }

        public IList<DocumentDto> GetContractVersionDocuments(EntityType entityType, int entityId)
        {
            return this.Context.Documents.GetContractVersionDocuments(entityType, entityId);
        }

        public IList<DocumentDto> GetRiders(EntityType entityType, int entityId)
        {
            var allDocuments = this.Context.Documents.GetDocuments(entityType, entityId);

            var results = allDocuments.Where(
                x => x.DocumentTypeId == (int)DocumentType.ArtistRider
                     || x.DocumentTypeId == (int)DocumentType.HospitalityRider
                     || x.DocumentTypeId == (int)DocumentType.TravelRider
                     || x.DocumentTypeId == (int)DocumentType.TechRider
                     || x.DocumentTypeId == (int)DocumentType.VenueRider).ToList();

            return results;
        }

        public DocumentDto GetDocument(EntityType entityType, int entityId, int documentId)
        {
            return this.Context.Documents.GetDocument(entityType, entityId, documentId);
        }

        public async Task<DocumentDto> GetDocumentAsync(EntityType entityType, int entityId, int documentId)
        {
            return await this.Context.Documents.GetDocumentAsync(entityType, entityId, documentId);
        }

        public DocumentDto GetGenericRider(int id)
        {
            return this.Context.Documents.GetGenericRider(id);
        }

        public MemoryStream GetFromStorage(DocumentDto documentDto, string libraryName)
        {
            var blobId = Guid.Parse(documentDto.StorageFileName);

            var blobLibrary = this.StorageProvider.GetBlobLibrary(libraryName);

            var blob = blobLibrary.GetBlob(blobId);

            if (blob.Size >= 0)
            {
                var ms = new MemoryStream();
                blob.RetrieveToStream(ms);
                ms.Position = 0;
                return ms;
            }
            else
            {
                throw new Exception($"Could not retrieve file contents for documentId: {documentDto.DocumentId}");
            }
        }

        public async Task<MemoryStream> GetFromStorageAsync(DocumentDto documentDto, string libraryName)
        {
            var blobId = Guid.Parse(documentDto.StorageFileName);

            var blobLibrary = this.StorageProvider.GetBlobLibrary(libraryName);

            var blob = blobLibrary.GetBlob(blobId);

            if (blob.Size >= 0)
            {
                var ms = new MemoryStream();
                blob.RetrieveToStream(ms);
                ms.Position = 0;
                return ms;
            }
            else
            {
                throw new Exception($"Could not retrieve file contents for documentId: {documentDto.DocumentId}");
            }
        }

        public async Task<DocumentDto> GetRelatedDocumentAsync(UrlKeyRelatedDocumentDto relatedDocument)
        {
            return await this.Context.Documents.GetRelatedDocumentAsync(relatedDocument);
        }

        public async Task<bool> DocumentIsRelatedToUrlKeyAsync(
            UrlKeyHolderType urlKeyHolder,
            string urlKey,
            int documentId)
        {
            return await this.Context.Documents.DocumentIsRelatedToUrlKeyAsync(
                urlKeyHolder,
                urlKey,
                documentId);
        }

        public void AddGenericRider(DocumentDto dto, IPrincipal user)
        {
            var blobsToAdd = new List<IBlob>();

            var blobLibrary = this.StorageProvider.GetBlobLibrary("GenericRiders");

            blobLibrary.CreateIfNotExists();

            try
            {
                dto.DocumentId = 0;
                dto.SetAsCreated(user);

                var blob = blobLibrary.NewBlob();

                blob.SaveFromStream(dto.Contents);
                blob.Properties.Add("ORIG_FILENAME", dto.StorageFileName);
                blob.SaveProperties();

                blobsToAdd.Add(blob);

                dto.StorageFileName = blob.Id.ToString();

                this.Context.Documents.CreateGenericRider(dto);
            }
            catch (Exception ex)
            {
                // Delete the added blobs since an exception occurred.
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public void SyncDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user)
        {
            var existingDocuments = this.GetDocuments(entityType, entityId);
            var activeDocuments = updatedDocuments.Where(x => !x.IsDeleted);

            var blobsToAdd = new List<IBlob>();

            var blobLibrary = this.StorageProvider.GetBlobLibrary(entityType.ToString());

            blobLibrary.CreateIfNotExists();

            try
            {
                // Get a list of all the existing documents that still exist in the updated list.
                var documentsToKeep =
                    from e in existingDocuments
                    join a in activeDocuments on e.DocumentId equals a.DocumentId
                    select e;

                // Add new documents, if necessary.
                var documentsToAdd = activeDocuments.Except(documentsToKeep, x => x.DocumentId);

                foreach (var documentToAdd in documentsToAdd)
                {
                    documentToAdd.DocumentId = 0;
                    documentToAdd.SetAsCreated(user);

                    var blob = blobLibrary.NewBlob();

                    blob.SaveFromStream(documentToAdd.Contents);
                    blob.Properties.Add("ORIG_FILENAME", documentToAdd.StorageFileName);
                    blob.SaveProperties();

                    blobsToAdd.Add(blob);

                    documentToAdd.StorageFileName = blob.Id.ToString();

                    this.Context.Documents.Create(entityType, entityId, documentToAdd);
                }

                // Remove existing documents, if necessary.
                var documentsToRemove = existingDocuments.Except(documentsToKeep);

                foreach (var documentToRemove in documentsToRemove)
                {
                    this.Context.Documents.RemoveDocumentFrom(
                        entityType,
                        entityId,
                        documentToRemove.DocumentId,
                        user.GetUserId());
                }
            }
            catch (Exception ex)
            {
                // Delete the added blobs since an exception occurred.
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task SyncContractDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user)
        {
            var existingDocuments = this.Context.ContractDocuments.GetByContractId(entityId);

            var activeDocuments = updatedDocuments.Where(x => !x.IsDeleted);

            var blobsToAdd = new List<IBlob>();

            var blobLibrary = this.StorageProvider.GetBlobLibrary(entityType.ToString());

            blobLibrary.CreateIfNotExists();
            int[] riderDocumentTypeIds = { (int)DocumentType.ArtistRider, (int)DocumentType.HospitalityRider, (int)DocumentType.TechRider, (int)DocumentType.TravelRider, (int)DocumentType.VenueRider };
            var AddedRiderName = string.Empty;
            var RemovedRiderName = string.Empty;
            try
            {


                // Get a list of all the existing documents that still exist in the updated list.
                var documentsToKeep =
                    from e in existingDocuments
                    join a in activeDocuments on e.DocumentId equals a.DocumentId
                    select e;

                // Add new documents, if necessary.
                var documentsToAdd = activeDocuments.Except(documentsToKeep.Select(d => new DocumentDto { DocumentId = d.DocumentId }), x => x.DocumentId);

                foreach (var documentToAdd in documentsToAdd)
                {

                    try
                    {
                        if (riderDocumentTypeIds.Contains(documentToAdd.DocumentTypeId))
                        {
                            if (string.IsNullOrWhiteSpace(AddedRiderName))
                            {
                                AddedRiderName = documentToAdd.OriginalFileName;
                            }
                            else
                            {
                                AddedRiderName += ", " + documentToAdd.OriginalFileName;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        log.Error(ex);
                    }

                    if (entityType == EntityType.Contract)
                    {
                        if (documentToAdd.Contents != null)
                        {

                            var docEx = documentToAdd.DocumentExtension.Text;
                            var status = true;
                            if (docEx.ToLower().Contains("doc"))
                            {
                                string rootPath = MobiusConfiguration.GetString("BlobStorage:DefaultFileSystemProvider:rootPath");
                                try
                                {
                                    string tempInputPath = Path.Combine(rootPath, $"{documentToAdd.OriginalFileName}.{docEx}");
                                    string tempOutputPath = Path.Combine(rootPath, $"{documentToAdd.OriginalFileName}.pdf");
                                    using (var fileStream = new FileStream(tempInputPath, FileMode.Create, FileAccess.Write))
                                    {
                                        await documentToAdd.Contents.CopyToAsync(fileStream);
                                    }

                                    // Convert using OfficeConverter

                                    var reuslt = await this.ConvertAsync(tempInputPath, tempOutputPath);
                                    if (!reuslt.ToLower().Contains("success"))
                                    {
                                        status = false;
                                        throw new Exception("Fail Doc to Pdf convert.");
                                    }
                                    using (var fileStream = new FileStream(tempOutputPath, FileMode.Open, FileAccess.Read))
                                    {
                                        documentToAdd.Contents = new MemoryStream();
                                        await fileStream.CopyToAsync(documentToAdd.Contents);
                                        documentToAdd.Contents.Position = 0; // Reset stream position
                                    }

                                    // Update the file extension
                                    documentToAdd.DocumentExtension.Text = "pdf";

                                    try
                                    {
                                        System.IO.File.Delete(tempInputPath);
                                        System.IO.File.Delete(tempOutputPath);
                                    }
                                    catch (Exception ex)
                                    {
                                        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        log.Error(ex);
                                    }

                                }
                                catch (Exception ex)
                                {
                                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex);
                                }
                            }
                            if (status)
                            {
                                documentToAdd.DocumentId = 0;
                                documentToAdd.SetAsCreated(user);

                                var blob = blobLibrary.NewBlob();

                                blob.SaveFromStream(documentToAdd.Contents);
                                blob.Properties.Add("ORIG_FILENAME", documentToAdd.StorageFileName);
                                blob.SaveProperties();

                                blobsToAdd.Add(blob);

                                documentToAdd.StorageFileName = blob.Id.ToString();
                            }
                        }
                    }
                    else
                    {
                      



                        documentToAdd.DocumentId = 0;
                        documentToAdd.SetAsCreated(user);

                        var blob = blobLibrary.NewBlob();

                        blob.SaveFromStream(documentToAdd.Contents);
                        blob.Properties.Add("ORIG_FILENAME", documentToAdd.StorageFileName);
                        blob.SaveProperties();

                        blobsToAdd.Add(blob);


                        documentToAdd.StorageFileName = blob.Id.ToString();

                    }




                    this.Context.Documents.Create(entityType, entityId, documentToAdd);
                }

                // Remove existing documents, if necessary.
                var documentsToRemove = existingDocuments.Except(documentsToKeep);

                foreach (var documentToRemove in documentsToRemove)
                {

                    try
                    {
                        var removeDocument = Task.Run(() => this.Context.Documents.GetByIdAsync(documentToRemove.DocumentId)).GetAwaiter().GetResult();
                        if (riderDocumentTypeIds.Contains(removeDocument.DocumentTypeId))
                        {
                            if (string.IsNullOrWhiteSpace(RemovedRiderName))
                            {
                                RemovedRiderName = removeDocument.OriginalFileName;
                            }
                            else
                            {
                                RemovedRiderName += ", " + removeDocument.OriginalFileName;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        log.Error(ex);
                    }


                    this.Context.Documents.RemoveDocumentFrom(
                        entityType,
                        entityId,
                        documentToRemove.DocumentId,
                        user.GetUserId());

                    // Remove the contract document
                    var contractDocs = this.Context.ContractDocuments.GetByDocumentId(documentToRemove.DocumentId);

                    foreach (var contractDoc in contractDocs.Where(a=>a.OriginalEntityId== entityId && a.OriginalEntityTypeId==(int)entityType))
                    {
                        this.Context.ContractDocuments.Delete(contractDoc.ContractDocumentId);
                    }


                }
            }
            catch (Exception ex)
            {
                // Delete the added blobs since an exception occurred.
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }


            try
            {
                if (!string.IsNullOrWhiteSpace(RemovedRiderName) || !string.IsNullOrWhiteSpace(AddedRiderName))
                {
                    List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();

                    contractChanges.Add(new ContractChangesDto()
                    {
                        Name = "changes riders",
                        Old = string.IsNullOrWhiteSpace(RemovedRiderName)?string.Empty : "Removed files " + RemovedRiderName,
                        New = string.IsNullOrWhiteSpace(AddedRiderName)?string.Empty :"Added files " + AddedRiderName,
                        Createddate = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"),
                        Createdby = user.Identity.Name,
                        IsPDFChange = true
                    });

                    // if (contractChanges.Any())
                    {
                        string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                        bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                        using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                        {
                            Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",entityId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                            DynamicParameters parameters = new DynamicParameters(dictionary);
                            IDbConnection conn = sqlConnectionFactory.CreateConnection();
                            conn.Execute("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                            if (conn.State == ConnectionState.Open)
                            {
                                conn.Close();
                            }
                        }

                    }
                }

            }
            catch (Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
            }
        }


        public async Task SyncAddendumDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user, List<AppUser> lmds)
        {
            var existingDocuments = this.Context.ContractDocuments.GetAllAddendumdocumentsByContractId(entityId);
            if (existingDocuments == null)
            {
                existingDocuments = new List<AddendumDocumentDto>();
            }
            if (existingDocuments.Any())
            {
                existingDocuments = existingDocuments.Where(a => a.Status == "Added" || a.Status == "Pending" || (a.Status == "Approved" && a.IsPrimary)).ToList();
            }
            var activeDocuments = new List<DocumentDto>();
            if (updatedDocuments != null)
            {
                activeDocuments = updatedDocuments.Where(x => !x.IsDeleted).ToList();
            }

            var blobsToAdd = new List<IBlob>();

            var blobLibrary = this.StorageProvider.GetBlobLibrary(entityType.ToString());

            blobLibrary.CreateIfNotExists();

            try
            {
                // Get a list of all the existing documents that still exist in the updated list.
                var documentsToKeep =
                    from e in existingDocuments
                    join a in activeDocuments on e.DocumentId equals a.DocumentId
                    select e;

                // Add new documents, if necessary.
                var documentsToAdd = activeDocuments.Except(documentsToKeep.Select(d => new DocumentDto { DocumentId = d.DocumentId }), x => x.DocumentId);
                try
                {
                    foreach (var documentToAdd in documentsToAdd)
                    {
                        if (documentToAdd.Contents != null)
                        {

                            var docEx = documentToAdd.DocumentExtension.Text;
                            var status = true;
                            if (docEx.ToLower().Contains("doc"))
                            {
                                string rootPath = MobiusConfiguration.GetString("BlobStorage:DefaultFileSystemProvider:rootPath");
                                try
                                {
                                    string tempInputPath = Path.Combine(rootPath, $"{documentToAdd.OriginalFileName}.{docEx}");
                                    string tempOutputPath = Path.Combine(rootPath, $"{documentToAdd.OriginalFileName}.pdf");
                                    using (var fileStream = new FileStream(tempInputPath, FileMode.Create, FileAccess.Write))
                                    {
                                        await documentToAdd.Contents.CopyToAsync(fileStream);
                                    }

                                    // Convert using OfficeConverter

                                    var reuslt = await this.ConvertAsync(tempInputPath, tempOutputPath);
                                    if (!reuslt.ToLower().Contains("success"))
                                    {
                                        status = false;
                                        throw new Exception("Fail Doc to Pdf convert.");
                                    }
                                    using (var fileStream = new FileStream(tempOutputPath, FileMode.Open, FileAccess.Read))
                                    {
                                        documentToAdd.Contents = new MemoryStream();
                                        await fileStream.CopyToAsync(documentToAdd.Contents);
                                        documentToAdd.Contents.Position = 0; // Reset stream position
                                    }

                                    // Update the file extension
                                    documentToAdd.DocumentExtension.Text = "pdf";

                                    try
                                    {
                                        System.IO.File.Delete(tempInputPath);
                                        System.IO.File.Delete(tempOutputPath);
                                    }
                                    catch (Exception ex)
                                    {
                                        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        log.Error(ex);
                                    }

                                }
                                catch (Exception ex)
                                {
                                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex);
                                }
                            }
                            if (status)
                            {
                                documentToAdd.DocumentId = 0;
                                documentToAdd.SetAsCreated(user);

                                var blob = blobLibrary.NewBlob();

                                blob.SaveFromStream(documentToAdd.Contents);
                                blob.Properties.Add("ORIG_FILENAME", documentToAdd.StorageFileName);
                                blob.SaveProperties();

                                blobsToAdd.Add(blob);

                                documentToAdd.StorageFileName = blob.Id.ToString();

                                this.Context.Documents.AddendumDocumentCreate(entityType, entityId, documentToAdd);
                            }
                        }
                    }
                }
                catch { }

                // Remove existing documents, if necessary.
                var documentsToRemove = existingDocuments.Except(documentsToKeep);

                foreach (var documentToRemove in documentsToRemove)
                {
                    this.Context.Documents.RemoveDocumentFrom(
                        entityType,
                        entityId,
                        documentToRemove.DocumentId,
                        user.GetUserId());

                    // Remove the contract document
                    var contractDocs = this.Context.ContractDocuments.GetAddendumdocumentsByDocumentId(documentToRemove.DocumentId);

                    foreach (var contractDoc in contractDocs)
                    {
                        this.Context.ContractDocuments.AddendumDocumentDelete(contractDoc.AddendumDocumentId);
                    }
                }

                try
                {
                    if (entityId == (int)(EntityType.Contract) && documentsToRemove != null && documentsToRemove.Count() > 0)
                    {
                        List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Remove Amendment File",
                            Old = Convert.ToString(documentsToRemove.FirstOrDefault().OriginalFileName + " " + documentsToRemove.FirstOrDefault().Description),
                            New = Convert.ToString("Remove file"),
                            Createddate = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"),
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                        if (contractChanges!=null && contractChanges.Count > 0)
                        {
                            string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                            bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                            {
                                Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",entityId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                                DynamicParameters parameters = new DynamicParameters(dictionary);
                                IDbConnection conn = sqlConnectionFactory.CreateConnection();
                                await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                                if (conn.State == ConnectionState.Open)
                                {
                                    conn.Close();
                                }
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }

            }
            catch (Exception ex)
            {
                // Delete the added blobs since an exception occurred.
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<int> SyncSentForApproveAddendumDocuments(int contractId, IPrincipal user, List<AppUser> lmds)
        {
            int addendumDocumentId = 0;
            try
            {
                var addendums = await _eceCrmEntities.AddendumDocument.Where(a => a.ContractId == contractId && !a.IsDeleted && a.Status == "Added").ToListAsync();

                foreach (var i in addendums)
                {
                    addendumDocumentId = i.AddendumDocumentId;
                    i.Status = "Pending";
                    i.UpdatedDate = DateTime.Now;
                    i.UpdatedById = user.GetUserId();
                }
                await _eceCrmEntities.SaveChangesAsync();


                //try
                //{



                //    foreach (var lmd in lmds)
                //    {
                //        var addendumReminderId = (int)AppEventType.AddendumReminder;

                //        var appEvent = await this._eceCrmEntities.LuAppEventTypes.FirstOrDefaultAsync(a => a.AppEventTypeId == addendumReminderId);
                //        var alertText = appEvent.Description.Replace("{ContractId}", contractId.ToString());


                //        // Send alert to the Addendum Reminder LMD                           

                //        //await _entityReminderService.AddAlertAsync(user.GetUserId(), lmd.AppUserId,alertText, (int)entityType,entityId, AppEventType.AddendumReminder);

                //        var alert = new AlertDto
                //        {
                //            AppUserId = lmd.AppUserId,
                //            Description = alertText,
                //            IsRead = false,
                //            EntityTypeId = (int)EntityType.Contract,
                //            EntityId = contractId,
                //            AppEventTypeId = (int)AppEventType.AddendumReminder,
                //        };

                //        await this._alertService.CreateAsync(alert, user);

                //    }


                //}
                //catch (Exception ex)
                //{
                //    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                //    log.Error(ex);
                //}

            }
            catch (Exception ex)
            {


                throw new Exception("Unhandled Business Exception", ex);
            }
            return addendumDocumentId;
        }

        public void LinkDocumentTo(EntityType entityType, int entityId, DocumentDto dto, int createdById)
        {
            this.Context.Documents.LinkDocumentTo(entityType, entityId, dto, createdById);
        }

        public void AddDocumentTo(EntityType entityType, int entityId, DocumentDto dto, int createdById)
        {
            var blobLibrary = this.StorageProvider.GetBlobLibrary(entityType.ToString());

            blobLibrary.CreateIfNotExists();

            try
            {
                dto.DocumentId = 0;
                dto.SetAsCreated(createdById);

                var blob = blobLibrary.NewBlob();

                blob.SaveFromStream(dto.Contents);
                blob.Properties.Add("ORIG_FILENAME", dto.StorageFileName);
                blob.SaveProperties();

                dto.StorageFileName = blob.Id.ToString();

                this.Context.Documents.Create(entityType, entityId, dto);
            }
            catch (Exception ex)
            {
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public void RemoveDocumentFrom(EntityType entityType, int entityId, int documentId, int removedById)
        {
            this.Context.BeginTransaction();

            try
            {
                this.Context.Documents.RemoveDocumentFrom(entityType, entityId, documentId, removedById);

                if (entityType == EntityType.Contract)
                {
                    // Remove the contract document
                    var contractDocs = this.Context.ContractDocuments.GetByDocumentId(documentId);

                    foreach (var contractDoc in contractDocs.Where(a=>a.OriginalEntityId== entityId && a.OriginalEntityTypeId==(int)entityType))
                    {
                        this.Context.ContractDocuments.Delete(contractDoc.ContractDocumentId);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteDocumentLinkAsync(int documentId, int entityId, EntityType entityTypeId)
        {
            this.Context.BeginTransaction();
            try
            {
                await this.Context.Documents.DeleteDocumentLinkAsync(documentId, entityId, entityTypeId);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public void SyncContractInternalDocuments(EntityType entityType, int entityId, IEnumerable<DocumentDto> updatedDocuments, IPrincipal user)
        {
            var existingDocuments = this.Context.ContractDocuments.GetByContractId(entityId);

            var activeDocuments = updatedDocuments.Where(x => !x.IsDeleted);

            var blobLibrary = this.StorageProvider.GetBlobLibrary(entityType.ToString());

            blobLibrary.CreateIfNotExists();

            var blobsToAdd = new List<IBlob>();
            try
            {

                var documentsToKeep =
                   from e in existingDocuments
                   join a in activeDocuments on e.DocumentId equals a.DocumentId
                   select e;

                // Add new documents, if necessary.
                var documentsToAdd = activeDocuments.Except(documentsToKeep.Select(d => new DocumentDto { DocumentId = d.DocumentId }), x => x.DocumentId);


                foreach (var documentToAdd in documentsToAdd)
                {
                    documentToAdd.DocumentId = 0;
                    documentToAdd.SetAsCreated(user);

                    var blob = blobLibrary.NewBlob();

                    blob.SaveFromStream(documentToAdd.Contents);
                    blob.Properties.Add("ORIG_FILENAME", documentToAdd.StorageFileName);
                    blob.SaveProperties();

                    blobsToAdd.Add(blob);

                    documentToAdd.StorageFileName = blob.Id.ToString();

                    this.Context.Documents.Create(entityType, entityId, documentToAdd);
                }

            }
            catch (Exception ex)
            {
                // Delete the added blobs since an exception occurred.
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public void RemoveInternalDocuments(EntityType entityType, int documentId, IPrincipal user)
        {
            try
            {
                var document = this.Context.ContractDocuments.GetByDocumentId(documentId);
                if (document != null)
                {
                    this.Context.Documents.RemoveDocumentFrom(
                            entityType,
                            document[0].ContractId,
                            documentId,
                            user.GetUserId());
                    this.Context.ContractDocuments.Delete(documentId);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unhandled Business Exception", ex);
            }
        }


        public async Task<bool> ReSendForApproveUpdateAddendumDocumentsByAgentAsync(int addendumDocumentId, IPrincipal user, List<AppUser> lmds)
        {
            bool isValid = false;
            try
            {
                var addendum = await this._eceCrmEntities.AddendumDocument.FirstOrDefaultAsync(a => a.AddendumDocumentId == addendumDocumentId);
                if (addendum != null)
                {
                    if (addendum.Status == "Rejected")
                    {
                        var result = await this.Context.ContractDocuments.ReSendForApproveUpdateAddendumDocumentsByAgentAsync(addendumDocumentId, addendum.Status, user);

                        return result;
                        //if (result)
                        //{
                        //    try
                        //    {



                        //        foreach (var lmd in lmds)
                        //        {
                        //            var addendumReminderId = (int)AppEventType.AddendumReminder;

                        //            var appEvent = await this._eceCrmEntities.LuAppEventTypes.FirstOrDefaultAsync(a => a.AppEventTypeId == addendumReminderId);
                        //            var alertText = appEvent.Description.Replace("{ContractId}", addendum.ContractId.ToString());


                        //            // Send alert to the Addendum Reminder LMD                           

                        //            //await _entityReminderService.AddAlertAsync(user.GetUserId(), lmd.AppUserId,alertText, (int)entityType,entityId, AppEventType.AddendumReminder);

                        //            var alert = new AlertDto
                        //            {
                        //                AppUserId = lmd.AppUserId,
                        //                Description = alertText,
                        //                IsRead = false,
                        //                EntityTypeId = (int)EntityType.Contract,
                        //                EntityId = addendum.ContractId,
                        //                AppEventTypeId = (int)AppEventType.AddendumReminder,
                        //            };

                        //            await this._alertService.CreateAsync(alert, user);

                        //        }

                        //        isValid = true;
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        //        log.Error(ex);
                        //    }

                        //    isValid = true;
                        //}
                    }

                }

            }
            catch (Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
                isValid = false;
            }
            return isValid;
        }

        public async Task<bool> SetPreIsPrimaryAddendumDocumentsByAgentAsync(int addendumDocumentId, IPrincipal user)
        {
            return await this.Context.ContractDocuments.SetPreIsPrimaryAddendumDocumentsByAgentAsync(addendumDocumentId, user);
        }

        public async Task<bool> ResetAllPrimaryAddendumByAgentAsync(int contractId, IPrincipal user)
        {
            bool isValid = false;
            try
            {
                var addendums = await _eceCrmEntities.AddendumDocument.Where(a => a.ContractId == contractId && a.IsPrimary).ToListAsync();
                foreach (var i in addendums)
                {
                    i.IsPrimary = false;
                    i.UpdatedById = user.GetUserId();
                    i.UpdatedDate = DateTime.Now;
                }
                await _eceCrmEntities.SaveChangesAsync();
                isValid = true;

                try
                {

                    if (addendums != null && addendums.Any())
                    {
                        var addendum = addendums.FirstOrDefault();
                        if (addendum != null)
                        {
                            List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();

                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "Remove Amendment File",
                                Old = Convert.ToString("Remove Amendment File"),
                                New = Convert.ToString("Remove Amendment File"),
                                Createddate = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"),
                                Createdby = user.Identity.Name,
                                IsPDFChange = true
                            });

                            if (contractChanges!=null && contractChanges.Count > 0)
                            {
                                string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                                bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                                {
                                    Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",addendum.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                                    DynamicParameters parameters = new DynamicParameters(dictionary);
                                    IDbConnection conn = sqlConnectionFactory.CreateConnection();
                                    await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                                    if (conn.State == ConnectionState.Open)
                                    {
                                        conn.Close();
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }
            }
            catch (Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);

            }

            return isValid;

        }


        /// <summary>
        /// Asynchronously converts a Word document to PDF.
        /// </summary>
        /// <param name="inputPath">The full path to the input Word document.</param>
        /// <param name="outputPath">The full path where the PDF will be saved.</param>
        /// <returns>A Task that returns "Success" if conversion succeeds, or an error message.</returns>
        public async Task<string> ConvertAsync(string inputPath, string outputPath)
        {
            return await Task.Run(() =>
            {
                string result = "Success";

                try
                {

                    Spire.Doc.License.LicenseProvider.SetLicenseKey(spireDocLicenseKey);
                    //Spire.License.LicenseProvider.LoadLicenseFromFile("path-to-your-license-file.lic");
                    Spire.Doc.Document doc = new Spire.Doc.Document();
                    doc.LoadFromFile(inputPath);
                    // Convert to PDF
                    doc.SaveToFile(outputPath, Spire.Doc.FileFormat.PDF);
                }
                catch (Exception ex)
                {
                    result = "Failure";
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }

                return result;
            });
        }

    }
}
