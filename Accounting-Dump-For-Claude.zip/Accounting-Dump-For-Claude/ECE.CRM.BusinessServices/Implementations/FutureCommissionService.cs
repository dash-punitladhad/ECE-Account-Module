﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using Infinity.Mobius.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class FutureCommissionService : IFutureCommissionService
	{
		public FutureCommissionService(IUnitOfWork context, ILogger logger)
		{
			this.Context = context;
			this.Logger = logger;
		}
		public IUnitOfWork Context { get; private set; }
		public ILogger Logger { get; private set; }

		public async Task<IList<FutureCommissionDto>> GetAgentFutureCommission(AgentDrawFilterModel filterModel)
		{
			return await this.Context.FutureCommissionDao.GetFutureCommissions(filterModel);
		}
	}
}
