﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class EntityService : IEntityService
    {
        private readonly IPresenterService _presenterService;
        private readonly IArtistService _artistService;
        private readonly IVenueService _venueService;
        private readonly IBlueCardService _blueCardService;
        private readonly IContractService _contractService;
        private readonly ILeadService _leadService;

        public EntityService(IUnitOfWork context,
                             IPresenterService presenterService,
                             IArtistService artistService,
                             IVenueService venueService,
                             IBlueCardService blueCardService,
                             IContractService contractService,
                             ILeadService leadService)
        {
            this.Context = context;

            this._presenterService = presenterService;
            this._artistService = artistService;
            this._venueService = venueService;
            this._blueCardService = blueCardService;
            this._contractService = contractService;
            this._leadService = leadService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task ToggleEntityActiveStatusAsync(int entityId, bool isActive, int updatedBy, EntityType entityType, int? blueCardClosedReasonId)
        {
            switch (entityType)
            {
                case EntityType.Presenter:
                    await this._presenterService.TogglePresenterStatusAsync(entityId, isActive, updatedBy);
                    break;
                case EntityType.Artist:
                    await this._artistService.ToggleArtistStatusAsync(entityId, isActive, updatedBy);
                    break;
                case EntityType.Venue:
                    await this._venueService.ToggleVenueStatusAsync(entityId, isActive, updatedBy);
                    break;
                case EntityType.BlueCard:
                    await this._blueCardService.ToggleBlueCardStatusAsync(entityId, isActive, updatedBy, blueCardClosedReasonId);
                    break;
                case EntityType.Contract:
                    break;
                case EntityType.Lead:
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(entityType), entityType, null);
            }
        }

        public async Task ReassignEntityAgentAsync(int entityId, int agentId, EntityType entityType, IPrincipal user)
        {
            switch (entityType)
            {
                case EntityType.Presenter:
                    await this._presenterService.ReassignPresenterAgentAsync(entityId, agentId, user);
                    break;

                case EntityType.Artist:
                    await this._artistService.ReassignArtistAgentAsync(entityId, agentId, user);
                    break;

                case EntityType.Venue:
                    await this._venueService.ReassignVenueAgentAsync(entityId, agentId, user);
                    break;

                case EntityType.BlueCard:
                    await this._blueCardService.ReassignBlueCardAgentAsync(entityId, agentId, user);
                    break;

                case EntityType.Contract:
                    break;

                case EntityType.Lead:
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(entityType), entityType, null);
            }
        }

        public async Task ToggleEntityArchiveStatusAsync(int entityId, bool isArchived, int updatedBy, EntityType entityType)
        {
            switch (entityType)
            {
                case EntityType.Presenter:
                    await this._presenterService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                case EntityType.Artist:
                    await this._artistService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                case EntityType.Venue:
                    await this._venueService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                case EntityType.BlueCard:
                    await this._blueCardService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                case EntityType.Contract:
                    await this._contractService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                case EntityType.Lead:
                    await this._leadService.ToggleArchiveStatusAsync(entityId, isArchived, updatedBy);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(entityType), entityType, null);
            }
        }

        public async Task ToggleProblemContractStatusAsync(int entityId, bool isExcluded, int updatedBy, EntityType entityType)
        {
            switch (entityType)
            {
                case EntityType.Contract:
                    await this._contractService.ToggleProblemContractStatusAsync(entityId, isExcluded, updatedBy);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(entityType), entityType, null);
            }
        }
        public async Task ToggleAgentAttendContractStatusAsync(int entityId, bool isExcluded, int updatedBy, EntityType entityType)
        {
            switch (entityType)
            {
                case EntityType.Contract:
                    await this._contractService.ToggleAgentAttendContractStatusAsync(entityId, isExcluded, updatedBy);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(entityType), entityType, null);
            }
        }
    }
}
