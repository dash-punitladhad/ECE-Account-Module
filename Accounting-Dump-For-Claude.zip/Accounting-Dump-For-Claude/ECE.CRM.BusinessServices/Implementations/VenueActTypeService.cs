﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class VenueActTypeService : IVenueActTypeService
    {
        public VenueActTypeService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<int> CreateAsync(VenueActTypeDto venueActType)
        {
            return await this.Context.VenueActTypes.CreateAsync(venueActType);
        }

        public async Task<List<VenueActTypeDto>> GetVenueActTypesByVenueAsync(int id)
        {
            return await this.Context.VenueActTypes.GetVenueActTypesByVenueAsync(id);
        }

        public async Task SyncVenueActTypes(int venueId, IEnumerable<string> venueActTypes)
        {
            this.Context.BeginTransaction();

            try
            {
                var existingVenueActTypes = await this.Context.VenueActTypes.GetVenueActTypesByVenueAsync(venueId);

                var listOfSelectedVenueActTypes =
                    venueActTypes?.Select(x => Convert.ToInt32(x.Trim())).ToList()
                    ?? new List<int>();

                var actTypesToKeep =
                    existingVenueActTypes.Where(x => listOfSelectedVenueActTypes.Contains(x.ActTypeId)).ToList();

                var actTypesToAdd = listOfSelectedVenueActTypes.Except(
                                    actTypesToKeep.Select(x => x.ActTypeId).ToList(),
                                    x => x);

                foreach (int i in actTypesToAdd)
                {
                    var v = new VenueActTypeDto() { VenueId = venueId, ActTypeId = i, VenueActTypeId = 0 };
                    await this.Context.VenueActTypes.CreateAsync(v);
                }

                var actTypesToRemove = existingVenueActTypes.Except(actTypesToKeep).ToList();

                foreach (var dto in actTypesToRemove)
                {
                    await this.Context.VenueActTypes.Delete(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }
    }
}
