﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    public class IcsFileService : IIcsFileService
    {
        public byte[] GetIcsEventFile(IcsFileDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException("dto");
            }

            var result = BuildIcsFile(dto);

            byte[] fileBytes;

            using (var ms = new MemoryStream())
            {
                using (var sw = new StreamWriter(ms))
                {
                    sw.Write(result);
                    sw.Flush();

                    fileBytes = ms.ToArray();
                }
            }

            return fileBytes;
        }

        private string BuildIcsFile(IcsFileDto icsFileDto)
        {
            var config =
               new
               {
                   IcsProdId = MobiusConfiguration.GetString("ICS.ProdId"),
                   IcsVersion = MobiusConfiguration.GetString("ICS.Version"),
                   IcsMeetingMethod = MobiusConfiguration.GetString("ICS.MeetingMethod"),
                   IcsAppointmentMethod = MobiusConfiguration.GetString("ICS.AppointmentMethod"),
                   IcsDateFormat = MobiusConfiguration.GetString("ICS.DateFormat")
               };

            var timeZoneInfo = icsFileDto.TimeZoneInfo;
            var timeZoneName = string.Empty;
            TimeSpan? tzOffset = null;
            var tzStandardOffset = timeZoneInfo.BaseUtcOffset;
            var tzDaylightOffset = tzStandardOffset.Subtract(new TimeSpan(0, -1, 0, 0));
            if (timeZoneInfo.IsDaylightSavingTime(icsFileDto.BeginDateTime))
            {
                timeZoneName = timeZoneInfo.DaylightName;
                tzOffset = tzDaylightOffset;
            }
            else
            {
                timeZoneName = timeZoneInfo.StandardName;
                tzOffset = tzStandardOffset;
            }

            var calcStartDateTime = icsFileDto.BeginDateTime.AddHours(tzOffset.Value.Hours);
            var calcEndDateTime = icsFileDto.EndDateTime.AddHours(tzOffset.Value.Hours);

            StringBuilder builder = new StringBuilder();

            builder.AppendLine("BEGIN:VCALENDAR");
            builder.AppendLine(config.IcsProdId);
            builder.AppendFormat("VERSION:{0}\n", config.IcsVersion);
            builder.AppendFormat("METHOD:{0}\n", icsFileDto.Attendees != null && icsFileDto.Attendees.Count > 0 ? config.IcsMeetingMethod : config.IcsAppointmentMethod);
            builder.AppendLine("BEGIN:TIMEZONE");
            builder.AppendFormat("TZID:{0}\n", timeZoneName);
            builder.AppendLine("BEGIN:STANDARD");
            builder.AppendLine("DTSTART:16011104T020000");
            builder.AppendLine("RRULE:FREQ=YEARLY;BYDAY=1SU;BYMONTH=11");
            builder.AppendFormat("TZOFFSETFROM:{0}\n", tzDaylightOffset);
            builder.AppendFormat("TZOFFSETTO:{0}\n", tzStandardOffset);
            builder.AppendLine("END:STANDARD");
            builder.AppendLine("BEGIN:DAYLIGHT");
            builder.AppendLine("DTSTART:16010311T020000");
            builder.AppendLine("RRULE:FREQ=YEARLY;BYDAY=2SU;BYMONTH=3");
            builder.AppendFormat("TZOFFSETFROM:{0}\n", tzStandardOffset);
            builder.AppendFormat("TZOFFSETTO:{0}\n", tzDaylightOffset);
            builder.AppendLine("END:DAYLIGHT");
            builder.AppendLine("END:TIMEZONE");
            builder.AppendLine("BEGIN:VEVENT");

            if (icsFileDto.Attendees != null && icsFileDto.Attendees.Count > 0)
            {
                foreach (KeyValuePair<string, string> attendee in icsFileDto.Attendees)
                {
                    builder.AppendFormat("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}\n", attendee.Key, attendee.Value);
                }
            }

            builder.AppendFormat("LOCATION:{0}\n", icsFileDto.Location);
            builder.AppendLine("PRIORITY:5");
            builder.AppendFormat("ORGANIZER;CN=\"{0}\"SENT-BY=\"mailto:{1}\":mailto:{1}\n", icsFileDto.OrganizerDisplayName, icsFileDto.OrganizerEmail);
            builder.AppendFormat("DESCRIPTION: {0}\n", icsFileDto.EventDescription);
            builder.AppendFormat("SUMMARY:{0}\n", icsFileDto.EventSummary);
            builder.AppendFormat("DTSTART;TZID=\"{0}\":{1}\n", timeZoneName, calcStartDateTime.ToString(config.IcsDateFormat));
            builder.AppendFormat("DTSTAMP:{0}\n", icsFileDto.TimeStamp.ToString(config.IcsDateFormat));
            builder.AppendFormat("DTEND;TZID=\"{0}\":{1}\n", timeZoneName, calcEndDateTime.ToString(config.IcsDateFormat));
            builder.AppendLine("TRANSP:OPAQUE");
            builder.AppendLine("CLASS:PUBLIC");
            builder.AppendFormat("UID:{0}\n", Guid.NewGuid());
            builder.AppendLine("BEGIN:VALARM");
            builder.AppendLine("TRIGGER:-PT15M");
            builder.AppendLine("ACTION:DISPLAY");
            builder.AppendLine("DESCRIPTION:Reminder");
            builder.AppendLine("END:VALARM");
            builder.AppendLine("END:VEVENT");
            builder.AppendLine("END:VCALENDAR");

            var result = builder.ToString();
            return result;
        }
    }
}
