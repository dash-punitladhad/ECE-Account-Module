namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class GeneralLedgerService : IGeneralLedgerService
    {
        public static readonly char CreditChangeType = 'C';

        public static readonly char DebitChangeType = 'D';

        private static readonly int[] EceContractTrxTypes = new[]
        {
            (int)ContractTransactionType.Commission,
            (int)ContractTransactionType.SharedBonus,
            (int)ContractTransactionType.GasCard,
            (int)ContractTransactionType.ContractFee,
            (int)ContractTransactionType.NonExclusiveContractFee,
            (int)ContractTransactionType.AgentWorking,
            (int)ContractTransactionType.ReserveAllowance,
            (int)ContractTransactionType.AR,
            (int)ContractTransactionType.UnpaidContractExpenses
        };
        private static readonly int[] EceContractTrxTypesOld = new[]
        {
            (int)ContractTransactionType.SharedBonus,
            (int)ContractTransactionType.GasCard,
            (int)ContractTransactionType.ContractFee,
            (int)ContractTransactionType.NonExclusiveContractFee,
            (int)ContractTransactionType.AgentWorking,
            (int)ContractTransactionType.ReserveAllowance
        };
        private readonly IUserService _userService;

        private readonly IPayrollService _payrollService;
         private readonly IEceCrmEntities _eceCrmEntities;
        private IDictionary<GeneralLedgerEvent, List<GeneralLedgerTransactionTypeDto>> _generalLedgerTransactionTypes = null;

        public GeneralLedgerService(
            IUnitOfWork context,
            IUserService userService,

            IPayrollService payrollService,IEceCrmEntities eceCrmEntities
            )

        {
            this.Context = context;
            this._userService = userService;
            this._payrollService = payrollService;
           
            this._generalLedgerTransactionTypes = new Dictionary<GeneralLedgerEvent, List<GeneralLedgerTransactionTypeDto>>();
            this._eceCrmEntities = eceCrmEntities;
        }

        public IUnitOfWork Context { get; private set; }

        public static GeneralLedgerEvent GetGeneralLedgerEventToPay(int contractTransactionTypeId)
        {
            if (Enum.IsDefined(typeof(ContractTransactionType), contractTransactionTypeId))
            {
                var contractTransactionType = (ContractTransactionType)contractTransactionTypeId;

                return GetGeneralLedgerEventToPay(contractTransactionType);
            }

            return GeneralLedgerEvent.Unknown;
        }

        public static GeneralLedgerEvent GetGeneralLedgerEventToPay(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.Commission:
                    return GeneralLedgerEvent.EceContractExpensePaid;

                case ContractTransactionType.SharedBonus:
                    return GeneralLedgerEvent.EceSharedBonusPaid;

                case ContractTransactionType.GasCard:
                case ContractTransactionType.ReserveAllowance:
                    return GeneralLedgerEvent.EceGasCardPaid;

                case ContractTransactionType.ContractFee:
                    return GeneralLedgerEvent.EceContractFeePaid;

                case ContractTransactionType.NonExclusiveContractFee:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeePaid;

                case ContractTransactionType.AgentWorking:
                    return GeneralLedgerEvent.ECEAgentWorkingPaid;
                case ContractTransactionType.AR:
                    return GeneralLedgerEvent.ARPaid;
                case ContractTransactionType.UnpaidContractExpenses:
                    return GeneralLedgerEvent.UnpaidContractExpensesPaid;
                default:
                    throw new ArgumentException($"Unexpected Contract Transaction Type {contractTransactionType}");
            }
        }

        public static GeneralLedgerEvent GetGeneralLedgerEventToReturn(int contractTransactionTypeId)
        {
            if (Enum.IsDefined(typeof(ContractTransactionType), contractTransactionTypeId))
            {
                var contractTransactionType = (ContractTransactionType)contractTransactionTypeId;

                return GetGeneralLedgerEventToReturn(contractTransactionType);
            }

            return GeneralLedgerEvent.Unknown;
        }

        public static GeneralLedgerEvent GetGeneralLedgerEventToReturn(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.Commission:
                    return GeneralLedgerEvent.ReverseEceContractExpensePaid;

                case ContractTransactionType.SharedBonus:
                    return GeneralLedgerEvent.EceSharedBonusReturned;

                case ContractTransactionType.GasCard:
                case ContractTransactionType.ReserveAllowance:
                    return GeneralLedgerEvent.EceGasCardReturned;

                case ContractTransactionType.ContractFee:
                    return GeneralLedgerEvent.EceContractFeeReturned;

                case ContractTransactionType.NonExclusiveContractFee:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeeReturned;

                case ContractTransactionType.AgentWorking:
                    return GeneralLedgerEvent.ECEAgentWorkingReturned;

                case ContractTransactionType.AR:
                    return GeneralLedgerEvent.ARReturned;
                case ContractTransactionType.UnpaidContractExpenses:
                    return GeneralLedgerEvent.UnpaidContractExpensesReturned;
                default:
                    throw new ArgumentException($"Unexpected Contract Transaction Type {contractTransactionType}");
            }
        }

        public static bool IsEceExpense(ContractTransactionType contractTransactionType)
        {
            return GeneralLedgerService.IsEceExpense((int)contractTransactionType);
        }

        public static bool IsEceExpense(int contractTransactionTypeId)
        {
            return GeneralLedgerService.EceContractTrxTypes.Contains(contractTransactionTypeId);
        }
        public static bool IsEceExpenseOld(int contractTransactionTypeId)
        {
            return GeneralLedgerService.EceContractTrxTypesOld.Contains(contractTransactionTypeId);
        }

        public GeneralLedgerEvent GetReversedGlEvent(GeneralLedgerEvent generalLedgerEvent)
        {
            switch (generalLedgerEvent)
            {
                case GeneralLedgerEvent.RecordContDepOwedtoECE:
                    return GeneralLedgerEvent.DepositNoLongerDueContCxld;

                case GeneralLedgerEvent.ContractIncomeAdded:
                    return GeneralLedgerEvent.ContractIncomeDecreased;

                case GeneralLedgerEvent.DepositReceived:
                    return GeneralLedgerEvent.DepositUnposted;

                case GeneralLedgerEvent.DepositUnposted:
                    return GeneralLedgerEvent.DepositReceived;

                case GeneralLedgerEvent.EceContractExpensePaid:
                    return GeneralLedgerEvent.ReverseEceContractExpensePaid;

                case GeneralLedgerEvent.ReverseEceContractExpensePaid:
                    return GeneralLedgerEvent.EceContractExpensePaid;

                case GeneralLedgerEvent.ArtistExpensePaid:
                    return GeneralLedgerEvent.ReverseArtistExpensePaid;

                case GeneralLedgerEvent.ReverseArtistExpensePaid:
                    return GeneralLedgerEvent.ArtistExpensePaid;

                case GeneralLedgerEvent.OtherExpensePaid:
                    return GeneralLedgerEvent.ReverseOtherExpensePaid;

                case GeneralLedgerEvent.ReverseOtherExpensePaid:
                    return GeneralLedgerEvent.OtherExpensePaid;

                case GeneralLedgerEvent.AgentPayrollCommisionsPaid:
                    return GeneralLedgerEvent.ReverseAgentPayrollCommisionsPaid;

                case GeneralLedgerEvent.ReverseAgentPayrollCommisionsPaid:
                    return GeneralLedgerEvent.AgentPayrollCommisionsPaid;

                case GeneralLedgerEvent.AgentWorkingPaid:
                    return GeneralLedgerEvent.ReverseAgentWorkingPaid;

                case GeneralLedgerEvent.ReverseAgentWorkingPaid:
                    return GeneralLedgerEvent.AgentWorkingPaid;

                case GeneralLedgerEvent.ContractIncomeIncreased:
                    return GeneralLedgerEvent.ContractIncomeDecreased;

                case GeneralLedgerEvent.ContractIncomeDecreased:
                    return GeneralLedgerEvent.ContractIncomeIncreased;

                case GeneralLedgerEvent.EceSharedBonusPaid:
                    return GeneralLedgerEvent.EceSharedBonusReturned;

                case GeneralLedgerEvent.EceSharedBonusReturned:
                    return GeneralLedgerEvent.EceSharedBonusPaid;

                case GeneralLedgerEvent.EceGasCardPaid:
                    return GeneralLedgerEvent.EceGasCardReturned;

                case GeneralLedgerEvent.EceGasCardReturned:
                    return GeneralLedgerEvent.EceGasCardPaid;

                case GeneralLedgerEvent.EceContractFeePaid:
                    return GeneralLedgerEvent.EceContractFeeReturned;

                case GeneralLedgerEvent.EceContractFeeReturned:
                    return GeneralLedgerEvent.EceContractFeePaid;

                case GeneralLedgerEvent.EceNonExclusiveArtistFeePaid:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeeReturned;

                case GeneralLedgerEvent.EceNonExclusiveArtistFeeReturned:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeePaid;

                case GeneralLedgerEvent.ECEAgentWorkingPaid:
                    return GeneralLedgerEvent.ECEAgentWorkingReturned;

                case GeneralLedgerEvent.ECEAgentWorkingReturned:
                    return GeneralLedgerEvent.ECEAgentWorkingPaid;

                case GeneralLedgerEvent.ARPaid:
                    return GeneralLedgerEvent.ARReturned;

                case GeneralLedgerEvent.ARReturned:
                    return GeneralLedgerEvent.ARPaid;
                case GeneralLedgerEvent.UnpaidContractExpensesPaid:
                    return GeneralLedgerEvent.UnpaidContractExpensesReturned;
                case GeneralLedgerEvent.UnpaidContractExpensesReturned:
                    return GeneralLedgerEvent.UnpaidContractExpensesPaid;
                case GeneralLedgerEvent.AdminAccountPaid:
                    return GeneralLedgerEvent.AdminAccoutReturned;
                case GeneralLedgerEvent.AdminAccountOtherExpPaid:
                    return GeneralLedgerEvent.AdminAccountOtherExpReturned;
            }

            return GeneralLedgerEvent.Unknown;
        }

        public GeneralLedgerEvent GetEventForPayingNonEceExpense(ContractTransactionDto transaction)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException(nameof(transaction));
            }

            if (!Enum.IsDefined(typeof(ContractEntityType), transaction.ContractEntityTypeId))
            {
                throw new ArgumentException($"Invalid Contract Entity Type {transaction.ContractEntityTypeId}");
            }

            var entityType = (ContractEntityType)transaction.ContractEntityTypeId;

            if (entityType == ContractEntityType.ECE)
            {
                throw new ArgumentException($"Invalid Contract Transaction {transaction.ContractTransactionId}");
            }

            if (transaction.IsIncome && entityType == ContractEntityType.Artist)
            {
                return GeneralLedgerEvent.XdeductWithAref;
            }

            if (entityType == ContractEntityType.Artist)
            {
                return GeneralLedgerEvent.ArtistExpensePaid;
            }
            else
            {
                return GeneralLedgerEvent.OtherExpensePaid;
            }
        }

        public GeneralLedgerEvent GetEventForPayingIncome(ContractTransactionDto transaction)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException(nameof(transaction));
            }

            if (!Enum.IsDefined(typeof(ContractEntityType), transaction.ContractEntityTypeId))
            {
                throw new ArgumentException($"Invalid Contract Entity Type {transaction.ContractEntityTypeId}");
            }

            var entityType = (ContractEntityType)transaction.ContractEntityTypeId;

            if (entityType == ContractEntityType.ECE)
            {
                throw new ArgumentException($"Invalid Contract Transaction {transaction.ContractTransactionId}");
            }

            if (entityType == ContractEntityType.Artist)
            {
                return GeneralLedgerEvent.XdeductWithAref;
            }

            throw new ArgumentException($"Cannot pay income records for entity type '{entityType}'");
        }

        public async Task<IList<GeneralLedgerAccountDto>> GetAccountsAsync()
        {
            var results = await this.Context.GeneralLedgers.GetAccountsAsync();

            return results;
        }

        public async Task<IList<GeneralLedgerJournalActivityDto>> GetJournalActivityAsync()
        {
            var results = await this.Context.GeneralLedgers.GetJournalActivityAsync();

            return results;
        }

        public async Task<IList<GeneralLedgerJournalDto>> GetJournalActivityByContractTransactionIdAsync(int id)
        {
            var results = await this.Context.GeneralLedgers.GetJournalActivityByContractTransactionIdAsync(id);

            return results;
        }

        public async Task<GeneralLedgerAccountDto> GetGLAccountByIdAsync(int id)
        {
            var dto = await this.Context.GeneralLedgers.GetGLAccountByIdAsync(id);

            return dto;
        }

        public async Task<IList<GeneralLedgerJournalActivityDto>> GetGLJournalDetailsByCriteriaAsync(GLJournalDetailsSearchCriteriaDto criteria)
        {
            var results = await this.Context.GeneralLedgers.GetGLJournalDetailsByCriteriaAsync(criteria);

            return results;
        }

        public async Task<bool> ContractIsInitializedAsync(int id)
        {
            var criteria = new GLJournalDetailsSearchCriteriaDto();
            criteria.ContractId = id;

            var glActivity = await this.GetGLJournalDetailsByCriteriaAsync(criteria);
            var incomeAdded = glActivity
                .Where(x => x.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Liability && x.ChangeType == "C")
                .Total(x => x.PostedAmount);

            var incomeRemoved = glActivity
                .Where(x => x.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Liability && x.ChangeType == "D")
                .Total(x => x.PostedAmount);

            return incomeAdded > incomeRemoved;
        }

        public async Task<IList<GLJournalSearchResultDto>> GetGLJournalEntriesByCriteriaAsync(GLJournalSearchCriteriaDto criteria)
        {
            var results = await this.Context.GeneralLedgers.GetGLJournalEntriesByCriteriaAsync(criteria);

            return results;
        }

        public async Task<IList<ExpenseManagementSearchResultDto>> GetExpenseManagementByCriteriaAsync(ExpenseManagementSearchCriteriaDto criteria)
        {
            var results = await this.Context.GeneralLedgers.GetExpenseManagementByCriteriaAsync(criteria);

            return results;
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId)
        {
            var journalTransactionNumber = this.Context.GeneralLedgers.GetNextJournalTransactionSequenceValue();

            foreach (var gltt in generalLedgerTransactionTypes)
            {
                var debitLedger = new GeneralLedgerJournalDto
                {
                    GeneralLedgerAccountId = gltt.DebitAccountId,
                    AgentId = transaction.AgentId,
                    ChangeDirection = gltt.DebitChangeDirection.ToString(),
                    ChangeType = DebitChangeType.ToString(),
                    ContractId = transaction.ContractId,
                    ContractTransactionId = transaction.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    ContractEntityId = transaction.ContractEntityId,
                    ContractEntityTypeId = transaction.ContractEntityTypeId,
                    PostedDate = DateTime.Now,
                    PostedAmount = amount,
                    OfficeId = transaction.OfficeId,
                    LineOfBusinessId = transaction.LineOfBusinessId,
                    JournalTransactionNumber = journalTransactionNumber,
                    ExpenseBatchId = expenseBatchId,
                    ReferenceNumber = referenceNumber,
                };

                debitLedger.SetAsCreated(user);

                await this.Context.GeneralLedgers.CreateJournalEntryAsync(debitLedger);

                var creditLedger = new GeneralLedgerJournalDto
                {
                    GeneralLedgerAccountId = gltt.CreditAccountId,
                    AgentId = transaction.AgentId,
                    ChangeDirection = gltt.CreditChangeDirection.ToString(),
                    ChangeType = CreditChangeType.ToString(),
                    ContractId = transaction.ContractId,
                    ContractTransactionId = transaction.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    ContractEntityId = transaction.ContractEntityId,
                    ContractEntityTypeId = transaction.ContractEntityTypeId,
                    PostedDate = DateTime.Now,
                    PostedAmount = amount,
                    OfficeId = transaction.OfficeId,
                    LineOfBusinessId = transaction.LineOfBusinessId,
                    JournalTransactionNumber = journalTransactionNumber,
                    ExpenseBatchId = expenseBatchId,
                    ReferenceNumber = referenceNumber,
                };

                creditLedger.SetAsCreated(user);

                await this.Context.GeneralLedgers.CreateJournalEntryAsync(creditLedger);
            }
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId)
        {
            List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes = null;

            if (_generalLedgerTransactionTypes.ContainsKey(generalLedgerEvent))
            {
                generalLedgerTransactionTypes = _generalLedgerTransactionTypes[generalLedgerEvent];
            }
            else
            {
                generalLedgerTransactionTypes = await this.Context.GeneralLedgerTransactionTypes
                    .GetTransactionTypesByEventIdAsync((int)generalLedgerEvent, transaction.ContractEntityTypeId);

                _generalLedgerTransactionTypes[generalLedgerEvent] = generalLedgerTransactionTypes;
            }

            if (!generalLedgerTransactionTypes.Any())
            {
                var contractEntityType = (ContractEntityType)transaction.ContractEntityTypeId;

                throw new UnhandledBusinessException($"No G/L Transactions for {generalLedgerEvent} {contractEntityType}");
            }

            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, amount, transaction, user, referenceNumber, expenseBatchId);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerEvent, amount, transaction, user, referenceNumber, null);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, int? expenseBatchId)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerEvent, amount, transaction, user, null, expenseBatchId);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerEvent, amount, transaction, user, null, null);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, amount, transaction, user, referenceNumber, null);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user, int? expenseBatchId)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, amount, transaction, user, null, expenseBatchId);
        }

        public async Task CreateGeneralLedgerJournalEntryAsync(List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes, decimal amount, ContractTransactionDto transaction, IPrincipal user)
        {
            await this.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, amount, transaction, user, null, null);
        }

        public decimal GetUnallocatedIncome(IEnumerable<ContractTransactionDto> contractTransactions)
        {
            if (contractTransactions == null)
            {
                return decimal.Zero;
            }

            var incomePaid = contractTransactions
                .Where(x => !x.IsExpense)
                .Sum(x => x.PaidAmount.GetValueOrDefault());

            var expensePaid = contractTransactions
                .Where(x => x.IsExpense)
                .Sum(x => x.PaidAmount.GetValueOrDefault());

            var unallocatedIncome = incomePaid - expensePaid;

            return unallocatedIncome;
        }

        public decimal UpdateExpensePaidAmount(ContractTransactionDto expense, decimal amountToPay, IEnumerable<ContractTransactionDto> contractTransactions)
        {
            var paidAmount = amountToPay;

            var unallocatedIncome = this.GetUnallocatedIncome(contractTransactions);
            if (unallocatedIncome <= decimal.Zero && paidAmount > decimal.Zero)
            {
                // Don't pay if there is not enough unallocated income in escrow.
                return decimal.Zero;
            }

            if (paidAmount < decimal.Zero)
            {
                /*
                 * When the amount to pay is negative, make sure not to return more than
                 * what is due.
                 */

                if (expense.DueAmount < decimal.Zero)
                {
                    if (expense.DueAmount > paidAmount)
                    {
                        paidAmount = expense.DueAmount;
                    }
                }
                else
                {
                    if (expense.DueAmount >= -paidAmount)
                    {
                        paidAmount = decimal.Zero;
                    }
                    else if (expense.PaidAmount.GetValueOrDefault() < -paidAmount)
                    {
                        paidAmount = -expense.PaidAmount.GetValueOrDefault();
                    }
                }

                expense.PaidAmount = expense.PaidAmount.GetValueOrDefault() + paidAmount;
            }
            else
            {
                if (expense.DueAmount < paidAmount)
                {
                    paidAmount = expense.DueAmount;
                }

                if (unallocatedIncome > decimal.Zero && paidAmount > unallocatedIncome)
                {
                    // Partially pay the expense if amount to pay exceeds escrow balance
                    paidAmount = unallocatedIncome;
                    expense.PaidAmount = unallocatedIncome;
                }
                else
                {
                    // Fully pay the expense
                    expense.PaidAmount = expense.PaidAmount.GetValueOrDefault() + paidAmount;
                }
            }

            ContractTransactionHelper.SynchronizePaidDate(expense);

            return paidAmount;
        }

        public async Task<decimal> PayEceExpenseAsync(ContractTransactionDto expense, decimal amountToPay, IPrincipal user,bool isConverted)
        {
            if (expense == null)
            {
                throw new ArgumentNullException(nameof(expense));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (amountToPay == decimal.Zero)
            {
                // Nothing to do if expense is zero.
                return decimal.Zero;
            }

            if (expense.IsIncome)
            {
                // Don't pay income records
                return decimal.Zero;
            }

            if (expense.ContractEntityTypeId != (int)ContractEntityType.ECE ||
                IsEceExpense(expense.ContractTransactionTypeId) == false)
            {
                // Don't pay non-ECE expenses
                return decimal.Zero;
            }

            try
            {
                this.Context.BeginTransaction();

                var contractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(expense.ContractId);

                var paidAmount = isConverted ? expense.RequiredAmount : this.UpdateExpensePaidAmount(expense, amountToPay, contractTransactions);
                if (paidAmount == decimal.Zero)
                {
                    // Don't pay if there is not enough in escrow.
                    this.Context.Commit();
                    return decimal.Zero;
                }
                if (isConverted)
                {
                    expense.OfficeId = (int)ECEOffice.Admin;
                    expense.AgentId = this._eceCrmEntities.AppUsers.FirstOrDefault(_=>_.FirstName.ToLower() == "admin" && _.LastName.ToLower() == "office").AppUserId;
                }

                expense.SetAsUpdated(user);
                await this.Context.ContractTransactions.UpdateAsync(expense);
                
                GeneralLedgerEvent glEvent;

                if (paidAmount > decimal.Zero)
                {
                    glEvent = GetGeneralLedgerEventToPay(expense.ContractTransactionTypeId);
                }
                else
                {
                    glEvent = GetGeneralLedgerEventToReturn(expense.ContractTransactionTypeId);
                }

                await this.CreateGeneralLedgerJournalEntryAsync(glEvent, Math.Abs(paidAmount.Value), expense, user);

                await this._payrollService.SynchronizeAgentPayrollLogAsync(expense, user);

                this.Context.Commit();

                return paidAmount.Value;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// Pays any unpaid ECE expenses with money in escrow, prioritizing commissions first.
        /// </summary>
        /// <param name="contractId">The contract id.</param>
        /// <param name="user">The user.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task PayEceExpensesForContractAsync(int contractId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var contract = await this.Context.Contracts.GetByIdAsync(contractId);
            var contractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractId);
            contract.ContractTransactions = contractTransactions;
            var unallocatedIncome = this.GetUnallocatedIncome(contractTransactions);

            // Get unpaid ECE expenses (of a certain type) putting commissions at the top of the list.
            var unpaidEceExpenses = contractTransactions
                .Where(x => x.IsExpense
                    && x.ContractEntityTypeId == (int)ContractEntityType.ECE
                    && x.DueAmount != decimal.Zero
                    && EceContractTrxTypes.Contains(x.ContractTransactionTypeId))
                .OrderBy(x => x.ContractTransactionTypeId != (int)ContractTransactionType.Commission)
                .ToList();

            // Pay any expenses you can.
            var i = 0;
            var unpaidEceExpensesCount = unpaidEceExpenses.Count;

            while (unallocatedIncome > decimal.Zero && i < unpaidEceExpensesCount)
            {
                var expense = unpaidEceExpenses[i];
                expense.ParentContract = contract;

                var dueAmount = expense.DueAmount;
                var paidAmount = decimal.Zero;

                if (unallocatedIncome < dueAmount)
                {
                    // Partially pay the expense
                    expense.PaidAmount = expense.PaidAmount.GetValueOrDefault() + unallocatedIncome;

                    paidAmount = unallocatedIncome;
                }
                else
                {
                    // Fully pay the expense
                    expense.PaidAmount = expense.PaidAmount.GetValueOrDefault() + dueAmount;
                    ContractTransactionHelper.SynchronizePaidDate(expense);

                    paidAmount = dueAmount;
                }

                unallocatedIncome -= paidAmount;

                expense.SetAsUpdated(user);
                await this.Context.ContractTransactions.UpdateAsync(expense);

                if (paidAmount != decimal.Zero)
                {
                    var glEvent = GetGeneralLedgerEventToPay(expense.ContractTransactionTypeId);

                    await this.CreateGeneralLedgerJournalEntryAsync(glEvent, paidAmount, expense, user);

                    await this._payrollService.SynchronizeAgentPayrollLogAsync(expense, user);
                }

                i++;
            }
        }

        public async Task UnpayEceExpensesForContractAsync(decimal amountToUnpay, int contractId, IPrincipal user)
        {
            // Get paid ECE expenses.
            var contractTrxCriteria = new ContractTransactionSearchCriteriaDto();
            contractTrxCriteria.ContractId = contractId;
            contractTrxCriteria.IsExpense = true;
            contractTrxCriteria.ContractEntityTypeIds.Add((int)ContractEntityType.ECE);
            contractTrxCriteria.PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.PaidSomething;
            contractTrxCriteria.ContractTransactionTypeIds.AddRange(EceContractTrxTypes);

            var contractTransactions = await this.Context.ContractTransactions.GetByCriteriaAsync(contractTrxCriteria);

            // Sort by youngest first, then putting commissions at the bottom of the list.
            var paidEceExpenses = contractTransactions
                .OrderBy(x => x.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                .ThenByDescending(x => x.ContractTransactionId)
                .ToList();

            var amountRemainingToUnpay = amountToUnpay;

            var i = 0;
            var paidEceExpensesCount = paidEceExpenses.Count;

            while (amountRemainingToUnpay > decimal.Zero && i < paidEceExpensesCount)
            {
                var expense = paidEceExpenses[i];

                var expenseAmountUnpaid = decimal.Zero;
                var expenseAmountPaid = expense.PaidAmount.GetValueOrDefault();

                if (amountRemainingToUnpay < expenseAmountPaid)
                {
                    // Partially unpay the expense
                    expenseAmountUnpaid = amountRemainingToUnpay;
                    expense.PaidAmount = expense.PaidAmount.GetValueOrDefault() - amountRemainingToUnpay;
                }
                else
                {
                    // Fully unpay the expense
                    expenseAmountUnpaid = expenseAmountPaid;
                    expense.PaidAmount = decimal.Zero;
                }

                ContractTransactionHelper.SynchronizePaidDate(expense);
                expense.SetAsUpdated(user);
                await this.Context.ContractTransactions.UpdateAsync(expense);

                amountRemainingToUnpay -= expenseAmountUnpaid;

                if (expenseAmountUnpaid != decimal.Zero)
                {
                    var glEvent = GetGeneralLedgerEventToReturn(expense.ContractTransactionTypeId);

                    await this.CreateGeneralLedgerJournalEntryAsync(glEvent, expenseAmountUnpaid, expense, user);

                    // Remove the log entry, since the expense is no longer paid in full.
                    await this._payrollService.DeleteAgentPayrollLogAsync(expense.ContractTransactionId, user);
                }

                i++;
            }
        }

        public async Task<GeneralLedgerTransactionTypeDto> GetGLTransactionTypeByIdAsync(int id)
        {
            var dto = await this.Context.GeneralLedgerTransactionTypes.GetByIdAsync(id);

            return dto;
        }

        public async Task<List<GeneralLedgerTransactionTypeDto>> GetTransactionTypesByEventIdAsync(int id, int? contractEntityTypeId)
        {
            return await this.Context.GeneralLedgerTransactionTypes.GetTransactionTypesByEventIdAsync(id, contractEntityTypeId);
        }

        public async Task AddManualJournalEntriesAsync(IList<GeneralLedgerJournalDto> entries, IPrincipal user)
        {
            if (entries == null)
            {
                throw new ArgumentNullException(nameof(entries));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var journalTransactionNumber = this.Context.GeneralLedgers.GetNextJournalTransactionSequenceValue();

                foreach (var entry in entries)
                {
                    entry.JournalTransactionNumber = journalTransactionNumber;
                    entry.SetAsCreated(user);

                    await this.Context.GeneralLedgers.CreateJournalEntryAsync(entry);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateGeneralLedgerJournalAsync(GeneralLedgerJournalDto dto)
        {
            await this.Context.GeneralLedgers.UpdateGeneralLedgerJournalAsync(dto);
        }

        public async Task<bool> HasGeneralLedgerJournalEntriesAsync(int contractId)
        {
            return await this.Context.GeneralLedgers.HasGeneralLedgerJournalEntriesAsync(contractId);
        }

        public async Task<IList<GeneralLedgerJournalDto>> GetSelectedTransactionsAsync(int[] selectedEntries)
        {
            var entries = await this.Context.GeneralLedgers.GetSelectedTransactionsAsync(selectedEntries);

            return entries;
        }

        public async Task ReverseReapplyOfficeLOBChangeAsync(ContractDto dto, IPrincipal user)
        {
            var criteria = new GLJournalSearchCriteriaDto
            {
                ContractId = dto.ContractId,
            };

            var newOfficeId = dto.OfficeId;
            var newLineOfBusinessId = dto.LineOfBusinessId;

            var results = await this.GetGLJournalEntriesByCriteriaAsync(criteria);

            var events = results
                .OrderBy(x => x.GeneralLedgerJournalId)
                .Select(x => new
                {
                    x.JournalTransactionNumber,
                    x.GeneralLedgerEventId,
                    x.PostedAmount,
                    x.ReferenceNumber,
                    x.ContractEntityTypeId,
                    x.ContractTransactionId,
                    x.AgentId,
                    x.ContractEntityId,
                    x.OfficeId,
                    x.LineOfBusinessId
                })
                .Distinct();

            // reverse the Original GL Entries
            foreach (var glEvent in events)
            {
                List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes;

                var reversedEvent = this.GetReversedGlEvent((GeneralLedgerEvent)glEvent.GeneralLedgerEventId);
                if (reversedEvent == GeneralLedgerEvent.Unknown)
                {
                    // Create a list of reverse transaction types.
                    generalLedgerTransactionTypes = new List<GeneralLedgerTransactionTypeDto>();

                    var originalTransactionTypes = await this.GetTransactionTypesByEventIdAsync(glEvent.GeneralLedgerEventId, glEvent.ContractEntityTypeId);
                    foreach (var originalTransactionType in originalTransactionTypes)
                    {
                        generalLedgerTransactionTypes.Add(originalTransactionType.Reverse());
                    }
                }
                else
                {
                    // Use the list of transaction types for the reverse event.
                    generalLedgerTransactionTypes = await this.GetTransactionTypesByEventIdAsync((int)reversedEvent, glEvent.ContractEntityTypeId);
                }

                var transaction = results.FirstOrDefault(x => x.JournalTransactionNumber == glEvent.JournalTransactionNumber);

                var amount = transaction.PostedAmount;

                var journalTransactionNumber = this.Context.GeneralLedgers.GetNextJournalTransactionSequenceValue();

                foreach (var gltt in generalLedgerTransactionTypes)
                {
                    var debitLedger = new GeneralLedgerJournalDto
                    {
                        GeneralLedgerAccountId = gltt.DebitAccountId,
                        AgentId = transaction.AgentId,
                        ChangeDirection = gltt.DebitChangeDirection.ToString(),
                        ChangeType = "D",
                        ContractId = transaction.ContractId,
                        ContractTransactionId = transaction.ContractTransactionId,
                        GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                        GeneralLedgerEventId = (int)reversedEvent,
                        ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                        ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                        PostedDate = DateTime.Now,
                        PostedAmount = amount,
                        OfficeId = transaction.OfficeId,
                        LineOfBusinessId = transaction.LineOfBusinessId,
                        ReferenceNumber = glEvent.ReferenceNumber,
                        JournalTransactionNumber = journalTransactionNumber
                    };

                    debitLedger.SetAsCreated(user);

                    await this.Context.GeneralLedgers.CreateJournalEntryAsync(debitLedger);

                    var creditLedger = new GeneralLedgerJournalDto
                    {
                        GeneralLedgerAccountId = gltt.CreditAccountId,
                        AgentId = transaction.AgentId,
                        ChangeDirection = gltt.CreditChangeDirection.ToString(),
                        ChangeType = "C",
                        ContractId = transaction.ContractId,
                        ContractTransactionId = transaction.ContractTransactionId,
                        GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                        GeneralLedgerEventId = (int)reversedEvent,
                        ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                        ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                        PostedDate = DateTime.Now,
                        PostedAmount = amount,
                        OfficeId = transaction.OfficeId,
                        LineOfBusinessId = transaction.LineOfBusinessId,
                        ReferenceNumber = glEvent.ReferenceNumber,
                        JournalTransactionNumber = journalTransactionNumber
                    };

                    creditLedger.SetAsCreated(user);

                    await this.Context.GeneralLedgers.CreateJournalEntryAsync(creditLedger);
                }
            }

            // Reapply Original GL Entries using the new Office/LOB
            foreach (var glEvent in events)
            {
                var originalTransactionTypes = await this.GetTransactionTypesByEventIdAsync(glEvent.GeneralLedgerEventId, glEvent.ContractEntityTypeId);

                var transaction = results.FirstOrDefault(x => x.JournalTransactionNumber == glEvent.JournalTransactionNumber);

                var amount = transaction.PostedAmount;

                var journalTransactionNumber = this.Context.GeneralLedgers.GetNextJournalTransactionSequenceValue();

                foreach (var gltt in originalTransactionTypes)
                {
                    var debitLedger = new GeneralLedgerJournalDto
                    {
                        GeneralLedgerAccountId = gltt.DebitAccountId,
                        AgentId = transaction.AgentId,
                        ChangeDirection = gltt.DebitChangeDirection.ToString(),
                        ChangeType = "D",
                        ContractId = transaction.ContractId,
                        ContractTransactionId = transaction.ContractTransactionId,
                        GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                        GeneralLedgerEventId = gltt.GeneralLedgerEventId,
                        ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                        ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                        PostedDate = DateTime.Now,
                        PostedAmount = amount,
                        OfficeId = newOfficeId,
                        LineOfBusinessId = newLineOfBusinessId,
                        ReferenceNumber = glEvent.ReferenceNumber,
                        JournalTransactionNumber = journalTransactionNumber
                    };

                    debitLedger.SetAsCreated(user);

                    await this.Context.GeneralLedgers.CreateJournalEntryAsync(debitLedger);

                    var creditLedger = new GeneralLedgerJournalDto
                    {
                        GeneralLedgerAccountId = gltt.CreditAccountId,
                        AgentId = transaction.AgentId,
                        ChangeDirection = gltt.CreditChangeDirection.ToString(),
                        ChangeType = "C",
                        ContractId = transaction.ContractId,
                        ContractTransactionId = transaction.ContractTransactionId,
                        GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                        GeneralLedgerEventId = gltt.GeneralLedgerEventId,
                        ContractEntityId = transaction.ContractEntityId.GetValueOrDefault(),
                        ContractEntityTypeId = transaction.ContractEntityTypeId.GetValueOrDefault(),
                        PostedDate = DateTime.Now,
                        PostedAmount = amount,
                        OfficeId = newOfficeId,
                        LineOfBusinessId = newLineOfBusinessId,
                        ReferenceNumber = glEvent.ReferenceNumber,
                        JournalTransactionNumber = journalTransactionNumber
                    };

                    creditLedger.SetAsCreated(user);

                    await this.Context.GeneralLedgers.CreateJournalEntryAsync(creditLedger);
                }
            }
        }

        public async Task<decimal> PayEceExpense_UCE_Async(ContractTransactionDto expense, decimal amountToPay, bool isGLReverse, IPrincipal user)
        {
            if (expense == null)
            {
                throw new ArgumentNullException(nameof(expense));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (amountToPay == decimal.Zero)
            {
                // Nothing to do if expense is zero.
                return decimal.Zero;
            }

            if (expense.IsIncome)
            {
                // Don't pay income records
                return decimal.Zero;
            }

            //if (expense.ContractEntityTypeId != (int)ContractEntityType.ECE ||
            //    IsEceExpense(expense.ContractTr
            //    op0\\
            //   nsactionTypeId) == false)
            //{
            //    // Don't pay non-ECE expenses
            //    return decimal.Zero;
            //}

            try
            {
                this.Context.BeginTransaction();

                var contractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(expense.ContractId);

                var glExists = await FetchLastLogDetailAsync(expense.ContractTransactionId);
                if (glExists == null || glExists.IsGLReversed)
                {
                    isGLReverse = false;
                    expense.PaidAmount = expense.RequiredAmount;
                    expense.PaidDate = DateTime.Now;
                    var officeData = await this.Context.Lookups.GetOfficeByIdAsync(24);
                    if (officeData != null)
                    {
                        expense.Office = officeData;
                        expense.OfficeId = officeData.OfficeId;
                    }
                    var agentData =  this._eceCrmEntities.AppUsers.FirstOrDefault(_=>_.FirstName == "Admin" && _.LastName == "Office");
                    expense.AgentId = agentData.AppUserId;
                    expense.AgentFullName = $"{agentData.FirstName} {agentData.LastName}";

                }
                else if (glExists != null && glExists.IsGLConverted)
                {
                    isGLReverse = true;
                    expense.PaidAmount = 0;
                    expense.PaidDate = null;
                    var officeData = await this.Context.Lookups.GetOfficeByIdAsync(24);
                    if (officeData != null)
                    {
                        expense.Office = officeData;
                        expense.OfficeId = officeData.OfficeId;
                    }
                    var agentData = this._eceCrmEntities.AppUsers.FirstOrDefault(_ => _.FirstName == "Admin" && _.LastName == "Office");
                    expense.AgentId = agentData.AppUserId;
                    expense.AgentFullName = $"{agentData.FirstName} {agentData.LastName}";
                }
                else
                {
                    isGLReverse = false;
                    expense.PaidAmount = expense.RequiredAmount;
                    expense.PaidDate = DateTime.Now;
                    var officeData = await this.Context.Lookups.GetOfficeByIdAsync(24);
                    if (officeData != null)
                    {
                        expense.Office = officeData;
                        expense.OfficeId = officeData.OfficeId;
                    }
                    var agentData = this._eceCrmEntities.AppUsers.FirstOrDefault(_ => _.FirstName == "Admin" && _.LastName == "Office");
                    expense.AgentId = agentData.AppUserId;
                    expense.AgentFullName = $"{agentData.FirstName} {agentData.LastName}";
                }
                expense.SetAsUpdated(user);
                await this.Context.ContractTransactions.UpdateAsync(expense);

                GeneralLedgerEvent glEvent;

                if (!isGLReverse)
                {
                    glEvent = GetGeneralLedgerEventToPay_UCE((ContractTransactionType)expense.ContractTransactionTypeId);
                }
                else
                {
                    glEvent = GetGeneralLedgerEventToReturn_UCE((ContractTransactionType)expense.ContractTransactionTypeId);
                }

                await this.Create_UCE_GeneralLedgerJournalEntryAsync(glEvent, Math.Abs(expense.RequiredAmount.Value), expense, user, null, null,isGLReverse);
                
                await this._payrollService.SynchronizeAgentPayrollLogAsync(expense, user);

                await this.CreateUCEGLLogAsync(new UCEGLLogsDTO { 
                ContractTransactionId = expense.ContractTransactionId,
                CreatedBy = user.GetUserId(),
                CreatedOn = DateTime.Now,
                IsGLConverted = !isGLReverse,
                IsGLReversed = isGLReverse
                });

                this.Context.Commit();

                return expense.RequiredAmount.Value;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public Task<UCEGLLogsDTO> FetchLastLogDetailAsync(int contractTransactionId)
        {
            return this.Context.GeneralLedgers.FetchLastLogDetailAsync(contractTransactionId);
        }

        public async Task Create_UCE_GeneralLedgerJournalEntryAsync(GeneralLedgerEvent generalLedgerEvent, decimal amount, ContractTransactionDto transaction, IPrincipal user, string referenceNumber, int? expenseBatchId,bool isGLReverse)
        {

            List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes = new List<GeneralLedgerTransactionTypeDto>();

            if((int)generalLedgerEvent != (int)GeneralLedgerEvent.Unknown)
            {
                if (!isGLReverse)
                {
                    var data = this._eceCrmEntities.GeneralLedgerTransactionTypes.Where(_=>_.GeneralLedgerTransactionTypeId == 10000 || _.GeneralLedgerTransactionTypeId == 10001).ToList();
                    foreach(var dt in data)
                    {
                        generalLedgerTransactionTypes.Add(new GeneralLedgerTransactionTypeDto
                        {
                            CreditAccountId = dt.CreditAccountId,
                            CreditChangeDirection = Convert.ToChar(dt.CreditChangeDirection),
                            DebitAccountId = dt.DebitAccountId,
                            DebitChangeDirection = Convert.ToChar(dt.DebitChangeDirection),
                            Description = dt.Description,
                            GeneralLedgerEventId = dt.GeneralLedgerEventId,
                            GeneralLedgerTransactionTypeId = dt.GeneralLedgerTransactionTypeId
                        });
                    }
                }
                else
                {
                    var data = this._eceCrmEntities.GeneralLedgerTransactionTypes.Where(_ => _.GeneralLedgerTransactionTypeId == 10002 || _.GeneralLedgerTransactionTypeId == 10003).ToList();
                    foreach (var dt in data)
                    {
                        generalLedgerTransactionTypes.Add(new GeneralLedgerTransactionTypeDto
                        {
                            CreditAccountId = dt.CreditAccountId,
                            CreditChangeDirection = Convert.ToChar(dt.CreditChangeDirection),
                            DebitAccountId = dt.DebitAccountId,
                            DebitChangeDirection = Convert.ToChar(dt.DebitChangeDirection),
                            Description = dt.Description,
                            GeneralLedgerEventId = dt.GeneralLedgerEventId,
                            GeneralLedgerTransactionTypeId = dt.GeneralLedgerTransactionTypeId
                        });
                    }
                }
            }

            else if ((int)generalLedgerEvent == (int)GeneralLedgerEvent.Unknown)
            {
                if (!isGLReverse)
                {
                    var data = this._eceCrmEntities.GeneralLedgerTransactionTypes.Where(_ => _.GeneralLedgerTransactionTypeId == 10004 || _.GeneralLedgerTransactionTypeId == 10005).ToList();
                    foreach (var dt in data)
                    {
                        generalLedgerTransactionTypes.Add(new GeneralLedgerTransactionTypeDto
                        {
                            CreditAccountId = dt.CreditAccountId,
                            CreditChangeDirection = Convert.ToChar(dt.CreditChangeDirection),
                            DebitAccountId = dt.DebitAccountId,
                            DebitChangeDirection = Convert.ToChar(dt.DebitChangeDirection),
                            Description = dt.Description,
                            GeneralLedgerEventId = dt.GeneralLedgerEventId,
                            GeneralLedgerTransactionTypeId = dt.GeneralLedgerTransactionTypeId
                        });
                    }
                }
                else
                {
                    var data = this._eceCrmEntities.GeneralLedgerTransactionTypes.Where(_ => _.GeneralLedgerTransactionTypeId == 10006 || _.GeneralLedgerTransactionTypeId == 10007).ToList();
                    foreach (var dt in data)
                    {
                        generalLedgerTransactionTypes.Add(new GeneralLedgerTransactionTypeDto
                        {
                            CreditAccountId = dt.CreditAccountId,
                            CreditChangeDirection = Convert.ToChar(dt.CreditChangeDirection),
                            DebitAccountId = dt.DebitAccountId,
                            DebitChangeDirection = Convert.ToChar(dt.DebitChangeDirection),
                            Description = dt.Description,
                            GeneralLedgerEventId = dt.GeneralLedgerEventId,
                            GeneralLedgerTransactionTypeId = dt.GeneralLedgerTransactionTypeId
                        });
                    }
                }
            }

            var journalTransactionNumber = this.Context.GeneralLedgers.GetNextJournalTransactionSequenceValue();

            foreach (var gltt in generalLedgerTransactionTypes)
            {
                var debitLedger = new GeneralLedgerJournalDto
                {
                    GeneralLedgerAccountId = gltt.DebitAccountId,
                    AgentId = transaction.AgentId,
                    ChangeDirection = gltt.DebitChangeDirection.ToString(),
                    ChangeType = DebitChangeType.ToString(),
                    ContractId = transaction.ContractId,
                    ContractTransactionId = transaction.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    ContractEntityId = transaction.ContractEntityId,
                    ContractEntityTypeId = transaction.ContractEntityTypeId,
                    PostedDate = DateTime.Now,
                    PostedAmount = amount,
                    OfficeId = transaction.OfficeId,
                    LineOfBusinessId = transaction.LineOfBusinessId,
                    JournalTransactionNumber = journalTransactionNumber,
                    ExpenseBatchId = expenseBatchId,
                    ReferenceNumber = referenceNumber,
                };

                debitLedger.SetAsCreated(user);

                await this.Context.GeneralLedgers.CreateJournalEntryAsync(debitLedger);

                var creditLedger = new GeneralLedgerJournalDto
                {
                    GeneralLedgerAccountId = gltt.CreditAccountId,
                    AgentId = transaction.AgentId,
                    ChangeDirection = gltt.CreditChangeDirection.ToString(),
                    ChangeType = CreditChangeType.ToString(),
                    ContractId = transaction.ContractId,
                    ContractTransactionId = transaction.ContractTransactionId,
                    GeneralLedgerTransactionTypeId = gltt.GeneralLedgerTransactionTypeId,
                    ContractEntityId = transaction.ContractEntityId,
                    ContractEntityTypeId = transaction.ContractEntityTypeId,
                    PostedDate = DateTime.Now,
                    PostedAmount = amount,
                    OfficeId = transaction.OfficeId,
                    LineOfBusinessId = transaction.LineOfBusinessId,
                    JournalTransactionNumber = journalTransactionNumber,
                    ExpenseBatchId = expenseBatchId,
                    ReferenceNumber = referenceNumber,
                };

                creditLedger.SetAsCreated(user);

                await this.Context.GeneralLedgers.CreateJournalEntry_UCE_Async(creditLedger);
            }
        }

        public async Task CreateUCEGLLogAsync(UCEGLLogsDTO logsDTO)
        {
            if (logsDTO == null)
            {
                throw new ArgumentNullException();
            }
            await this.Context.GeneralLedgers.CreateUCEGLLogAsync(logsDTO);
        }

        public static GeneralLedgerEvent GetGeneralLedgerEventToPay_UCE(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.Commission:
                    return GeneralLedgerEvent.EceContractExpensePaid;

                case ContractTransactionType.SharedBonus:
                    return GeneralLedgerEvent.EceSharedBonusPaid;

                case ContractTransactionType.GasCard:
                case ContractTransactionType.ReserveAllowance:
                    return GeneralLedgerEvent.EceGasCardPaid;

                case ContractTransactionType.ContractFee:
                    return GeneralLedgerEvent.EceContractFeePaid;

                case ContractTransactionType.NonExclusiveContractFee:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeePaid;

                case ContractTransactionType.AgentWorking:
                    return GeneralLedgerEvent.ECEAgentWorkingPaid;
                case ContractTransactionType.AR:
                    return GeneralLedgerEvent.ARPaid;
                case ContractTransactionType.UnpaidContractExpenses:
                    return GeneralLedgerEvent.UnpaidContractExpensesPaid;
                default:
                    return GeneralLedgerEvent.Unknown;
            }
        }

        public static GeneralLedgerEvent GetGeneralLedgerEventToReturn_UCE(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.Commission:
                    return GeneralLedgerEvent.ReverseEceContractExpensePaid;

                case ContractTransactionType.SharedBonus:
                    return GeneralLedgerEvent.EceSharedBonusReturned;

                case ContractTransactionType.GasCard:
                case ContractTransactionType.ReserveAllowance:
                    return GeneralLedgerEvent.EceGasCardReturned;

                case ContractTransactionType.ContractFee:
                    return GeneralLedgerEvent.EceContractFeeReturned;

                case ContractTransactionType.NonExclusiveContractFee:
                    return GeneralLedgerEvent.EceNonExclusiveArtistFeeReturned;

                case ContractTransactionType.AgentWorking:
                    return GeneralLedgerEvent.ECEAgentWorkingReturned;

                case ContractTransactionType.AR:
                    return GeneralLedgerEvent.ARReturned;
                case ContractTransactionType.UnpaidContractExpenses:
                    return GeneralLedgerEvent.UnpaidContractExpensesReturned;
                default:
                    return GeneralLedgerEvent.Unknown;
            }
        }
    }
}