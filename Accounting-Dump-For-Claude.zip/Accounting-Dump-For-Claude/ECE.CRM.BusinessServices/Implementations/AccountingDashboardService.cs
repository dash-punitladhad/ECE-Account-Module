﻿namespace ECE.CRM.BusinessServices.Implementations
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class AccountingDashboardService : IAccountingDashboardService
    {
        private readonly IPayrollService _payrollService;

        private readonly IExpenseBatchService _expenseBatchService;

        public AccountingDashboardService(
            IUnitOfWork context,
            IPayrollService payrollService,
            IExpenseBatchService expenseBatchService)
        {
            Context = context;
            _payrollService = payrollService;
            _expenseBatchService = expenseBatchService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<OfficeRevenueDto>> GetOfficeRevenueAsync(int year, int month)
        {
            var monthToQuery = new DateTime(year, month, 1);

            var currentMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            if (monthToQuery > currentMonth)
            {
                return new List<OfficeRevenueDto>();
            }

            return await Context.AccountingDashboard.GetOfficeRevenueAsync(monthToQuery);
        }

        public async Task<ExpenseSummaryDto> GetExpenseSummaryAsync()
        {
            var summary = new ExpenseSummaryDto();

            // ========== Get ExpensesReadyToPay ==========
            var criteria = new ExpenseManagementSearchCriteriaDto();

            criteria.PaymentDateTo = DateTime.Today;
            criteria.Status = (int)ExpenseStatus.ApprovedForPayment;
            criteria.SelectedPayeeTypes = new[]
            {
                (int)ContractEntityType.Other,
                (int)ContractEntityType.Reseller,
                (int)ContractEntityType.Vendor,
                (int)ContractEntityType.Transfer,
            };

            var results = await Context.GeneralLedgers.GetExpenseManagementByCriteriaAsync(criteria);

            summary.OtherExpensesReadyToPay = results.Count;

            // ========== Get EstimatedUpcomingPayroll ==========
            var previewBatch = await _payrollService.CalculateNextPayrollBatchAsync();

            summary.EstimatedUpcomingPayroll = previewBatch.TotalPayrollAmount;

            // ========== Get EstimatedUpcomingArtistPayments ==========
            var upcomingExpenses = await Context.GeneralLedgers.GetUpcomingArtistExpensesAsync(DateTime.Today);

            // Expenses with sufficient escrow and artist that have W-9 on file
            // OriginalRequiredAmount = Escrow Amount
            var eligibleExpenses = upcomingExpenses.Where(x => x.OriginalRequiredAmount > x.DueAmount);

            var existingPayments = Enumerable.Empty<ExpensePaymentDto>();

            var resultingExpenses = await _expenseBatchService.ProcessExpenseBatchAsync(0, eligibleExpenses, existingPayments);

            summary.EstimatedUpcomingArtistPayments = resultingExpenses.Total(x => x.PaymentAmount);

            return summary;
        }

        public async Task<ArtistsMissingW9Dto> GetArtistsMissingW9Async()
        {
            var dto = await Context.Artists.GetArtistsMissingW9Async();

            return dto;
        }

        public async Task<ContractSummaryDto> GetContractSummaryAsync()
        {
            return await Context.AccountingDashboard.GetContractSummaryAsync();
        }
    }
}
