﻿namespace ECE.CRM.BusinessServices
{
    using Dapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Threading.Tasks;
    using System.Linq;

    public class EntityHistoryService : IEntityHistoryService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EntityHistoryService" /> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public EntityHistoryService(IUnitOfWork context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public IUnitOfWork Context { get; private set; }

        public async Task CreateEntityHistoryAsync(EntityHistoryDto history)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.EntityHistory.CreateAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public void CreateEntityHistory(EntityHistoryDto history)
        {
            this.Context.BeginTransaction();

            try
            {
                this.Context.EntityHistory.Create(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<IList<EntityHistoryDto>> GetByEntityAsync(int entityId, EntityType entityType)
        {
            return await this.Context.EntityHistory.GetByEntityAsync(entityId, entityType);
        }

        public async Task<IList<ContractChangesModel>> GetByContractChangesAsync(int contractId)
        {
            List<ContractChangesModel> contractChangesModels = new List<ContractChangesModel>();

            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"contractid",contractId}
                        };
                    DynamicParameters parameters = new DynamicParameters(dictionary);
                    IDbConnection conn = sqlConnectionFactory.CreateConnection();
               var   contractChangesDtos = (await conn.QueryAsync<ContractChangesDto>("Sp_Get_ContractChangeHistoryByContract", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue)).AsList<ContractChangesDto>();
                    if(contractChangesDtos!=null && contractChangesDtos.Count>0)
                    {
                        contractChangesModels = contractChangesDtos.Select(x => new ContractChangesModel() {
                            Name = x.Name,
                            Old=x.Old,
                            New=x.New,
                            Createddate = DateTime.ParseExact(x.Createddate, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture),
                            Createdby=x.Createdby,
                            IsPDFChange=x.IsPDFChange
                        }).ToList();

                    }
                    
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
            catch(Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
                contractChangesModels = new List<ContractChangesModel>();
            }

            return contractChangesModels;
        }
    }
}
