﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using Newtonsoft.Json;
    using System;
    using System.Runtime.Serialization;

    public class NoCommissionProgramException : Exception
    {
        /// <summary>
        /// The default exception message
        /// </summary>
        public const string DefaultExceptionMessage = "No commission program configured for this agent.";

        /// <summary>
        /// The DTO that was used to generate the exception.
        /// </summary>
        private BaseDto _dto = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class.
        /// </summary>
        public NoCommissionProgramException()
            : base(DefaultExceptionMessage)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        public NoCommissionProgramException(BaseDto dto)
            : base(DefaultExceptionMessage)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public NoCommissionProgramException(BaseDto dto, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class
        /// for a specified agent.
        /// </summary>
        /// <param name="agentId">The agent identifier.</param>
        public NoCommissionProgramException(int agentId)
            : base(DefaultExceptionMessage)
        {
            this.Data["AgentId"] = agentId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class
        /// for a specified agent.
        /// </summary>
        /// <param name="agentId">The agent identifier.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public NoCommissionProgramException(int agentId, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this.Data["AgentId"] = agentId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class
        /// with a specified error message.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        public NoCommissionProgramException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class with a
        /// reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public NoCommissionProgramException(Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class with a
        /// specified error message and a reference to the inner exception that
        /// is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public NoCommissionProgramException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="NoCommissionProgramException" /> class with
        /// serialized data.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source or destination.</param>
        public NoCommissionProgramException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        private void SerializeDto()
        {
            if (this._dto == null)
            {
                return;
            }

            var serialized = JsonConvert.SerializeObject(this._dto);

            this.Data["DTO"] = serialized;
        }
    }
}
