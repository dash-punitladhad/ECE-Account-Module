﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistSongService : IArtistSongService
    {
        private readonly IUserService _userService;
        private readonly IArtistService _artistService;
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;

        public ArtistSongService(IUnitOfWork context,
            IUserService userService,
            IArtistService artistService,
            ILookupService lookupService,
            IAlertService alertService)
        {
            this.Context = context;

            this._userService = userService;
            this._artistService = artistService;
            this._lookupService = lookupService;
            this._alertService = alertService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ArtistSongDto>> GetArtistSongsAsync(int artistId)
        {
            return await this.Context.ArtistSongs.GetArtistSongsAsync(artistId);
        }

        public async Task<IList<ArtistSongDto>> GetApprovedArtistSongsAsync(int artistId)
        {
            return await this.Context.ArtistSongs.GetApprovedArtistSongsAsync(artistId);
        }

        public async Task<IList<ArtistSongDto>> GetPendingArtistSongsAsync(int artistId)
        {
            return await this.Context.ArtistSongs.GetPendingArtistSongsAsync(artistId);
        }

        public async Task<ArtistSongDto> GetArtistSongByIdAsync(int artistSongId)
        {
            return await this.Context.ArtistSongs.GetArtistSongByIdAsync(artistSongId);
        }

        public async Task<bool> CanEditAsync(int userId, int artistId)
        {
            var user = await this._userService.GetUserAsync(new AppUserDto { AppUserId = userId }, true);
            var artist = await this._artistService.GetArtistByIdAsync(artistId);

            var freePassRoles = user.Roles.Where(x =>
                x.RoleId == (int)ECERole.LMD ||
                x.RoleId == (int)ECERole.Marketing ||
                x.RoleId == (int)ECERole.ArtistServices);

            if (freePassRoles.Any())
            {
                return true;
            }

            var hasAgentRole = user.Roles.Any(x => x.RoleId == (int)ECERole.Agent);

            if (hasAgentRole)
            {
                if (user.AppUserId == artist.AgentId)
                {
                    return true;
                }
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (artist.AgentId == null)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == artist.AgentId.Value);
            }

            return false;
        }

        public async Task CreateSongAsync(ArtistSongDto song, IPrincipal user)
        {
            song.CreatedById = user.GetUserId();
            song.CreatedDate = DateTime.Now;

            if (user.IsInRole(ECERole.Artist))
            {
                song.IsApproved = false;
            }
            else
            {
                song.IsApproved = true;
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistSongs.CreateAsync(song);

                if (user.IsInRole(ECERole.Artist))
                {
                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ArtistSongListModified);

                    var artist = await this._artistService.GetArtistByIdAsync(song.ArtistId);

                    // Create alert
                    AlertDto alert = new AlertDto
                    {
                        AppUserId = artist.AgentId.Value,
                        Description = appEvent.Text.Replace("{ArtistName}", artist.Name),
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Artist,
                        EntityId = artist.ArtistId,
                        AppEventTypeId = (int)AppEventType.ArtistSongListModified
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task UpdateSongAsync(ArtistSongDto song, IPrincipal user)
        {
            song.UpdatedById = user.GetUserId();
            song.UpdatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistSongs.UpdateAsync(song);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task DeleteSongAsync(ArtistSongDto song, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistSongs.DeleteAsync(song);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task ApproveSongAsync(ArtistSongDto song, IPrincipal user)
        {
            song.UpdatedById = user.GetUserId();
            song.UpdatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistSongs.ApproveAsync(song);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }
    }
}
