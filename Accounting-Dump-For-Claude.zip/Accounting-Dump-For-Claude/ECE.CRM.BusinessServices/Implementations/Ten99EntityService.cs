﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class Ten99EntityService : ITen99EntityService
    {
        public Ten99EntityService(IUnitOfWork context)
        {
            Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<Ten99EntityDto> GetByIdAsync(ContractEntityType entityType, int entityId)
        {
            return await Context.Ten99Entities.GetByIdAsync(entityType, entityId);
        }

        public async Task<Ten99EntityDto> GetUnofficialByIdAsync(int year, ContractEntityType entityType, int entityId)
        {
            return await Context.Ten99Entities.GetUnofficialByIdAsync(year, entityType, entityId);
        }

        public async Task<IList<Ten99SearchResultDto>> GetByCriteriaAsync(Ten99SearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            SecurityHelper.EncryptFederalTINCriteria(criteria);

            return await Context.Ten99Entities.GetByCriteriaAsync(criteria);
        }

        public async Task<IList<PaymentTransactionDto>> GetExpensePaymentTransactionsAsync(int year, int entityTypeId, int entityId)
        {
            var list = new List<PaymentTransactionDto>();

            var transactions = await Context.Ten99Entities.GetTransactionsForYearAsync(year, entityTypeId, entityId);

            var transactionGroups = transactions.GroupBy(x => x.ExpensePaymentId);

            var crossDeductionDeposits = await Context.Ten99Entities.GetCrossDeductionsForYearAsync(year, entityTypeId, entityId);

            var crossDeductionDepositsGroups = crossDeductionDeposits.GroupBy(x => x.ExpensePaymentId);

            var loanRepayments = await Context.Ten99Entities.GetLoanRepaymentsForYearAsync(year, entityTypeId, entityId);

            var loanRepaymentGroups = loanRepayments.GroupBy(x => x.ExpensePaymentId);

            foreach (var transactionGroup in transactionGroups)
            {
                var paymentTransactions = transactionGroup
                    .OrderBy(x => x.ContractId)
                    .ThenBy(x => x.DueDate)
                    .ThenBy(x => x.ContractTransactionTypeId)
                    .ThenBy(x => x.TransactionId)
                    .ToList();

                // Find matching loan repayments
                var loanRepaymentGroup = loanRepaymentGroups.FirstOrDefault(x => x.Key == transactionGroup.Key);
                if (loanRepaymentGroup != null)
                {
                    var loanRepaymentTransactions = loanRepaymentGroup.ToList();

                    // Insert the loan repayments immediately after the first transaction in the payment.
                    for (int i = 0; i < loanRepaymentTransactions.Count; i++)
                    {
                        paymentTransactions.Insert(1 + i, loanRepaymentTransactions[i]);
                    }
                }

                // Find matching cross deductions
                var crossDeductionDepositsGroup = crossDeductionDepositsGroups.FirstOrDefault(x => x.Key == transactionGroup.Key);
                if (crossDeductionDepositsGroup != null)
                {
                    var crossDeductionTransactions = crossDeductionDepositsGroup.ToList();

                    for (int i = 0; i < crossDeductionTransactions.Count; i++)
                    {
                        paymentTransactions.Add(crossDeductionTransactions[i]);
                    }
                }

                list.AddRange(paymentTransactions);
            }

            var sortIndex = 0;

            foreach (var item in list)
            {
                // Set all income records (deposits & loan repayments) as negative amounts
                if (item.IsIncome)
                {
                    item.RequiredAmount = item.RequiredAmount * decimal.MinusOne;
                }

                // Set the sort index to allow the UI to sort using multiple properties.
                item.SortIndex = sortIndex++;
            }

            return list;
        }
    }
}
