namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataAccess.Utilities;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.DataTransferObjects.ContractDetails;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.EntityFramework;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.IO;
    using System.Linq;
    using System.Net.Mail;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web;

    public class ContractService : IContractService
    {
        public const int CancellationNoteMaxLength = 3000;

        public static readonly decimal EceCancelFeeAmount = 50m;

        public static readonly decimal ContractFeeAmount = 50m;

        public static readonly decimal NonExclusiveContractFeeAmount = 50m;

        public static readonly int MonthsPresenterPortalLinkExpiresIn = 6;

        public static readonly ECERole[] RolesAllowedAccessToNationalContracts = new ECERole[]
        {
            ECERole.LMD,
            ECERole.Nationals,
            ECERole.Accounting,
            ECERole.AccountingAdmin,
        };

        private readonly IAlertService _alertService;
        private readonly IArtistService _artistService;
        private readonly IBlueCardService _blueCardService;
        private readonly IContactService _contactService;
        private readonly IContractArtistService _contractArtistService;
        private readonly IContractArtistEventDateService _contractArtistEventDateService;
        private readonly IContractCancellationService _contractCancellationService;
        private readonly IContractEventDateService _contractEventDateService;
        private readonly IContractTermService _contractTermsService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly ILookupService _lookupService;
        private readonly IPresenterService _presenterService;
        private readonly IVenueService _venueService;
        private readonly ICommunicationLogService _communicationLogService;
        private readonly IVendorService _vendorService;
        private readonly IResellerService _resellerService;
        private readonly IDocumentService _documentService;
        private readonly IContractDocumentService _contractDocumentService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IReminderService _reminderService;
        private readonly IEceCrmEntities _iEceCrmEntities;
        private readonly IUserService _userService;
        private readonly IPayrollService _payrollService;
        private readonly IPandaDocService _pandaDocService;
        private readonly IMessageService _messageService;
        private readonly IContractChangeNoteHistoryService _contractChangeNoteHistoryService;
        public ContractService(
            IUnitOfWork context,
            IAlertService alertService = null,
            IArtistService artistService = null,
            IBlueCardService blueCardService = null,
            IContactService contactService = null,
            IContractArtistService contractArtistService = null,
            IContractArtistEventDateService contractArtistEventDateService = null,
            IContractCancellationService contractCancellationService = null,
            IContractEventDateService contractEventDateService = null,
            IContractTermService contractTermsService = null,
            IContractTransactionService contractTransactionService = null,
            IGeneralLedgerService generalLedgerService = null,
            ILookupService lookupService = null,
            IPresenterService presenterService = null,
            IVenueService venueService = null,
            ICommunicationLogService communicationLogService = null,
            IVendorService vendorService = null,
            IResellerService resellerService = null,
            IDocumentService documentService = null,
            IContractDocumentService contractDocumentService = null,
            IEntityHistoryService entityHistoryService = null,
            IReminderService reminderService = null,
            IEceCrmEntities iEceCrmEntities = null,
            IUserService userService = null,
            IPayrollService payrollService = null,
            IPandaDocService pandaDocService = null,
            IMessageService messageService = null,
            IContractChangeNoteHistoryService contractChangeNoteHistoryService = null
            )
        {
            this.Context = context;
            this._alertService = alertService;
            this._artistService = artistService;
            this._blueCardService = blueCardService;
            this._contactService = contactService;
            this._contractArtistService = contractArtistService;
            this._contractCancellationService = contractCancellationService;
            this._contractEventDateService = contractEventDateService;
            this._contractTermsService = contractTermsService;
            this._contractTransactionService = contractTransactionService;
            this._lookupService = lookupService;
            this._communicationLogService = communicationLogService;
            this._contractArtistEventDateService = contractArtistEventDateService;
            this._generalLedgerService = generalLedgerService;
            this._lookupService = lookupService;
            this._presenterService = presenterService;
            this._venueService = venueService;
            this._vendorService = vendorService;
            this._resellerService = resellerService;
            this._documentService = documentService;
            this._contractDocumentService = contractDocumentService;
            this._entityHistoryService = entityHistoryService;
            this._reminderService = reminderService;
            this._iEceCrmEntities = iEceCrmEntities;
            this._userService = userService;
            this._payrollService = payrollService;
            this._pandaDocService = pandaDocService;
            this._messageService = messageService;
            this._contractChangeNoteHistoryService = contractChangeNoteHistoryService;
        }

        public IUnitOfWork Context { get; private set; }

        public decimal GetRequiredAmount(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.ContractFee:
                    return ContractFeeAmount;

                case ContractTransactionType.NonExclusiveContractFee:
                    return NonExclusiveContractFeeAmount;

                case ContractTransactionType.EceCancelFee:
                    return EceCancelFeeAmount;

                default:
                    return decimal.Zero;
            }
        }

        public ContractTransactionDto CreateECEExpense(ContractDto contract, ContractTransactionType contractTransactionType)
        {
            var transactionViewModel = new ContractTransactionDto()
            {
                ContractId = contract.ContractId,
                AgentId = contract.AgentId,
                ContractEntityId = 0,
                ContractEntityTypeId = (int)ContractEntityType.ECE,
                PayeeName = "ECE-OTHER",
                ContractTransactionTypeId = (int)contractTransactionType,
                RequiredAmount = this.GetRequiredAmount(contractTransactionType),
                PaidAmount = decimal.Zero
            };

            switch (contractTransactionType)
            {
                case ContractTransactionType.ContractFee:
                    transactionViewModel.ContractTransactionTypeName = "CONTRACT FEE";
                    transactionViewModel.DueDate = DateTime.Today.AddDays(14);

                    return transactionViewModel;

                case ContractTransactionType.NonExclusiveContractFee:
                    transactionViewModel.ContractTransactionTypeName = "CONT FEE NON-EX";
                    transactionViewModel.DueDate = DateTime.Today.AddDays(14);

                    return transactionViewModel;
                case ContractTransactionType.AR:
                    transactionViewModel.ContractTransactionTypeName = "AR";
                    transactionViewModel.DueDate = DateTime.Today.AddDays(14);

                    return transactionViewModel;

                default:
                    return null;
            }
        }

        public ContractTransactionDto CreateCommission(int appUserId, decimal? percentage)
        {
            return new ContractTransactionDto()
            {
                AgentId = appUserId,
                RequiredPercentage = percentage ?? 100m
            };
        }

        public Task<IEnumerable<ContractDto>> GetByAgentIdAsync(int agentId)
        {
            throw new NotImplementedException();
        }

        public async Task<ContractDto> GetByIdAsync(int id, bool includeChildren = false)
        {
            if (id <= 0)
            {
                throw new ArgumentNullException(nameof(id));
            }

            var dto = await this.Context.Contracts.GetByIdAsync(id);
            if (dto != null && (dto.EventTypeId != null || dto.EventTypeId > 0))
            {
                var eventType = this._iEceCrmEntities.LuEventTypes.FirstOrDefault(a => a.EventTypeId == dto.EventTypeId.Value);
                if (eventType != null)
                {
                    dto.EventTypeName = eventType.Name;
                }
            }

            if (includeChildren && dto != null)
            {
                var eventDates = await this.Context.ContractEventDates.GetByContractIdAsync(id);

                dto.EventDatesObject = eventDates;

                dto.ContractArtists = await this.Context.ContractArtists.GetByContractIdAsync(id);

                dto.ContractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(dto.ContractId);

                dto.ContractTerms = await this.Context.ContractTerms.GetByContractIdAsync(dto.ContractId, true);

                if (dto.LineOfBusinessId != null)
                {
                    dto.LineOfBusiness = await this.Context.Contracts.GetLineOfBusinessAsync(dto.LineOfBusinessId.Value);
                }

                if (dto.LeadSourceId != null)
                {
                    dto.LeadSource = await this.Context.Contracts.GetLeadSourceAsync(dto.LeadSourceId.Value);
                }

                if (dto.ResellerId != null && dto.IsReseller.Value)
                {
                    dto.Reseller = await this.Context.Resellers.GetByIdAsync(dto.ResellerId.Value);
                }

                dto.SignatureProgress = await this.Context.Signatures.GetSignatoriesByContractAsync(dto);

                var dates = await this.Context.ContractArtistEventDates.GetByContractIdAsync(dto.ContractId);

                // Get event dates and time zone for each contract artist
                foreach (var contractArtist in dto.ContractArtists)
                {
                    var artistEventDates = dates.Where(x => x.ContractArtistId == contractArtist.ContractArtistId);
                    contractArtist.ArtistEventDates = artistEventDates.ToList();
                    contractArtist.ContractId = dto.ContractId;
                }

                dto.ChildrenIncluded = true;
            }

            return dto;
        }

        public async Task<IEnumerable<ContractSearchResultDto>> GetByCriteriaAsync(ContractSearchCriteriaDto criteria)
        {
            var results = await this.Context.Contracts.GetByCriteriaAsync(criteria);

            return results;
        }
        public async Task<string> GetByCriteriaExportAsync(ContractSearchCriteriaDto criteria)
        {
            var results = await this.Context.Contracts.GetByCriteriaExportAsync(criteria);

            return results;
        }

        public async Task<ContractSearchResultDetailDto> GetContractSearchDetailAsync(int id)
        {
            var results = await this.Context.Contracts.GetContractSearchDetailAsync(id);

            results.Artists = results.Artists.OrderBy(x => x.Name).ToList();

            return results;
        }

        public async Task CreateAsync(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                dto.SetAsCreated(user);

                await this.Context.Contracts.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ContractDto> CreateFromBlueCardAsync(int blueCardId, IPrincipal user)
        {
            var blueCard = await this._blueCardService.GetBlueCardByIdAsync(blueCardId);

            if (blueCard == null)
            {
                throw new UnhandledBusinessException(EntityType.BlueCard, blueCardId);
            }

            blueCard.BlueCardArtists = await this._blueCardService.GetBlueCardArtistsAsync(blueCardId);

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var dto = new ContractDto();

            try
            {
                dto.IsInProgress = true;
                dto.ContractStatusId = (int)ContractStatus.InProgress;
                var contractContacts = new List<ContactDto>();

                var blueCardContacts = _contactService.GetContacts(EntityType.BlueCard, blueCardId);
                var blueCardEventDates = blueCard.EventDates;

                if (blueCard.VenueId.HasValue)
                {
                    var venue = await this._venueService.GetVenueByIdAsync(blueCard.VenueId.Value, true);
                    dto.LoadFromBlueCard(blueCard, blueCard.AgentId, venue);
                }
                else
                {
                    dto.LoadFromBlueCard(blueCard, blueCard.AgentId);
                }

                if (blueCard.PresenterId.HasValue)
                {
                    // Map the properties not found on the Blue Card
                    var presenter = await this._presenterService.GetPresenterByIdAsync(blueCard.PresenterId.Value, false);
                    dto.PresenterTypeId = presenter.PresenterTypeId;
                }

                dto.SetAsCreated(user);

                await this.Context.Contracts.CreateAsync(dto);

                if (blueCardContacts != null && blueCardContacts.Any())
                {
                    foreach (var bcc in blueCardContacts)
                    {
                        bcc.ContactId = 0;
                        bcc.EntityId = dto.ContractId;
                        bcc.EntityTypeId = (int)EntityType.Contract;
                        contractContacts.Add(bcc);
                    }

                    this._contactService.SyncContacts(EntityType.Contract, dto.ContractId, contractContacts, user);
                }

                if (blueCardEventDates != null && blueCardEventDates.Any())
                {
                    foreach (var bced in blueCardEventDates)
                    {
                        var contractEventDate =
                            new ContractEventDateDto() { ContractId = dto.ContractId, EventDate = bced };

                        await _contractEventDateService.CreateAsync(contractEventDate);
                    }
                }

                await this._blueCardService.ToggleBlueCardStatusAsync(
                    blueCard.BlueCardId,
                    true,
                    user.GetUserId(),
                    (int)BlueCardClosedReason.Contract);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }

            return dto;
        }

        public async Task<ContractDto> CreateFromPresenterAsync(int presenterId, IPrincipal user)
        {
            var presenter = await this._presenterService.GetPresenterByIdAsync(presenterId, true);

            if (presenter == null)
            {
                throw new UnhandledBusinessException(EntityType.Presenter, presenterId);
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var dto = new ContractDto();
            this.Context.BeginTransaction();
            try
            {
                dto.IsInProgress = true;
                dto.ContractStatusId = (int)ContractStatus.InProgress;
                var contractContacts = new List<ContactDto>();

                dto.LoadFromPresenter(presenter, presenter.AgentId);

                var presenterContacts = presenter.Contacts;

                dto.SetAsCreated(user);

                await this.Context.Contracts.CreateAsync(dto);

                if (presenterContacts != null && presenterContacts.Any())
                {
                    foreach (var pc in presenterContacts)
                    {
                        pc.EntityId = dto.ContractId;
                        pc.EntityTypeId = (int)EntityType.Contract;
                        contractContacts.Add(pc);
                    }

                    this._contactService.SyncContacts(EntityType.Contract, dto.ContractId, contractContacts, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }

            return dto;
        }

        public async Task UpdateAsync(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);
                await this.Context.Contracts.UpdateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task<PresenterPortalDto> CreatePresenterPortalAsync(ContractDto contract, IPrincipal user)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var urlKey = SecurityHelper.GeneratePasswordToken();

                var lastEventDate = new ContractEventDateDto
                {
                    EventDate = DateTime.Now
                };

                if (contract.EventDatesObject != null)
                {
                    lastEventDate = contract.EventDatesObject.OrderByDescending(x => x.EventDate).FirstOrDefault();
                }

                var portalDto = new PresenterPortalDto
                {
                    PresenterId = contract.PresenterId,
                    ContractId = contract.ContractId,
                    UrlKey = urlKey,
                    ExpirationDate = lastEventDate == null ? DateTime.Now.AddMonths(MonthsPresenterPortalLinkExpiresIn) : lastEventDate.EventDate.AddMonths(MonthsPresenterPortalLinkExpiresIn)
                };

                portalDto.SetAsCreated(user);

                await this.Context.Contracts.CreatePresenterPortalAsync(portalDto);

                this.Context.Commit();

                return portalDto;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }
        public async Task<PresenterPortalDto> GetPresenterPortalAsync(int contractId)
        {
            return await this.Context.Contracts.GetPresenterPortalForContractAsync(contractId);
        }

        public async Task InitializeAsync(int id, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contract = await this.GetByIdAsync(id, true);
                if (contract == null)
                {
                    throw new ArgumentException($"Contract {id} not found.");
                }

                if (contract.ContractStatusId != (int)ContractStatus.Created &&
                    contract.ContractStatusId != (int)ContractStatus.PartiallyCanceled &&
                    contract.ContractStatusId != (int)ContractStatus.Canceled)
                {
                    throw new ArgumentException($"Contract {id} has already been initalized.");
                }

                if (await _generalLedgerService.ContractIsInitializedAsync(contract.ContractId))
                {
                    throw new ArgumentException($"Contract {id} has already been initalized.");
                }

                // Create GL journal entries for deposit income records.
                foreach (var transaction in contract.ContractTransactions)
                {
                    if (transaction.IsIncome && transaction.RequiredAmount != decimal.Zero)
                    {
                        transaction.ParentContract = contract;

                        await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ContractIncomeAdded, transaction.RequiredAmount ?? decimal.Zero, transaction, user);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IssueContractResponseDto> IssueAsync(IssueContractDto dto, IPrincipal user, bool isPandadoc = false)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            IssueContractResponseDto issueContractResponse = new IssueContractResponseDto();
            issueContractResponse.IsValid = true;
            try
            {
                this.Context.BeginTransaction();

                var contract = await this.GetByIdAsync(dto.ContractId, true);

                var agents = _lookupService.GetAllAgents();
                var agent = agents.FirstOrDefault(x => x.AppUserId == contract.AgentId);

                if (contract == null)
                {
                    throw new ArgumentException($"Contract {dto.ContractId} not found.");
                }

                // Ensure only one presenter portal key is created for each contract
                var portalDto = await this.Context.Contracts.GetPresenterPortalForContractAsync(dto.ContractId);

                if (portalDto == null)
                {
                    portalDto = await this.CreatePresenterPortalAsync(contract, user);
                }

                // Begin send email
                var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
                var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.IssueContract);

                var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);
                var commLogs = new List<CommunicationLogDto>();

                string appName = MobiusConfiguration.GetString("Application.Name");

                string url = string.Format(
                    "{0}{1}{2}",
                    MobiusConfiguration.GetString("Application.Url"),
                    MobiusConfiguration.GetString("Application.EventDetailsUrl"),
                    portalDto.UrlKey);



                //if (isPandadoc)
                //{
                //    string pandadocSignUrl = string.Format(
                // "{0}contract/viewsignpandadoc/{1}?id={2}",
                // MobiusConfiguration.GetString("Application.Url"),
                //portalDto.UrlKey,
                // portalDto.ContractId);
                //    string pandadocSignlinkHtml = "<a target='_blank'  href='" + pandadocSignUrl + "'>View/Sign Contract</a>";
                //    if (!string.IsNullOrWhiteSpace(dto.Body))
                //    {
                //        dto.Body += "<br><br>" + pandadocSignlinkHtml + "<br><br>";
                //    }

                //}

                var defaultSubject = bodyTemplate.Subject.Replace("{AppName}", appName);

                var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                var body = bodyBuilder
                    .Replace("{AgentEmailAddress}", agent == null ? string.Empty : agent.Username)
                    .Replace("{Year}", DateTime.Now.Year.ToString())
                    .Replace("{Body}", bodyTemplate.Body)
                    .Replace("{BodyInput}", dto.Body)
                    .Replace("{Url}", url)
                    .Replace("{AppName}", appName)
                    .Replace("{Subject}", defaultSubject)
                    .Replace("''", "'")
                    .ToString();


                //if (isPandadoc)
                //{
                //    bodyBuilder = new StringBuilder(dto.Body);
                //    body = bodyBuilder.ToString();

                //}

                if (dto.Subject == string.Empty)
                {
                    email.Subject = defaultSubject;
                }
                else
                {
                    email.Subject = $"{dto.Subject}";
                }

                email.Body = body;
                email.IsBodyHtml = bodyTemplate.IsHtml;

                contract.Contacts = this._contactService.GetContacts(EntityType.Contract, dto.ContractId);

                foreach (var c in dto.Contacts)
                {
                    var contact = contract.Contacts.Where(x => x.ContactId == c).FirstOrDefault();
                    if (contact == null)
                    {
                        throw new ArgumentException($"ContactId {c} not found.");
                    }

                    if (!string.IsNullOrWhiteSpace(contact.EmailAddress))
                    {
                        email.AddRecipient(contact);

                        var notes = contract.ContractStatusId == (int)ContractStatus.Created
                            ? "Issued Contract"
                            : contract.IsPandaDoc ? "Re-issue Pandadoc Contract" : "Resent Portal Link";

                        var commLog = new CommunicationLogDto
                        {
                            CommunicationMethodId = (int)CommunicationMethod.Email,
                            ContactId = contact.ContactId,
                            EntityId = dto.ContractId,
                            EntityTypeId = (int)EntityType.Contract,
                            LogDate = DateTime.Now,
                            LogTime = DateTime.Now.ToShortTimeString(),
                            Notes = notes
                        };

                        _communicationLogService.AddCommunicationLog(commLog, user);

                        commLogs.Add(commLog);
                    }
                }

                // if the contract isn't in the 'created' status, we don't perform any data changes - we're only sending an email to the relevant contacts.
                if (contract.ContractStatusId == (int)ContractStatus.Created)
                {
                    var contractIsInitialized = await _generalLedgerService.ContractIsInitializedAsync(contract.ContractId);
                    contract.ContractStatusId = (int)ContractStatus.Issued;
                    contract.IssueDate = DateTime.Today;
                    contract.ContractDueDate = dto.DueDate;

                    await this.UpdateAsync(contract, user);
                    var signature = new ContractSignatureDto
                    {
                        ContractId = contract.ContractId,
                        DueDate = contract.ContractDueDate,
                        EntityId = (int)contract.PresenterId,
                        EntityTypeId = (int)EntityType.Presenter,
                        IsReceived = false
                    };

                    signature.SetAsCreated(user.GetUserId());

                    await this.Context.ContractSignatures.CreateAsync(signature);

                    if (contractIsInitialized == false)
                    {
                        // Create GL journal entries for deposit income records.
                        foreach (var transaction in contract.ContractTransactions)
                        {
                            transaction.ParentContract = contract;

                            var amount = transaction.RequiredAmount.GetValueOrDefault();

                            if (this.MustMaintainGLForIncomeTransaction(transaction, true) && amount != decimal.Zero)
                            {
                                GeneralLedgerEvent glEvent;

                                if (amount < decimal.Zero)
                                {
                                    glEvent = GeneralLedgerEvent.ContractIncomeDecreased;
                                }
                                else
                                {
                                    glEvent = GeneralLedgerEvent.ContractIncomeAdded;
                                }

                                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(glEvent, Math.Abs(amount), transaction, user);
                            }
                        }
                    }

                    // Audit contract event
                    var history = new EntityHistoryDto
                    {
                        EntityId = dto.ContractId,
                        Type = EntityType.Contract,
                        Event = AuditEvent.ContractIssued,
                        Description = "--",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);

                    // Should be 9 AM five days prior to due date.
                    var remindOnDate = contract.ContractDueDate.Value.AddDays(-5).AddHours(9);

                    var reminder = new ReminderDto
                    {
                        AppUserId = contract.AgentId,
                        Description = $"Follow up on contract signature and deposit for {contract.PresenterAccountName}.",
                        RemindOn = remindOnDate,
                        EntityId = (int)contract.ContractId,
                        EntityTypeId = (int)EntityType.Contract,
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    this._reminderService.AddReminder(reminder);
                }
                else
                {
                    if (contract.IsPandaDoc)
                    {
                        if (contract.ContractStatusId == (int)ContractStatus.Canceled || contract.ContractStatusId == (int)ContractStatus.PartiallyCanceled)
                        {
                            throw new Exception("The contract has already been cancelled or partially cancelled.");
                        }
                        contract.ContractStatusId = (int)ContractStatus.ReIssue;
                        contract.ReIssueDate = DateTime.Today;
                        await this.UpdateAsync(contract, user);
                    }
                }

                if (contract.IsPandaDoc && (contract.ContractStatusId == (int)ContractStatus.Issued || contract.ContractStatusId == (int)ContractStatus.ReIssue))
                {

                    ContractChangeNoteHistoryDto contractChangeNoteHistoryDto = new ContractChangeNoteHistoryDto();
                    contractChangeNoteHistoryDto.ContractId = contract.ContractId;
                    contractChangeNoteHistoryDto.ContractStatusId = contract.ContractStatusId;
                    contractChangeNoteHistoryDto.ChangeNote = contract.ChangesNote;
                    contractChangeNoteHistoryDto.StatusChangedDate = DateTime.Today;
                    contractChangeNoteHistoryDto.CreatedById = user.GetUserId();
                    contractChangeNoteHistoryDto.CreatedDate = TimeProvider.Current.Now;
                    await this._contractChangeNoteHistoryService.CreateAsync(contractChangeNoteHistoryDto);
                }


                this.Context.Commit();

                if (agent != null)
                {
                    if (TextHelper.IsValidEmail(agent.Username))
                    {
                        email.SetFrom(agent.Username, agent.FullName);
                    }
                }

                // Override agent's email address with the no-reply email address
                // We need to leave the call in to get the agent's email address because we'll add it
                // the email body in the future.
                if (MobiusConfiguration.GetBoolean("Email.UseNoReply"))
                {
                    var noReplyEmailAddress = MobiusConfiguration.GetString("Email.FromAddress");
                    var noReplyEmailName = MobiusConfiguration.GetString("Email.FromName");

                    email.SetFrom(noReplyEmailAddress, noReplyEmailName);
                }

                if (email.HasRecipient)
                {
                    if (dto.UploadedFiles != null)
                    {
                        foreach (var attch in dto.UploadedFiles)
                        {
                            if (attch.ContentLength > 0)
                            {
                                Attachment attachment = new Attachment(attch.InputStream, attch.FileName);

                                email.Attachments.Add(attachment);
                            }
                        }
                    }

                    var smtpManager = new SmtpManager(this.Context);

                    if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                    {
                        smtpManager.SendMessage(email, agent.AppUserId.Value, SendMessageMode.Queued, "contractissue", dto.AttachmentFileNames);
                    }

                    foreach (var commLog in commLogs)
                    {
                        commLog.EmailQueueId = email.EmailQueueId ?? null;

                        await this._communicationLogService.UpdateAsync(commLog);
                    }
                }
                // tuple = new Tuple<bool, string, string>(true, email.Subject, email.Body);
                // Note: Sending of artist emails (green card) has been moved to a separate method
                // End send email
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                issueContractResponse.IsValid = false;
                issueContractResponse.Message = ex.Message;
                await Helper.LogError("Error", ex);
                //throw new UnhandledBusinessException(ex);
            }

            return issueContractResponse;
        }

        public async Task<ContractDto> GetContractByUrlKeyAsync(string key, bool includeChildren = true)
        {
            var presenterPortal = await this.Context.Contracts.GetContractByUrlKeyAsync(key);
            if (presenterPortal == null)
            {
                return null;
            }

            var contract = await this.GetByIdAsync(presenterPortal.ContractId, includeChildren);
            if (contract != null)
            {
                contract.PresenterPortalId = presenterPortal.PresenterPortalId;
            }

            return contract;
        }

        public async Task<bool> CanViewAsync(ContractDto contract, IPrincipal user)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var canView = true;

            if (contract.LineOfBusinessId == (int)LineOfBusiness.National)
            {
                if (user.GetUserId() != contract.AgentId)
                {
                    canView = false;

                    // users who are not the contract's Responsible Agent must have one of the following roles
                    // to view National Line Of Business Contracts
                    var hasAtLeastOneRole = RolesAllowedAccessToNationalContracts.Any(x => user.IsInRole(x));
                    if (hasAtLeastOneRole)
                    {
                        canView = true;
                    }

                    if (canView == false && user.IsInRole(ECERole.Assistant))
                    {
                        // An assistant can view contracts 'owned' by agents in the same office as the assistant.
                        var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                        canView = agentsInSameOffices.Any(x => x.AppUserId == contract.AgentId);
                    }
                }
            }

            if (user.GetUserId() == -1)
            {
                canView = true;
            }

            return canView;
        }

        public async Task<bool> CheckCanEditAsync(int contractId, int userId)
        {
            var contract = await this.GetByIdAsync(contractId);
            if (contract == null)
            {
                throw new UnhandledBusinessException(EntityType.Contract, contractId);
            }

            return contract.AgentId == userId;
        }

        public bool HasEditPermission(int agentId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (agentId == user.GetUserId() || user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Assistant))
            {
                return true;
            }

            return false;
        }

        public bool CanModifyContractFees(IPrincipal user)
        {
            /*
             * Issue ECE-3305:
             * With regards to our contract fees (Shared Bonus, Reserve Allowance and Contract Fee for exclusives,
             * Contract Fee for non-exclusives), those should not be something that agents have the ability to
             * cancel out in the contract entry phase, but rather be required to send a Contract Message to
             * Lydia, copying the LMD, to have those waived fees be approved by the LMD.
             */

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            else if (user.IsInRole(ECERole.LMD) || user.IsInRole(ECERole.Owner) || user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting) || user.IsInRole(ECERole.DOAS))
            {
                return true;
            }
            //if (user.IsInRole(ECERole.LMD) || user.IsInRole(ECERole.Owner))
            //{
            //    // Allow LMD users or Owner users to change the fees.
            //    return true;
            //}

            //if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            //{
            //    // Allow accounting or accounting admin users to change fees.
            //    return true;
            //}

            return false;
        }

        public async Task<bool> HasEditableStatusAsync(ContractDto dto, int userId)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (dto.ContractStatusId == (int)ContractStatus.Created || dto.ContractStatusId == (int)ContractStatus.Issued || dto.ContractStatusId == (int)ContractStatus.ReIssue)
            {
                if (dto.SignatureProgress == null)
                {
                    dto.SignatureProgress = await this.Context.Signatures.GetSignatoriesByContractAsync(dto);
                }

                // Only permit edits if no received signatures exist
                if (!dto.SignatureProgress.Any(x => x.SignatureReceived.HasValue))
                {
                    return true;
                }
            }

            if (dto.ContractStatusId == (int)ContractStatus.InProgress)
            {
                return true;
            }

            if (dto.IsPandaDoc && dto.AgentId == userId)
            {
                return true;
            }
            return false;
        }

        public bool HasEditableStatus(ContractDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (dto.ContractStatusId == (int)ContractStatus.Created || dto.ContractStatusId == (int)ContractStatus.Issued || dto.ContractStatusId == (int)ContractStatus.ReIssue)
            {
                return true;
            }

            return false;
        }

        public bool CanUpdateGross(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            // Accounting users can always update the gross
            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                return true;
            }

            // Booking agents can update the gross on Backend Deal contracts
            if (dto.IsBackendDeal == true && dto.AgentId == user.GetUserId())
            {
                return true;
            }

            return false;
        }

        public bool CanUpdateOriginalGross(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            // Accounting users can always update the original gross
            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                return true;
            }

            return false;
        }

        public bool CanFullyCancel(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (dto.ContractStatusId != (int)ContractStatus.PartiallyCanceled)
            {
                return false;
            }

            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                return true;
            }

            return false;
        }

        public bool CanRequestCancellation(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (dto.ContractStatusId == (int)ContractStatus.PartiallyCanceled ||
                dto.ContractStatusId == (int)ContractStatus.Canceled)
            {
                // Can't request cancellation of contracts that are cancelled.
                return false;
            }

            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                // Accounting department users can request cancellation
                return true;
            }

            if (dto.AgentId == user.GetUserId())
            {
                // The booking agent can request cancellation
                return true;
            }

            return false;
        }

        public bool CanReinstate(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (dto.ContractStatusId != (int)ContractStatus.PartiallyCanceled &&
                dto.ContractStatusId != (int)ContractStatus.Canceled)
            {
                // Can't reinstate contracts that aren't cancelled.
                return false;
            }

            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                // Accounting department users can reinstate contracts at any time
                return true;
            }

            return false;
        }

        public async Task<bool> CanViewDepositsAsync(ContractDto contract, IPrincipal user)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (user.IsInRole(ECERole.Accounting) ||
                user.IsInRole(ECERole.AccountingAdmin) ||
                user.IsInRole(ECERole.Owner) ||
                user.IsInRole(ECERole.Assistant)
                ) 
            {
                return true;
            }

            var canView = true;

            if (user.GetUserId() != contract.AgentId)
            {
                canView = false;

                if (user.IsInRole(ECERole.Assistant))
                {
                    // An assistant can view contracts 'owned' by agents in the same office as the assistant.
                    var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                    canView = agentsInSameOffices.Any(x => x.AppUserId == contract.AgentId);
                }

                if (canView == false && user.IsInRole(ECERole.LMD))
                {
                    // An LMD can view contracts 'owned' by agents in the same office as the LMD.
                    var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.LMD);
                    canView = agentsInSameOffices.Any(x => x.AppUserId == contract.AgentId);
                }
            }

            return canView;
        }


        public async Task<(bool, bool)> CanViewAgentPayHistoryAsync(ContractDto contract, IPrincipal user)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (user.IsInRole(ECERole.Accounting) ||
                user.IsInRole(ECERole.AccountingAdmin) ||
                user.IsInRole(ECERole.Owner) || user.IsInRole(ECERole.SysAdmin))
            {
                return (true, true);
            }

            var isLMDValid = false;

            if (user.IsInRole(ECERole.LMD))
            {
                var officelist = await _userService.GetOfficesForUser(user.GetUserId(), (int)ECERole.LMD);

                var roleId = (int)ECERole.Agent;
                var officeIdsForUser = officelist.Select(x => (int?)x.OfficeId).ToList();
                var results = await (from u in this._iEceCrmEntities.AppUsers
                                     join aur in this._iEceCrmEntities.AppUserRoles on u.AppUserId equals aur.AppUserId
                                     where !aur.IsDeleted
                                     && aur.RoleId == roleId
                                     && officeIdsForUser.Contains(aur.OfficeId)
                                     orderby u.FirstName, u.LastName
                                     select u
                            )
                          .Distinct()
                          .ToListAsync();

                var lmdAgents = results.Select(x => x.AppUserId).ToList();

                isLMDValid = lmdAgents.Contains(contract.AgentId) || officeIdsForUser.Contains(contract.OfficeId);
                //return (result, true);
            }

            if (isLMDValid)
            {
                return (isLMDValid, true);
            }

            var canView = false;

            if (user.GetUserId() > 0)
            {
                var result = false;
                try
                {
                    var userId = user.GetUserId();
                    var logs = await this._payrollService.GetAgentPayrollLogsByContractIdAsync(contract.ContractId);
                    var PayrollLogTypeId = (int)PayrollLogType.AgentCommission;



                    if (logs != null && logs.Any())
                    {

                        result = logs.Where(a => a.AgentId == userId).Any();
                    }
                }
                catch (Exception ex)
                {
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }

                return (result, false);
            }

            return (canView, false);
        }

        public bool HasDepositOrSignature(ContractDto dto)
        {
            return ContractTransactionService.HasDepositOrSignature(dto);
        }

        public async Task<bool> CanPartiallyCancelAsync(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (dto.ContractStatusId == (int)ContractStatus.PartiallyCanceled ||
                dto.ContractStatusId == (int)ContractStatus.Canceled)
            {
                // Can't cancel contracts that are already cancelled.
                return false;
            }

            if (user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Accounting))
            {
                // Accounting department users can cancel contracts at any time
                return true;
            }

            if (ContractTransactionService.HasDepositOrSignature(dto))
            {
                return false;
            }

            if (user.GetUserId() == dto.AgentId)
            {
                return true;
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                // An assistant can cancel contracts 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                if (agentsInSameOffices.Any(x => x.AppUserId == dto.AgentId))
                {
                    return true;
                }
            }

            if (user.IsInRole(ECERole.LMD))
            {
                // An LMD can cancel contracts 'owned' by agents in the same office as the LMD.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.LMD);
                if (agentsInSameOffices.Any(x => x.AppUserId == dto.AgentId))
                {
                    return true;
                }
            }

            return false;
        }

        public ContractDto GetProgressAsync(ContractDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            dto.IsIssued = dto.IssueDate.HasValue;

            var transactions = dto.ContractTransactions;

            // Deposit received
            var unreceivedDeposits = transactions
                .Where(x => x.IsIncome && x.RequiredAmount != decimal.Zero && x.PaidDate == null);

            if (unreceivedDeposits.Any())
            {
                // At least one deposit is not received in full.
                dto.DepositReceived = false;

                if (unreceivedDeposits.Any(x => x.DueDate < DateTime.Now))
                {
                    // At least one deposit is not received in full, and is overdue.
                    dto.IsDepositLate = true;
                }
            }
            else
            {
                // All deposits received in full.
                dto.DepositReceived = true;
            }

            // Presenter signed
            var presenterSignature = dto.SignatureProgress.Where(x => x.SignatoryTypeId == (int)EntityType.Presenter).FirstOrDefault();

            if (presenterSignature != null && presenterSignature.SignatureReceived != null)
            {
                dto.PresenterSigned = true;
            }
            else
            {
                dto.PresenterSigned = false;

                if (presenterSignature != null &&
                    presenterSignature.SignatureDue != null &&
                    presenterSignature.SignatureDue < DateTime.Now)
                {
                    dto.IsPresenterSignatureLate = true;
                }
                else
                {
                    dto.IsPresenterSignatureLate = false;
                }
            }

            // Artist Signed
            var artistSignatures = dto.SignatureProgress.Where(x => x.SignatoryTypeId == (int)EntityType.Artist).ToList();

            if (artistSignatures == null || artistSignatures.Count == 0)
            {
                dto.ArtistSigned = false;
            }
            else
            {
                dto.ArtistSigned = true;
            }

            // if any artist has not signed, we change the flag to false
            DateTime? earliestSignatureDueDate = null;

            foreach (var artistSignature in artistSignatures)
            {
                if (artistSignature.SignatureReceived == null)
                {
                    dto.ArtistSigned = false;

                    if (artistSignature.SignatureDue != null &&
                       (artistSignature.SignatureDue < earliestSignatureDueDate ||
                        earliestSignatureDueDate == null))
                    {
                        earliestSignatureDueDate = artistSignature.SignatureDue;
                    }
                }
            }

            if (!dto.ArtistSigned && earliestSignatureDueDate < DateTime.Now)
            {
                dto.IsArtistSignatureLate = true;
            }

            dto.EventDateSelected = false;

            // Event date selected
            if (dto.EventDatesObject != null && dto.EventDatesObject.Count > 0)
            {
                var firstDate = dto.EventDatesObject.OrderBy(x => x.EventDate).FirstOrDefault();

                if (firstDate != null &&
                    (firstDate.EventDate.Date <= DateTime.Now.Date))
                {
                    dto.EventDateSelected = true;
                }
            }

            // Aref released
            dto.ArefReleased = false;
            dto.IsArefReleaseLate = false;

            foreach (var transaction in transactions)
            {
                if (transaction.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment && transaction.PaidDate != null)
                {
                    dto.ArefReleased = true;
                }
                else if (transaction.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment &&
                         transaction.DueDate != null &&
                         transaction.DueDate < DateTime.Now)
                {
                    dto.IsArefReleaseLate = true;
                }
            }


            if (IsValidContractStatus(dto.ContractStatusId) && (!dto.PresenterSigned && !dto.ArtistSigned))
            {
                PresenterPortalDto portalDto = null;

                Task.Run(async() => {
                    portalDto = await Context.Contracts
                        .GetPresenterPortalForContractAsync(dto.ContractId);
                }).Wait();

                if (portalDto != null)
                {
                    dto.PresenterPdSignLink = BuildPresenterSignLink(portalDto);
                }
            }

            if (IsValidContractStatus(dto.ContractStatusId) && (dto.PresenterSigned && !dto.ArtistSigned))
            {
                List<ContractArtistDto> contractArtists = null;

                Task.Run(async() => {
                    contractArtists = (await Context.ContractArtists
                                        .GetByContractIdAsync(dto.ContractId)).ToList();
                }).Wait();

                var artistId = contractArtists?.FirstOrDefault()?.ArtistId;

                if (artistId.HasValue)
                {
                    var encryptedKey = EncryptDecrypt.Encrypt(
                        dto.ContractId + "/" + artistId.Value);

                    dto.ArtistPdSignLink = string.Format(
                        "{0}artist/viewsignpandadoc/{1}",
                        MobiusConfiguration.GetString("Application.Url"),
                        encryptedKey);
                }

            }

            return dto;
        }

        public ContractDto GetTotalGrossAndCommission(ContractDto contract)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            contract.TotalGross = (contract.OriginalGross ?? contract.Gross).GetValueOrDefault();
            contract.TotalEceCommission = decimal.Zero;

            foreach (var ct in contract.ContractTransactions)
            {
                if (ct.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                {
                    contract.TotalEceCommission += ct.RequiredAmount.GetValueOrDefault();
                }
            }

            return contract;
        }

        public async Task UpdateGrossAsync(ContractDto dto, decimal newGross, decimal? newOriginalGross, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var description = $"Gross {dto.Gross:C}";
                if (dto.OriginalGross.HasValue)
                {
                    description = $"Reporting Gross {dto.Gross:C}/Original Gross {dto.OriginalGross:C}";
                }

                dto.Gross = newGross.ToFixed();
                dto.OriginalGross = newOriginalGross.HasValue ? newOriginalGross.ToFixed() : newOriginalGross;
                if (dto.OriginalGross == dto.Gross)
                {
                    dto.OriginalGross = null;
                }

                dto.SetAsUpdated(user);

                await this.Context.Contracts.UpdateGrossAsync(dto);

                // Record the event in the change log
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ContractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ContractGrossChange,
                    Description = description,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                if (dto.ContractTypeId == (int)ContractType.Standard)
                {
                    // Update the artist pickup.
                    await UpdateArtistPickupAmountsAsync(dto, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task UpdateNotesAsync(int contractId, string notes)
        {
            await this.Context.Contracts.UpdateNotesAsync(contractId, notes);

            return;
        }

        public async Task RequestCancellationAsync(ContractDto dto, string cancellationReason, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var accountingUsers = this.Context.Users.GetUsersByRole((int)ECERole.Accounting, false);

                // Create alert
                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractRequestCancel);
                var alertText = appEvent.Text.Replace("{ContractId}", dto.ContractId.ToString());

                if (!string.IsNullOrWhiteSpace(cancellationReason))
                {
                    alertText = $"{alertText} Reason Given: {cancellationReason}";
                }

                foreach (var accountingUser in accountingUsers)
                {
                    var alert = new AlertDto
                    {
                        AppUserId = accountingUser.AppUserId.Value,
                        Description = alertText,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Contract,
                        EntityId = dto.ContractId,
                        AppEventTypeId = (int)AppEventType.ContractRequestCancel
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task ApplyCancellationActionsAsync(ContractCancellationDto dto, ContractDto contract, IPrincipal user)
        {
            var contractTransactions = await this._contractTransactionService.GetByContractIdAsync(dto.ContractId);

            // Create a replacement contract.
            if (dto.CreateReplacement)
            {
                var replacementContract = await this.CloneContractAsync(dto.ContractId, true, user);
                dto.ReplacementContractId = replacementContract.ContractId;
            }

            // Zero out unpaid items.
            if (dto.ZeroUnpaidItems)
            {
                var contractIsInitialized = await _generalLedgerService.ContractIsInitializedAsync(contract.ContractId);

                foreach (var transaction in contractTransactions)
                {
                    if (!transaction.PaidDate.HasValue)
                    {
                        if (transaction.IsIncome)
                        {
                            if (transaction.RequiredAmount > decimal.Zero && contractIsInitialized)
                            {
                                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(
                                    GeneralLedgerEvent.ContractIncomeDecreased,
                                    Math.Abs(transaction.RequiredAmount.GetValueOrDefault()),
                                    transaction,
                                    user);
                            }
                        }

                        transaction.RequiredAmount = decimal.Zero;

                        await _contractTransactionService.UpdateAsync(transaction, user);
                    }
                }
            }

            // Send the artist(s) primary contact an email.
            if (dto.NotifyArtist)
            {
                var agents = _lookupService.GetAllActiveAgents();
                var agent = agents.FirstOrDefault(x => x.AppUserId == contract.AgentId);

                await GenerateCancellationEmailAsync(contract, user);
            }

            // Generate Refunds
            if (dto.GenerateRefunds)
            {
                await this.GenerateRefundAsync(contract.ContractId, user);
            }

            // Apply cancellation fee.
            if (dto.ApplyCancellationFee)
            {
                var cancellationFeeTransaction = new ContractTransactionDto()
                {
                    ContractId = contract.ContractId,
                    PayeeName = contract.PresenterAccountName,
                    ContractEntityTypeId = (int)ContractEntityType.Presenter,
                    ContractEntityId = contract.PresenterId ?? 0,
                    RequiredAmount = this.GetRequiredAmount(ContractTransactionType.EceCancelFee),
                    PaidAmount = decimal.Zero,
                    DueDate = DateTime.Today,
                    ContractTransactionTypeId = (int)ContractTransactionType.EceCancelFee,
                    IsExpense = false
                };

                await _contractTransactionService.CreateAsync(cancellationFeeTransaction, user);
                dto.CancellationFeeTransactionId = cancellationFeeTransaction.ContractTransactionId;

                var hasEntries = await _generalLedgerService.HasGeneralLedgerJournalEntriesAsync(contract.ContractId);

                if (this.MustMaintainGeneralLedgerEntries(contract, hasEntries))
                {
                    await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ContractIncomeAdded, EceCancelFeeAmount, cancellationFeeTransaction, user);
                }
            }
        }

        public async Task UpdateCanceledContractAsync(ContractCancellationDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contract = await this.GetByIdAsync(dto.ContractId);

                await this.ApplyCancellationActionsAsync(dto, contract, user);

                // create cancellation record
                await this._contractCancellationService.CreateAsync(dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task CancelContractAsync(ContractCancellationDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contract = await this.GetByIdAsync(dto.ContractId);
                if (contract == null)
                {
                    throw new ArgumentException($"Contract {dto.ContractId} not found.");
                }

                await this.ApplyCancellationActionsAsync(dto, contract, user);

                // Update the contract.
                contract.ContractStatusId = (int)ContractStatus.PartiallyCanceled;
                contract.CancellationDate = DateTime.Today;

                var reasonNotes = string.Empty;
                if (!string.IsNullOrEmpty(dto.CancellationReasonNotes))
                {
                    reasonNotes = $"Reason: {dto.CancellationReasonNotes}";
                }

                var cancellationNote = Environment.NewLine + $"Cancelled by {user.Identity.Name} on {DateTime.Today:MM/dd/yyyy}. {reasonNotes}".Trim();

                var notesLength = contract.Notes?.Length ?? 0;
                if (notesLength + cancellationNote.Length < CancellationNoteMaxLength)
                {
                    contract.Notes = string.Format("{0}{1}", contract.Notes, cancellationNote);
                }

                await this.UpdateAsync(contract, user);
                await this._pandaDocService.RemoveSignaturesAndRevertDraftAsync(contract, user);

                await this._contractCancellationService.CreateAsync(dto, user);

                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractCancelled);
                var alertText = appEvent.Text.Replace("{ContractId}", contract.ContractId.ToString());
                if (!string.IsNullOrWhiteSpace(reasonNotes))
                {
                    alertText = $"{alertText} {reasonNotes}";
                }

                var userIsBookingAgent = contract.AgentId == user.GetUserId();
                var userHasAccountingRole = user.IsInRole(ECERole.Accounting);

                if (!userIsBookingAgent)
                {
                    // Send alert to the booking agent
                    var alert = new AlertDto
                    {
                        AppUserId = contract.AgentId,
                        Description = alertText,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Contract,
                        EntityId = contract.ContractId,
                        AppEventTypeId = (int)AppEventType.ContractCancelled
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                if (!userHasAccountingRole)
                {
                    // Send alert to all accounting users.
                    var accountingUsers = this.Context.Users.GetUsersByRole((int)ECERole.Accounting, false);

                    foreach (var accountingUser in accountingUsers)
                    {
                        var alert = new AlertDto
                        {
                            AppUserId = accountingUser.AppUserId.Value,
                            Description = alertText,
                            IsRead = false,
                            EntityTypeId = (int)EntityType.Contract,
                            EntityId = dto.ContractId,
                            AppEventTypeId = (int)AppEventType.ContractCancelled
                        };

                        await this._alertService.CreateAsync(alert, user);
                    }
                }

                // Audit contract event
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ContractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ContractCancellation,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task<ContractDto> CloneContractAsync(int contractId, bool includeMoney, IPrincipal user)
        {
            var newContract = await this.GetByIdAsync(contractId);

            var artists = (await _iEceCrmEntities.SqlQueryAsync<ArtistCloneDto>("select ArtistId, Name, AgentId, AgencyName, MailingAddress1, MailingAddress2, MailingCity, MailingStateId, MailingZip, MailingCountryId, PhysicalAddressCity, PhysicalAddressStateId, PhysicalGeoLatitude, PhysicalGeoLongitude, PhysicalGeography, PayeeName, PaymentInfo, TIN, TINHashed, ArefMailingInstructions, BankName, BankRoutingNumber, BankAccountNumber, IsW9OnFile, W9OnFileDate, Is1099Exempt, OtherTerms, Notes, SalesPitchNotes, IsExclusive, ExclusiveStartDate, IsDateClearedByRA, IsActive, IsNational, NationalAgencyId, SecretKey, NationalNetPriceLowerBound, NationalNetPriceUpperBound, NationalOneOffPrice, CreatedDate, CreatedById, UpdatedDate, UpdatedById, ArchiveDate, IsAR, ContractLink, IsNotParticipating from Artist with(nolock)")).ToList();
            var presenters = (await _iEceCrmEntities.SqlQueryAsync<PresenterCloneDto>("select PresenterId, AgentId, AccountName, OrganizationName, PresenterTypeId, MailingAddress1, MailingAddress2, MailingCity, MailingStateId, MailingZip, MailingCountryId, PhysicalAddress1, PhysicalAddress2, PhysicalCity, PhysicalStateId, PhysicalZip, PhysicalCountryId, PhysicalGeoLatitude, PhysicalGeoLongitude, PhysicalGeography, Notes, IsActive, CreatedDate, CreatedById, UpdatedDate, UpdatedById, ArchiveDate from Presenter with(nolock)")).ToList();
            var venues = (await _iEceCrmEntities.SqlQueryAsync<VenueCloneDto>("select VenueId, AgentId, Name, VenueSettingId, IsSettingCovered, MailingAddress1, MailingAddress2, MailingCity, MailingStateId, MailingZip, MailingCountryId, PhysicalAddress1, PhysicalAddress2, PhysicalCity, PhysicalStateId, PhysicalZip, PhysicalCountryId, PhysicalGeoLatitude, PhysicalGeoLongitude, PhysicalGeography, Notes, Capacity, IsActive, PresenterId, CreatedDate, CreatedById, UpdatedDate, UpdatedById, ArchiveDate from Venue with(nolock)")).ToList();
            if (newContract == null)
            {
                throw new ArgumentNullException(nameof(contractId));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (newContract != null && newContract.ContractTemplateHistory != null)
            {
                newContract.ContractTemplateHistory = null;
            }

            if (newContract != null && newContract.ContractChangeNoteHistories != null)
            {
                newContract.ContractChangeNoteHistories = null;
            }

            //if (newContract != null && newContract.Agent != null)
            //{
            //    newContract.Agent = null;
            //}

            newContract.Notes = string.Empty;
            newContract.ChangesNote = string.Empty;

            this.Context.BeginTransaction();
            try
            {
                // Ensure the contract is in progress so the user is allowed to enter the contract creation wizard.
                newContract.ContractStatusId = (int)ContractStatus.InProgress;
                newContract.IsInProgress = true;

                // Reset these status fields and clear original gross to allow agents to use the Wizard to affect changes
                newContract.IsIssued = false;
                newContract.IssueDate = null;
                newContract.IsDepositLate = false;
                newContract.IsPaid = false;
                newContract.IsPresenterSignatureLate = false;
                newContract.IsArefReleaseLate = false;
                newContract.IsArtistSignatureLate = false;
                newContract.CancellationDate = null;
                newContract.HasIssues = false;
                newContract.OriginalGross = null;
                newContract.ContractDueDate = null;
                if (venues.Where(a => !a.IsActive && a.VenueId == newContract.VenueId).Any())
                {
                    newContract.VenueId = null;
                    newContract.VenueCapacity = null;
                    newContract.VenueContactEmail = null;
                    newContract.VenueContactFax = null;
                    newContract.VenueContactName = null;
                    newContract.VenueContactPhone = null;
                    newContract.VenueContactTitle = null;
                    newContract.VenueGeoLatitude = null;
                    newContract.VenueGeoLongitude = null;
                    newContract.VenueName = null;
                    newContract.VenuePhysicalAddress1 = null;
                    newContract.VenuePhysicalAddress2 = null;
                    newContract.VenuePhysicalCity = null;
                    newContract.VenuePhysicalCountryId = null;
                    newContract.VenuePhysicalStateId = null;
                    newContract.VenuePhysicalZip = null;
                    newContract.VenueSettingId = null;
                }
                if (presenters.Where(a => !a.IsActive && a.PresenterId == newContract.PresenterId).Any())
                {
                    newContract.PresenterId = null;
                    newContract.PresenterAccountName = null;
                    newContract.PresenterMailingAddress1 = null;
                    newContract.PresenterMailingAddress2 = null;
                    newContract.PresenterMailingCity = null;
                    newContract.PresenterMailingCountryId = null;
                    newContract.PresenterMailingStateId = null;
                    newContract.PresenterMailingZip = null;
                    newContract.PresenterOrganizationName = null;
                    newContract.PresenterPortalId = null;
                    newContract.PresenterSigned = false;
                    newContract.PresenterTypeId = null;
                }
                // Set it's children collections to null, otherwise it would automatically create records for items.
                // This way we can explicitly clone what we want.
                newContract.ContractArtists = null;
                newContract.ContractTransactions = null;
                newContract.ContractDocuments = null;

                await this.CreateAsync(newContract, user);

                // ContractArtists
                var clonedContractArtists = new List<ClonedEntity<ContractArtistDto>>();
                var replacementContractArtists = await this._contractArtistService.GetByContractIdAsync(contractId);
                bool isArtist = true;
                foreach (var artist in replacementContractArtists)
                {
                    if (artists.Where(a => a.IsActive && a.ArtistId == artist.ArtistId).Any())
                    {
                        artist.ContractId = newContract.ContractId;

                        var clonedContractArtist = new ClonedEntity<ContractArtistDto>(artist, artist.ContractArtistId);
                        clonedContractArtists.Add(clonedContractArtist);

                        await this._contractArtistService.CreateAsync(artist, user);
                    }
                    else
                    {
                        isArtist = false;
                    }
                }
                if (!isArtist)
                {
                    var contract = this._iEceCrmEntities.Contracts.FirstOrDefault(a => a.ContractId == newContract.ContractId);
                    if (contract != null)
                    {
                        contract.BlueCardId = null;
                    }
                    await this._iEceCrmEntities.SaveChangesAsync();
                }


                //change logic clone contract exclude event date(s) and date with associated event
                //// ContractEventDates
                //    var clonedContractEventDates = new List<ClonedEntity<ContractEventDateDto>>();
                //var replacementContractEventDates = await this._contractEventDateService.GetByContractIdAsync(contractId);
                //foreach (var eventDate in replacementContractEventDates)
                //{
                //    eventDate.ContractId = newContract.ContractId;

                //    var clonedContractEventDate = new ClonedEntity<ContractEventDateDto>(eventDate, eventDate.ContractEventDateId);
                //    clonedContractEventDates.Add(clonedContractEventDate);

                //    await this._contractEventDateService.CreateAsync(eventDate);
                //}
                //var contractEventDate = new ContractEventDateDto();
                //// ContractArtistEventDates - Create relationships between artist and events
                //foreach (var contractArtist in clonedContractArtists)
                //{
                //    var replacementContractArtistEventDates = await this.Context.ContractArtistEventDates.GetByContractArtistIdAsync(contractArtist.OriginalId);

                //    foreach (var artistEventDate in replacementContractArtistEventDates)
                //    {
                //        artistEventDate.ContractArtistId = contractArtist.Entity.ContractArtistId;
                //        var eventDate = clonedContractEventDates.OrderBy(a => a.Entity.EventDate).FirstOrDefault(x => x.OriginalId == artistEventDate.ContractEventDateId);

                //        // This should never be null.
                //        if (eventDate != null)
                //        {
                //            contractEventDate = eventDate.Entity;
                //            artistEventDate.ContractEventDateId = eventDate.Entity.ContractEventDateId;
                //        }

                //        await this._contractArtistEventDateService.CreateAsync(artistEventDate);
                //    }
                //}



                if (includeMoney)
                {
                    var isOld = false;
                    var isOldConfiguration = false;



                    // ContractTransactions
                    var replacementContractTransactions = await this._contractTransactionService.GetByContractIdAsync(contractId);

                    try
                    {

                        foreach (var contractTransaction in replacementContractTransactions)
                        {
                            if (GeneralLedgerService.IsEceExpenseOld(contractTransaction.ContractTransactionTypeId))
                            {
                                isOld = true;
                                break;
                            }
                        }
                    }
                    catch (Exception ex)
                    { }



                    var value = await DaoHelper.GetConfigurationValue("IsPrograms");

                    DateTime dateTime = DateTime.Now.AddDays(10);
                    try
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            dateTime = Convert.ToDateTime(value);
                        }
                    }
                    catch { }

                    if (!(dateTime.Date <= DateTime.Now.Date))
                    {
                        isOldConfiguration = true;
                    }
                    var contractExpenses = new List<ContractTransactionDto>();
                    ContractArtistDto artist = null;
                    if (clonedContractArtists != null && clonedContractArtists.Count > 0)
                    {
                        artist = clonedContractArtists.FirstOrDefault().Entity;
                    }
                    if (newContract.ContractTypeId.Value == (int)ContractType.Special)
                    {
                        foreach (var contractTransaction in replacementContractTransactions)
                        {
                            contractTransaction.ContractId = newContract.ContractId;
                            contractTransaction.PaidDate = null;
                            contractTransaction.PaidAmount = decimal.Zero;
                            contractTransaction.CanRelease = false;
                            contractTransaction.ReferenceNumber = null;
                            contractTransaction.ExpensePaymentId = null;
                            contractTransaction.ExpensePayment = null;
                            contractTransaction.ExpensePaymentStatusId = null;
                            contractTransaction.UpdatedById = null;
                            contractTransaction.UpdatedDate = null;
                            contractTransaction.LineOfBusinessId = newContract.LineOfBusinessId;
                            await this._contractTransactionService.CreateAsync(contractTransaction, user);
                        }
                    }
                    else if ((isOld == isOldConfiguration))
                    {
                        //replacementContractTransactions = replacementContractTransactions.Where(a => a.ContractTransactionTypeId != (int)ContractTransactionType.ReserveAllowance && a.ContractTransactionTypeId != (int)ContractTransactionType.SharedBonus || a.ContractTransactionTypeId != (int)ContractTransactionType.AR || a.ContractTransactionTypeId != (int)ContractTransactionType.NonExclusiveContractFee).ToList();
                        var replacementContractTransactionsTemp = new List<ContractTransactionDto>();
                        foreach (var replacementContractTransaction in replacementContractTransactions)
                        {
                            if (replacementContractTransaction.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment)
                            {
                                replacementContractTransactionsTemp.Add(replacementContractTransaction);
                            }
                            else if (replacementContractTransaction.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                            {
                                replacementContractTransactionsTemp.Add(replacementContractTransaction);
                            }
                            else if (replacementContractTransaction.ContractTransactionTypeId == (int)ContractTransactionType.Deposit)
                            {
                                replacementContractTransactionsTemp.Add(replacementContractTransaction);
                            }

                        }
                        replacementContractTransactions = new List<ContractTransactionDto>();
                        replacementContractTransactions = replacementContractTransactionsTemp;

                        var programs = this.Context.Lookups.GetAllPrograms();

                        var artistOriginal = artists.FirstOrDefault(a => a.ArtistId == artist.ArtistId);
                        if (artistOriginal != null && programs.Any())
                        {
                            var artistPrograms = await this._artistService.GetProgramsByArtistAsync(artistOriginal.ArtistId);

                            if (artistPrograms != null && artistPrograms.Any())
                            {
                                if (dateTime.Date > DateTime.Now.Date)
                                {
                                    foreach (var ap in artistPrograms)
                                    {
                                        var p = programs.First(x => ap.ProgramId == x.ProgramId);





                                        var model = new ContractTransactionDto()
                                        {

                                            ContractTransactionId = 0,
                                            ContractId = newContract.ContractId,
                                            AgentId = newContract.AgentId,
                                            ArtistId = null,
                                            ContractEntityId = 0,
                                            ContractEntityTypeId = (int)ContractEntityType.ECE,
                                            ContractTransactionTypeId = 0,
                                            PayeeName = p.Name,
                                            RequiredAmount = (ap.EcePercentage.Value / 100) * ap.Amount.Value,
                                            PaidAmount = decimal.Zero,
                                            IsExpense = true,
                                            //DueDate = contractEventDate.EventDate,
                                            DueDate = DateTime.Today.AddDays(14),

                                        };
                                        var model2 = new ContractTransactionDto()
                                        {

                                            ContractTransactionId = 0,
                                            ContractId = newContract.ContractId,
                                            AgentId = newContract.AgentId,
                                            ArtistId = artistOriginal.AgentId,
                                            ContractEntityId = 0,
                                            ContractEntityTypeId = (int)ContractEntityType.Artist,
                                            ContractTransactionTypeId = 0,
                                            PayeeName = p.Name,
                                            RequiredAmount = (ap.ArtistPercentage.Value / 100) * ap.Amount.Value,
                                            PaidAmount = decimal.Zero,
                                            IsExpense = true,
                                            //DueDate = contractEventDate.EventDate,
                                            DueDate = DateTime.Today.AddDays(14),

                                        };

                                        switch (ap.ProgramId)
                                        {
                                            case 1:
                                                model.ContractTransactionTypeId = (int)ContractTransactionType.SharedBonus;
                                                model2.ContractTransactionTypeId = (int)ContractTransactionType.SharedBonus;
                                                break;
                                            case 2:
                                                model.ContractTransactionTypeId = (int)ContractTransactionType.ReserveAllowance;
                                                model2.ContractTransactionTypeId = (int)ContractTransactionType.ReserveAllowance;
                                                break;
                                        }
                                        replacementContractTransactions.Add(model);
                                        replacementContractTransactions.Add(model2);


                                    }
                                }
                            }
                        }



                        if (!isOldConfiguration)
                        {


                            if ((!(newContract.LineOfBusinessId == (int)LineOfBusiness.National || newContract.LineOfBusinessId == (int)LineOfBusiness.Touring || artist.IsNational)) && artist.IsAR)
                            {

                                var contractAR = this.CreateECEExpense(
                                  newContract,
                                  ContractTransactionType.AR);
                                //add fees
                                //contractAR
                                replacementContractTransactions.Add(contractAR);
                            }
                            else
                            {
                                if (artist.IsNotParticipating)
                                {
                                    var contractNonExclusiveContractFee = this.CreateECEExpense(
                                      newContract,
                                      ContractTransactionType.NonExclusiveContractFee);

                                    replacementContractTransactions.Add(contractNonExclusiveContractFee);
                                }
                            }
                        }
                        else
                        {
                            var contractFee = this.CreateECEExpense(
                       newContract,
                       ContractTransactionType.ContractFee);

                            replacementContractTransactions.Add(contractFee);

                            if (artist != null)
                            {
                                var hasNonExclusiveArtist = !artist.IsExclusive;
                                if (hasNonExclusiveArtist)
                                {
                                    var contractNonExclusive = this.CreateECEExpense(
                                        newContract,
                                        ContractTransactionType.NonExclusiveContractFee);

                                    contractExpenses.Add(contractNonExclusive);
                                }
                            }



                        }
                        var contractTransactionLookups = this.Context.Lookups.GetAllContractTransactionTypes();
                        replacementContractTransactions.ToList().ForEach(e =>
                        {



                            e.ContractTransactionTypeName =
                                contractTransactionLookups
                                    .FirstOrDefault(x => x.Value == e.ContractTransactionTypeId.ToString())?.Text ??
                                string.Empty;

                            if (e.ContractTransactionTypeId == (int)ContractTransactionType.NonExclusiveContractFee)
                            {
                                e.ContractTransactionTypeName = "Cont Fee Non-Ex";
                                e.IsExpense = true;
                            }
                            else if (e.ContractTransactionTypeId == (int)ContractTransactionType.ContractFee)
                            {
                                e.ContractTransactionTypeName = "Contract Fee";
                                e.IsExpense = true;
                            }

                            if (e.ContractTransactionTypeId == (int)ContractTransactionType.AR)
                            {
                                e.ContractTransactionTypeName = "AR";

                                var gross = Convert.ToString(newContract.Gross.Value);
                                var allTierMaster = _artistService.GetAllTier(gross, newContract.ContractId).GetAwaiter().GetResult();
                                decimal? arAmount = 0;
                                if (allTierMaster != null && allTierMaster.Count() > 0)
                                {
                                    var tierMaster = allTierMaster.FirstOrDefault();
                                    arAmount = tierMaster == null ? 0 : tierMaster.Tiers;
                                }
                                e.RequiredAmount = arAmount.Value;

                                e.IsExpense = true;
                            }


                            var contractEntityTypeId = (ContractEntityType)e.ContractEntityTypeId;

                            switch (contractEntityTypeId)
                            {
                                //case ContractEntityType.Presenter:
                                //    e.ContractEntityId = e.ContractEntityId;
                                //    break;
                                case ContractEntityType.Artist:
                                    e.ArtistId = e.ContractEntityId;
                                    break;
                                case ContractEntityType.Reseller:
                                    e.ResellerId = e.ContractEntityId;
                                    break;
                                case ContractEntityType.ECE:
                                    if (e.ContractEntityId != 0)
                                    {
                                        e.AgentId = e.ContractEntityId;
                                    }

                                    break;
                                case ContractEntityType.Vendor:
                                    e.VendorId = e.ContractEntityId;
                                    break;
                                    //case ContractEntityType.Transfer:
                                    //    e.ContractEntityId = e.ContractEntityId;
                                    //    break;
                                    //case ContractEntityType.Other:
                                    //    e.ContractEntityId = e.ContractEntityId;
                                    //    break;
                            }

                            // viewModel.Expenses.Add(model);
                        });


                        foreach (var contractTransaction in replacementContractTransactions)
                        {
                            contractTransaction.ContractId = newContract.ContractId;
                            contractTransaction.PaidDate = null;
                            contractTransaction.PaidAmount = decimal.Zero;
                            contractTransaction.CanRelease = false;
                            contractTransaction.ReferenceNumber = null;
                            contractTransaction.ExpensePaymentId = null;
                            contractTransaction.ExpensePayment = null;
                            contractTransaction.ExpensePaymentStatusId = null;
                            contractTransaction.UpdatedById = null;
                            contractTransaction.UpdatedDate = null;
                            contractTransaction.LineOfBusinessId = newContract.LineOfBusinessId;
                            contractTransaction.ArtistId = (contractTransaction.ContractEntityTypeId == (int)ContractEntityType.Artist ? artist.ArtistId : (int?)null);
                            contractTransaction.AgentId = newContract.AgentId;
                            await this._contractTransactionService.CreateAsync(contractTransaction, user);
                        }
                    }
                    else
                    {
                        if (!isOldConfiguration)
                        {


                            if ((!(newContract.LineOfBusinessId == (int)LineOfBusiness.National || newContract.LineOfBusinessId == (int)LineOfBusiness.Touring || artist.IsNational)) && artist.IsAR)
                            {

                                var contractAR = this.CreateECEExpense(
                                  newContract,
                                  ContractTransactionType.AR);
                                //add fees
                                //contractAR
                                contractExpenses.Add(contractAR);
                            }
                            else
                            {
                                if (artist.IsNotParticipating)
                                {
                                    var contractNonExclusiveContractFee = this.CreateECEExpense(
                                      newContract,
                                      ContractTransactionType.NonExclusiveContractFee);

                                    contractExpenses.Add(contractNonExclusiveContractFee);
                                }
                            }
                        }
                        else
                        {
                            var contractFee = this.CreateECEExpense(
                       newContract,
                       ContractTransactionType.ContractFee);

                            contractExpenses.Add(contractFee);

                            if (artist != null)
                            {
                                var hasNonExclusiveArtist = !artist.IsExclusive;
                                if (hasNonExclusiveArtist)
                                {
                                    var contractNonExclusive = this.CreateECEExpense(
                                        newContract,
                                        ContractTransactionType.NonExclusiveContractFee);

                                    contractExpenses.Add(contractNonExclusive);
                                }
                            }



                        }


                        // Add to Commissions
                        var cc = this.CreateCommission(newContract.AgentId, null);

                        var nationalContractRemoveFeesDate = DateTime.Now;
                        try
                        {
                            nationalContractRemoveFeesDate = Convert.ToDateTime(await DaoHelper.GetConfigurationValue("NationalContractRemoveFees"));
                        }
                        catch { }
                        if (newContract.CreatedDate < nationalContractRemoveFeesDate)
                        {
                            if (artist != null && artist.IsNational)
                            {
                                var nationalAgentUsername = MobiusConfiguration.GetString("Application.NationalAgentUsername");
                                var nationalAgents =
                                    await this._userService.GetByCriteriaAsync(
                                        new UserSearchCriteriaDto() { UserName = nationalAgentUsername });
                                var nationalAgent = nationalAgents.FirstOrDefault();

                                if (nationalAgent != null)
                                {
                                    var nc = this.CreateCommission(nationalAgent.AppUserId.GetValueOrDefault(), 15);
                                    cc.RequiredPercentage = 85;
                                    var model = new ContractTransactionDto()
                                    {
                                        ContractId = newContract.ContractId,
                                        ContractTransactionId = nc.ContractTransactionId,
                                        AgentId = nc.AgentId.GetValueOrDefault(),
                                        AgentFullName = nationalAgent.FullName,
                                        RequiredPercentage = nc.RequiredPercentage.GetValueOrDefault(),
                                        RequiredAmount = (newContract.Gross.Value / 100) * nc.RequiredPercentage.GetValueOrDefault(),
                                        PayeeName = newContract.Agent.FullName,
                                        ContractEntityTypeId = (int)ContractEntityType.ECE,
                                        ContractEntityId = 0,
                                        ArtistId = artist.ArtistId,
                                        OfficeId = newContract.OfficeId,
                                        ContractTransactionTypeId = (int)ContractTransactionType.Commission,
                                        ContractTransactionTypeName = newContract.Agent.FullName,
                                    };
                                    contractExpenses.Add(model);
                                }
                            }
                        }

                        var modelCommition = new ContractTransactionDto()
                        {
                            ContractId = newContract.ContractId,
                            ContractTransactionId = cc.ContractTransactionId,
                            AgentId = cc.AgentId.GetValueOrDefault(),
                            AgentFullName = newContract.Agent.FullName,
                            RequiredPercentage = cc.RequiredPercentage.GetValueOrDefault(),
                            RequiredAmount = (newContract.Gross.Value / 100) * cc.RequiredPercentage.GetValueOrDefault(),
                            PayeeName = newContract.Agent.FullName,
                            ContractEntityTypeId = (int)ContractEntityType.ECE,
                            ContractEntityId = 0,
                            ArtistId = artist.ArtistId,
                            OfficeId = newContract.OfficeId,
                            ContractTransactionTypeId = (int)ContractTransactionType.Commission,
                            ContractTransactionTypeName = newContract.Agent.FullName,
                        };

                        contractExpenses.Add(modelCommition);
                        var contractTransactionLookups = this.Context.Lookups.GetAllContractTransactionTypes();

                        contractExpenses.ForEach(e =>
                        {



                            e.ContractTransactionTypeName =
                                contractTransactionLookups
                                    .FirstOrDefault(x => x.Value == e.ContractTransactionTypeId.ToString())?.Text ??
                                string.Empty;

                            if (e.ContractTransactionTypeId == (int)ContractTransactionType.NonExclusiveContractFee)
                            {
                                e.ContractTransactionTypeName = "Cont Fee Non-Ex";

                            }
                            else if (e.ContractTransactionTypeId == (int)ContractTransactionType.ContractFee)
                            {
                                e.ContractTransactionTypeName = "Contract Fee";

                            }

                            if (e.ContractTransactionTypeId == (int)ContractTransactionType.AR)
                            {
                                e.ContractTransactionTypeName = "AR";

                                var gross = Convert.ToString(newContract.Gross.Value);
                                var allTierMaster = _artistService.GetAllTier(gross, newContract.ContractId).GetAwaiter().GetResult();
                                decimal? arAmount = 0;
                                if (allTierMaster != null && allTierMaster.Count() > 0)
                                {
                                    var tierMaster = allTierMaster.FirstOrDefault();
                                    arAmount = tierMaster == null ? 0 : tierMaster.Tiers;
                                }
                                e.RequiredAmount = arAmount.Value;


                            }
                            e.IsExpense = true;

                            var contractEntityTypeId = (ContractEntityType)e.ContractEntityTypeId;

                            switch (contractEntityTypeId)
                            {
                                //case ContractEntityType.Presenter:
                                //    e.ContractEntityId = e.ContractEntityId;
                                //    break;
                                case ContractEntityType.Artist:
                                    e.ArtistId = e.ContractEntityId;
                                    break;
                                case ContractEntityType.Reseller:
                                    e.ResellerId = e.ContractEntityId;
                                    break;
                                case ContractEntityType.ECE:
                                    if (e.ContractEntityId != 0)
                                    {
                                        e.AgentId = e.ContractEntityId;
                                    }

                                    break;
                                case ContractEntityType.Vendor:
                                    e.VendorId = e.ContractEntityId;
                                    break;
                                    //case ContractEntityType.Transfer:
                                    //    e.ContractEntityId = e.ContractEntityId;
                                    //    break;
                                    //case ContractEntityType.Other:
                                    //    e.ContractEntityId = e.ContractEntityId;
                                    //    break;
                            }

                            // viewModel.Expenses.Add(model);
                        });


                        var programs = this.Context.Lookups.GetAllPrograms();
                        var artistOriginal = this._iEceCrmEntities.Artists.FirstOrDefault(a => a.ArtistId == artist.ArtistId);
                        if (artistOriginal != null && artistOriginal.ArtistPrograms.Any() && programs.Any())
                        {
                            var artistPrograms = await this._artistService.GetProgramsByArtistAsync(artistOriginal.ArtistId);

                            if (artistPrograms != null && artistPrograms.Any())
                            {
                                if (dateTime.Date > DateTime.Now.Date)
                                {
                                    foreach (var ap in artistPrograms)
                                    {
                                        var p = programs.First(x => ap.ProgramId == x.ProgramId);





                                        var model = new ContractTransactionDto()
                                        {

                                            ContractTransactionId = 0,
                                            ContractId = newContract.ContractId,
                                            AgentId = newContract.AgentId,
                                            ArtistId = null,
                                            OfficeId = newContract.OfficeId,
                                            ContractEntityId = 0,
                                            ContractEntityTypeId = (int)ContractEntityType.ECE,
                                            ContractTransactionTypeId = 0,
                                            PayeeName = "ECE-OTHER",
                                            RequiredAmount = (ap.EcePercentage.Value / 100) * ap.Amount.Value,
                                            PaidAmount = decimal.Zero,
                                            IsExpense = true,
                                            //DueDate = contractEventDate.EventDate,
                                            DueDate = DateTime.Today.AddDays(14),

                                        };
                                        var model2 = new ContractTransactionDto()
                                        {

                                            ContractTransactionId = 0,
                                            ContractId = newContract.ContractId,
                                            AgentId = newContract.AgentId,
                                            ArtistId = null,// artistOriginal.ArtistId,
                                            OfficeId = newContract.OfficeId,
                                            ContractEntityId = 0,
                                            ContractEntityTypeId = (int)ContractEntityType.Artist,
                                            ContractTransactionTypeId = 0,
                                            PayeeName = artist.ArtistName,
                                            RequiredAmount = (ap.ArtistPercentage.Value / 100) * ap.Amount.Value,
                                            PaidAmount = decimal.Zero,
                                            IsExpense = true,
                                            //DueDate = contractEventDate.EventDate,
                                            DueDate = DateTime.Today.AddDays(14),

                                        };
                                        //var model = new ContractTransactionDto()
                                        //{
                                        //    ContractId = newContract.ContractId,
                                        //    ContractTransactionId = 0,
                                        //    RequiredAmount = ap.Amount,
                                        //    Name = p.Name,
                                        //    ProgramId = ap.ProgramId,
                                        //    ArtistId = viewModel.ContractArtist.ArtistId
                                        //};

                                        switch (ap.ProgramId)
                                        {
                                            case 1:
                                                model.ContractTransactionTypeId = (int)ContractTransactionType.SharedBonus;
                                                model2.ContractTransactionTypeId = (int)ContractTransactionType.SharedBonus;
                                                break;
                                            case 2:
                                                model.ContractTransactionTypeId = (int)ContractTransactionType.ReserveAllowance;
                                                model2.ContractTransactionTypeId = (int)ContractTransactionType.ReserveAllowance;
                                                break;
                                        }
                                        contractExpenses.Add(model);
                                        contractExpenses.Add(model2);

                                    }
                                }
                            }
                        }

                        foreach (var contractTransaction in contractExpenses)
                        {
                            contractTransaction.ContractId = newContract.ContractId;
                            contractTransaction.PaidDate = null;
                            contractTransaction.PaidAmount = decimal.Zero;
                            contractTransaction.CanRelease = false;
                            contractTransaction.ReferenceNumber = null;
                            contractTransaction.ExpensePaymentId = null;
                            contractTransaction.ExpensePayment = null;
                            contractTransaction.ExpensePaymentStatusId = null;
                            contractTransaction.UpdatedById = null;
                            contractTransaction.UpdatedDate = null;
                            contractTransaction.LineOfBusinessId = newContract.LineOfBusinessId;
                            contractTransaction.ArtistId = (contractTransaction.ContractEntityTypeId == (int)ContractEntityType.Artist ? artist.ArtistId : (int?)null);
                            contractTransaction.AgentId = newContract.AgentId;
                            await this._contractTransactionService.CreateAsync(contractTransaction, user);
                        }

                    }
                }


                // Contract Terms
                var contractTerms = await this._contractTermsService.GetByContractIdAsync(contractId);

                if (contractTerms.Any())
                {
                    contractTerms = contractTerms
                    .GroupBy(t => t.TermId)
                    .Select(g => g.First())
                    .ToList();

                    foreach (var contractTerm in contractTerms)
                    {
                        contractTerm.ContractId = newContract.ContractId;
                        await this._contractTermsService.CreateAsync(contractTerm, user);
                    }
                }

                // Contract Riders
                var contractDocuments = await this._contractDocumentService.GetByContractIdAsync(contractId);
                var contractRiders = contractDocuments.Where(x => x.IsRider).ToList();
                if (contractRiders.Any())
                {
                    contractRiders = contractRiders
                   .GroupBy(t => t.DocumentId)
                   .Select(g => g.First())
                   .ToList();
                    foreach (var contractRider in contractRiders)
                    {
                        contractRider.ContractId = newContract.ContractId;
                        await this._contractDocumentService.CreateAsync(contractRider, user);
                    }
                }

                // Contacts
                var contactsToClone = await this._contactService.GetContactsAsync(EntityType.Contract, contractId);
                var newContacts = new List<ContactDto>();

                foreach (var contact in contactsToClone)
                {
                    var newContact = contact.ShallowCopy();
                    newContact.EntityId = newContract.ContractId;
                    newContact.SetAsCreated(user);
                    newContacts.Add(newContact);
                }

                this._contactService.SyncContacts(EntityType.Contract, newContract.ContractId, newContacts, user);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }

            this.Context.Commit();

            return newContract;
        }

        public async Task<bool> CanIssue(ContractDto contract, IPrincipal user)
        {
            /*
             * NOTE: Assistants can also issue contracts.
             *
             * The business rules are enforced in the WebUI project:
             *
             * ContractController.Issue()
             */

            if (user == contract)
            {
                throw new ArgumentNullException(nameof(contract));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (contract.IsNoIssue == true)
            {
                // Can't issue 'No Issue' contracts
                return false;
            }

            if (contract.AgentId == user.GetUserId())
            {
                // Responsible agents can issue contracts
                return true;
            }

            if (user.IsInRole(ECERole.LMD))
            {
                // An LMD can view contracts 'owned' by agents in the same office as the LMD.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.LMD);
                return agentsInSameOffices.Any(x => x.AppUserId == contract.AgentId);
            }

            return false;
        }

        /// <summary>
        /// To create refunds for a contract, the system must balance the
        /// contract by creating offsetting transactions and create GL entries for accounting purposes.
        /// </summary>
        /// <param name="contractId">The contract id to generate refunds for.</param>
        /// <param name="user">The user.</param>
        /// <returns>Task</returns>
        public async Task GenerateRefundAsync(int contractId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var contractTransactions = await this._contractTransactionService.GetByContractIdAsync(contractId);

            this.Context.BeginTransaction();
            try
            {
                foreach (var contractTransaction in contractTransactions)
                {
                    // if expense
                    if (contractTransaction.IsExpense)
                    {
                        // create income
                        if (contractTransaction.PaidDate != null)
                        {
                            var amount = contractTransaction.PaidAmount.GetValueOrDefault();

                            var newContractTransaction = new ContractTransactionDto()
                            {
                                IsExpense = false,
                                ContractId = contractTransaction.ContractId,
                                LineOfBusinessId = contractTransaction.LineOfBusinessId,
                                OfficeId = contractTransaction.OfficeId,
                                RequiredAmount = amount,
                                PaidAmount = decimal.Zero,
                                DueDate = DateTime.Today,
                                PayeeName = contractTransaction.PayeeName,
                                ContractEntityId = contractTransaction.ContractEntityId,
                                ContractEntityTypeId = contractTransaction.ContractEntityTypeId,
                                ContractTransactionTypeId = (int)ContractTransactionType.Refund,
                            };

                            if (contractTransaction.ContractEntityTypeId.Equals((int)ContractEntityType.ECE))
                            {
                                newContractTransaction.PaidDate = DateTime.Today;
                                newContractTransaction.PaidAmount = amount;

                                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ReverseEceContractExpensePaid, amount, contractTransaction, user);
                            }
                            else
                            {
                                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ContractIncomeAdded, amount, contractTransaction, user);
                            }

                            await this._contractTransactionService.CreateAsync(newContractTransaction, user);
                        }
                        else
                        {
                            contractTransaction.RequiredAmount = decimal.Zero;
                            await this._contractTransactionService.UpdateAsync(contractTransaction, user);
                        }
                    }
                    else
                    {
                        // If income, create expense
                        var difference = (contractTransaction.RequiredAmount ?? decimal.Zero) - (contractTransaction.PaidAmount ?? decimal.Zero);

                        if (contractTransaction.PaidAmount.GetValueOrDefault() > 0)
                        {
                            var newContractTransaction = new ContractTransactionDto()
                            {
                                IsExpense = true,
                                ContractId = contractTransaction.ContractId,
                                LineOfBusinessId = contractTransaction.LineOfBusinessId,
                                OfficeId = contractTransaction.OfficeId,
                                RequiredAmount = contractTransaction.PaidAmount.GetValueOrDefault(),
                                PaidAmount = decimal.Zero,
                                DueDate = DateTime.Today,
                                PayeeName = contractTransaction.PayeeName,
                                ContractEntityId = contractTransaction.ContractEntityId,
                                ContractEntityTypeId = contractTransaction.ContractEntityTypeId,
                                ContractTransactionTypeId = (int)ContractTransactionType.Refund,
                                CanRelease = true
                            };

                            if (difference > decimal.Zero)
                            {
                                contractTransaction.RequiredAmount = contractTransaction.PaidAmount.GetValueOrDefault();
                                await this._contractTransactionService.UpdateAsync(contractTransaction, user);
                                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ContractIncomeDecreased, difference, contractTransaction, user);
                            }

                            await this._contractTransactionService.CreateAsync(newContractTransaction, user);
                        }

                        if (contractTransaction.PaidAmount.GetValueOrDefault() == decimal.Zero)
                        {
                            contractTransaction.RequiredAmount = decimal.Zero;
                            await this._contractTransactionService.UpdateAsync(contractTransaction, user);
                            await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.ContractIncomeDecreased, difference, contractTransaction, user);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }

            this.Context.Commit();
        }

        public async Task UpdateTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var contractTransaction = await this.Context.ContractTransactions.GetByIdAsync(dto.ContractTransactionId);
                if (contractTransaction == null)
                {
                    throw new ArgumentException($"Contract transaction {dto.ContractTransactionId} not found.");
                }

                var changeToEntityType = contractTransaction.ContractEntityTypeId != dto.ContractEntityTypeId;

                if (changeToEntityType)
                {
                    if (dto.ContractEntityTypeId == (int)ContractEntityType.Artist)
                    {
                        dto.ContractEntityId = dto.ArtistId.GetValueOrDefault();
                    }
                    else if (dto.ContractEntityTypeId == (int)ContractEntityType.Vendor)
                    {
                        dto.ArtistId = null;
                        if (dto.VendorId > 0 && dto.ContractEntityId == contractTransaction.ArtistId.GetValueOrDefault())
                        {
                            dto.ContractEntityId = dto.VendorId;
                        }
                    }
                    else if (dto.ContractEntityTypeId == (int)ContractEntityType.Presenter)
                    {
                        dto.ArtistId = null;
                    }
                    else if (dto.ContractEntityTypeId == (int)ContractEntityType.Reseller)
                    {
                        dto.ArtistId = null;
                    }
                    else
                    {
                        dto.ArtistId = null;
                        if (dto.ResellerId > 0 && dto.ContractEntityId == contractTransaction.ArtistId.GetValueOrDefault())
                        {
                            dto.ContractEntityId = dto.ResellerId;
                        }
                    }
                }

                var changeToRequiredAmount = dto.RequiredAmount.GetValueOrDefault() - contractTransaction.RequiredAmount.GetValueOrDefault();

                contractTransaction.ParentContract = dto.ParentContract;
                contractTransaction.DueDate = dto.DueDate;
                contractTransaction.ContractTransactionTypeId = dto.ContractTransactionTypeId;
                contractTransaction.ContractEntityTypeId = dto.ContractEntityTypeId;
                contractTransaction.ContractEntityId = dto.ContractEntityId;
                contractTransaction.RequiredAmount = dto.RequiredAmount.GetValueOrDefault();
                contractTransaction.Notes = dto.Notes;

                contractTransaction.ArtistId = dto.ArtistId;
                contractTransaction.VendorId = dto.VendorId;
                contractTransaction.ResellerId = dto.ResellerId;
                contractTransaction.AgentId = dto.AgentId;

                contractTransaction.PaidAmount = dto.PaidAmount;
                contractTransaction.PaidDate = dto.PaidDate;

                this._contractTransactionService.SynchronizePaidDate(contractTransaction);

                contractTransaction.CanRelease = dto.CanRelease;

                if (updateGeneralLedger)
                {
                    if (changeToRequiredAmount != decimal.Zero)
                    {
                        var hasEntries = await _generalLedgerService.HasGeneralLedgerJournalEntriesAsync(contractTransaction.ContractId);

                        if (this.MustMaintainGLForIncomeTransaction(contractTransaction, hasEntries))
                        {
                            GeneralLedgerEvent glEvent;

                            if (changeToRequiredAmount < decimal.Zero)
                            {
                                glEvent = GeneralLedgerEvent.ContractIncomeDecreased;
                            }
                            else
                            {
                                glEvent = GeneralLedgerEvent.ContractIncomeIncreased;
                            }

                            await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(
                                glEvent,
                                Math.Abs(changeToRequiredAmount),
                                contractTransaction,
                                user);
                        }
                        else if (contractTransaction.IsExpense)
                        {
                            await this._generalLedgerService.PayEceExpenseAsync(contractTransaction, changeToRequiredAmount, user);
                        }
                    }
                    else if (changeToEntityType && contractTransaction.IsExpense && contractTransaction.ExpensePayment == null)
                    {
                        await this._generalLedgerService.PayEceExpenseAsync(contractTransaction, contractTransaction.RequiredAmount.GetValueOrDefault(), user);
                    }

                    await this.PrepTransactionForSaveAsync(contractTransaction, user, true);

                    await this.UpdateArtistPickupAmountsAsync(contractTransaction, user);
                }
                else
                {
                    dto.SetAsUpdated(user);

                    await this.Context.ContractTransactions.UpdateAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> CheckArtistNetAsync(ContractTransactionDto dto)
        {
            if (dto == null ||
                dto.ContractEntityTypeId != (int)ContractEntityType.Artist ||
                dto.ContractTransactionTypeId != (int)ContractTransactionType.ArtistPayment)
            {
                return true;
            }

            var programTypes = new List<int>()
            {
                (int)ContractTransactionType.ReserveAllowance,
                (int)ContractTransactionType.GasCard,
                (int)ContractTransactionType.SharedBonus
            };

            var contractId = dto.ContractId;

            var contractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractId);
            var match = contractTransactions.FirstOrDefault(x => x.ContractTransactionId == dto.ContractTransactionId);
            if (match != null)
            {
                contractTransactions.Remove(match);
                contractTransactions.Add(dto);
            }

            var contractArtist = await this.Context.ContractArtists.GetByContractAndArtistIdAsync(contractId, dto.ContractEntityId);
            if (contractArtist != null)
            {
                var artistArefAmount = contractTransactions
                    .Where(x => x.IsExpense &&
                                x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                                x.ContractEntityId == contractArtist.ArtistId &&
                                x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment)
                    .Total(x => x.RequiredAmount);

                var artistProgramAmount = contractTransactions
                    .Where(x => x.IsExpense &&
                                x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                                x.ContractEntityId == contractArtist.ArtistId &&
                                programTypes.Contains(x.ContractTransactionTypeId))
                    .Total(x => x.RequiredAmount);

                if (artistArefAmount + artistProgramAmount > contractArtist.Gross)
                {
                    return false;
                }
            }

            return true;
        }

        public async Task UpdateArtistPickupAmountsAsync(ContractTransactionDto dto, IPrincipal user)
        {
            var contract = dto.ParentContract ?? new ContractDto { ContractId = dto.ContractId };

            await UpdateArtistPickupAmountsAsync(contract, user);
        }

        public async Task UpdateArtistPickupAmountsAsync(ContractDto dto, IPrincipal user)
        {
            var contractId = dto.ContractId;

            var programTypes = new List<int>()
            {
                (int)ContractTransactionType.ReserveAllowance,
                (int)ContractTransactionType.GasCard,
                (int)ContractTransactionType.SharedBonus
            };

            var contract = await this.Context.Contracts.GetByIdAsync(dto.ContractId);
            if (contract == null)
            {
                throw new ArgumentException($"Contract {dto.ContractId} not found");
            }

            var contractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractId);

            var contractArtists = await this.Context.ContractArtists.GetByContractIdAsync(contractId);

            var totalGrossAmount = contract.Gross.GetValueOrDefault();

            var totalCommissionAmount = contractTransactions
                .Where(x => x.IsExpense &&
                            x.ContractEntityTypeId == (int)ContractEntityType.ECE &&
                            x.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                .Total(x => x.RequiredAmount);

            var totalOtherExpenesesAmount = contractTransactions
                .Where(x => x.IsExpense &&
                            ((x.ContractEntityTypeId == (int)ContractEntityType.ECE && x.ContractTransactionTypeId != (int)ContractTransactionType.Commission) ||
                            (x.ContractEntityTypeId != (int)ContractEntityType.ECE && x.ContractEntityTypeId != (int)ContractEntityType.Artist)))
                .Total(x => x.RequiredAmount);

            foreach (var contractArtist in contractArtists)
            {
                var artistDepositAmount = contractTransactions
                    .Where(x => !x.IsExpense &&
                                x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                                x.ContractEntityId == contractArtist.ArtistId)
                    .Total(x => x.RequiredAmount);

                if (contractArtists.Count == 1 && contract.ContractTypeId == (int)ContractType.Standard)
                {
                    contractArtist.Gross = totalGrossAmount - totalCommissionAmount - totalOtherExpenesesAmount;
                    contractArtist.EceCommission = totalCommissionAmount;
                }

                var artistArefAmount = contractTransactions
                    .Where(x => x.IsExpense &&
                                x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                                x.ContractEntityId == contractArtist.ArtistId &&
                                !programTypes.Contains(x.ContractTransactionTypeId))
                    .Total(x => x.RequiredAmount);

                var artistProgramAmount = contractTransactions
                    .Where(x => x.IsExpense &&
                                x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                                x.ContractEntityId == contractArtist.ArtistId &&
                                programTypes.Contains(x.ContractTransactionTypeId))
                    .Total(x => x.RequiredAmount);

                if (artistArefAmount + artistProgramAmount > contractArtist.Gross)
                {
                    contractArtist.Gross = artistArefAmount + artistProgramAmount;
                }

                contractArtist.Aref = artistArefAmount.ToFixed();
                contractArtist.ProgramsTotal = artistProgramAmount.ToFixed();
                contractArtist.Pickup = contractArtist.Gross.ToFixed()
                    - contractArtist.Aref.GetValueOrDefault()
                    - contractArtist.ProgramsTotal.GetValueOrDefault()
                    + artistDepositAmount.ToFixed();

                contractArtist.SetAsUpdated(user);

                await this.Context.ContractArtists.UpdateAsync(contractArtist);
            }
        }

        public bool MustMaintainGLForIncomeTransaction(ContractTransactionDto dto, bool hasEntries)
        {
            var amount = dto.RequiredAmount.GetValueOrDefault();

            return
                dto.IsIncome &&
                this.MustMaintainGeneralLedgerEntries(dto.ParentContract, hasEntries);
        }

        public bool MustMaintainGeneralLedgerEntries(ContractDto dto, bool hasEntries)
        {
            return dto.IssueDate.HasValue || hasEntries;
        }

        public async Task CreateTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                await this.PrepTransactionForSaveAsync(dto, user);

                this._contractTransactionService.SynchronizePaidDate(dto);

                await this.UpdateArtistPickupAmountsAsync(dto, user);

                var amount = dto.RequiredAmount.GetValueOrDefault();

                if (updateGeneralLedger)
                {
                    var hasEntries = await _generalLedgerService.HasGeneralLedgerJournalEntriesAsync(dto.ContractId);

                    if (this.MustMaintainGLForIncomeTransaction(dto, hasEntries))
                    {
                        GeneralLedgerEvent glEvent;

                        if (amount < decimal.Zero)
                        {
                            glEvent = GeneralLedgerEvent.ContractIncomeDecreased;
                        }
                        else
                        {
                            glEvent = GeneralLedgerEvent.ContractIncomeIncreased;
                        }

                        await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(
                            glEvent,
                            amount,
                            dto,
                            user);
                    }
                    else if (dto.IsExpense)
                    {
                        var amountToPay = dto.RequiredAmount.GetValueOrDefault();
                        var paidAmount = await this._generalLedgerService.PayEceExpenseAsync(dto, amountToPay, user);
                        if (paidAmount < decimal.Zero)
                        {
                            // Apply newly unallocated funds to ECE expenses.
                            await this._generalLedgerService.PayEceExpensesForContractAsync(dto.ContractId, user);
                        }
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteTransactionAsync(ContractTransactionDto dto, bool updateGeneralLedger, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                await this._contractTransactionService.DeleteAsync(dto.ContractTransactionId, user, true);

                await this.UpdateArtistPickupAmountsAsync(dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public void SetTransactionPayeeName(ContractDto contract, ContractTransactionDto dto)
        {
            if (dto.ContractEntityTypeId == (int)ContractEntityType.Presenter)
            {
                dto.PayeeName = "PRESENTER";
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.Transfer)
            {
                dto.PayeeName = "TRANSFER - " + string.Format("{0:C}", dto.RequiredAmount.GetValueOrDefault());
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.Other)
            {
                dto.PayeeName = "OTHER";
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.ECE)
            {
                if (dto.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                {
                    dto.PayeeName = "EASTCOAST ENT.";
                }
                else
                {
                    dto.PayeeName = "ECE-OTHER";
                }
            }
        }

        public async Task<ContractTransactionDto> PrepTransactionForSaveAsync(ContractTransactionDto dto, IPrincipal user, bool update = false)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (dto.ContractEntityTypeId == (int)ContractEntityType.Artist)
            {
                dto.ContractEntityId = dto.ArtistId.Value;
                var artist = await this._artistService.GetArtistByIdAsync(dto.ArtistId.Value);
                dto.PayeeName = artist.Name;
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.Vendor)
            {
                dto.ArtistId = null;
                if (dto.ContractEntityId == 0 && dto.VendorId > 0)
                {
                    dto.ContractEntityId = dto.VendorId;
                }

                var vendor = await this._vendorService.GetByIdAsync(dto.ContractEntityId);
                dto.PayeeName = vendor?.Name ?? "VENDOR";
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.Presenter)
            {
                dto.ArtistId = null;
                var contract = await this.GetByIdAsync(dto.ContractId);
                dto.ContractEntityId = contract.PresenterId.Value;
                dto.PayeeName = "PRESENTER";
            }
            else if (dto.ContractEntityTypeId == (int)ContractEntityType.Reseller)
            {
                dto.ArtistId = null;
                if (dto.ContractEntityId == 0 && dto.ResellerId > 0)
                {
                    dto.ContractEntityId = dto.ResellerId;
                }

                var reseller = await this._resellerService.GetByIdAsync(dto.ContractEntityId);
                dto.PayeeName = reseller?.Name ?? "RESELLER";
            }
            else
            {
                dto.ArtistId = null;
                dto.ContractEntityId = 0;

                // TODO: Move to TextHelper
                if (dto.ContractEntityTypeId == (int)ContractEntityType.Transfer)
                {
                    dto.PayeeName = "TRANSFER - " + string.Format("{0:C}", dto.RequiredAmount.GetValueOrDefault());
                }
                else if (dto.ContractEntityTypeId == (int)ContractEntityType.ECE)
                {
                    if (dto.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                    {
                        dto.PayeeName = "EASTCOAST ENT.";
                    }
                    else
                    {
                        dto.PayeeName = "ECE-OTHER";
                    }
                }
                else
                {
                    dto.PayeeName = "OTHER";
                }
            }

            if (update)
            {
                await this._contractTransactionService.UpdateAsync(dto, user);
            }
            else
            {
                dto.SetAsCreated(user);
                await this.Context.ContractTransactions.CreateAsync(dto);
            }

            return dto;
        }

        public async Task ReinstateAsync(int contractId, IPrincipal user)
        {
            var contract = await this.GetByIdAsync(contractId, true);
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(contractId));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var updatedStatus = ContractStatus.Created;

            // Determine the reinstatement status based on prior work done
            bool isIssued = contract.IssueDate.HasValue;

            int signatureCount = contract.SignatureProgress.Count();
            int signatureReceivedCount = contract.SignatureProgress.Count(x => x.SignatureReceived != null);

            int depositsCount = contract.ContractTransactions.Count(x => !x.IsExpense);
            int depositsReceivedCount = contract.ContractTransactions.Count(x => !x.IsExpense && x.PaidDate != null);

            if (isIssued &&
                signatureReceivedCount == signatureCount &&
                depositsReceivedCount == depositsCount)
            {
                // Issued, all signatures received, all deposits received
                updatedStatus = ContractStatus.Completed;
            }
            else if (isIssued &&
                        signatureReceivedCount == signatureCount &&
                        depositsReceivedCount < depositsCount)
            {
                // Issued, all signatures received, some deposits received
                updatedStatus = ContractStatus.FullyExecuted;
            }
            else if (isIssued &&
                        ((depositsReceivedCount > 0 || depositsReceivedCount < depositsCount) ||
                        (signatureReceivedCount > 0 || signatureReceivedCount < signatureCount)))
            {
                // Issued, some deposits or signatures received
                var hasReissue = contract.ContractChangeNoteHistories?
                                .Any(a => a.ContractStatusId == (int)ContractStatus.ReIssue) == true;

                updatedStatus = hasReissue
                    ? ContractStatus.ReIssue
                    : ContractStatus.Issued;
            }
            else
            {
                updatedStatus = ContractStatus.Created;
            }

            this.Context.BeginTransaction();

            try
            {
                contract.ContractStatusId = (int)updatedStatus;
                await this.UpdateAsync(contract, user);

                // Audit contract event
                var history = new EntityHistoryDto
                {
                    EntityId = contractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ContractReinstated,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }

            this.Context.Commit();
        }

        public async Task CompleteCreationAsync(int contractId, IPrincipal user, PandaDocRequestContractInfoDto contractDetailsModel = null,bool onIssue = false)
        {
            var contract = await this.GetByIdAsync(contractId);

            try
            {
               // this.Context.BeginTransaction();

                if (contract.ContractStatusId == (int)ContractStatus.InProgress)
                {
                    contract.ContractStatusId = (int)ContractStatus.Created;
                    contract.IsInProgress = false;

                    // Audit contract event
                    var history = new EntityHistoryDto
                    {
                        EntityId = contractId,
                        Type = EntityType.Contract,
                        Event = AuditEvent.ContractCreated,
                        Description = "--",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                    await this._pandaDocService.SetPandaDocTemplateIdAndContractTermsAndCondtion(contractId);
                    var contractTemplateHis = await _iEceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.ContractId == contractId);
                    if (contractDetailsModel != null && contractTemplateHis != null)
                    {
                        try
                        {
                            var result = await this._pandaDocService.CreateDocument(contractDetailsModel);
                        }
                        catch (Exception ex)
                        {
                            var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                            log.Error(ex);

                        }
                    }
                }
                else
                {
                    var contractTemplateHis = await _iEceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.ContractId == contractId);
                    if (contractTemplateHis == null || string.IsNullOrWhiteSpace(contractTemplateHis.PandaDocMainTemplateId))
                    {
                        await this._pandaDocService.SetPandaDocTemplateIdAndContractTermsAndCondtion(contractId);
                    }

                    contractTemplateHis = await _iEceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.ContractId == contractId);
                    if (contractTemplateHis != null && contractDetailsModel != null && !string.IsNullOrWhiteSpace(contractTemplateHis.PandaDocMainTemplateId) && string.IsNullOrWhiteSpace(contractTemplateHis.PandaDocDocumentId))
                    {                       
                            try
                            {
                                var result = await this._pandaDocService.CreateDocument(contractDetailsModel);
                            }
                            catch (Exception ex)
                            {
                                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                log.Error(ex);

                            }                        
                    }
                    else if(contractTemplateHis != null && contractDetailsModel != null && contractTemplateHis.IsPDFChanges && !string.IsNullOrWhiteSpace(contractTemplateHis.PandaDocDocumentId))
                    {
                        try
                        {
                            var result = await this._pandaDocService.AddOrUpdateContractPandaDocAsync(contractDetailsModel);
                        }
                        catch (Exception ex)
                        {
                            var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                            log.Error(ex);

                        }
                    }
                }

                contract.SetAsUpdated(user.GetUserId());

                await this.Context.Contracts.CompleteCreationAsync(contract);

                if (contract.BlueCardId.HasValue)
                {
                    await this._blueCardService.ToggleBlueCardStatusAsync(contract.BlueCardId.Value, true, user.GetUserId(), (int)BlueCardClosedReason.Contract);
                }

               // this.Context.Commit();
            }
            catch (Exception ex)
            {
               // this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task<IList<ContractDocumentDto>> GetAvailableRidersForContractAsync(int contractId)
        {
            if (contractId <= 0)
            {
                throw new ArgumentException(nameof(contractId));
            }

            var contract = await this.GetByIdAsync(contractId);

            var availableContractDocuments = new List<ContractDocumentDto>();

            var genericRiders = await this._lookupService.GetGenericRidersAsync(contract.EventTypeId.GetValueOrDefault());

            var contractDocuments = await this._contractDocumentService.GetByContractIdAsync(contractId);

            foreach (var gr in genericRiders)
            {
                var cd = new ContractDocumentDto
                {
                    DocumentId = gr.DocumentId,
                    ContractId = contractId,
                    IsRider = true,
                    OriginalEntityName = "Generic Rider",
                    OriginalEntityId = contractId,
                    OriginalEntityTypeId = (int)EntityType.Contract,
                    IsDeleted = false,
                    CreatedDate = gr.CreatedDate,
                    UpdatedDate = gr.UpdatedDate,
                    GenericRiderId = gr.GenericRiderId,
                    IsGenericRider = true,
                    Description = $"Generic Rider - {gr.Description}",
                };

                var contractDocument = contractDocuments.FirstOrDefault(x => x.DocumentId == gr.DocumentId);
                if (contractDocument != null)
                {
                    cd.ContractDocumentId = contractDocument.ContractDocumentId;
                }

                availableContractDocuments.Add(cd);
            }

            if (contract?.VenueId != null)
            {
                var venueRiders = this._documentService.GetDocuments(EntityType.Venue, contract.VenueId.Value);

                var venue = await this._venueService.GetVenueByIdAsync(contract.VenueId.Value, false);

                foreach (var vr in venueRiders)
                {
                    var cd = new ContractDocumentDto
                    {
                        DocumentId = vr.DocumentId,
                        ContractId = contractId,
                        IsRider = true,
                        OriginalEntityName = venue.Name,
                        OriginalEntityId = contract.VenueId.Value,
                        OriginalEntityTypeId = (int)EntityType.Venue,
                        IsDeleted = false,
                        CreatedDate = vr.CreatedDate,
                        UpdatedDate = vr.UpdatedDate,
                        Description = $"{venue.Name} - {vr.Description}",
                    };

                    availableContractDocuments.Add(cd);
                }
            }

            var contractArtists = await this._contractArtistService.GetByContractIdAsync(contractId);

            if (contractArtists.Any())
            {
                foreach (var ca in contractArtists)
                {
                    var artistRiders = this._documentService.GetDocuments(EntityType.Artist, ca.ArtistId);

                    // Filter out non-riders
                    artistRiders = artistRiders.Where(x => x.DocumentTypeId == (int)DocumentType.ArtistRider).ToList();

                    var artist = await this._artistService.GetArtistByIdAsync(ca.ArtistId);

                    foreach (var ar in artistRiders)
                    {
                        var cd = new ContractDocumentDto
                        {
                            DocumentId = ar.DocumentId,
                            ContractId = contractId,
                            IsRider = true,
                            OriginalEntityName = artist.Name,
                            OriginalEntityId = ca.ArtistId,
                            OriginalEntityTypeId = (int)EntityType.Artist,
                            IsDeleted = false,
                            CreatedDate = ar.CreatedDate,
                            UpdatedDate = ar.UpdatedDate,
                            Description = $"{artist.Name} - {ar.Description}",
                        };

                        availableContractDocuments.Add(cd);
                    }
                }

                if (contract.LineOfBusinessId.HasValue && contract.LineOfBusinessId.Value == 1)
                {
                    // for national artist rider
                    foreach (var ca in contractArtists.Where(_ => _.IsNational == true))
                    {
                        var natartistRiders = this._documentService.GetDocuments(EntityType.Artist, ca.ArtistId);

                        natartistRiders = natartistRiders.Where(x => x.DocumentTypeId == (int)DocumentType.NationalArtistRider).ToList();

                        var artist = await this._artistService.GetArtistByIdAsync(ca.ArtistId);

                        foreach (var ar in natartistRiders)
                        {
                            var cd = new ContractDocumentDto
                            {
                                DocumentId = ar.DocumentId,
                                ContractId = contractId,
                                IsRider = true,
                                OriginalEntityName = artist.Name,
                                OriginalEntityId = ca.ArtistId,
                                OriginalEntityTypeId = (int)EntityType.Artist,
                                IsDeleted = false,
                                CreatedDate = ar.CreatedDate,
                                UpdatedDate = ar.UpdatedDate,
                                Description = $"{artist.Name} - {ar.Description}",
                            };

                            availableContractDocuments.Add(cd);
                        }

                        var agencyData = await this.Context.NationalAgencies.GetByIdAsync(artist.NationalAgencyId.Value);
                        if (agencyData != null)
                        {
                            var natagencyRiders = this._documentService.GetDocuments(EntityType.National, agencyData.NationalAgencyId);
                            foreach (var rid in natagencyRiders.Where(_ => _.DocumentTypeId == (int)DocumentType.NationalAgencyRider))
                            {
                                var cd = new ContractDocumentDto
                                {
                                    DocumentId = rid.DocumentId,
                                    ContractId = contractId,
                                    IsRider = true,
                                    OriginalEntityName = agencyData.Name,
                                    OriginalEntityId = agencyData.NationalAgencyId,
                                    OriginalEntityTypeId = (int)EntityType.National,
                                    IsDeleted = false,
                                    CreatedDate = rid.CreatedDate,
                                    UpdatedDate = rid.UpdatedDate,
                                    Description = $"{agencyData.Name} - {rid.Description}",
                                };

                                availableContractDocuments.Add(cd);
                            }
                        }
                    }
                }
            }

            // Apply sorting: Non-generic rider at the top then by entity type and entity name.
            availableContractDocuments = availableContractDocuments
                .OrderBy(x => x.IsGenericRider)
                .ThenBy(x => x.OriginalEntityTypeId)
                .ThenBy(x => x.Description)
                .ToList();

            return availableContractDocuments;
        }

        public async Task<string> GetContractEntityName(int entityId, int entityTypeId, ContractDto contract)
        {
            if (contract.ContractArtists == null || contract.ContractArtists.Count == 0)
            {
                contract.ContractArtists = await this._contractArtistService.GetByContractIdAsync(contract.ContractId);
            }

            // Build out original entity name
            switch (entityTypeId)
            {
                case (int)EntityType.Presenter:
                    return contract.PresenterAccountName;

                case (int)EntityType.Venue:
                    return contract.VenueName;

                case (int)EntityType.Artist:
                    return contract.ContractArtists.FirstOrDefault(x => x.ArtistId == entityId)?.ArtistName;

                default:
                    return string.Empty;
            }
        }

        public async Task ToggleArchiveStatusAsync(int contractId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetByIdAsync(contractId);
                DateTime? archiveDate = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;
                }

                await this.Context.Contracts.ToggleArchiveStatusAsync(contractId, archiveDate, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = contractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<ContractMiniDetailDto> GetContractMiniDetailsAsync(int contractId)
        {
            var miniDetails = await this.Context.Contracts.GetContractMiniDetailsAsync(contractId);

            return miniDetails;
        }

        public async Task<IList<ContactStatusDto>> GetContractStatusValues(int[] contractIds)
        {
            var results = await this.Context.Contracts.GetContractStatusValues(contractIds);

            return results;
        }

        public async Task<bool> CanReverseReapplyGLEntriesAsync(ContractDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var criteria = new GLJournalSearchCriteriaDto
            {
                ContractId = dto.ContractId
            };

            var activity = await this.Context.GeneralLedgers.GetGLJournalEntriesByCriteriaAsync(criteria);

            var officeCount = activity.Where(x => x.OfficeId > 0).Select(x => x.OfficeId).Distinct().Count();
            var lobCount = activity.Where(x => x.LineOfBusinessId > 0).Select(x => x.LineOfBusinessId).Distinct().Count();

            if (officeCount == 1 && lobCount == 1)
            {
                return true;
            }

            return false;
        }

        public async Task ReassignAgentAsync(ContractDto dto, int newAgentId, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contract = await this.Context.Contracts.GetByIdAsync(dto.ContractId);
                if (contract == null)
                {
                    throw new ArgumentException($"Contract {dto.ContractId} not found.");
                }

                var originalAgent = await this.Context.Users.GetByIdAsync(contract.AgentId);
                var originalAgentName = $"{originalAgent.FirstName} {originalAgent.LastName}";

                // Update the Contract's Booking Agent
                contract.AgentId = newAgentId;
                contract.SetAsUpdated(user);

                await this.Context.Contracts.UpdateAsync(contract);

                // Update the Contract Transaction's associated agent
                var transactions = await this.Context.ContractTransactions.GetByContractIdAsync(dto.ContractId);
                foreach (var transaction in transactions)
                {
                    if (transaction.IsExpense &&
                        transaction.DueAmount != decimal.Zero &&
                        transaction.AgentId == originalAgent.AppUserId.GetValueOrDefault())
                    {
                        transaction.AgentId = newAgentId;
                        transaction.SetAsUpdated(user);
                        await this.Context.ContractTransactions.UpdateAsync(transaction);
                    }

                    if (transaction.IsExpense &&
                        transaction.DueAmount != decimal.Zero &&
                        transaction.ContractEntityTypeId == (int)ContractEntityType.ECE &&
                        transaction.ContractEntityId == originalAgent.AppUserId.GetValueOrDefault())
                    {
                        transaction.ContractEntityId = newAgentId;
                        transaction.SetAsUpdated(user);
                        await this.Context.ContractTransactions.UpdateAsync(transaction);
                    }
                }

                // Update the Agent Payroll Logs
                var payrollLogs = await this.Context.AgentPayrollLogs.GetByContractIdAsync(dto.ContractId);
                foreach (var payrollLog in payrollLogs)
                {
                    if (payrollLog.PayrollPaymentId == null &&
                        payrollLog.PostDate == null &&
                        payrollLog.AgentId == originalAgent.AppUserId.GetValueOrDefault())
                    {
                        payrollLog.AgentId = newAgentId;
                        if (payrollLog.GrossAmount != decimal.Zero &&
                            (payrollLog.PayrollLogTypeId == (int)PayrollLogType.AgentCommission ||
                             payrollLog.PayrollLogTypeId == (int)PayrollLogType.MentorshipCommission ||
                             payrollLog.PayrollLogTypeId == (int)PayrollLogType.TransferCommission))
                        {
                            // Reset the Net Amount and let the payroll process recalculate the correct amount.
                            payrollLog.NetAmount = decimal.Zero;
                            payrollLog.CommissionRate = decimal.Zero;
                        }

                        payrollLog.SetAsUpdated(user);
                        await this.Context.AgentPayrollLogs.UpdateAsync(payrollLog);
                    }
                }

                // Record the event in the change log
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ContractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.AgentChanged,
                    Description = originalAgentName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                var newAgent = await this.Context.Users.GetByIdAsync(newAgentId);
                var newAgentName = $"{newAgent.FirstName} {newAgent.LastName}";

                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractReassignedAgent);
                var appEventText = appEvent.Text
                    .Replace("{ContractId}", dto.ContractId.ToString())
                    .Replace("{AgentFullName}", newAgentName);

                // Send an alert to the original agent
                AlertDto alert = new AlertDto
                {
                    AppUserId = originalAgent.AppUserId.GetValueOrDefault(),
                    Description = appEventText,
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Contract,
                    EntityId = dto.ContractId,
                    AppEventTypeId = (int)AppEventType.ContractReassignedAgent
                };

                await this._alertService.CreateAsync(alert, user);

                // Send an alert to the new agent
                alert = new AlertDto
                {
                    AppUserId = newAgent.AppUserId.GetValueOrDefault(),
                    Description = appEventText,
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Contract,
                    EntityId = dto.ContractId,
                    AppEventTypeId = (int)AppEventType.ContractReassignedAgent
                };

                await this._alertService.CreateAsync(alert, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task ReassignOfficeLOBAsync(ContractDto dto, bool reverseReapplyGeneralLedger, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contract = await this.Context.Contracts.GetByIdAsync(dto.ContractId);
                if (contract == null)
                {
                    throw new ArgumentException($"Contract {dto.ContractId} not found.");
                }

                var originalOfficeId = contract.OfficeId;
                var originalOffice = _lookupService.GetAllOffices().FirstOrDefault(x => x.OfficeId == contract.OfficeId);
                var originalLineOfBusinessId = contract.LineOfBusinessId;
                var originalLineOfBusiness = _lookupService.GetLinesOfBusiness().FirstOrDefault(x => x.LineOfBusinessId == contract.LineOfBusinessId);

                var originalOfficeLOB = $"{originalOffice?.Name}/{originalLineOfBusiness?.Name}";

                // Update the Contract's Data
                contract.OfficeId = dto.OfficeId;
                contract.LineOfBusinessId = dto.LineOfBusinessId;
                contract.SetAsUpdated(user);

                await this.Context.Contracts.UpdateAsync(contract);

                // Update the Contract Transaction's associated agent
                var transactions = await this.Context.ContractTransactions.GetByContractIdAsync(dto.ContractId);
                foreach (var transaction in transactions)
                {
                    transaction.OfficeId = dto.OfficeId;
                    transaction.LineOfBusinessId = dto.LineOfBusinessId;
                    transaction.SetAsUpdated(user);
                    await this.Context.ContractTransactions.UpdateAsync(transaction);
                }

                var canReverseReapplyGLEntries = await this.CanReverseReapplyGLEntriesAsync(dto);

                if (canReverseReapplyGLEntries && reverseReapplyGeneralLedger)
                {
                    await this._generalLedgerService.ReverseReapplyOfficeLOBChangeAsync(dto, user);
                }

                // Record the event in the change log
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ContractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ContractOfficeLOBChange,
                    Description = originalOfficeLOB,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SendArtistGreenCardEmailAsync(ContractDto contract, IList<ContractArtistContactDto> contacts, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                // Get a list of distinct artists
                var artistIds = contacts.Select(x => x.ArtistId).Distinct();

                var messages = new Dictionary<int, TemplateMailMessage>();

                foreach (int artistId in artistIds)
                {
                    var artist = contract.ContractArtists.FirstOrDefault(x => x.ArtistId == artistId);

                    if (artist != null && artist.IsNational)
                    {
                        continue;
                    }

                    // Get the recipients
                    var recipients = contacts.Where(x => x.ArtistId == artistId).Select(x => x.EmailAddress).ToList();

                    var message = await this.GenerateArtistGreenCardEmailAsync(contract, artist, recipients, false, user);
                    if (message != null)
                    {
                        messages.Add(artistId, message);
                    }
                }

                foreach (var contact in contacts)
                {
                    int? emailQueueId = null;

                    if (messages.ContainsKey(contact.ArtistId.GetValueOrDefault()))
                    {
                        var message = messages[contact.ArtistId.GetValueOrDefault()];
                        if (message != null)
                        {
                            emailQueueId = message.EmailQueueId;
                        }
                    }

                    var commLog = new CommunicationLogDto
                    {
                        CommunicationMethodId = (int)CommunicationMethod.Email,
                        ContactId = contact.ContactId.Value,
                        EntityId = contract.ContractId,
                        EntityTypeId = (int)EntityType.Contract,
                        EmailQueueId = emailQueueId,
                        LogDate = DateTime.Now,
                        LogTime = DateTime.Now.ToShortTimeString(),
                        Notes = "Sent Booking Confirmation"
                    };

                    this._communicationLogService.AddCommunicationLog(commLog, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task ToggleProblemContractStatusAsync(int contractId, bool status, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetByIdAsync(contractId);

                await this.Context.Contracts.ToggleProblemStatusAsync(contractId, status, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = contractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ProbContractStatusChanged,
                    Description = original.IsProblemExcluded ? "Excluded" : "Included",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task ToggleAgentAttendContractStatusAsync(int contractId, bool status, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetByIdAsync(contractId);

                await this.Context.Contracts.ToggleAgentAttendStatusAsync(contractId, status, updatedBy);


                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<List<ContractVersionDetailDto>> GetContractVersionDetails(int contractId)
        {
            List<ContractVersionDetailDto> ContractVersionDetails = new List<ContractVersionDetailDto>();
            try
            {

                ContractVersionDetails = (await _iEceCrmEntities.ContractVersion.Where(a => a.ContractId == contractId).ToListAsync())
                .Select(x => Mapper.Map<ContractVersion, ContractVersionDetailDto>(x))
                .ToList();


            }
            catch (Exception ex)
            {
                throw new Exception("Unhandled Business Exception", ex);
            }

            return ContractVersionDetails;
        }


        public async Task<List<string>> SaveAttachmentFilesAsync(List<HttpPostedFileBase> postedFileBases)
        {
            List<string> filepaths = new List<string>();
            if (postedFileBases == null || postedFileBases.Count <= 0)
                return filepaths;

            string attachmentBasePath =
                MobiusConfiguration.Current.AppSettings["Attachment.PhysicalPath"];

            try
            {
                if (!Directory.Exists(attachmentBasePath))
                {
                    Directory.CreateDirectory(attachmentBasePath);
                }
                foreach (var postedFileBase in postedFileBases)
                {
                    string extension = Path.GetExtension(postedFileBase.FileName);
                    string sanitizedName = Path.GetFileNameWithoutExtension(postedFileBase.FileName);

                    sanitizedName = new string(
                        sanitizedName.Where(char.IsLetterOrDigit).ToArray());

                    if (string.IsNullOrWhiteSpace(sanitizedName))
                    {
                        sanitizedName = "Attachment";
                    }

                    if (sanitizedName.Length > 30)
                    {
                        sanitizedName = sanitizedName.Substring(0, 30);
                    }

                    string attachmentFileName =
                        $"{sanitizedName}-{Guid.NewGuid()}{extension}";

                    string fullPath =
                        Path.Combine(attachmentBasePath, attachmentFileName);

                    using (var fileStream = new FileStream(
                        fullPath,
                        FileMode.Create,
                        FileAccess.Write,
                        FileShare.None,
                        bufferSize: 81920,
                        useAsync: true))
                    {
                        await postedFileBase.InputStream.CopyToAsync(fileStream);
                    }
                    filepaths.Add(fullPath);
                }


                return filepaths;
            }
            catch (Exception ex)
            {
                new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION")
                    .Error(ex);

                return filepaths;
            }
        }

        private async Task<TemplateMailMessage> GenerateArtistGreenCardEmailAsync(ContractDto contract, ContractArtistDto artist, List<string> recipients, bool isCanceled = false, IPrincipal user = null)
        {
            var timeZones = this.Context.Lookups.GetAllTimeZones();

            var contractZone = timeZones.FirstOrDefault(m => m.TimezoneId == contract.TimezoneId);

            if (contractZone == null)
            {
                throw new Exception("Timezone not found");
            }
            var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(contractZone.LookupName);
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
            var bodyTemplateBookingConfirm = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.ArtistContractBookingConfirmationUpdate);
            var bodyTemplateContractCanceled = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.ArtistContractCanceled);

            var state = await this._lookupService.GetStateByIdAsync(contract.VenuePhysicalStateId.Value);
            var agent = await this.Context.Users.GetByIdAsync(contract.AgentId);
            var primaryContact = contract.Contacts.FirstOrDefault(x => x.IsPrimary);

            // Get the contract level information
            var artistName = artist.ArtistName;
            var agentFullName = agent.FullName;
            var agentEmail = agent.Username;
            var venueName = contract.VenueName;

            var venueAddress = contract.VenuePhysicalAddress1;

            if (!string.IsNullOrEmpty(contract.VenuePhysicalAddress2))
            {
                venueAddress += string.Format($"<br />{contract.VenuePhysicalAddress2}");
            }

            var venueCity = contract.VenuePhysicalCity;
            var venueState = state?.Abbreviation ?? "--";
            var presenterName = contract.PresenterAccountName;
            var presenterOrgName = contract.PresenterOrganizationName;
            var contactName = primaryContact == null ? string.Empty : primaryContact.FullName;
            var contactEmailAddress = primaryContact == null ? string.Empty : primaryContact.EmailAddress;
            var contactPrimaryPhone = primaryContact == null ? string.Empty : primaryContact.PrimaryPhoneNumber;
            var sharedBonus = string.Empty;

            var canceledText = string.Empty;
            var greenCardType = "Booking Confirmation for";

            var terms = await this.BuildContractTermsAsync(contract, artist.ContractArtistId);
            var artistEventDateTemp = artist.ArtistEventDates.OrderBy(x => x.EventDate).FirstOrDefault();
            var firstEventDate = artistEventDateTemp == null ? (DateTime?)null : artistEventDateTemp.EventDate;
            var artistDates = string.Join(", ", artist.ArtistEventDates.Select(x => x.EventDate.Value.ToShortDateString()).ToList());
            var artistDatesForBody = new StringBuilder();

            if (contract != null && artist != null && user != null && contract.ContractTypeId == (int)ContractType.Standard)
            {
                var contractSignature = await this.Context.ContractSignatures.GetByContractIdAsync(contract.ContractId);
                var contractSign = contractSignature.FirstOrDefault(a => a.EntityTypeId == (int)EntityType.Artist && a.EntityId == artist.ArtistId);
                if (contractSign == null)
                {
                    var contractSignatureDto = new ContractSignatureDto
                    {
                        ContractId = artist.ContractId,
                        DueDate = DateTime.Today,
                        EntityId = artist.ArtistId,
                        EntityTypeId = (int)EntityType.Artist,
                        IsReceived = false,
                        ReceivedDate = null,
                        SignatureId = null,
                    };
                    contractSignatureDto.SetAsCreated(user);


                    await this.Context.ContractSignatures.CreateAsync(contractSignatureDto);
                }
                else if (contractSign != null && contractSign.ContractSignatureId == 0)
                {
                    var contractSignatureDto = new ContractSignatureDto
                    {
                        ContractId = contractSign.ContractId,
                        DueDate = contractSign.DueDate,
                        EntityId = contractSign.EntityId,
                        EntityTypeId = (int)EntityType.Artist,
                        IsReceived = false,
                    };
                    contractSignatureDto.SetAsCreated(user);


                    await this.Context.ContractSignatures.CreateAsync(contractSignatureDto);
                }
            }

            string sql = string.Format(" select top 1 * from Contract with(nolock) where Contractid={0} ", contract.ContractId.ToString());

            var dt = DaoHelper.GetDataSet(sql).GetAwaiter().GetResult();

            var value = DaoHelper.GetConfigurationValue("BypassDaylightLogic").GetAwaiter().GetResult();

            DateTime contractDate = DateTime.Now.AddYears(-10);
            if (dt != null && dt.Rows.Count > 0)
            {
                contractDate = Convert.ToDateTime(dt.Rows[0]["CreatedDate"]);
            }
            DateTime dateTime = contractDate.AddDays(10);
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    dateTime = Convert.ToDateTime(value);
                }
            }
            catch { }

            foreach (var artistEventDate in artist.ArtistEventDates)
            {
                DateTime? startTime = new DateTime();
                DateTime? endTime = new DateTime();
                //If Part:Timezoneinfo decodetime convert is not set and does include direct database values.
                //Else Part:Timezoneinfo decodetime convert is set.
                if (contractDate.Date >= dateTime.Date)
                {
                    startTime = artistEventDate.EventDate.Value.Add(artistEventDate.EventStartTimeSpan.Value);
                    endTime = artistEventDate.EventDate.Value.Add(artistEventDate.EventEndTimeSpan.Value);
                }
                else
                {
                    startTime = timeZoneInfo.DecodeTime(artistEventDate.EventDate.Value, artistEventDate.EventStartTimeSpan.Value);
                    endTime = timeZoneInfo.DecodeTime(artistEventDate.EventDate.Value, artistEventDate.EventEndTimeSpan.Value);
                }

                if (string.IsNullOrEmpty(artistDatesForBody.ToString()))
                {
                    artistDatesForBody.Append(artistEventDate.EventDate.Value.ToShortDateString() + " " + startTime.Value.ToString("hh:mm tt") +
                        " - " + endTime.Value.ToString("hh:mm tt") +
                        " - " + artistEventDate.ShowNumber.ToString() + " Show");
                }
                else
                {
                    artistDatesForBody.Append(", " + artistEventDate.EventDate.Value.ToShortDateString() + " " + startTime.Value.ToString("hh:mm tt") +
                       " - " + endTime.Value.ToString("hh:mm tt") +
                       " - " + artistEventDate.ShowNumber.ToString() + " Show");
                }

            }

            decimal artistNet = decimal.Zero;

            if (contract.ContractTypeId.HasValue && contract.ContractTypeId.Value == (int)ContractType.Special)
            {
                artistNet = contract.ContractTransactions
                    .Where(z => z.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment
                                && z.ArtistId == artist.ArtistId
                                && z.RequiredAmount.HasValue)
                    .Sum(x => x.RequiredAmount.GetValueOrDefault());
            }
            else
            {
                artistNet = artist.Gross;
            }

            var hasSharedBonus = contract.ContractTransactions.Any(z =>
                                    z.ContractTransactionTypeId == (int)ContractTransactionType.SharedBonus
                                    && z.ArtistId == artist.ArtistId);

            if (hasSharedBonus)
            {
                sharedBonus = "(includes Shared Bonus)";
            }

            if (contract.ContractStatusId == (int)ContractStatus.PartiallyCanceled ||
                contract.ContractStatusId == (int)ContractStatus.Canceled ||
                isCanceled)
            {
                greenCardType = "Canceled";
                canceledText = "<p><b>This contract has been canceled!</b></p>";
            }

            // Begin send email

            var email = new TemplateMailMessage(bodyTemplateBookingConfirm.EmailTemplateId);
            var subject = string.Empty;
            var body = string.Empty;
            if (greenCardType.ToLower().Contains("canceled"))
            {
                email = new TemplateMailMessage(bodyTemplateContractCanceled.EmailTemplateId);

                subject = bodyTemplateContractCanceled.Subject
                   .Replace("{ContractNumber}", contract.ContractId.ToString())
                   .Replace("{FirstEventDate}", artistDates);

                var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                body = bodyBuilder
                   .Replace("{Year}", DateTime.Now.Year.ToString())
                   .Replace("{Body}", bodyTemplateContractCanceled.Body)
                   .Replace("{ArtistName}", artistName)
                   .Replace("{Canceled}", canceledText)
                   .Replace("{AgentEmailAddress}", agentEmail)
                   .Replace("{AgentFullName}", agentFullName)
                   .Replace("{VenueName}", venueName)
                   .Replace("{LocationAddress}", venueAddress)
                   .Replace("{LocationCity}", venueCity)
                   .Replace("{LocationState}", venueState)
                   .Replace("{ArtistEventDates}", artistDatesForBody.ToString())
                   .Replace("{ArtistNet}", artistNet.ToString("C"))
                   .Replace("{SharedBonus}", sharedBonus)
                   .Replace("{PresenterName}", presenterName)
                   .Replace("{OrgName}", presenterOrgName)
                   .Replace("{PrimaryContactName}", contactName)
                   .Replace("{PrimaryContactEmailAddress}", contactEmailAddress)
                   .Replace("{PrimaryContactPhone}", contactPrimaryPhone)
                   .Replace("{ContractTerms}", terms)
                   .Replace("''", "'")
                   .ToString();
            }
            else if (greenCardType.ToLower().Contains("booking confirmation"))
            {
                email = new TemplateMailMessage(bodyTemplateBookingConfirm.EmailTemplateId);

                subject = bodyTemplateBookingConfirm.Subject
                   .Replace("{ContractNumber}", contract.ContractId.ToString())
                   .Replace("{FirstEventDate}", artistDates);

                var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                body = bodyBuilder
                   .Replace("{Year}", DateTime.Now.Year.ToString())
                   .Replace("{Body}", bodyTemplateBookingConfirm.Body)
                   .Replace("{ArtistName}", artistName)
                   .Replace("{Canceled}", canceledText)
                   .Replace("{AgentEmailAddress}", agentEmail)
                   .Replace("{AgentFullName}", agentFullName)
                   .Replace("{VenueName}", venueName)
                   .Replace("{LocationAddress}", venueAddress)
                   .Replace("{LocationCity}", venueCity)
                   .Replace("{LocationState}", venueState)
                   .Replace("{ArtistEventDates}", artistDatesForBody.ToString())
                   .Replace("{ArtistNet}", artistNet.ToString("C"))
                   .Replace("{SharedBonus}", sharedBonus)
                   .Replace("{PresenterName}", presenterName)
                   .Replace("{OrgName}", presenterOrgName)
                   .Replace("{PrimaryContactName}", contactName)
                   .Replace("{PrimaryContactEmailAddress}", contactEmailAddress)
                   .Replace("{PrimaryContactPhone}", contactPrimaryPhone)
                   .Replace("{ContractTerms}", terms)
                   .Replace("''", "'")
                   .ToString();
            }
            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = greenCardType.ToLower().Contains("canceled") ? bodyTemplateContractCanceled.IsHtml : bodyTemplateBookingConfirm.IsHtml;

            foreach (var recipient in recipients)
            {
                email.AddRecipient(recipient);
            }

            if (agent != null)
            {
                if (TextHelper.IsValidEmail(agent.Username))
                {
                    email.SetFrom(agent.Username, agent.FullName);
                }
            }

            // Override agent's email address with the no-reply email address
            // We need to leave the call in to get the agent's email address because we'll add it
            // the email body in the future.
            if (MobiusConfiguration.GetBoolean("Email.UseNoReply"))
            {
                var noReplyEmailAddress = MobiusConfiguration.GetString("Email.FromAddress");
                var noReplyEmailName = MobiusConfiguration.GetString("Email.FromName");
                email.SetFrom(noReplyEmailAddress, noReplyEmailName);
            }

            var smtpManager = new SmtpManager(this.Context);

            // Set release date to be 24 hours from now. If that falls on a Sat or Sun, release on Mon
            var releaseDate = TextHelper.CalcReleaseDateNoWeekend(DateTime.Now.AddHours(24));
            if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
            {
                smtpManager.SendMessage(email, agent.AppUserId.Value, releaseDate);
            }

            return email;
        }

        private async Task<string> BuildContractTermsAsync(ContractDto contract, int contractArtistId)
        {
            var additionalTerms = contract.Terms;
            var terms = contract.ContractTerms;

            if ((contract.IsBuySell.HasValue && contract.IsBuySell.Value)
                || contract.ContractTypeId == (int)ContractType.Special)
            {
                var agreement = await this.Context.ContractArtistAgreements.GetByContractArtistIdAsync(contractArtistId);

                if (agreement != null)
                {
                    additionalTerms = agreement.Terms;

                    var agreementTerms = await this.Context.ContractArtistAgreements.GetTermsForAgreementAsync(agreement.ContractArtistAgreementId);
                    var convertedTerms = new List<ContractTermDto>();

                    foreach (var agreementTerm in agreementTerms)
                    {
                        convertedTerms.Add(new ContractTermDto
                        {
                            TermId = agreementTerm.TermId,
                            TermText = agreementTerm.TermText
                        });
                    }

                    terms = convertedTerms;
                }
                else
                {
                    return string.Empty;
                }
            }

            if (string.IsNullOrEmpty(additionalTerms) && terms.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder html = new StringBuilder();
            html.Append("Contract Terms:<br />");

            foreach (var term in terms)
            {
                html.Append($"{term.TermText}<br />");
            }

            if (!string.IsNullOrEmpty(additionalTerms))
            {
                additionalTerms = additionalTerms.Replace(Environment.NewLine, "<br />");
            }

            html.Append($"{additionalTerms}<br />");

            return html.ToString();
        }

        private async Task GenerateCancellationEmailAsync(ContractDto contract, IPrincipal user)
        {
            var fullContract = await this.GetByIdAsync(contract.ContractId, true);
            fullContract.Contacts = this._contactService.GetContacts(EntityType.Contract, contract.ContractId);

            foreach (var artist in fullContract.ContractArtists)
            {
                if (artist.IsNational)
                {
                    continue;
                }

                var artistContacts = await _contactService.GetContactsAsync(EntityType.Artist, artist.ArtistId);
                var primaryContact = artistContacts.FirstOrDefault(x => x.IsPrimary);

                if (primaryContact != null && !string.IsNullOrEmpty(primaryContact.EmailAddress))
                {
                    List<string> recipients = new List<string>
                    {
                        primaryContact.EmailAddress
                    };

                    var message = await this.GenerateArtistGreenCardEmailAsync(fullContract, artist, recipients, true, user);
                    if (message != null)
                    {
                        var commLog = new CommunicationLogDto
                        {
                            CommunicationMethodId = (int)CommunicationMethod.Email,
                            ContactId = primaryContact.ContactId,
                            EntityId = contract.ContractId,
                            EntityTypeId = (int)EntityType.Contract,
                            EmailQueueId = message.EmailQueueId,
                            LogDate = DateTime.Now,
                            LogTime = DateTime.Now.ToShortTimeString(),
                            Notes = "Sent Booking Confirmation"
                        };

                        this._communicationLogService.AddCommunicationLog(commLog, user);
                    }
                }
            }
        }

        private async Task<ContractDto> VerifyGeoCoordinates(ContractDto contract)
        {
            // Assumes Physical zip is present
            if (!contract.VenueGeoLatitude.HasValue || !contract.VenueGeoLongitude.HasValue)
            {
                var zipCoords = await this._lookupService.GetZipCodeGeographyAsync(contract.VenuePhysicalZip);

                if (zipCoords != null)
                {
                    contract.VenueGeoLatitude = zipCoords.Latitude;
                    contract.VenueGeoLongitude = zipCoords.Longitude;
                }
                else
                {
                    // Can't locate, set to default. this will drive BR to display messages
                    contract.VenueGeoLatitude = decimal.Zero;
                    contract.VenueGeoLongitude = decimal.Zero;
                }
            }

            return contract;
        }




        /// <summary>
        /// Shared logic for send and resend operations.
        /// </summary>
        public async Task<bool> ProcessAddendumAsync(int referenceId, string description, bool isResend, IPrincipal user, bool autoApprove = false)
        {
            bool isValid = false;
            try
            {
                AddendumDocument addendum;
                ContractDto contract;

                if (isResend)
                {
                    addendum = await _iEceCrmEntities.AddendumDocument.FirstOrDefaultAsync(a => a.AddendumDocumentId == referenceId);
                    if (addendum == null)
                        throw new Exception("Amendment Number not found.");

                    contract = await this.GetByIdAsync(addendum.ContractId, true);
                }
                else
                {
                    contract = await this.GetByIdAsync(referenceId, true);
                }

                if (contract == null)
                    throw new Exception("Contract Number not found.");

                var userAgent = await _userService.GetUserAsync(new AppUserDto { AppUserId = contract.AgentId }, includeSettings: true);
                if (userAgent == null)
                {
                    throw new Exception("User not found.");
                }


                int agentHomeOfficeId = GetAgentHomeOfficeId(userAgent);
                var recipients = await GetLmdUsersAsync(contract.AgentId, agentHomeOfficeId);

                if (!autoApprove && !recipients.Any())
                    throw new Exception("No LMD recipients found for this office.");
                var officeLmd = await _iEceCrmEntities.LuOfficeAmendmentApprovers
                    .FirstOrDefaultAsync(x => x.OfficeId == agentHomeOfficeId);
                
                if (officeLmd == null)
                    throw new Exception("No LMD recipient configured for this office.");

                var recipientId = officeLmd.AppUserId;
                var lmdList = new List<int> { recipientId };
                recipients = await _iEceCrmEntities.AppUsers.Where(u => u.AppUserId == recipientId).ToListAsync();

                // Sync or resend documents
                int? addendumDocumentId = null;
                bool result = false;

                if (isResend)
                {
                    addendumDocumentId = referenceId;
                    result = await _documentService.ReSendForApproveUpdateAddendumDocumentsByAgentAsync(referenceId, user, recipients);
                }
                else
                {
                    addendumDocumentId = await _documentService.SyncSentForApproveAddendumDocuments(referenceId, user, recipients);
                    result = addendumDocumentId != null && addendumDocumentId > 0;
                }

                if (result && addendumDocumentId.HasValue)
                {
                    if (autoApprove)
                    {
                        await _contractDocumentService.UpdateAddendumDocumentsByLMDAsync(addendumDocumentId.Value, "Approved", user, null);
                    }
                    else if (recipients.Any())
                    {
                        //var recipientId = recipients.First().AppUserId;
                        //var lmdList = recipients.Select(r => r.AppUserId).ToList();

                        addendum = await _iEceCrmEntities.AddendumDocument.FirstOrDefaultAsync(a => a.AddendumDocumentId == addendumDocumentId);
                        if (addendum != null)
                        {
                            await SendAddendumMessageAsync(contract, addendum, recipientId, lmdList, description, isResend, user);
                        }
                    }
                }

                isValid = true;
            }
            catch (Exception ex)
            {
                new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                return false;
            }

            return isValid;
        }

        /// <summary>
        /// Builds and sends the contract message for LMD users.
        /// </summary>
        private async Task SendAddendumMessageAsync(ContractDto contract, AddendumDocument addendum, int recipientId, List<int> lmds, string description, bool isResend, IPrincipal user)
        {
            string baseUrl = MobiusConfiguration.GetString("Application.Url");
            string redirectUrl = $"{baseUrl}contract/amendmentreview/" + EncryptDecrypt.Encrypt(Convert.ToString(addendum.AddendumDocumentId));

            string link = $"<a  href='{redirectUrl}' target='_blank' style='cursor:pointer;color:black;text-decoration:underline;font-weight:bold;'>Go to Review</a>";

            string body = $"Kindly review the attached amendment for changes {link}.\n\n{description}";
            string subject = $"Update on Amendment for Contract # {addendum.ContractId}";

            var canView = await this.CanViewAsync(contract, user);
            if (!canView)
                throw new UnauthorizedAccessException("User not authorized to view contract.");

            var message = new MessageDto
            {
                SenderId = user.GetUserId(),
                RecipientId = recipientId,
                EntityId = addendum.ContractId,
                EntityTypeId = (int)EntityType.Contract,
                Body = body,
                Subject = subject
            };
            lmds = lmds ?? new List<int>();
            // Remove current user if present
            int currentUserId = user.GetUserId();
            lmds.RemoveAll(id => id == currentUserId);
            if (lmds.Any())
            {
                await _messageService.CreateAsync(message, lmds, user);
            }
        }

        /// <summary>
        /// Gets the home office ID from user settings.
        /// </summary>
        private static int GetAgentHomeOfficeId(AppUserDto user)
        {
            var setting = user.Settings.GetSetting(AppUserSettingKey.HomeOffice);
            var id = 0;
            return int.TryParse(setting?.Value, out id) ? id : 0;
        }

        /// <summary>
        /// Retrieves all LMD users for the same home office.
        /// </summary>
        private async Task<List<AppUser>> GetLmdUsersAsync(int excludeUserId, int officeId)
        {
            int lmdRoleId = (int)ECERole.LMD;

            return await (from u in _iEceCrmEntities.AppUsers
                          join aur in _iEceCrmEntities.AppUserRoles on u.AppUserId equals aur.AppUserId
                          where !aur.IsDeleted
                                && aur.RoleId == lmdRoleId
                                && u.AppUserId != excludeUserId
                                && aur.OfficeId == officeId
                          orderby u.FirstName, u.LastName
                          select u)
                         .Distinct()
                         .ToListAsync();
        }

        private static bool IsValidContractStatus(int statusId)
        {
            return statusId == (int)ContractStatus.Issued
                || statusId == (int)ContractStatus.ReIssue
                || statusId == (int)ContractStatus.FullyExecuted
                || statusId == (int)ContractStatus.Completed;
        }

        private static string BuildPresenterSignLink(PresenterPortalDto portalDto)
        {
            return string.Format(
                "{0}contract/viewsignpandadoc/{1}?id={2}",
                MobiusConfiguration.GetString("Application.Url"),
                portalDto.UrlKey,
                portalDto.ContractId);
        }
   
        public async Task UpdateContractTermsCondition(ContractDto contract)
        {
            await this.Context.Contracts.UpdateContractTermsCondition(contract);
        }
    }
}