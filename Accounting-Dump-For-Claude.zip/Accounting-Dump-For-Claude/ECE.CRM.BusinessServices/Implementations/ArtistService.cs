﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using Infinity.Mobius.Configuration;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;

    public class ArtistService : IArtistService
    {
        private readonly IUserService _userService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ITINHistoryService _tinHistoryService;
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;
        private readonly IContactService _contactService;
        private readonly INationalArtistContactService _nationalArtistContactService;
        private readonly IWebLinkService _webLinkService;
        private readonly IDocumentService _documentService;
        private readonly IGenreTypeService<ArtistGenreTypeDto> _artistGenreTypeService;
        private readonly IArtistRelationService _artistRelationService;
        private readonly IRolePermissionService _rolePermissionService;
        private readonly IMessageService _messageService;

        public ArtistService(
            IUnitOfWork context,
            IUserService userService)
        {
            this.Context = context;
            this._userService = userService;
        }

        public ArtistService(IUnitOfWork context,
            IEntityHistoryService entityHistoryService,
            ITINHistoryService tinHistoryService,
            IUserService userService,
            ILookupService lookupService,
            IAlertService alertService,
            IContactService contactService,
            INationalArtistContactService nationalArtistContactService,
            IWebLinkService webLinkService,
            IDocumentService documentService,
            IGenreTypeService<ArtistGenreTypeDto> artistGenreTypeService,
            IArtistRelationService artistRelationService,
            IRolePermissionService rolePermissionService, IMessageService messageService)
        {
            this.Context = context;

            this._entityHistoryService = entityHistoryService;
            this._tinHistoryService = tinHistoryService;
            this._userService = userService;
            this._lookupService = lookupService;
            this._alertService = alertService;
            this._contactService = contactService;
            this._nationalArtistContactService = nationalArtistContactService;
            this._webLinkService = webLinkService;
            this._documentService = documentService;
            this._artistGenreTypeService = artistGenreTypeService;
            this._artistRelationService = artistRelationService;
            this._rolePermissionService = rolePermissionService;
            this._messageService = messageService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<ArtistDto>> GetArtistsByCharsAsync(string chars)
        {
            var dto = await this.Context.Artists.GetArtistsByCharsAsync(chars);

            return dto;
        }

        public async Task<List<ArtistDto>> GetArtistsByCharsWithExcludedValuesAsync(string chars,
            List<int> excludedValues)
        {
            var dto = await this.Context.Artists.GetArtistsByCharsAsync(chars);

            var excludedEntities = dto.Where(x => excludedValues.Contains(x.ArtistId));

            dto = dto.Except(excludedEntities).ToList();

            return dto;
        }

        public async Task CreateAsync(ArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);
                dto.IsActive = true;

                dto = this.VerifyGeoCoordinates(dto);

                if (dto.IsNational)
                {
                    await ResolveNationalArtistContactsAsync(dto, user);
                }

                // Generate the secret key.
                dto.SecretKey = SecurityHelper.GenerateSecretKey();

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                int newArtistId = await this.Context.Artists.CreateAsync(dto);
                await this._artistGenreTypeService.SyncChildrenAsync(newArtistId, dto.GenreTypesJson);

                // Syncing Act Types
                var actTypeIds = dto.ActTypesJson;
                if (actTypeIds != null)
                {
                    foreach (string s in actTypeIds)
                    {
                        int newActTypeId;
                        var value = int.TryParse(s, out newActTypeId);

                        var artistActType = new ArtistActTypeDto();
                        artistActType.ArtistId = newArtistId;
                        artistActType.ActTypeId = newActTypeId;

                        await this.Context.Artists.CreateArtistActTypeAsync(artistActType);
                    }
                }

                // Syncing Event Types
                if (!dto.IsNational)
                {
                    var eventTypeIds = dto.EventTypesJson;
                    if (eventTypeIds != null)
                    {
                        foreach (string s in eventTypeIds)
                        {
                            int newEventTypeId;
                            var value = int.TryParse(s, out newEventTypeId);

                            var artistEventType = new ArtistEventTypeDto();
                            artistEventType.ArtistId = newArtistId;
                            artistEventType.EventTypeId = newEventTypeId;

                            await this.Context.Artists.CreateArtistEventTypeAsync(artistEventType);
                        }
                    }
                }

                // Syncing Contacts
                if (!dto.IsNational)
                {
                    this._contactService.SyncContacts(EntityType.Artist, dto.ArtistId, dto.Contacts, user);
                }

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ArtistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.Created,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                // Add the artist created record to the audit table.
                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Artist, dto.ArtistId, ex);
            }
        }

        public async Task UpdateAsync(ArtistDto dto, IPrincipal user, bool canUpdateAccounting)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto = this.VerifyGeoCoordinates(dto);

                var original = await this.GetArtistByIdAsync(dto.ArtistId);

                var blobsToAdd = new List<IBlob>();

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                if (!original.IsExclusive && dto.IsExclusive &&
                    original.AgentId == null && dto.AgentId != null)
                {
                    await this.ReassignArtistAgentAsync(dto.ArtistId, dto.AgentId.Value, user);
                }

                dto.SetAsUpdated(user);

                if (canUpdateAccounting)
                {
                    SecurityHelper.EncryptFederalTIN(dto);

                    if (SecurityHelper.TINHasChanged(original, dto))
                    {
                        // Save previous TIN
                        await this._tinHistoryService.CreateTINHistoryAsync(original, user);
                    }
                }
                else
                {
                    // Reset any change made by the user to the Accounting fields
                    dto.AccountNumber = original.AccountNumber;
                    dto.BankName = original.BankName;
                    dto.RoutingNumber = original.RoutingNumber;
                    dto.TaxIdentificationNumber = original.TaxIdentificationNumber;
                    dto.TINHashed = original.TINHashed;
                    dto.TIN = original.TIN;
                    dto.ArefMailingInstructions = original.ArefMailingInstructions;
                    dto.IsW9OnFile = original.IsW9OnFile;
                    dto.W9OnFileDate = original.W9OnFileDate;
                    dto.Is1099Exempt = original.Is1099Exempt;
                }

                if(!user.IsInRole(ECERole.SysAdmin) && !user.IsInRole(ECERole.ArtistServices))
                {
                    dto.IsExclusive = original.IsExclusive;
                    dto.ExclusiveStartDate = original.ExclusiveStartDate;
                }

                await this.Context.Artists.UpdateAsync(dto, canUpdateAccounting);
                await this._artistGenreTypeService.SyncChildrenAsync(dto.ArtistId, dto.GenreTypesJson);

                // Sync partial view generated objects.
                if (dto.IsNational)
                {
                    await this.ResolveNationalArtistContactsAsync(dto, user);

                    // See if the national agency changed
                    if (original.NationalAgencyId != dto.NationalAgencyId)
                    {
                        foreach (var nationalArtistContact in original.NationalArtistContacts)
                        {
                            await _nationalArtistContactService.HardDeleteAsync(nationalArtistContact);
                        }
                    }
                }
                else
                {
                    this._contactService.SyncContacts(EntityType.Artist, dto.ArtistId, dto.Contacts, user);
                }

                this._webLinkService.SyncWebLinks(EntityType.Artist, dto.ArtistId, dto.WebLinks, user);
                this._documentService.SyncDocuments(EntityType.Artist, dto.ArtistId, dto.Documents, user);

                // Syncing Act Types
                var originalActTypes = await this.GetActTypesByArtistAsync(dto.ArtistId);

                var listOfSelectedActTypes =
                    dto.ActTypesJson?.Select(x => Convert.ToInt32(x.Trim())).ToList()
                    ?? new List<int>();

                var actTypesToKeep =
                    originalActTypes.Where(x => listOfSelectedActTypes.Contains(x.ActTypeId)).ToList();

                var actTypesToAdd = listOfSelectedActTypes.Except(
                    actTypesToKeep.Select(x => x.ActTypeId).ToList(),
                    x => x);

                var actTypesToRemove = originalActTypes.Except(actTypesToKeep).ToList();
                var artistActTypesToRemove = new List<ArtistActTypeDto>();

                foreach (var actType in actTypesToRemove)
                {
                    artistActTypesToRemove.Add(new ArtistActTypeDto
                    {
                        ArtistId = dto.ArtistId,
                        ActTypeId = actType.ActTypeId
                    });
                }

                foreach (int i in actTypesToAdd)
                {
                    var a = new ArtistActTypeDto
                    {
                        ActTypeId = i,
                        ArtistActTypeId = 0,
                        ArtistId = dto.ArtistId
                    };

                    await this.Context.Artists.CreateArtistActTypeAsync(a);
                }

                foreach (ArtistActTypeDto atd in artistActTypesToRemove)
                {
                    await this.Context.Artists.DeleteArtistActTypeAsync(atd);
                }

                string changePrograms = string.Empty;
                // Nationals don't have events or programs
                if (!dto.IsNational)
                {
                    // Syncing Event Types
                    var originalEventTypes = await this.GetEventTypesByArtistAsync(dto.ArtistId);

                    var listOfSelectedEventTypes =
                        dto.EventTypesJson?.Select(x => Convert.ToInt32(x.Trim())).ToList()
                        ?? new List<int>();

                    var eventTypesToKeep =
                        originalEventTypes.Where(x => listOfSelectedEventTypes.Contains(x.EventTypeId)).ToList();

                    var eventTypesToAdd = listOfSelectedEventTypes.Except(
                        eventTypesToKeep.Select(x => x.EventTypeId).ToList(),
                        x => x);

                    var eventTypesToRemove = originalEventTypes.Except(eventTypesToKeep).ToList();
                    var artistEventTypesToRemove = new List<ArtistEventTypeDto>();

                    foreach (var eventType in eventTypesToRemove)
                    {
                        artistEventTypesToRemove.Add(new ArtistEventTypeDto
                        {
                            ArtistId = dto.ArtistId,
                            EventTypeId = eventType.EventTypeId
                        });
                    }

                    foreach (int i in eventTypesToAdd)
                    {
                        var a = new ArtistEventTypeDto
                        {
                            EventTypeId = i,
                            ArtistEventTypeId = 0,
                            ArtistId = dto.ArtistId
                        };

                        await this.Context.Artists.CreateArtistEventTypeAsync(a);
                    }

                    foreach (ArtistEventTypeDto atd in artistEventTypesToRemove)
                    {
                        await this.Context.Artists.DeleteArtistEventTypeAsync(atd);
                    }

                    // Sync programs
                    var originalPrograms = await this.GetProgramsByArtistAsync(dto.ArtistId);

                    var listOfSelectedPrograms =
                        dto.ProgramsJson?.Select(x => Convert.ToInt32(x.Trim())).ToList()
                        ?? new List<int>();
                    var updatedPrograms = Context.Lookups.GetAllPrograms().Where(x => listOfSelectedPrograms.Contains(x.ProgramId)).ToList();

                    var programsToKeep =
                        originalPrograms.Where(x => listOfSelectedPrograms.Contains(x.ProgramId)).ToList();

                    var programsToAdd = listOfSelectedPrograms.Except(
                        programsToKeep.Select(x => x.ProgramId).ToList(),
                        x => x);

                    var programsToRemove = originalPrograms.Except(programsToKeep).ToList();
                    var artistProgramsToRemove = new List<ArtistProgramDto>();

                    foreach (var program in programsToRemove)
                    {
                        artistProgramsToRemove.Add(new ArtistProgramDto
                        {
                            ArtistId = dto.ArtistId,
                            ProgramId = program.ProgramId,
                            IsActive = false
                        });
                    }

                    foreach (int i in programsToAdd)
                    {
                        var a = new ArtistProgramDto
                        {
                            ProgramId = i,
                            ArtistProgramId = 0,
                            ArtistId = dto.ArtistId,
                            IsActive = true
                        };

                        a.SetAsCreated(user);
                        await this.Context.Artists.CreateArtistProgramAsync(a);
                    }

                    foreach (ArtistProgramDto p in artistProgramsToRemove)
                    {
                        p.SetAsUpdated(user);
                        await this.Context.Artists.DeleteArtistProgramAsync(p);
                    }

                    if (originalPrograms?.ToList().Count() != updatedPrograms?.ToList().Count())
                    {

                        foreach (var program in originalPrograms)
                        {
                            changePrograms += program.Name + " ,";
                        }
                        if (string.IsNullOrEmpty(changePrograms))
                        {
                            changePrograms = "None";
                        }
                    }
                }

                // JsonConvert.SerializeObject

                // end sync multiselects
                await this.AuditUpdatedEntity(original, dto, user, changePrograms);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Artist, dto.ArtistId, ex);
            }
        }

        public async Task AuditUpdatedEntity(ArtistDto original, ArtistDto updated, IPrincipal user, string changePrograms)
        {
            // Audit Artist Exclusive change
            if (!updated.IsExclusive == original.IsExclusive)
            {
                //message send all authorize persons.

                await this._messageService.CreateExclusiveArtistAsync(updated.ArtistId, user, updated.IsExclusive);

                var history = new EntityHistoryDto
                {
                    EntityId = updated.ArtistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.ArtistExclusiveChanged,
                    Description = original.IsExclusive ? "Exclusive" : "Non-Exclusive",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // AR change log
            if (!updated.IsAR == original.IsAR)
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.ArtistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.ArtistProgramsAndARChanged,
                    Description = original.IsAR ? "Select AR" : "Unselect AR",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }


            // Artist Programs Log
            if (!string.IsNullOrEmpty(changePrograms))
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.ArtistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.ArtistProgramsAndARChanged,
                    Description = changePrograms,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // National artists don't have physical locations.
            if (!original.IsNational)
            {
                // Audit Artist Home Location change
                if (updated.PhysicalAddressCity != original.PhysicalAddressCity ||
                    updated.PhysicalAddressStateId != original.PhysicalAddressStateId)
                {
                    var originalCountry = this._lookupService.GetAllCountries()
                        .Where(x => x.CountryId == original.MailingCountryId)
                        .FirstOrDefault();

                    var originalState = this._lookupService.GetAllStatesByCountry(original.MailingCountryId ?? 0)
                        .Where(x => x.StateId == original.PhysicalAddressStateId)
                        .FirstOrDefault();

                    var cityState = originalState?.Abbreviation == "--"
                        ? $"{original.PhysicalAddressCity}, {originalCountry?.Abbreviation}"
                        : $"{original.PhysicalAddressCity}, {originalState?.Abbreviation}";

                    var history = new EntityHistoryDto
                    {
                        EntityId = updated.ArtistId,
                        Type = EntityType.Artist,
                        Event = AuditEvent.ArtistHomeLocationChanged,
                        Description = cityState,
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                }
            }
            else
            {
                if (updated.NationalNetPriceLowerBound != original.NationalNetPriceLowerBound ||
                    updated.NationalNetPriceUpperBound != original.NationalNetPriceUpperBound ||
                    updated.NationalOneOffPrice != original.NationalOneOffPrice)
                {
                    var description = $"NET/HARD [{original.NationalNetPriceLowerBound:C} - {original.NationalNetPriceUpperBound:C}], ONE-OFF {original.NationalOneOffPrice:C}";

                    var history = new EntityHistoryDto
                    {
                        EntityId = updated.ArtistId,
                        Type = EntityType.Artist,
                        Event = AuditEvent.NationalArtistPriceChange,
                        Description = description,
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                }
            }

            // Audit Federal TIN change
            if (!string.Equals(updated.TaxIdentificationNumber, original.TaxIdentificationNumber, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.TaxIdentificationNumber))
                {
                    original.TaxIdentificationNumber = string.Empty;
                }

                string hiddenTIN = SecurityHelper.HideTaxIdentificationNumber(original.TaxIdentificationNumber) ?? "--";

                var history = new EntityHistoryDto
                {
                    EntityId = updated.ArtistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.ArtistTINChanged,
                    Description = hiddenTIN,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }

        public async Task<bool> CheckForDuplicates(string artistName)
        {
            var result = await this.Context.Artists.CheckForDuplicates(artistName);

            return result;
        }

        public async Task<IList<ArtistSearchResultsDto>> GetByCriteriaAsync(ArtistSearchCriteriaDto criteria)
        {
            // For TIN, encrypt and perform a match on only the numeric value
            if (!string.IsNullOrEmpty(criteria.TaxIdentificationNumber))
            {
                criteria.TaxIdentificationNumber = SecurityHelper.EncryptValueWithoutSalt(
                    TextHelper.OnlyNumericValue(criteria.TaxIdentificationNumber));
            }

            var results = await this.Context.Artists.GetByCriteriaAsync(criteria);

            foreach (var result in results)
            {
                if (result.IsExclusive && result.ExclusiveStartDate.HasValue)
                {
                    result.IsArtistConsideredExclusive = result.ExclusiveStartDate.Value.Date <= DateTime.Now.Date;
                }
            }

            return results;
        }
        public async Task<(string, string)> GetByCriteriaExportAsync(ArtistSearchCriteriaDto criteria)
        {
            // For TIN, encrypt and perform a match on only the numeric value
            if (!string.IsNullOrEmpty(criteria.TaxIdentificationNumber))
            {
                criteria.TaxIdentificationNumber = SecurityHelper.EncryptValueWithoutSalt(
                    TextHelper.OnlyNumericValue(criteria.TaxIdentificationNumber));
            }

            var results = await this.Context.Artists.GetByCriteriaExportAsync(criteria);

            return results;
        }

        public async Task<bool> CanAddArtistFeedbackAsync(IPrincipal user, int? assignedAgentId, bool checkAccountingRoles = false)
        {
            var activeAgents = _lookupService.GetAllActiveAgents();

            if (user.IsInRole(ECERole.Agent))
            {
                var isActiveAgent = activeAgents.Any(a => a.AppUserId == user.GetUserId());

                return isActiveAgent;
            }

            var canEditAnyArtist = user.IsInRole(ECERole.Owner)
                                   || user.IsInRole(ECERole.LMD)
                                   || user.IsInRole(ECERole.ArtistServices)
                                   || user.IsInRole(ECERole.Marketing);
            if (canEditAnyArtist)
            {
                // Owner, LMD, Marketing and Artist Services users can edit any artist.
                return true;
            }

            if (checkAccountingRoles)
            {
                var hasAccountingAdmin = user.IsInRole(ECERole.AccountingAdmin);
                if (hasAccountingAdmin || user.IsInRole(ECERole.LMD))
                {
                    // Accounting Administrators can edit the banking information for any artist.
                    return true;
                }
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (assignedAgentId == null)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == assignedAgentId);
            }

            return false;
        }

        public async Task<bool> CanEditAsync(IPrincipal user, int? assignedAgentId, bool isExclusive, bool checkAccountingRoles = false)
        {
            var canEdit = this.CanEdit(user, assignedAgentId, isExclusive, checkAccountingRoles);
            if (canEdit)
            {
                return true;
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (assignedAgentId == null)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == assignedAgentId);
            }

            return false;
        }

        public bool CanEdit(IPrincipal user, int? assignedAgentId, bool isExclusive, bool checkAccountingRoles = false)
        {
            if (assignedAgentId.HasValue &&
                (user.GetUserId() == assignedAgentId))
            {
                // The agent that 'owns' the artist can always edit the artist.
                return true;
            }

            if (!isExclusive)
            {
                // Agents can only edit non-exclusive artists that they don't 'own'.
                var hasAgentRole = user.IsInRole(ECERole.Agent);
                if (hasAgentRole)
                {
                    return true;
                }
            }

            var canEditAnyArtist = user.IsInRole(ECERole.Owner)
                || user.IsInRole(ECERole.LMD)
                || user.IsInRole(ECERole.ArtistServices)
                || user.IsInRole(ECERole.Marketing);
            if (canEditAnyArtist)
            {
                // Owner, LMD, Marketing and Artist Services users can edit any artist.
                return true;
            }

            if (checkAccountingRoles)
            {
                var hasAccountingAdmin = user.IsInRole(ECERole.AccountingAdmin);
                if (hasAccountingAdmin)
                {
                    // Accounting Administrators can edit the banking information for any artist.
                    return true;
                }
            }

            return false;
        }

        public async Task<ArtistDto> GetArtistByIdAsync(int id)
        {
            var dto = await this.Context.Artists.GetByIdAsync(id);

            if (dto != null)
            {
                dto.Contacts = this.Context.Contacts.GetContacts(EntityType.Artist, id);

                dto.GenreTypesDetail = await this.Context.Artists.GetGenreTypesAsync(id);
                dto.ActTypesDetail = await this.Context.Artists.GetActTypesAsync(id);
                dto.EventTypesDetail = await this.Context.Artists.GetEventTypesAsync(id);
                dto.ProgramsDetail = await this.Context.Artists.GetProgramsAsync(id);

                dto.IsExclusiveFormPending = await this.Context.Artists.IsExclusiveArtistFormPendingAsync(id);

                if (dto.IsNational)
                {
                    dto.PriceLastUpdatedDate = await this.Context.Artists.GetPriceLastUpdatedDateAsync(id);
                    dto.NationalArtistContacts = await this.Context.NationalArtistContacts.GetByNationalArtistAsync(id);
                }
            }

            return dto;
        }

        public bool CanUseDirectDeposit(ArtistDto dto)
        {
            if (dto == null)
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(dto.RoutingNumber) &&
                !string.IsNullOrWhiteSpace(dto.AccountNumber))
            {
                return true;
            }

            return false;
        }

        public async Task ToggleArtistStatusAsync(int artistId, bool isActive, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetArtistByIdAsync(artistId);

                await this.Context.Artists.ToggleArtistStatusAsync(artistId, isActive, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = artistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.StatusChanged,
                    Description = original.IsActive ? "Active" : "Inactive",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task ReassignArtistAgentAsync(int artistId, int agentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var originalArtist = await this.GetArtistByIdAsync(artistId);
                var originalAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = originalArtist.AgentId }, false);
                var originalAgentName = string.Empty;

                if (originalAgent != null)
                {
                    originalAgentName = $"{originalAgent.FirstName} {originalAgent.LastName}";
                }
                else
                {
                    originalAgentName = "No Responsible Agent";
                }

                await this.Context.Artists.ReassignArtistAgentAsync(artistId, agentId, user.GetUserId());

                var history = new EntityHistoryDto
                {
                    EntityId = artistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.AgentChanged,
                    Description = originalAgentName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ArtistAssigned);

                // Create alert
                AlertDto alert = new AlertDto
                {
                    AppUserId = agentId,
                    Description = appEvent.Text,
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Artist,
                    EntityId = artistId,
                    AppEventTypeId = (int)AppEventType.ArtistAssigned
                };

                await this._alertService.CreateAsync(alert, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task ToggleArchiveStatusAsync(int artistId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetArtistByIdAsync(artistId);
                DateTime? archiveDate = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;
                }

                await this.Context.Artists.ToggleArchiveStatusAsync(artistId, archiveDate, !isArchived, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = artistId,
                    Type = EntityType.Artist,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<ICollection<ActTypeDto>> GetActTypesByArtistAsync(int id)
        {
            return await this.Context.Artists.GetActTypesAsync(id);
        }

        public async Task<ICollection<EventTypeDto>> GetEventTypesByArtistAsync(int id)
        {
            return await this.Context.Artists.GetEventTypesAsync(id);
        }

        public async Task<ICollection<GenreTypeDto>> GetGenreTypesByArtistAsync(int id)
        {
            return await this.Context.Artists.GetGenreTypesAsync(id);
        }

        public async Task<ICollection<ProgramDto>> GetProgramsByArtistAsync(int id)
        {
            return await this.Context.Artists.GetProgramsAsync(id);
        }

        public async Task<IList<ArtistPricingDto>> GetArtistPricingsByIdAsync(int id)
        {
            var dto = await this.Context.ArtistPricings.GetPricingsByIdAsync(id);

            return dto;
        }

        public async Task<List<TiersMasterDto>> GetAllTier(string amount, int? contractId = 0)
        {
            return await this.Context.TiersMaster.GetAllTiermaster(amount, contractId);
        }
        public DateTime? GetPricingLastUpdateDate(IList<ArtistPricingDto> prices)
        {
            if (prices.Count == 0)
            {
                return null;
            }

            var lastUpdated = prices.Where(x => x.UpdatedDate != null).OrderByDescending(x => x.UpdatedDate)
                .FirstOrDefault();

            if (lastUpdated != null)
            {
                return lastUpdated.UpdatedDate;
            }

            var lastCreated = prices.OrderByDescending(x => x.CreatedDate).FirstOrDefault();

            return lastCreated?.CreatedDate;
        }

        public async Task<List<ArtistPriceHistoriesDto>> GetPriceHistoryByArtistAsync(int id)
        {
            // int year = 1997;
            int year = DateTime.Now.Year;

            var historyCollection = new List<ArtistPriceHistoriesDto>();
            var thisYearHistory = await this.Context.ArtistPricings.GetPriceHistoryByArtistAndYearAsync(id, year);
            var lastYearHistory = await this.Context.ArtistPricings.GetPriceHistoryByArtistAndYearAsync(id, year - 1);
            var lastLastYearHistory = await this.Context.ArtistPricings.GetPriceHistoryByArtistAndYearAsync(id, year - 2);

            for (var month = 1; month <= 12; month++)
            {
                // make sure months with no data return an average gross of 0
                if (!thisYearHistory.Where(x => x.Month == month).Any())
                {
                    var dto = new ArtistPriceHistoryDto
                    {
                        Month = month,
                        Year = year,
                        AverageGross = 0
                    };

                    thisYearHistory.Insert(month - 1, dto);
                }

                if (!lastYearHistory.Where(x => x.Month == month).Any())
                {
                    var dto = new ArtistPriceHistoryDto
                    {
                        Month = month,
                        Year = year - 1,
                        AverageGross = 0
                    };

                    lastYearHistory.Insert(month - 1, dto);
                }

                if (!lastLastYearHistory.Where(x => x.Month == month).Any())
                {
                    var dto = new ArtistPriceHistoryDto
                    {
                        Month = month,
                        Year = year - 2,
                        AverageGross = 0
                    };

                    lastLastYearHistory.Insert(month - 1, dto);
                }
            }

            historyCollection.Add(new ArtistPriceHistoriesDto { ThisYearHistory = thisYearHistory });
            historyCollection.Add(new ArtistPriceHistoriesDto { LastYearHistory = lastYearHistory });
            historyCollection.Add(new ArtistPriceHistoriesDto { LastLastYearHistory = lastLastYearHistory });

            return historyCollection;
        }

        public async Task<ArtistPitchMetricsDto> GetPitchMetricsAsync(int id, DateTime asOfDate)
        {
            var oneYearAgo = asOfDate.AddYears(-1);
            var firstOfYear = new DateTime(asOfDate.Year, 1, 1);

            decimal blueCardConversionRate = 0;
            decimal contractGrossAverageOneYearAgo = 0;
            decimal contractGrossAverageYtd = 0;
            decimal showGrossAverageOneYearAgo = 0;
            decimal showGrossAverageYtd = 0;
            decimal saturdayAverageGrossYtd = 0;
            decimal contractGrossYtd = 0;

            var totalShowsOneYearAgo = 0;
            var totalShowsYtd = 0;

            // Get all contracts from one year ago and all of the contracts year-to-date
            var contractOneYearAgo =
                await this.Context.Contracts.GetByArtistIdBetweenIssueDatesAsync(id, false, oneYearAgo, asOfDate);
            var contractsYtdCount = contractOneYearAgo.Where(x => x.CreatedDate >= firstOfYear).Count();

            // Get all blue cards that had the artist from the past year
            var blueCardsIds = await this.Context.BlueCards.GetAllBlueCardsForArtistInYear(id, asOfDate);
            var blueCardCount = blueCardsIds.Count();

            // Determine the number of contracts that were converted from a blue card in the past year
            var contractsFromBlueCard = contractOneYearAgo
                .Where(x => x.BlueCardId != null && blueCardsIds.Contains(x.BlueCardId.Value))
                .Count();

            if (blueCardCount > 0)
            {
                decimal numerator = contractsFromBlueCard;
                decimal denominator = blueCardCount;

                blueCardConversionRate = (numerator / denominator) * 100m;
            }

            // Get the average of all the contract gross records from the last year.
            var contractOneYearAgoGross =
                await this.Context.ContractArtists.GetArtistGrossBetweenDatesAsync(id, oneYearAgo, asOfDate);

            if (contractOneYearAgo.Count() > 0)
            {
                contractGrossAverageOneYearAgo = contractOneYearAgoGross / contractOneYearAgo.Count();
            }

            // Get the average of all contract gross records in this year to date.
            contractGrossYtd =
                await this.Context.ContractArtists.GetArtistGrossBetweenDatesAsync(id, firstOfYear, asOfDate);

            if (contractsYtdCount > 0)
            {
                contractGrossAverageYtd = contractGrossYtd / contractsYtdCount;
            }

            // Get the average of all shows from the last year.
            totalShowsOneYearAgo = await this.Context.ContractArtists.GetShowCountAsync(id, oneYearAgo, asOfDate);

            if (totalShowsOneYearAgo > 0)
            {
                showGrossAverageOneYearAgo = contractOneYearAgoGross / totalShowsOneYearAgo;
            }

            // Get the average of all shows in the current year to date.
            totalShowsYtd = await this.Context.ContractArtists.GetShowCountAsync(id, firstOfYear, asOfDate);

            if (totalShowsYtd > 0)
            {
                showGrossAverageYtd = contractGrossYtd / totalShowsYtd;
            }

            // Get the number of Saturdays in the last year that were booked.
            var saturdayContracts =
                await this.Context.ContractArtists.GetSaturdayContractsForArtistAsync(id, oneYearAgo, asOfDate);

            var saturdayContractsGross =
                await this.Context.ContractArtists.GetSaturdayContractsForArtistsGrossAsync(id, oneYearAgo, asOfDate);

            var saturdayCountYtd = saturdayContracts.Count();

            // Get the average of all the contract gross records from Saturdays in the last year.
            if (saturdayCountYtd > 0 && saturdayContractsGross > 0)
            {
                saturdayAverageGrossYtd = saturdayContractsGross / saturdayCountYtd;
            }

            return new ArtistPitchMetricsDto
            {
                BlueCardPitches = blueCardCount,
                BlueCardsToContracts = contractsFromBlueCard,
                BlueCardConversionRate = blueCardConversionRate,
                ContractAverageGross = contractGrossAverageOneYearAgo,
                ContractAverageGrossYtd = contractGrossAverageYtd,
                ShowAverage = showGrossAverageOneYearAgo,
                ShowAverageYtd = showGrossAverageYtd,
                SaturdaysBooked = saturdayCountYtd,
                ContractAverageGrossSaturday = saturdayAverageGrossYtd,
                ArtistId = id
            };
        }

        public async Task<ArtistPricingDto> GetPricingByIdAsync(int id)
        {
            var dto = await this.Context.ArtistPricings.GetPricingByIdAsync(id);

            return dto;
        }

        public async Task CreatePricingAsync(ArtistPricingDto pricing, IPrincipal user)
        {
            pricing.CreatedById = user.GetUserId();
            pricing.CreatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistPricings.CreateAsync(pricing);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task UpdatePricingAsync(ArtistPricingDto pricing, IPrincipal user)
        {
            pricing.UpdatedById = user.GetUserId();
            pricing.UpdatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistPricings.UpdateAsync(pricing);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task DeletePricingAsync(ArtistPricingDto pricing, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistPricings.DeleteAsync(pricing);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task<bool> CanEditPricingAsync(int userId, int artistId)
        {
            var user = await this._userService.GetUserAsync(new AppUserDto { AppUserId = userId }, true);
            var artist = await this.GetArtistByIdAsync(artistId);

            var freePassRoles = user.Roles.Where(x =>
                x.RoleId == (int)ECERole.LMD ||
                x.RoleId == (int)ECERole.ArtistServices ||
                x.RoleId == (int)ECERole.Marketing);

            if (freePassRoles.Any())
            {
                return true;
            }

            var hasAgentRole = user.Roles.Any(x => x.RoleId == (int)ECERole.Agent);

            if (hasAgentRole)
            {
                if (user.AppUserId == artist.AgentId)
                {
                    return true;
                }
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (artist.AgentId == null)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == artist.AgentId.Value);
            }

            return false;
        }

        public async Task<bool> CanEditPricingAsync(ArtistDto artist, IPrincipal user)
        {
            var freePassRoles =
                user.IsInRole(ECERole.LMD) ||
                user.IsInRole(ECERole.ArtistServices) ||
                user.IsInRole(ECERole.Marketing);

            if (freePassRoles)
            {
                return true;
            }

            var hasAgentRole = user.IsInRole(ECERole.Agent);

            if (hasAgentRole)
            {
                if (user.GetUserId() == artist.AgentId)
                {
                    return true;
                }
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (artist.AgentId == null)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == artist.AgentId.Value);
            }

            return false;
        }

        public async Task<bool> SendArtistPortalWelcomeEmailAsync(int appUserId)
        {
            // Assumes passed in user id is the active portal user account for this artist
            var artistPortalUser = await this._userService.GetUserByIdAsync(appUserId);

            if (artistPortalUser != null)
            {
                await this.GenerateWelcomeEmailAsync(artistPortalUser);
                return true;
            }

            return false;
        }

        public async Task<IList<NationalArtistSearchResultDto>> GetNationalArtistsByCriteriaAsync(
            NationalArtistSearchCriteriaDto criteria)
        {
            var results = await this.Context.Artists.GetNationalArtistsByCriteriaAsync(criteria);

            foreach (var result in results)
            {
                if (result.IsExclusive && result.ExclusiveStartDate.HasValue)
                {
                    result.IsArtistConsideredExclusive = result.ExclusiveStartDate.Value.Date <= DateTime.Now.Date;
                }
            }

            return results;
        }

        public async Task<string> GetNationalArtistsByCriteriaExportAsync(NationalArtistSearchCriteriaDto criteria)
        {
            var results = await this.Context.Artists.GetNationalArtistsByCriteriaWhereClause(criteria);

            return results;
        }

        public async Task<List<ArtistBookDateDto>> GetBookedDatesAsync(int id)
        {
            var relatedArtistIds = await this._artistRelationService.GetIdsAsync(id);

            return await this.Context.Artists.GetBookedDatesAsync(relatedArtistIds);
        }

        public async Task<List<ArtistBookDateDto>> GetBookedDatesAsync(int id, IList<DateTime> dates)
        {
            var relatedArtistIds = await this._artistRelationService.GetIdsAsync(id);

            return await this.Context.Artists.GetBookedDatesAsync(relatedArtistIds, dates);
        }

        public async Task CreatePortalAccessUserAsync(AppUserDto appUser, int artistId, IPrincipal user)
        {
            if (appUser == null)
            {
                throw new ArgumentNullException(nameof(appUser));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                await this._userService.CreateUserAsync(appUser, user);

                var appUserRole = new AppUserRoleDto()
                {
                    AppUserId = appUser.AppUserId.Value,
                    RoleId = (int)ECERole.Artist,
                    EntityId = artistId
                };

                await this._rolePermissionService.CreateAppUserRoleAsync(appUserRole, user);

                await this.SendArtistPortalWelcomeEmailAsync(appUser.AppUserId.Value);

                this.Context.Commit();


                if (appUserRole != null)
                {


                    List<AppUserRoleForPermissionDto> roleList = new List<AppUserRoleForPermissionDto>();                  
                        roleList.Add(new AppUserRoleForPermissionDto() { RoleId = appUserRole.RoleId, IsDeleted = appUserRole.IsDeleted });
                    
                    var roleListStr = JsonConvert.SerializeObject(roleList);
                    await _userService.SetUserRoleWisePermissions(roleListStr, appUserRole.AppUserId, user.GetUserId());
                }
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task LinkPortalAccessUserAsync(AppUserDto appUser, int artistId, IPrincipal user)
        {
            if (appUser == null)
            {
                throw new ArgumentNullException(nameof(appUser));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var appUserRole = new AppUserRoleDto()
                {
                    AppUserId = appUser.AppUserId.Value,
                    RoleId = (int)ECERole.Artist,
                    EntityId = artistId
                };

                await this._rolePermissionService.CreateAppUserRoleAsync(appUserRole, user);

                if (appUser.IsActive == false)
                {
                    appUser.IsActive = true;

                    await this._userService.UpdateDetailsAsync(appUser, user, true);

                    await this.SendArtistPortalWelcomeEmailAsync(appUser.AppUserId.Value);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<ArtistDto>> GetArtistsForUserAsync(int appUserId)
        {
            var roles = await this.Context.RolePermissions.GetUserRolesAsync(appUserId, false);

            var artistIds = roles
                .Where(x => x.RoleId == (int)ECERole.Artist && x.EntityId > 0)
                .Select(x => x.EntityId.GetValueOrDefault())
                .ToArray();

            return await this.Context.Artists.GetByArtistIdsAsync(artistIds);
        }

        public async Task ResetArtistUserAsync(int artistId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var artistAppUser = await this._userService.GetUserByEntityAsync(artistId, ECERole.Artist, true);
                if (artistAppUser == null)
                {
                    throw new ArgumentException($"Artist {artistId} does not have an active portal user", nameof(artistId));
                }

                artistAppUser.Roles = await this._rolePermissionService.GetRolesForUserAsync((int)artistAppUser.AppUserId);

                if (artistAppUser.ArtistCount() == 1)
                {
                    // Inactivate the user and remove the artist role from the user.
                    artistAppUser.IsActive = false;

                    await this._userService.UpdateDetailsAsync(artistAppUser, user, true);

                    await this._rolePermissionService.ToggleUserRoleDeletedStatusAsync(artistAppUser.AppUserId.Value, true);
                }
                else
                {
                    // Remove the artist role from the user.
                    var artistRole = artistAppUser.Roles
                        .Where(x => x.EntityId == artistId)
                        .FirstOrDefault();

                    if (artistRole != null)
                    {
                        artistRole.IsDeleted = true;
                        artistRole.SetAsUpdated(user);

                        await this._rolePermissionService.SyncRolesAsync(artistAppUser.AppUserId.Value, artistAppUser.Roles, user);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        private ArtistDto VerifyGeoCoordinates(ArtistDto artist)
        {
            // Assumes Physical zip is present
            if (!artist.PhysicalGeoLatitude.HasValue || !artist.PhysicalGeoLongitude.HasValue)
            {
                // Can't locate, set to default. this will drive BR to display messages
                artist.PhysicalGeoLatitude = decimal.Zero;
                artist.PhysicalGeoLongitude = decimal.Zero;
            }

            return artist;
        }

        private async Task ResolveNationalArtistContactsAsync(ArtistDto artist, IPrincipal user)
        {
            for (var i = artist.NationalArtistContacts.Count - 1; i >= 0; i--)
            {
                var nationalArtistContact = artist.NationalArtistContacts.ElementAt(i);

                // Remove non selected contacts &
                // set the selected contacts as created or updated.
                if (!nationalArtistContact.IsArtistContact)
                {
                    artist.NationalArtistContacts.Remove(nationalArtistContact);

                    if (nationalArtistContact.NationalArtistContactId > 0)
                    {
                        await _nationalArtistContactService.HardDeleteAsync(nationalArtistContact);
                    }
                }
                else
                {
                    if (nationalArtistContact.NationalArtistContactId > 0)
                    {
                        await _nationalArtistContactService.UpdateAsync(nationalArtistContact, user);
                    }
                    else
                    {
                        if (artist.ArtistId > 0)
                        {
                            nationalArtistContact.ArtistId = artist.ArtistId;
                            await _nationalArtistContactService.CreateAsync(nationalArtistContact, user);
                        }
                        else
                        {
                            nationalArtistContact.SetAsCreated(user);
                        }
                    }
                }
            }
        }

        private async Task GenerateWelcomeEmailAsync(AppUserDto appUser)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendWelcomeArtistPortal);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string supportEmail = MobiusConfiguration.GetString("Email.SupportAddress");

            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
            var body = bodyBuilder.Replace("{Body}", bodyTemplate.Body)
                .Replace("{FirstName}", appUser.FirstName)
                .Replace("{SupportEmail}", supportEmail)
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("''", "'")
                .ToString();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;
            email.To.Add(appUser.Username);

            this.Context.BeginTransaction();

            try
            {
                var smtpManager = new SmtpManager(this.Context);

                // Send the message, bypassing the email message queue.
                smtpManager.SendMessage(email, appUser.AppUserId.Value, SendMessageMode.Directly);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        
    }
}