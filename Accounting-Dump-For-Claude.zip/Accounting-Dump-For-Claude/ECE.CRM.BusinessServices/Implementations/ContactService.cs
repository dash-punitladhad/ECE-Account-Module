﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContactService : IContactService
    {
        private readonly IEntityHistoryService _entityHistoryService;

        public ContactService(
            IUnitOfWork context,
            IEntityHistoryService entityHistoryService)
        {
            this.Context = context;

            this._entityHistoryService = entityHistoryService;
        }

        public IUnitOfWork Context { get; private set; }

        public IList<ContactDto> GetContacts(EntityType entityType, int entityId)
        {
            IList<ContactDto> contacts = new List<ContactDto>();
            var isNationalArtist = false;

            if (entityType == EntityType.Artist)
            {
                var artist = this.Context.Artists.GetById(entityId);
                isNationalArtist = artist.IsNational;
            }

            if (isNationalArtist)
            {
                var nationalArtistContacts = this.Context.NationalArtistContacts.GetByNationalArtist(entityId);

                foreach (var nac in nationalArtistContacts)
                {
                    var contact = this.GetContactById(nac.ContactId);

                    if (contact != null)
                    {
                        contact.IsPrimary = nac.IsPrimary;
                        contacts.Add(contact);
                    }
                }
            }
            else
            {
                contacts = this.Context.Contacts.GetContacts(entityType, entityId);

                foreach (var c in contacts)
                {
                    foreach (var p in c.PhoneNumbers)
                    {
                        if (p.IsPrimaryPhone)
                        {
                            c.PrimaryPhoneNumber = p.Value;
                            break;
                        }
                    }
                }
            }

            return contacts;
        }

        public async Task<IList<ContactDto>> GetContactsAsync(EntityType entityType, int entityId)
        {
            IList<ContactDto> contacts = new List<ContactDto>();
            var isNationalArtist = false;

            if (entityType == EntityType.Artist)
            {
                var artist = await this.Context.Artists.GetByIdAsync(entityId);
                isNationalArtist = artist.IsNational;
            }

            if (isNationalArtist)
            {
                var nationalArtistContacts = await this.Context.NationalArtistContacts.GetByNationalArtistAsync(entityId);

                foreach (var nac in nationalArtistContacts)
                {
                    var contact = this.GetContactById(nac.ContactId);
                    if (contact != null)
                    {
                        contact.IsPrimary = nac.IsPrimary;
                        contacts.Add(contact);
                    }
                }
            }
            else
            {
                contacts = this.Context.Contacts.GetContacts(entityType, entityId);

                foreach (var c in contacts)
                {
                    foreach (var p in c.PhoneNumbers)
                    {
                        if (p.IsPrimaryPhone)
                        {
                            c.PrimaryPhoneNumber = p.Value;
                            break;
                        }
                    }
                }
            }

            return contacts;
        }

        public void SyncContacts(EntityType entityType, int entityId, IEnumerable<ContactDto> updatedContacts, IPrincipal user)
        {
            var existingContacts = this.GetContacts(entityType, entityId);
            var activeContacts = updatedContacts.Where(x => !x.IsDeleted);

            // Ensure all new contacts have a unique identifier.
            var newContacts = updatedContacts.Where(x => x.ContactId <= 0).ToArray();
            for (int i = 0; i < newContacts.Length; i++)
            {
                newContacts[i].ContactId = 0 - i;
            }

            // Get a list of all the existing contacts that still exist in the updated list.
            var contactsToKeep =
                from e in existingContacts
                join a in activeContacts on e.ContactId equals a.ContactId
                select e;

            // Update the existing contacts not being removed.
            foreach (var contactToKeep in contactsToKeep)
            {
                var updates = activeContacts.First(x => x.ContactId == contactToKeep.ContactId);

                contactToKeep.ContactTypeId = updates.ContactTypeId;
                contactToKeep.EmailAddress = updates.EmailAddress;
                contactToKeep.FirstName = updates.FirstName;
                contactToKeep.IsEmailDisabled = updates.IsEmailDisabled;
                contactToKeep.IsPrimary = updates.IsPrimary;
                contactToKeep.IsSigner = updates.IsSigner;
                contactToKeep.LastName = updates.LastName;
                contactToKeep.Notes = updates.Notes;
                contactToKeep.PhoneNumbers = updates.PhoneNumbers;
                contactToKeep.PreferredContactMethodId = updates.PreferredContactMethodId;
                contactToKeep.DisplayOrder = updates.DisplayOrder;

                contactToKeep.SetAsUpdated(user);

                this.Context.Contacts.Update(contactToKeep);
            }

            // Add new contacts, if necessary.
            var contactsToAdd = activeContacts.Except(contactsToKeep, x => x.ContactId);

            foreach (var contactToAdd in contactsToAdd)
            {
                contactToAdd.ContactId = 0;
                contactToAdd.EntityTypeId = (int)entityType;
                contactToAdd.EntityId = entityId;
                contactToAdd.SetAsCreated(user);

                this.Context.Contacts.Create(contactToAdd);
            }

            // Remove existing contacts, if necessary.
            var contactsToRemove = existingContacts.Except(contactsToKeep);

            foreach (var contactToRemove in contactsToRemove)
            {
                this.Context.Contacts.Delete(contactToRemove.ContactId, user.GetUserId());
            }
        }

        public ContactDto GetContactById(int id)
        {
            var dto = this.Context.Contacts.GetById(id);

            return dto;
        }

        public async Task<IList<ContactDto>> GetContactsByEmailAddressAsync(string emailAddress)
        {
            if (string.IsNullOrWhiteSpace(emailAddress))
            {
                throw new ArgumentNullException(nameof(emailAddress));
            }

            return await this.Context.Contacts.GetContactsByEmailAddressAsync(emailAddress);
        }

        public async Task<int> OptOutByEmailAddressAsync(string emailAddress)
        {
            if (string.IsNullOrWhiteSpace(emailAddress))
            {
                throw new ArgumentNullException(nameof(emailAddress));
            }

            var objectsAffected = 0;

            try
            {
                this.Context.BeginTransaction();

                var contacts = await this.Context.Contacts.GetContactsByEmailAddressAsync(emailAddress);

                var contactsToOptOut = contacts.Where(x => x.IsEmailDisabled == false);

                foreach (var contact in contactsToOptOut)
                {
                    contact.IsEmailDisabled = true;

                    await this.Context.Contacts.UpdateAsync(contact);

                    var history = new EntityHistoryDto
                    {
                        EntityId = contact.ContactId,
                        Type = EntityType.Contact,
                        Event = AuditEvent.ContactOptOut,
                        Description = emailAddress,
                        CreatedDate = DateTime.Now,
                        CreatedById = 0
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);

                    objectsAffected += 1;
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                ex.Data["EmailAddress"] = emailAddress;

                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return objectsAffected;
        }
    }
}
