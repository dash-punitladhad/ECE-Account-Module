﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class InquiryShoppingListService : IInquiryShoppingListService
    {
        public InquiryShoppingListService(IUnitOfWork context)
        {
            Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<InquiryShoppingListDto>> GetByInquiryIdAsync(int inquiryId)
        {
            var results = await this.Context.InquiryShoppingLists.GetByInquiryIdAsync(inquiryId);
            return results;
        }

        public async Task AddShoppingListItemAsync(InquiryShoppingListDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);
                await this.Context.InquiryShoppingLists.AddShoppingListItemAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateShoppingListItemAsync(int id, InquiryShoppingListDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);
                await this.Context.InquiryShoppingLists.UpdateShoppingListItemAsync(id, dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteShoppingListItemAsync(int id)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.InquiryShoppingLists.DeleteShoppingListItemAsync(id);

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }
    }
}
