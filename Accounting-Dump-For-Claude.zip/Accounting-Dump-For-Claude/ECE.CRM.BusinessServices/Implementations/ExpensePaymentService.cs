﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ExpensePaymentService : IExpensePaymentService
    {
        private readonly IGeneralLedgerService _generalLedgerService;

        private readonly IArtistChargeService _artistChargeService;

        public ExpensePaymentService(
            IUnitOfWork context,
            ILogger logger,
            IGeneralLedgerService generalLedgerService,
            IArtistChargeService artistChargeService)
        {
            this.Context = context;
            this.Logger = logger;
            this._generalLedgerService = generalLedgerService;
            this._artistChargeService = artistChargeService;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public static IEnumerable<ArtistChargeDto> GetLoansToRepay(IEnumerable<ArtistChargeDto> outstandingLoans, decimal grossAmount)
        {
            var remainingAmount = grossAmount;

            foreach (var outstandingLoan in outstandingLoans)
            {
                if (remainingAmount > decimal.Zero)
                {
                    var loanPaymentAmount = outstandingLoan.DeductionAmount;

                    remainingAmount -= loanPaymentAmount;

                    if (remainingAmount < decimal.Zero)
                    {
                        outstandingLoan.PaymentAmount += remainingAmount;
                        outstandingLoan.RemainingBalance += remainingAmount;
                    }

                    yield return outstandingLoan;
                }
            }
        }

        public static IEnumerable<Tuple<ContractTransactionDto, decimal>> GetDepositsToPay(IEnumerable<ContractTransactionDto> unpaidPayeeDeposits, decimal grossAmount, bool updatePaidAmount = false)
        {
            var remainingAmount = grossAmount;

            foreach (var unpaidPayeeDeposit in unpaidPayeeDeposits)
            {
                if (remainingAmount > decimal.Zero)
                {
                    var unpaidDepositAmount = unpaidPayeeDeposit.DueAmount;

                    remainingAmount -= unpaidDepositAmount;

                    if (remainingAmount < decimal.Zero)
                    {
                        if (updatePaidAmount)
                        {
                            unpaidPayeeDeposit.PaidAmount -= remainingAmount;
                        }

                        unpaidDepositAmount += remainingAmount;
                    }
                    else if (updatePaidAmount)
                    {
                        unpaidPayeeDeposit.PaidAmount = unpaidDepositAmount;
                    }

                    yield return Tuple.Create(unpaidPayeeDeposit, unpaidDepositAmount);
                }
            }
        }

        public async Task<ExpensePaymentDto> GetByIdAsync(int id)
        {
            var payment = await this.Context.ExpensePayments.GetByIdAsync(id);

            return payment;
        }

        public async Task<IList<ExpensePaymentDto>> GetByPayeeAndYearAsync(int contractEntityTypeId, int contractEntityId, int year)
        {
            var payments = await this.Context.ExpensePayments.GetByPayeeAndYearAsync(contractEntityTypeId, contractEntityId, year);

            return payments;
        }

        public async Task CreateAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                payment.SetAsCreated(user.GetUserId());

                await this.Context.ExpensePayments.CreateAsync(payment);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                payment.SetAsUpdated(user.GetUserId());

                await this.Context.ExpensePayments.UpdateAsync(payment);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            if (payment == null)
            {
                throw new ArgumentNullException(nameof(payment));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                if (payment.IsReadOnly)
                {
                    throw new ArgumentException($"Expense payment {payment.ExpensePaymentId} cannot be deleted because it is posted as part of batch {payment.ExpenseBatchId}");
                }

                payment.IsDeleted = true;
                payment.SetAsUpdated(user);

                await this.Context.ExpensePayments.UpdateAsync(payment);

                // Update the cached total payments amount at the batch level.
                var batch = await this.Context.ExpenseBatches.GetByIdAsync(payment.ExpenseBatchId);
                batch.BatchAmount = batch.ExpensePayments.Total(x => x.PaymentAmount);
                batch.SetAsUpdated(user);

                await this.Context.ExpenseBatches.UpdateAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdatePendingExpensePaymentAsync(ContractTransactionDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var transactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(dto.ExpensePaymentId.Value);

                await this.UpdatePendingExpensePaymentAsync(dto.ExpensePaymentId.Value, transactions, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentAmounts> GetExpensePaymentAmountsAsync(
            ExpensePaymentDto payment,
            IEnumerable<ContractTransactionDto> paymentTransactions,
            UpdatePendingExpensePaymentOptions options = UpdatePendingExpensePaymentOptions.Default)
        {
            var grossPaymentAmount = paymentTransactions
                .Where(x => x.IsExpense && x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                .Total(x => x.DueAmount);

            var deductionAmount = paymentTransactions
                .Where(x => x.IsIncome && x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                .Total(x => x.RequiredAmount);

            var hasArtistPaymentExpense =
                payment.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                paymentTransactions.Any(x => x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);

            Logger.LogInformation($"GetExpensePaymentAmounts: ExpensePaymentId {payment.ExpensePaymentId}, grossPaymentAmount {grossPaymentAmount:C}, deductionAmount {deductionAmount:C}");

            IEnumerable<ArtistChargeDto> loansToRepay = null;
            IEnumerable<ContractTransactionDto> depositsToPay = null;

            if (hasArtistPaymentExpense)
            {
                if ((options & UpdatePendingExpensePaymentOptions.ResyncLoanRepayments) == UpdatePendingExpensePaymentOptions.ResyncLoanRepayments)
                {
                    // Get any outstanding loans for the artist.
                    var outstandingLoans = await this.Context.ArtistCharges.GetArtistChargesByArtistIdAsync(payment.ContractEntityId);

                    // Filter out all but the loans there is sufficient money to pay.
                    loansToRepay = ExpensePaymentService.GetLoansToRepay(outstandingLoans, grossPaymentAmount);

                    // Get the total loan repayment amount to deduct from the artist payment.
                    deductionAmount += loansToRepay.Total(x => x.DeductionAmount);
                }
                else
                {
                    var existingRepayments = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(payment.ExpensePaymentId);

                    // Get the total loan repayment amount to deduct from the artist payment.
                    deductionAmount += existingRepayments.Total(x => x.TransactionAmount);
                }
            }

            var netPaymentAmount = decimal.Zero;

            if ((options & UpdatePendingExpensePaymentOptions.ResyncDeposits) == UpdatePendingExpensePaymentOptions.ResyncDeposits)
            {
                var unpaidPayeeDeposits = await this.Context.ContractTransactions.GetUnpaidIncomeRecordsByPayeeAsync(
                    payment.ContractEntityId,
                    (ContractEntityType)payment.ContractEntityTypeId);

                var deductedDeposits = ExpensePaymentService.GetDepositsToPay(unpaidPayeeDeposits, netPaymentAmount);

                var amountDeducted = deductedDeposits.Total(x => x.Item2);
                depositsToPay = deductedDeposits.Select(x => x.Item1);

                // Get the total deposit amount to deduct from the payment.
                deductionAmount = deductionAmount + amountDeducted;

                netPaymentAmount = grossPaymentAmount - deductionAmount;
            }
            else
            {
                var existingDeposits = await this.Context.ContractDeposits.GetCrossDeductionsAsync(payment.ExpensePaymentId);

                // Get the total loan repayment amount to deduct from the artist payment.
                deductionAmount += existingDeposits
                    .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                    .Total(x => x.AppliedAmount);

                netPaymentAmount = grossPaymentAmount - deductionAmount;
            }

            return new ExpensePaymentAmounts
            {
                DeductionAmount = deductionAmount,
                GrossAmount = grossPaymentAmount,
                PaymentAmount = netPaymentAmount,
                TransactionCount = paymentTransactions.Count(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold),
                LoansToRepay = loansToRepay,
                DepositsToPay = depositsToPay,
            };
        }

        public async Task UpdatePendingExpensePaymentAsync(
            int expensePaymentId,
            IEnumerable<ContractTransactionDto> paymentTransactions,
            IPrincipal user,
            UpdatePendingExpensePaymentOptions options = UpdatePendingExpensePaymentOptions.Default)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var payment = await this.Context.ExpensePayments.GetByIdAsync(expensePaymentId);
                if (payment.IsReadOnly)
                {
                    throw new ArgumentException($"Expense payment {payment.ExpensePaymentId} cannot be updated because it is posted as part of batch {payment.ExpenseBatchId}");
                }

                var paymentAmounts = await this.GetExpensePaymentAmountsAsync(payment, paymentTransactions, options);

                Logger.LogInformation($"UpdatePendingExpensePayment: {expensePaymentId} PaymentAmount {paymentAmounts.PaymentAmount:C}");

                var changeInPaymentAmount = payment.PaymentAmount - paymentAmounts.PaymentAmount;

                // Adjust the payment amount accordingly.
                payment.GrossAmount = paymentAmounts.GrossAmount;
                payment.PaymentAmount = paymentAmounts.PaymentAmount;
                payment.DeductionAmount = paymentAmounts.DeductionAmount;
                payment.TransactionCount = paymentAmounts.TransactionCount;
                payment.SetAsUpdated(user);

                await this.Context.ExpensePayments.UpdateAsync(payment);

                if ((options & UpdatePendingExpensePaymentOptions.ResyncLoanRepayments) == UpdatePendingExpensePaymentOptions.ResyncLoanRepayments)
                {
                    // Remove any existing loan repayments
                    var existingRepayments = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(payment.ExpensePaymentId, includeWithheld: true);
                    foreach (var existingRepayment in existingRepayments)
                    {
                        existingRepayment.IsDeleted = true;
                        existingRepayment.SetAsUpdated(user);

                        await this.Context.ArtistCharges.UpdateArtistChargeTransactionAsync(existingRepayment);
                    }

                    // Add any loans being repaid by this payment
                    await this.CreateLoanRepaymentTransactionsAsync(expensePaymentId, paymentAmounts.LoansToRepay, user);
                }

                if (changeInPaymentAmount != decimal.Zero)
                {
                    // Update the cached total payments amount at the batch level.
                    var batch = await this.Context.ExpenseBatches.GetByIdAsync(payment.ExpenseBatchId);
                    batch.BatchAmount = batch.BatchAmount - changeInPaymentAmount;
                    batch.SetAsUpdated(user);

                    await this.Context.ExpenseBatches.UpdateAsync(batch);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentDto> RemoveTransactionFromPaymentAsync(int contractTransactionId, int expensePaymentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var contractTransaction = await this.Context.ContractTransactions.GetByIdAsync(contractTransactionId);
                if (contractTransaction == null)
                {
                    throw new RemoveTransactionException($"Contract Transaction {contractTransactionId} Not Found");
                }

                if (contractTransaction.ExpensePaymentId == null)
                {
                    return null;
                }

                if (contractTransaction.ExpensePaymentId != expensePaymentId)
                {
                    throw new RemoveTransactionException($"Invalid Contract Transaction {contractTransactionId} for Expense Payment {expensePaymentId}");
                }

                var expensePayment = await this.GetByIdAsync(expensePaymentId);
                if (expensePayment.IsReadOnly)
                {
                    throw new RemoveTransactionException($"Cannot remove contract transaction {contractTransactionId} because it is posted as part of expense payment {expensePaymentId}");
                }

                // The amount required is positive for expenses and negative for income records (i.e. deposits)
                var amountBeingRemoved = contractTransaction.IsExpense
                    ? contractTransaction.RequiredAmount.GetValueOrDefault()
                    : -contractTransaction.RequiredAmount.GetValueOrDefault();

                if (amountBeingRemoved > expensePayment.PaymentAmount)
                {
                    /*
                     * An example when this will occur is removing an AREF when there is a deposit
                     * included in the payment.
                     */
                    throw new RemoveTransactionException($"Cannot remove contract transaction {contractTransactionId} because it would make the payment amount less than zero.");
                }

                contractTransaction.ExpensePaymentId = null;
                contractTransaction.ExpensePaymentStatusId = null;
                contractTransaction.SetAsUpdated(user);

                await this.Context.ContractTransactions.UpdateAsync(contractTransaction);

                var paymentTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePayment.ExpensePaymentId);
                if (paymentTransactions.Any())
                {
                    var resyncOptions = contractTransaction.IsIncome
                        ? UpdatePendingExpensePaymentOptions.ResyncNothing
                        : UpdatePendingExpensePaymentOptions.Default;

                    await this.UpdatePendingExpensePaymentAsync(
                        expensePayment.ExpensePaymentId,
                        paymentTransactions,
                        user,
                        resyncOptions);
                }
                else
                {
                    await this.DeleteAsync(expensePayment, user);
                }

                this.Context.Commit();

                return expensePayment;
            }
            catch (RemoveTransactionException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentDto> RemoveLoanRepaymentFromPaymentAsync(int artistChargeTransactionId, int expensePaymentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var artistChargeTransaction = await this.Context.ArtistCharges.GetArtistChargeTransactionAsync(artistChargeTransactionId);
                if (artistChargeTransaction == null)
                {
                    throw new RemoveTransactionException($"Artist Charge Transaction {artistChargeTransactionId} Not Found");
                }

                if (artistChargeTransaction.ExpensePaymentId == null)
                {
                    return null;
                }

                if (artistChargeTransaction.ExpensePaymentId != expensePaymentId)
                {
                    throw new RemoveTransactionException($"Invalid Artist Charge Transaction {artistChargeTransactionId} for Expense Payment {expensePaymentId}");
                }

                var expensePayment = await this.GetByIdAsync(expensePaymentId);
                if (expensePayment.IsReadOnly)
                {
                    throw new RemoveTransactionException($"Cannot remove artist charge transaction {artistChargeTransactionId} because it is posted as part of expense payment {expensePaymentId}");
                }

                artistChargeTransaction.ExpensePaymentStatusId = (int)ExpensePaymentStatus.Withhold;
                artistChargeTransaction.SetAsUpdated(user);

                await this.Context.ArtistCharges.UpdateArtistChargeTransactionAsync(artistChargeTransaction);

                var paymentTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePayment.ExpensePaymentId);
                if (paymentTransactions.Any())
                {
                    await this.UpdatePendingExpensePaymentAsync(
                        expensePayment.ExpensePaymentId,
                        paymentTransactions,
                        user,
                        UpdatePendingExpensePaymentOptions.ResyncNothing);
                }
                else
                {
                    await this.DeleteAsync(expensePayment, user);
                }

                this.Context.Commit();

                return expensePayment;
            }
            catch (RemoveTransactionException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentDto> RemoveCrossDeductionFromPaymentAsync(int contractDepositId, int expensePaymentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var contractDeposit = await this.Context.ContractDeposits.GetByIdAsync(contractDepositId);
                if (contractDeposit == null)
                {
                    throw new RemoveTransactionException($"Cross Deduction Deposit {contractDepositId} Not Found");
                }

                if (contractDeposit.ExpensePaymentId == null)
                {
                    return null;
                }

                if (contractDeposit.ExpensePaymentId != expensePaymentId)
                {
                    throw new RemoveTransactionException($"Invalid Cross Deduction Deposit {contractDepositId} for Expense Payment {expensePaymentId}");
                }

                var expensePayment = await this.GetByIdAsync(expensePaymentId);
                if (expensePayment.IsReadOnly)
                {
                    throw new RemoveTransactionException($"Cannot remove Cross Deduction Deposit {contractDepositId} because it is posted as part of expense payment {expensePaymentId}");
                }

                contractDeposit.ExpensePaymentStatusId = (int)ExpensePaymentStatus.Withhold;
                contractDeposit.SetAsUpdated(user);

                await this.Context.ContractDeposits.UpdateCrossDeductionDepositAsync(contractDeposit);

                var paymentTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePayment.ExpensePaymentId);
                if (paymentTransactions.Any())
                {
                    await this.UpdatePendingExpensePaymentAsync(
                        expensePayment.ExpensePaymentId,
                        paymentTransactions,
                        user,
                        UpdatePendingExpensePaymentOptions.ResyncNothing);
                }
                else
                {
                    await this.DeleteAsync(expensePayment, user);
                }

                this.Context.Commit();

                return expensePayment;
            }
            catch (RemoveTransactionException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateLoanRepaymentTransactionsAsync(int expensePaymentId, IEnumerable<ArtistChargeDto> loansToRepay, IPrincipal user)
        {
            if (loansToRepay == null)
            {
                return;
            }

            try
            {
                this.Context.BeginTransaction();

                var existingTransactions = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(expensePaymentId);

                foreach (var loanToRepay in loansToRepay)
                {
                    if (!existingTransactions.Any(x => x.ArtistChargeId == loanToRepay.ArtistChargeId))
                    {
                        await this._artistChargeService.CreateArtistChargeRepaymentAsync(loanToRepay, expensePaymentId, user);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task AddOneTimeChargeAsync(ArtistChargeDto artistCharge, int expensePaymentId, IPrincipal user)
        {
            if (artistCharge == null)
            {
                throw new ArgumentNullException(nameof(artistCharge));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                // create artist charge
                artistCharge.ArtistChargeStatusId = (int)ArtistChargeStatus.Outstanding;
                artistCharge.OriginalDate = DateTime.Now;

                // Start with owing the entire amount.
                artistCharge.RemainingBalance = artistCharge.OriginalAmount;

                artistCharge.SetAsCreated(user);

                await this.Context.ArtistCharges.CreateArtistChargeAsync(artistCharge);

                var paymentTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePaymentId);
                if (paymentTransactions.Any())
                {
                    await this.UpdatePendingExpensePaymentAsync(
                        expensePaymentId,
                        paymentTransactions,
                        user,
                        UpdatePendingExpensePaymentOptions.ResyncLoanRepayments);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdatePresenterRefundAsync(PresenterRefundDto refund, int expensePaymentId, IPrincipal user)
        {
            if (refund == null)
            {
                throw new ArgumentNullException(nameof(refund));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var payment = await this.Context.ExpensePayments.GetByIdAsync(expensePaymentId);
                if (payment == null)
                {
                    throw new ArgumentException($"Expense payment {expensePaymentId} not found");
                }

                if (payment.IsReadOnly)
                {
                    throw new ArgumentException($"Expense payment {payment.ExpensePaymentId} cannot be updated because it is posted as part of batch {payment.ExpenseBatchId}");
                }

                if (!refund.PayeeName.Equals(payment.PayeeName))
                {
                    payment.PayeeName = refund.PayeeName;
                    payment.SetAsUpdated(user);

                    await this.Context.ExpensePayments.UpdateAsync(payment);
                }

                var data = await this.Context.PresenterRefunds.GetByExpensePaymentIdAsync(expensePaymentId);
                if (data == null)
                {
                    data = refund;
                    data.ExpensePaymentId = expensePaymentId;
                    data.SetAsCreated(user);

                    await this.Context.PresenterRefunds.CreateAsync(data);
                }
                else
                {
                    data.MailingAddress1 = refund.MailingAddress1;
                    data.MailingAddress2 = refund.MailingAddress2;
                    data.MailingCity = refund.MailingCity;
                    data.MailingCountryId = refund.MailingCountryId;
                    data.MailingStateId = refund.MailingStateId;
                    data.MailingZip = refund.MailingZip;

                    data.SetAsUpdated(user);

                    await this.Context.PresenterRefunds.UpdateAsync(data);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
