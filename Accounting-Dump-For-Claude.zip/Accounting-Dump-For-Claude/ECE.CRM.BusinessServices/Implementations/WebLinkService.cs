﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;

    public class WebLinkService : IWebLinkService
    {
        public WebLinkService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public IList<WebLinkDto> GetWebLinks(EntityType entityType, int entityId)
        {
            return this.Context.WebLinks.GetWebLinks(entityType, entityId);
        }

        public void SyncWebLinks(EntityType entityType, int entityId, IEnumerable<WebLinkDto> updatedWebLinks, IPrincipal user)
        {
            var linkOrder = 0;
            var existingWebLinks = this.GetWebLinks(entityType, entityId);
            var activeWebLinks = updatedWebLinks.Where(x => !x.IsDeleted);

            foreach(var link in updatedWebLinks)
            {
                linkOrder++;
                link.DisplayOrder = linkOrder;
            }

            // Get a list of still-existing web links in the updated list.
            var webLinksToKeep =
                from w in existingWebLinks
                join a in activeWebLinks on w.WebLinkId equals a.WebLinkId
                select w;
            
            // Update web links that have not been deleted
            foreach (var webLinkToKeep in webLinksToKeep)
            {
                var updates = activeWebLinks.First(x => x.WebLinkId == webLinkToKeep.WebLinkId);
                var displayOrder = updatedWebLinks.FirstOrDefault(_=>_.WebLinkId == webLinkToKeep.WebLinkId).DisplayOrder;

                webLinkToKeep.WebLinkTypeId = updates.WebLinkTypeId;
                webLinkToKeep.Url = updates.Url;
                webLinkToKeep.Description = updates.Description;
                webLinkToKeep.DisplayOrder = displayOrder;
                webLinkToKeep.SetAsUpdated(user);

                this.Context.WebLinks.Update(webLinkToKeep);
            }

            // Add new web links, if necessary.
            var webLinksToAdd = activeWebLinks.Except(webLinksToKeep, x => x.WebLinkId);

            foreach (var webLinkToAdd in webLinksToAdd)
            {
                webLinkToAdd.WebLinkId = 0;
                webLinkToAdd.EntityTypeId = (int)entityType;
                webLinkToAdd.EntityId = entityId;
                webLinkToAdd.SetAsCreated(user);
                linkOrder++;
                webLinkToAdd.DisplayOrder = linkOrder;
                this.Context.WebLinks.Create(webLinkToAdd);
            }

            // Delete existing web links, if necessary.
            var webLinksToRemove = existingWebLinks.Except(webLinksToKeep);

            foreach (var webLinkToRemove in webLinksToRemove)
            {
                this.Context.WebLinks.Delete(webLinkToRemove.WebLinkId, user.GetUserId());
            }
        }
    }
}
