﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractArtistAgreementService : IContractArtistAgreementService
    {
        public ContractArtistAgreementService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ContractArtistAgreementDto>> GetByContractIdAsync(int contractId)
        {
            return await this.Context.ContractArtistAgreements.GetByContractIdAsync(contractId);
        }

        public async Task<ContractArtistAgreementDto> GetByContractArtistIdAsync(int artistId)
        {
            return await this.Context.ContractArtistAgreements.GetByContractArtistIdAsync(artistId);
        }

        public async Task<ContractArtistAgreementDto> GetByIdAsync(int id)
        {
            return await this.Context.ContractArtistAgreements.GetByIdAsync(id);
        }

        public async Task CreateAsync(ContractArtistAgreementDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);
                await this.Context.ContractArtistAgreements.CreateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new System.Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractArtistAgreementDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user.GetUserId());
                await this.Context.ContractArtistAgreements.UpdateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new System.Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(ContractArtistAgreementDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var artistAgreementDocuments = (await this.Context.ContractArtistAgreements.GetArtistAgreementDocumentsAsync(dto.ContractId))
                                               .Where(x => x.ContractDocumentId == dto.ContractDocumentId).ToList();

                foreach (var doc in artistAgreementDocuments)
                {
                    this.Context.Documents.RemoveDocumentFrom(EntityType.Contract, dto.ContractId, doc.DocumentId, user.GetUserId());
                    await this.Context.ContractDocuments.DeleteAsync(doc.ContractDocumentId);
                }

                dto.SetAsUpdated(user);

                await this.Context.ContractArtistAgreements.DeleteAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new System.Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<IList<ContractArtistAgreementTermDto>> GetTermsForAgreementAsync(int id)
        {
            return await this.Context.ContractArtistAgreements.GetTermsForAgreementAsync(id);
        }
    }
}
