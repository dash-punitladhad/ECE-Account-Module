﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    /// <summary>
    /// Roles and Permissions Implementation
    /// </summary>
    /// <seealso cref="ECE.CRM.BusinessServices.IRolePermissionService" />
    public class RolePermissionService : IRolePermissionService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RolePermissionService"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public RolePermissionService(IUnitOfWork context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public IUnitOfWork Context { get; private set; }

        /// <summary>
        /// Gets the permissions for user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of ECEPermissions.</returns>
        public async Task<IList<ECEPermissions>> GetPermissionsForUserAsync(int userId)
        {
            return await this.Context.RolePermissions.GetUserPermissionsAsync(userId);
        }

        public async Task<IList<AppUserRolePermissionDto>> GetUserRolePermissionsAsync(int userId)
        {
            var results = await this.Context.RolePermissions.GetUserRolePermissionsAsync(userId);

            return results;
        }

        public async Task<IList<ECERoleDto>> GetAllRolesAsync(bool? isActive = null)
        {
            return await this.Context.RolePermissions.GetAllRolesAsync(isActive);
        }

        public async Task<IList<AppUserDto>> GetUsersForRoleAsync(int roleId)
        {
            return await this.Context.RolePermissions.GetUsersForRoleAsync(roleId);
        }

        public async Task<IList<ECEPermissions>> GetPermissionsForRoleAsync(int roleId)
        {
            return await this.Context.RolePermissions.GetPermissionsForRoleAsync(roleId);
        }

        public async Task<IList<RolePermissionDto>> GetAllRolePermissionsAsync()
        {
            return await this.Context.RolePermissions.GetAllRolePermissionsAsync();
        }

        public async Task<IList<ECEPermissionDto>> GetAllPermissionsAsync()
        {
            return await this.Context.RolePermissions.GetAllPermissionsAsync();
        }

        public async Task<IList<ECERoleDto>> GetRolesForPermissionAsync(int permissionId)
        {
            return await this.Context.RolePermissions.GetRolesForPermissionAsync(permissionId);
        }

        public async Task<IList<AppUserDto>> GetUsersForPermissionAsync(int permissionId)
        {
            return await this.Context.RolePermissions.GetUsersForPermissionAsync(permissionId);
        }

        /// <summary>
        /// Gets the roles for user.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of AppUserRoles.</returns>
        public async Task<IList<AppUserRoleDto>> GetRolesForUserAsync(int userId)
        {
            return await this.Context.RolePermissions.GetUserRolesAsync(userId);
        }

        public async Task<IList<AppUserRoleDto>> GetRolesForUserAsync(int userId, bool includeDeleted)
        {
            return await this.Context.RolePermissions.GetUserRolesAsync(userId, includeDeleted);
        }

        public async Task<AppUserRoleDto> GetRoleForUserEntity(int userId, ECERole role, int entityId)
        {
            return await this.Context.RolePermissions.GetRoleForUserEntity(userId, role, entityId);
        }

        public async Task ToggleUserRoleDeletedStatusAsync(int appUserId, bool markAsDeleted)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.RolePermissions.ToggleUserRoleDeletedStatusAsync(appUserId, markAsDeleted);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task CreateAppUserRoleAsync(AppUserRoleDto appUserRole, IPrincipal user)
        {
            if (appUserRole == null)
            {
                throw new ArgumentNullException(nameof(appUserRole));
            }

            this.Context.BeginTransaction();
            try
            {
                appUserRole.SetAsCreated(user);

                await this.Context.RolePermissions.CreateAppUserRoleAsync(appUserRole);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<int?> GetEntityIdFromRole(int userId, int roleId)
        {
            return await this.Context.RolePermissions.GetEntityIdFromRole(userId, roleId);
        }

        public async Task<List<AppUserRoleDto>> SyncRolesAsync(int appUserId, IEnumerable<AppUserRoleDto> updatesRoles, IPrincipal user)
        {
            List<AppUserRoleDto> appUserRoles = new List<AppUserRoleDto>();
            var existingRoles = await this.GetRolesForUserAsync(appUserId);
            var activeRoles = updatesRoles.Where(x => !x.IsDeleted);

            // Get a list of still-existing app user roles in the updated list.
            var rolesToKeep =
                from r in existingRoles
                join a in activeRoles on r.Id equals a.Id
                select r;

            // Update app user roles that have not been deleted
            foreach (var roleToKeep in rolesToKeep)
            {
                var updates = activeRoles.First(x => x.Id == roleToKeep.Id);
                appUserRoles.Add(new AppUserRoleDto() { RoleId = roleToKeep.RoleId, IsDeleted = true });
                roleToKeep.RoleId = updates.RoleId;
                roleToKeep.OfficeId = updates.OfficeId;

                roleToKeep.SetAsUpdated(user);

               
                appUserRoles.Add(new AppUserRoleDto() { RoleId = roleToKeep.RoleId, IsDeleted = false });

                await this.Context.RolePermissions.UpdateAppUserRoleAsync(roleToKeep);
            }

            // Add new app user roles, if necessary.
            var rolesToAdd = activeRoles.Except(rolesToKeep, x => x.Id);

            foreach (var roleToAdd in rolesToAdd)
            {
                roleToAdd.AppUserId = appUserId;
                roleToAdd.RoleId = roleToAdd.RoleId;
                roleToAdd.OfficeId = roleToAdd.OfficeId;
                roleToAdd.SetAsCreated(user);

                await this.Context.RolePermissions.CreateAppUserRoleAsync(roleToAdd);
            }
            foreach (var roleToAdd in rolesToAdd)
            {
                roleToAdd.IsDeleted = false;
                appUserRoles.Add(roleToAdd);
            }


            // Delete existing app user roles, if necessary.
            var rolesToRemove = existingRoles.Except(rolesToKeep);

            foreach (var roleToRemove in rolesToRemove)
            {
                await this.Context.RolePermissions.DeleteAppUserRoleAsync(roleToRemove.Id, user.GetUserId());
            }

            foreach (var roleToRemove in rolesToRemove)
            {
                roleToRemove.IsDeleted = true;
                appUserRoles.Add(roleToRemove);
            }

            return appUserRoles;
        }
    }
}
