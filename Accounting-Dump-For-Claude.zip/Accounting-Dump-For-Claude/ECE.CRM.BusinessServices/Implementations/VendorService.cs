﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class VendorService : IVendorService
    {
        private readonly IContactService _contactService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ITINHistoryService _tinHistoryService;

        public VendorService(
            IUnitOfWork context,
            IContactService contactService,
            IEntityHistoryService entityHistoryService,
            ITINHistoryService tinHistoryService)
        {
            this.Context = context;

            this._contactService = contactService;
            this._entityHistoryService = entityHistoryService;
            this._tinHistoryService = tinHistoryService;
        }

        public VendorService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<VendorDto> GetByIdAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            return await Context.Vendors.GetByIdAsync(id);
        }

        public Task<IList<VendorDto>> GetByCharsAsync(string chars)
        {
            return this.Context.Vendors.GetByCharsAsync(chars);
        }

        public async Task<bool> CheckForDuplicatesAsync(int vendorId, string vendorName)
        {
            if (string.IsNullOrWhiteSpace(vendorName))
            {
                throw new ArgumentNullException(nameof(vendorName));
            }

            var result = await this.Context.Vendors.CheckForDuplicatesAsync(vendorId, vendorName.Trim());

            return result;
        }

        public Task<IList<VendorDto>> GetByCriteriaAsync(VendorSearchCriteriaDto criteria)
        {
            SecurityHelper.EncryptFederalTINCriteria(criteria);

            return this.Context.Vendors.GetByCriteriaAsync(criteria);
        }

        public async Task CreateAsync(VendorDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                SecurityHelper.EncryptFederalTIN(dto);

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                await this.Context.Vendors.CreateAsync(dto);

                this._contactService.SyncContacts(EntityType.Vendor, dto.VendorId, dto.Contacts, user);

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.VendorId,
                    Type = EntityType.Vendor,
                    Event = AuditEvent.Created,
                    Description = "Created",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Vendor, null, ex);
            }
        }

        public async Task UpdateAsync(VendorDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var original = await this.GetByIdAsync(dto.VendorId);

            try
            {
                if (original == null)
                {
                    throw new Exception($"Vendor {dto.VendorId} not found.");
                }

                dto.SetAsUpdated(user);

                SecurityHelper.EncryptFederalTIN(dto);

                if (SecurityHelper.TINHasChanged(original, dto))
                {
                    // Save previous TIN
                    await _tinHistoryService.CreateTINHistoryAsync(original, user);
                }

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                await this.Context.Vendors.UpdateAsync(dto);

                this._contactService.SyncContacts(EntityType.Vendor, dto.VendorId, dto.Contacts, user);

                await this.AuditUpdatedEntity(original, dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Vendor, dto.VendorId, ex);
            }
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateNotesAsync(int id, string notes)
        {
            try
            {
                this.Context.BeginTransaction();

                var vendor = await this.GetByIdAsync(id);
                if (vendor == null)
                {
                    throw new Exception($"Vendor {id} not found.");
                }

                vendor.Notes = notes;

                await this.Context.Vendors.UpdateAsync(vendor);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Vendor, id, ex);
            }
        }

        private async Task AuditUpdatedEntity(VendorDto original, VendorDto updated, IPrincipal user)
        {
            // Audit Vendor Name change
            if (!string.Equals(updated.Name, original.Name, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.Name))
                {
                    original.Name = "--";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = updated.VendorId,
                    Type = EntityType.Vendor,
                    Event = AuditEvent.VendorNameChanged,
                    Description = original.Name,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Payee Name change
            if (!string.Equals(updated.PayeeName, original.PayeeName, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.PayeeName))
                {
                    original.PayeeName = "--";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = updated.VendorId,
                    Type = EntityType.Vendor,
                    Event = AuditEvent.VendorPayeeNameChanged,
                    Description = original.PayeeName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Payee Name change
            if (!string.Equals(updated.TaxIdentificationNumber, original.TaxIdentificationNumber, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.TaxIdentificationNumber))
                {
                    original.TaxIdentificationNumber = string.Empty;
                }

                string hiddenTIN = SecurityHelper.HideTaxIdentificationNumber(original.TaxIdentificationNumber) ?? "--";

                var history = new EntityHistoryDto
                {
                    EntityId = updated.VendorId,
                    Type = EntityType.Vendor,
                    Event = AuditEvent.VendorTINChanged,
                    Description = hiddenTIN,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }
    }
}
