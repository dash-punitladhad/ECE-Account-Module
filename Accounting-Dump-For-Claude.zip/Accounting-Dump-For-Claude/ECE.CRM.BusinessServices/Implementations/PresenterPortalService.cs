﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public class PresenterPortalService : IPresenterPortalService
    {
        public PresenterPortalService(
            IUnitOfWork context,
            ILogger logger)
        {
            this.Context = context;
            this.Logger = logger;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<WeddingQuestionnaireDataDto> GetWeddingQuestionnaireDataAsync(ContractDto contract)
        {
            if (contract == null)
            {
                throw new ArgumentNullException(nameof(Contract));
            }

            var data = new WeddingQuestionnaireDataDto();

            data.PresenterAccountName = contract.PresenterAccountName;
            data.ContractId = contract.ContractId;

            var presenterPrimaryContact = await this.Context.Contacts.GetPrimaryContactAsync(EntityType.Contract, contract.ContractId);
            if (presenterPrimaryContact != null && !string.IsNullOrWhiteSpace(presenterPrimaryContact.EmailAddress))
            {
                data.PresenterEmailAddress = presenterPrimaryContact.EmailAddress?.Trim();
            }

            var agent = await this.Context.Users.GetByIdAsync(contract.AgentId);

            data.AgentId = agent.AppUserId.GetValueOrDefault();
            data.AgentUserId = agent.AgentUserId;

            if (contract.ContractArtists == null || !contract.ContractArtists.Any())
            {
                contract.ContractArtists = await this.Context.ContractArtists.GetByContractIdAsync(contract.ContractId);
            }

            var contractArtist = contract.ContractArtists.FirstOrDefault();

            if (contractArtist != null)
            {
                data.ArtistId = contractArtist.ArtistId;

                var artistPrimaryContact = await this.Context.Contacts.GetPrimaryContactAsync(EntityType.Artist, contractArtist.ArtistId);
                if (artistPrimaryContact != null && !string.IsNullOrWhiteSpace(artistPrimaryContact.EmailAddress))
                {
                    data.ArtistEmailAddress = artistPrimaryContact.EmailAddress?.Trim();
                }

                var eventDatesForArtist = await this.Context.ContractArtistEventDates.GetByContractArtistIdAsync(contractArtist.ContractArtistId);

                data.FirstEventDate = eventDatesForArtist.FirstOrDefault()?.EventDate;
            }

            // Use the booking agent's email address if an email address is not on file for the Artist.
            if (string.IsNullOrWhiteSpace(data.ArtistEmailAddress))
            {
                data.ArtistEmailAddress = agent.Username;
            }

            // Use the booking agent's email address if an email address is not on file for the Contract.
            if (string.IsNullOrWhiteSpace(data.PresenterEmailAddress))
            {
                data.PresenterEmailAddress = agent.Username;
            }

            return data;
        }
    }
}
