﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;

namespace ECE.CRM.BusinessServices.Implementations
{
    public class KeyProcessService : IKeyProcessService
    {
        public IUnitOfWork Context { get; private set; }
        public KeyProcessService(
            IUnitOfWork context)
        {
            this.Context = context;
        }


        public async Task<IList<KeyProcessDto>> GetAllKeyProcessAsync()
        {
            return await this.Context.KeyProcessDao.GetAllAsync();
        }


        public async Task<KeyProcessDto> GetById(int id)
        {
            return await this.Context.KeyProcessDao.GetByIdAsync(id);
        }

        public async Task Create(KeyProcessDto keyProcessDto, IPrincipal user)
        {
            if (keyProcessDto == null)
            {
                throw new ArgumentNullException(nameof(keyProcessDto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            keyProcessDto.SetAsCreated(user);
            await this.Context.KeyProcessDao.Create(keyProcessDto);
            this.Context.Commit();
        }

        public async Task Edit(KeyProcessDto keyProcessDto, IPrincipal user)
        {
            if (keyProcessDto == null)
            {
                throw new ArgumentNullException(nameof(keyProcessDto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            this.Context.BeginTransaction();
            keyProcessDto.SetAsUpdated(user);
            await this.Context.KeyProcessDao.Edit(keyProcessDto);
            this.Context.Commit();
        }


    }
}
