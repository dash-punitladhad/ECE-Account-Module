﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistFeedbackService : IArtistFeedbackService
    {
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;

        public ArtistFeedbackService(
            IUnitOfWork context,
            ILookupService lookupService,
            IAlertService alertService)
        {
            this.Context = context;
            this._lookupService = lookupService;
            this._alertService = alertService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<ArtistFeedbackDto> GetFeedbackByIdAsync(int feedbackId)
        {
            var feedback = await this.Context.ArtistFeedback.GetFeedbackByIdAsync(feedbackId);

            return feedback;
        }

        public async Task<IList<ArtistFeedbackDto>> GetAllFeedbackByArtistAsync(int artistId)
        {
            var feedbacks = await this.Context.ArtistFeedback.GetAllFeedbackByArtistAsync(artistId);

            return feedbacks;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetAllFeedbackByPresenterAsync(int presenterId)
        {
            var feedbacks = await this.Context.ArtistFeedback.GetAllFeedbackByPresenterAsync(presenterId);

            return feedbacks;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetMostRecentFeedbackByArtistAsync(int artistId, TimeSpan duration, int maxResults)
        {
            var feedbacks = await this.Context.ArtistFeedback.GetMostRecentFeedbackByArtistAsync(artistId, duration, maxResults);

            return feedbacks;
        }

        public async Task<IList<ArtistFeedbackDetailsDto>> GetDetailsByArtistAsync(int artistId)
        {
            var feedbacks = await this.Context.ArtistFeedback.GetDetailsByArtistAsync(artistId);

            return feedbacks;
        }

        public async Task<ArtistFeedbackDetailsDto> GetDetailsByIdAsync(int feedbackId)
        {
            var feedbacks = await this.Context.ArtistFeedback.GetDetailsByIdAsync(feedbackId);

            return feedbacks;
        }

        public async Task CreateAsync(ArtistFeedbackDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            dto.SetAsCreated(user);
            dto.ReviewDate = dto.CreatedDate;

            if (!string.IsNullOrEmpty(dto.Response))
            {
                // Record who gave the response and when they did it
                dto.AgentId = dto.CreatedById;
                dto.ResponseDate = dto.CreatedDate;
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistFeedback.CreateAsync(dto);

                // When created via the portal, send alerts to the booking agent on the contract,
                // and responsible agent for the artist (if one exists, and isn't the booking agent).
                if (dto.PresenterPortalId > 0)
                {
                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ArtistFeedbackCreated);

                    var artist = await this.Context.Artists.GetByIdAsync(dto.ArtistId);

                    var contract = await this.Context.Contracts.GetByIdAsync(dto.ContractId);

                    var alertText = appEvent.Text
                        .Replace("{ArtistName}", artist.Name)
                        .Replace("{ContractId}", dto.ContractId.ToString());

                    var bookingAgentId = contract.AgentId;

                    var alert = new AlertDto
                    {
                        AppUserId = bookingAgentId,
                        Description = alertText,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Artist,
                        EntityId = dto.ArtistId,
                        AppEventTypeId = (int)AppEventType.ArtistFeedbackCreated
                    };

                    await this._alertService.CreateAsync(alert, user);

                    var responsibleAgentId = artist.AgentId;

                    if (responsibleAgentId.HasValue && responsibleAgentId.Value != bookingAgentId)
                    {
                        alert = new AlertDto
                        {
                            AppUserId = responsibleAgentId.Value,
                            Description = alertText,
                            IsRead = false,
                            EntityTypeId = (int)EntityType.Artist,
                            EntityId = dto.ArtistId,
                            AppEventTypeId = (int)AppEventType.ArtistFeedbackCreated
                        };

                        await this._alertService.CreateAsync(alert, user);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<List<ContractFeedbackOptionDto>> GetAvailableContracts(int artistId)
        {
            var months = -6;
            var startTime = DateTime.Now.AddMonths(months);

            return await this.Context.Contracts.GetByArtistIdSinceEventDateAsync(artistId, startTime);
        }

        public async Task UpdateAsync(ArtistFeedbackDto dto, IPrincipal user)
        {
            dto.SetAsUpdated(user);

            // Agent is making the update
            dto.AgentId = user.GetUserId();

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ArtistFeedback.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
