﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public enum PayeeType
    {
        Presenter = 1,
        Artist = 2,
        ECECommission = 3,
        ECEOther = 4,
        Reseller = 5,
        Vendor = 6,
    }
}
