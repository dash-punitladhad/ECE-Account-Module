﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class InquiryService : IInquiryService
    {
        private readonly IBlueCardService _blueCardService;
        private readonly IAlertService _alertService;
        private readonly ILookupService _lookupService;
        private readonly IGenreTypeService<InquiryGenreTypeDto> _inquiryGenreTypeService;
        private readonly IInquiryRequestedArtistService _inquiryRequestedArtistService;

        public InquiryService(
            IUnitOfWork context,
            IBlueCardService blueCardService,
            IAlertService alertService,
            ILookupService lookupService,
            IGenreTypeService<InquiryGenreTypeDto> inquiryGenreTypeService,
            IInquiryRequestedArtistService inquiryRequestedArtistService)
        {
            Context = context;
            this._blueCardService = blueCardService;
            this._alertService = alertService;
            this._lookupService = lookupService;
            this._inquiryGenreTypeService = inquiryGenreTypeService;
            this._inquiryRequestedArtistService = inquiryRequestedArtistService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<InquiryDto> GetInquiryByIdAsync(int id)
        {
            var result = await this.Context.Inquiries.GetInquiryByIdAsync(id);
            return result;
        }

        public InquiryDto GetInquiryById(int id)
        {
            var result = this.Context.Inquiries.GetInquiryById(id);
            return result;
        }

        public async Task<IList<InquiryDto>> GetInquiriesByAgentAsync(int agentId)
        {
            var results = await this.Context.Inquiries.GetInquiriesByAgentAsync(agentId);
            return results;
        }

        public async Task<IList<InquiryDto>> GetInquiriesByBlueCardAsync(int blueCardId)
        {
            var results = await this.Context.Inquiries.GetInquiriesByBlueCardAsync(blueCardId);
            return results;
        }

        public async Task<IList<InquirySearchResultDto>> GetInquiriesByCriteriaAsync(InquirySearchCriteriaDto criteria)
        {
            var results = await this.Context.Inquiries.GetInquiriesByCriteriaAsync(criteria);
            return results;
        }

        public async Task CreateAsync(InquiryDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            try
            {
                dto.SetAsCreated(user);

                var selectedGenreTypes = dto.InquiryGenreTypes.Select(x => x.GenreTypeId).ToList();
                dto.InquiryGenreTypes.Clear();

                if (dto.InquiryRequestedArtists != null)
                {
                    if (dto.InquiryRequestedArtists.Any())
                    {
                        foreach (var artist in dto.InquiryRequestedArtists)
                        {
                            artist.SetAsCreated(user);
                        }
                    }
                }

                await this.Context.Inquiries.CreateAsync(dto);

                await this._inquiryGenreTypeService.SyncChildrenAsync(dto.InquiryId, selectedGenreTypes);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Inquiry, dto.InquiryId, ex);
            }
        }

        public async Task<string> GetByCriteriaExportAsync(InquirySearchCriteriaDto criteriaDto)
        {
            var results = await this.Context.Inquiries.GetByCriteriaExportAsync(criteriaDto);

            return results;
        }

        public async Task UpdateAsync(InquiryDto dto, IPrincipal user, bool sendAlert = false)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            try
            {
                dto.SetAsUpdated(user);

                var selectedGenreTypes = dto.InquiryGenreTypes.Select(x => x.GenreTypeId).ToList();
                dto.InquiryGenreTypes.Clear();

                await this.Context.Inquiries.UpdateAsync(dto);

                await this._inquiryGenreTypeService.SyncChildrenAsync(dto.InquiryId, selectedGenreTypes);

                if (sendAlert)
                {
                    var blueCardId = dto.BlueCardId;
                    var blueCard = await this._blueCardService.GetBlueCardByIdAsync(blueCardId);
                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.InquiryResponded);
                    var alertDto = new AlertDto()
                    {
                        AppUserId = blueCard.AgentId,
                        EntityTypeId = (int)EntityType.BlueCard,
                        Description = appEvent.Text,
                        EntityId = blueCardId,
                        AppEventTypeId = (int)AppEventType.InquiryResponded
                    };

                    await this._alertService.CreateAsync(alertDto, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Inquiry, dto.InquiryId, ex);
            }
        }
    }
}
