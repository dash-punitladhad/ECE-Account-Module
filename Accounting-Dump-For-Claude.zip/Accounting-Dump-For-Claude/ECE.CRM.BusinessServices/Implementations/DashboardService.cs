﻿namespace ECE.CRM.BusinessServices
{
    using Dapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Microsoft.PowerBI.Api;
    using Microsoft.PowerBI.Api.Models;
    using Microsoft.Rest;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class DashboardService : IDashboardService
    {
        public DashboardService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<RankedAgentDto>> GetTopAgentsByTransactionsAsync(
            int transactionType,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.Year, 1, 1);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetTopAgentsByTransactionsAsync(
                       transactionType,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<decimal> GetBlueCardConversionRateByAgentAsync(
            int agentId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.Year, 1, 1);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            return await this.Context.Dashboard.GetBlueCardConversionRateByAgentAsync(
                       agentId,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<decimal> GetAverageContractGrossByAgentAsync(
            int agentId,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.Year, 1, 1);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetAverageContractGrossByAgentAsync(
                       agentId,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<IList<string>> GetTopArtistsByAgentAsync(
            int agentId,
            int numberOfTopArtists,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.Year, 1, 1);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetTopArtistsByAgentAsync(
                       agentId,
                       numberOfTopArtists,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypeByAgentAsync(
            int agentId,
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!maxRecordsReturned.HasValue)
            {
                maxRecordsReturned = MobiusConfiguration.GetInt32("Search.MaxResults", 10);
            }

            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.Year, 1, 1);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetContractEventTypeByAgentAsync(
                       agentId,
                       maxRecordsReturned.Value,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public Task<IList<UpcomingEventWidgetDto>> GetEventsByCriteriaAsync(
            int? agentId = null,
            int? officeId = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            bool? isPublic = null,
             List<int> userOffices = null,
            bool includeCreated = false)
        {
            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            if (includeCreated && !contractStatuses.Contains((int)ContractStatus.Created))
            {
                contractStatuses.Add((int)ContractStatus.Created);
            }

            return this.Context.Dashboard.GetEventsByCriteriaAsync(
                contractStatuses,
                startDate,
                endDate,
                agentId,
                officeId,
                userOffices,
                isPublic);
        }
        public async Task<string> BuildCriteriaWhereClause(
            int? agentId = null,
            int? officeId = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            bool? isPublic = null,
            List<int> userOffices = null,
            bool includeCreated = false)
        {
            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            if (includeCreated && !contractStatuses.Contains((int)ContractStatus.Created))
            {
                contractStatuses.Add((int)ContractStatus.Created);
            }
            return await this.Context.Dashboard.BuildCriteriaWhereClause(
                contractStatuses,
                startDate,
                endDate,
                agentId,
                officeId,
                userOffices,
                isPublic);
        }
            public async Task<AgentStatsDto> GetStatsByAgentAsync(int agentId)
        {
            var agentStats = new AgentStatsDto();

            var topRankedAgents = await this.GetTopAgentsByTransactionsAsync((int)ContractTransactionType.Commission);
            var agent = topRankedAgents.FirstOrDefault(a => a.AgentId == agentId);
            var blueCardConversionRate = await this.GetBlueCardConversionRateByAgentAsync(agentId);
            var averageContractGross = await this.GetAverageContractGrossByAgentAsync(agentId);
            var top3Artists = await this.GetTopArtistsByAgentAsync(agentId, 3);
            var agentEventTypes = await this.GetContractEventTypeByAgentAsync(agentId, 10);

            agentStats.YtdCommissionRankInCompany = agent?.Rank.GetValueOrDefault();
            agentStats.BlueCardConversionRate = blueCardConversionRate;
            agentStats.AverageContractGross = averageContractGross;
            agentStats.TopArtistsByGross = top3Artists;
            agentStats.AgentEventTypes = agentEventTypes;

            return agentStats;
        }

        public async Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypesByOfficeAsync(
            int officeId,
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!maxRecordsReturned.HasValue)
            {
                maxRecordsReturned = MobiusConfiguration.GetInt32("Search.MaxResults", 10);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetContractEventTypesByOfficeAsync(
                       officeId,
                       maxRecordsReturned.Value,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<IList<AgentEventTypeWidgetDto>> GetContractEventTypesAsync(
            int? maxRecordsReturned = null,
            List<int> contractStatuses = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!maxRecordsReturned.HasValue)
            {
                maxRecordsReturned = MobiusConfiguration.GetInt32("Search.MaxResults", 10);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetContractEventTypesAsync(
                       maxRecordsReturned.Value,
                       contractStatuses,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<IList<SalesPerformanceDto>> GetSalesPerformanceStatsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            int officeId,
            IList<int> contractStatusesForSales = null,
            IList<int> contractStatusesForCollections = null)
        {
            if (contractStatusesForSales == null || !contractStatusesForSales.Any())
            {
                contractStatusesForSales = new List<int>
                                               {
                                                   (int)ContractStatus.Issued,
                                                   (int)ContractStatus.FullyExecuted,
                                                   (int)ContractStatus.Completed
                                               };
            }

            if (contractStatusesForCollections == null || !contractStatusesForCollections.Any())
            {
                contractStatusesForCollections =
                    new List<int>
                        {
                            (int)ContractStatus.Issued,
                            (int)ContractStatus.FullyExecuted,
                            (int)ContractStatus.Completed,
                            (int)ContractStatus.Canceled,
                            (int)ContractStatus.PartiallyCanceled
                        };
            }

            var results = await this.Context.Dashboard.GetSalesPerformanceStatsAsync(
                mtdStartDate,
                mtdEndDate,
                ytdStartDate,
                ytdEndDate,
                contractStatusesForSales,
                contractStatusesForCollections,
                officeId);

            results = results.OrderByDescending(x => x.MtdSales).ToList();

            for (int i = 0; i < results.Count; i++)
            {
                var r = results[i];
                r.Rank = i + 1;
            }

            return results;
        }

        public async Task<IList<BusinessPerformanceDto>> GetBusinessPerformanceAsync(
            DateTime startDate,
            DateTime endDate,
            int officeId,
            IList<int> contractStatuses = null)
        {
            if (contractStatuses == null || !contractStatuses.Any())
            {
                contractStatuses = this.ValidContractStatuses();
            }

            return await this.Context.Dashboard.GetBusinessPerformanceAsync(
                       startDate,
                       endDate,
                       contractStatuses,
                       officeId);
        }

        public async Task<IList<SalesPerformanceDto>> GetCompanySalesPerformanceStatsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            IList<int> contractStatusesForSales = null,
            IList<int> contractStatusesForCollections = null)
        {
            if (contractStatusesForSales == null || !contractStatusesForSales.Any())
            {
                contractStatusesForSales = new List<int>
                                               {
                                                   (int)ContractStatus.Issued,
                                                   (int)ContractStatus.FullyExecuted,
                                                   (int)ContractStatus.Completed
                                               };
            }

            if (contractStatusesForCollections == null || !contractStatusesForCollections.Any())
            {
                contractStatusesForCollections =
                    new List<int>
                        {
                            (int)ContractStatus.Issued,
                            (int)ContractStatus.FullyExecuted,
                            (int)ContractStatus.Completed,
                            (int)ContractStatus.Canceled,
                            (int)ContractStatus.PartiallyCanceled
                        };
            }

            return await this.Context.Dashboard.GetCompanySalesPerformanceStatsAsync(
                mtdStartDate,
                mtdEndDate,
                ytdStartDate,
                ytdEndDate,
                contractStatusesForSales,
                contractStatusesForCollections);
        }

        public async Task<IList<BusinessPerformanceDto>> GetCompanyBusinessPerformanceStatsAsync(
            DateTime startDate,
            DateTime endDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate)
        {
            return await this.Context.Dashboard.GetCompanyBusinessPerformanceStatsAsync(
                startDate,
                endDate,
                ytdStartDate,
                ytdEndDate);
        }

        public async Task<ConversionStatsDto> GetOfficeConversionStatsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetOfficeConversionStatsAsync(officeId, startDate.Value, endDate.Value);
        }

        public async Task<ConversionStatsDto> GetCompanyConversionStatsAsync(
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetCompanyConversionStatsAsync(startDate.Value, endDate.Value);
        }

        public async Task<ContractStatsDto> GetOfficeContractStatsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetOfficeContractStatsAsync(officeId, startDate.Value, endDate.Value);
        }

        public async Task<ContractStatsDto> GetCompanyContractStatsAsync(
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetCompanyContractStatsAsync(startDate.Value, endDate.Value);
        }

        public async Task<IList<BlueCardClosureReasonDto>> GetOfficeBlueCardClosuresAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetOfficeBlueCardClosuresAsync(
                       officeId,
                       startDate.Value,
                       endDate.Value);
        }

        public async Task<IList<OfficeCollectionDto>> GetOfficeCollectionsAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetOfficeCollectionsAsync(officeId, startDate.Value, endDate.Value);
        }

        public async Task<IList<OfficeCollectionDto>> GetCompanyCollectionsAsync(
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetCompanyCollectionsAsync(startDate.Value, endDate.Value);
        }

        public async Task<IList<OfficeCollectionDto>> GetOfficeSalesAsync(
            int officeId,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetOfficeSalesAsync(officeId, startDate.Value, endDate.Value);
        }

        public async Task<IList<OfficeCollectionDto>> GetCompanySalesAsync(
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-6);
            }

            return await this.Context.Dashboard.GetCompanySalesAsync(startDate.Value, endDate.Value);
        }

        public async Task<IList<StalePresenterDto>> GetOfficeStalePresentersAsync(
            int officeId,
            DateTime? staleDate = null)
        {
            if (!staleDate.HasValue)
            {
                staleDate = DateTime.Now.AddMonths(-18);
            }

            return await this.Context.Dashboard.GetOfficeStalePresentersAsync(officeId, staleDate.Value);
        }

        public async Task<IList<StalePresenterDto>> GetAgentStalePresentersAsync(
            int agentId,
            DateTime? staleDate = null)
        {
            if (!staleDate.HasValue)
            {
                staleDate = DateTime.Now.AddMonths(-18);
            }

            return await this.Context.Dashboard.GetAgentStalePresentersAsync(agentId, staleDate.Value);
        }

        public async Task<IList<TopAgentDto>> GetTopAgentsSalesAndCollectionsAsync(
            DateTime mtdStartDate,
            DateTime mtdEndDate,
            DateTime ytdStartDate,
            DateTime ytdEndDate,
            int? officeId = null)
        {
            return await this.Context.Dashboard.GetTopAgentsSalesAndCollectionsAsync(
                       mtdStartDate,
                       mtdEndDate,
                       ytdStartDate,
                       ytdEndDate,
                       officeId);
        }

        public async Task<IList<AgentPerformanceStatsResultDto>> GetAgentPerformanceStatsAsync(AgentPerformanceStatsCriteriaDto criteria)
        {
            return await this.Context.Dashboard.GetAgentPerformanceStatsAsync(criteria);
        }

        public async Task<IList<AgentPerformanceSummaryResultDto>> GetAgentPerformanceSummaryAsync(AgentPerformanceSummaryCriteriaDto criteria)
        {
            return await this.Context.Dashboard.GetAgentPerformanceSummaryAsync(criteria);
        }

        public async Task<IList<AgentPerformanceSummaryResultDto>> GetAgentPerformanceByContractOfficeAsync(AgentPerformanceSummaryCriteriaDto criteria)
        {
            return await this.Context.Dashboard.GetAgentPerformanceByContractOfficeAsync(criteria);
        }

        public async Task<IList<AgentPerformanceRankDto>> GetAgentPerformanceRankAsync(DateTime startDate,
            DateTime endDate)
        {
            return await this.Context.Dashboard.GetAgentPerformanceRankAsync(startDate, endDate);
        }

        public async Task<IList<SalesCollectionsResultDto>> GetSalesCollectionsAsync(SalesCollectionsCriteriaDto criteria)
        {
            if (criteria.DataSet == SalesCollectionsDataSet.Sales)
            {
                return await this.Context.Dashboard.GetSalesAsync(criteria);
            }
            else
            {
                return await this.Context.Dashboard.GetCollectionsAsync(criteria);
            }
        }

        private List<int> ValidContractStatuses()
        {
            return new List<int>
                       {
                           (int)ContractStatus.Issued,
                           (int)ContractStatus.FullyExecuted,
                           (int)ContractStatus.Completed,
                           (int)ContractStatus.ReIssue,
                       };
        }
        public async Task<RolesAndUsersDto> GetAllRolesAndUsers()
        {
            return await this.Context.Dashboard.GetAllRolesAndUsers();
        }
        public async Task<RolesAndUsersDashboardWiseDto> GetAllRolesAndUsersDashboardWise(long id)
        {

            return await this.Context.Dashboard.GetAllRolesAndUsersDashboardWise(id);

        }

        public async Task<string> GetDashboardModifyUrl(long id, IPrincipal user)
        {
            return await this.Context.Dashboard.GetDashboardModifyUrl(id, user);
        }


        public async Task<List<EntityReminderModelDto>> GetEntityReminderBothTypeByCriteriaAsync(int userId, int? reminderDate = null, int? entityTypeId = null, int? entityId = null, bool isAssigner = true)
        {

            List<EntityReminderModelDto> entityReminderModelList = new List<EntityReminderModelDto>();
            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"userid",userId},
                    {"reminderDate",reminderDate.HasValue? reminderDate.Value:1},
                    {"entityTypeId",entityTypeId.HasValue? entityTypeId.Value:0},
                    {"entityId",entityId.HasValue? entityId.Value:0},
                    {"IsAssigner",isAssigner}
                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    var entityReminderModelListAwait = await conn.QueryAsync<EntityReminderModelDto>("Sp_Get_EntityReminderList", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    if (entityReminderModelListAwait != null)
                    {
                        entityReminderModelList = entityReminderModelListAwait.ToList();
                    }
                    if (entityReminderModelList != null && entityReminderModelList.Count > 0)
                    {
                        entityReminderModelList.ForEach(a =>
                        {




                            bool isShowAssignToOther = false;
                            if (a.IsClosed.HasValue && a.IsClosed.Value)
                            {
                                isShowAssignToOther = true;
                            }
                            else
                            {
                                if (a.IsAssignToOther.HasValue && a.IsAssignToOther.Value)
                                {
                                    if (a.IsOwner.HasValue && a.IsOwner.Value)
                                    {
                                        isShowAssignToOther = false;
                                    }
                                    else
                                    {
                                        if (a.NumberOfLevel == 1)
                                        {
                                            isShowAssignToOther = true;
                                        }

                                        if (a.NumberOfLevel == 2)
                                        {
                                            isShowAssignToOther = false;
                                        }
                                    }
                                }


                            }
                            a.IsShowAssignToOther = isShowAssignToOther;


                            if (a.IsClosed.HasValue && a.IsClosed.Value)
                            {
                                a.IsCompleted = true;
                                a.IsAccept = true;
                                a.IsReject = false;
                                a.IsShowAssignToOther = false;
                            }
                            else
                            {
                                if (a.IsAssignToOther.HasValue && a.IsAssignToOther.Value)
                                {
                                    if (a.NumberOfLevel == 2)
                                    {
                                        if (a.CurrentAssignerId == a.LoginUserid)
                                        {
                                            a.IsAccept = true;
                                            a.IsCompleted = true;
                                        }
                                    }

                                }


                            }
                            if (a.IsCompleted.HasValue && a.IsCompleted.Value)
                            {
                                a.IsAccept = true;
                                a.IsShowAssignToOther = false;
                            }
                        });

                    }
                }

            }
            catch(Exception ex) 
            {
               
            }
            return entityReminderModelList.OrderByDescending(a=>a.ReminderDate).ToList();

        }

        public async Task<List<EntityReminderModelDto>> GetEntityReminderEntityWiseByCriteriaAsync(EntityReminderEntityWiseCriteriaDto model)
        {

            List<EntityReminderModelDto> entityReminderModelList = new List<EntityReminderModelDto>();
            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
            {
                var dictionary = new Dictionary<string, object>()
                {
                    {"entityTypeId",model.EntityTypeId},
                    {"entityId",model.EntityId}
                };
                var parameters = new DynamicParameters(dictionary);
                var conn = sqlConnectionFactory.CreateConnection();
                entityReminderModelList = (await conn.QueryAsync<EntityReminderModelDto>("Sp_Get_EntityReminderList_EntityWiseAll", parameters, commandType: CommandType.StoredProcedure)).ToList();
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return entityReminderModelList;

        }

        public async Task<RolesAndUsersBIDashboardDto> GetAllRolesAndUsersBIDashboard()
        {
            return await this.Context.Dashboard.GetAllRolesAndUsersBIDashboard();
        }
        public async Task<RolesAndUsersBIDashboardWiseDto> GetAllRolesAndUsersBIDashboardWise(int id)
        {

            return await this.Context.Dashboard.GetAllRolesAndUsersBIDashboardWise(id);

        }

        
        public async Task<string> GetAppOnlyAccessToken(IPrincipal user)
        {
            PowerBITokenDto powerBIToken = new PowerBITokenDto();
            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {

                    var parameters = new DynamicParameters();
                    parameters.Add("@UserName", user.Identity.Name, DbType.String, ParameterDirection.Input);
                    parameters.Add("@Token", dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);
                    parameters.Add("@return_value", dbType: DbType.Int32, direction: ParameterDirection.ReturnValue);
                    var conn = sqlConnectionFactory.CreateConnection();
                    await conn.QueryFirstOrDefaultAsync<BIDashboardValidMessageDto>("Sp_Get_BIDashboardPowerBIToken", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    var tokenString = parameters.Get<string>("@Token");
                    if (!string.IsNullOrWhiteSpace(tokenString))
                    {
                        powerBIToken = JsonConvert.DeserializeObject<PowerBITokenDto>(tokenString);
                    }

                }
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
            }
            return powerBIToken.access_token;
        }

        public  async Task<EmbedInfoDto> GetEmbedInfo(Guid workspaceId, Guid reportId, IPrincipal user)
        {
            try
            { 
            string urlPowerBiRestApiRoot = "https://api.powerbi.com/";
            var tokenCredentials = new TokenCredentials(await GetAppOnlyAccessToken(user), "Bearer");
            var pbiClient = new PowerBIClient(new Uri(urlPowerBiRestApiRoot), tokenCredentials);

            var report = await pbiClient.Reports.GetReportInGroupAsync(workspaceId, reportId);
            var embedUrl = report.EmbedUrl;

            var generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "edit");

            var tokenResponse = await pbiClient.Reports
                .GenerateTokenInGroupAsync(workspaceId, reportId, generateTokenRequestParameters);

            var embedToken = tokenResponse.Token;

            return new EmbedInfoDto
            {
                ReportId = report.Id,
                EmbedUrl = embedUrl,
                AccessToken = embedToken
            };
            }
            catch (Exception ex)
            {
                var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                Logger.Error(ex);
            }
            return new EmbedInfoDto();
        }

		public async Task<IEnumerable<UnpaidExpense_ContractDto>> GetAllUnpaidContractExpenses(IPrincipal user,int roleId,int officeId,int agentId)
		{
            return await this.Context.Dashboard.GetAllUnpaidContractExpenses(user,roleId,officeId,agentId);
		}

        public async Task<IEnumerable<UnpaidExpense_ContractDto>> GetAllUnpaidContractExpensesExport(IPrincipal user, int roleId, int officeId,int agentId)
        {
            return await this.Context.Dashboard.GetAllUnpaidContractExpensesExport(user,roleId,officeId,agentId);
        }



        public async Task<List<PresenterWeddingQuestionnaireDto>> GetPresenterWeddingQuestionnaireAsync(int userId)
        {

            List<PresenterWeddingQuestionnaireDto> weddingQuestionnaireList = new List<PresenterWeddingQuestionnaireDto>();
            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
            {
                var dictionary = new Dictionary<string, object>()
                {
                    {"userId",userId}
                };
                var parameters = new DynamicParameters(dictionary);
                var conn = sqlConnectionFactory.CreateConnection();
                weddingQuestionnaireList = (await conn.QueryAsync<PresenterWeddingQuestionnaireDto>("Sp_Get_WeddingQuestionnaireByUserId", parameters, commandType: CommandType.StoredProcedure)).ToList();
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return weddingQuestionnaireList;

        }

        public async Task<UsersFeatureFlagDto> GetAllUsersFeatureFlag()
        {
            return await this.Context.Dashboard.GetAllUsersFeatureFlag();
        }

        public async Task<UsersFeatureFlagWiseDto> GetAllUsersFeatureFlagWise(int id)
        {
            return await this.Context.Dashboard.GetAllUsersFeatureFlagWise(id);
        }
    }
}
