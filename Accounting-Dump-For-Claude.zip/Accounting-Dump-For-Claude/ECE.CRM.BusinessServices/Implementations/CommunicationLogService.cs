﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class CommunicationLogService : ICommunicationLogService
    {
        public CommunicationLogService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<CommunicationLogDto>> GetCommunicationLogs(EntityType entityType, int entityId)
        {
            var resultList = await this.Context.CommunicationLogs.GetCommunicationLogs(entityType, entityId);

            return resultList;
        }

        public async Task<IList<CommunicationLogSearchResultsDto>> GetByCriteriaAsync(CommunicationLogSearchCriteriaDto criteria)
        {
            var results = await this.Context.CommunicationLogs.GetByCriteriaAsync(criteria);

            return results;
        }

        public async Task<IList<CommunicationLogDto>> GetEmailQueuedCommunicationLogsAsync(int emailQueuedId)
        {
            return await this.Context.CommunicationLogs.GetEmailQueuedCommunicationLogsAsync(emailQueuedId);
        }

        public async Task UpdateAsync(CommunicationLogDto communicationLog)
        {
            if (communicationLog == null)
            {
                throw new ArgumentNullException(nameof(communicationLog));
            }

            this.Context.BeginTransaction();
            try
            {
                await this.Context.CommunicationLogs.UpdateAsync(communicationLog);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public void AddCommunicationLog(CommunicationLogDto log, IPrincipal user)
        {
            log.SetAsCreated(user);

            try
            {
                this.Context.BeginTransaction();
                this.Context.CommunicationLogs.Create(log);
                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }
    }
}
