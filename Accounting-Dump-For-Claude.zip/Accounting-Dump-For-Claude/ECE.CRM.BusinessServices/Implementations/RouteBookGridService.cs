﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class RouteBookGridService : IRouteBookGridService
    {
        public RouteBookGridService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<RouteBookGridDto> GetByIdAsync(int id, bool includeArtists = false)
        {
            var dto = await this.Context.RouteBookGrids.GetByIdAsync(id);

            if (includeArtists)
            {
                dto.Artists = await this.GetArtistsForGridAsync(id);
            }

            return dto;
        }

        public async Task<IList<RouteBookGridArtistDto>> GetArtistsForGridAsync(int routeBookGridId)
        {
            var artists = await this.Context.RouteBookGrids.GetArtistsForGridAsync(routeBookGridId);

            return artists;
        }

        public async Task CreateAsync(RouteBookGridDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                // Sort Artists By Name
                dto.Artists = dto.Artists.OrderBy(x => x.Name).ToList();

                await this.Context.RouteBookGrids.CreateAsync(dto);

                await this.SyncArtistsAsync(dto.RouteBookGridId, dto.Artists, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<RouteBookGridArtistDto> GetCustomGridArtistAsync(int artistId)
        {
            var artist = await this.Context.RouteBookGrids.GetCustomGridArtistAsync(artistId);

            return artist;
        }

        public async Task UpdateAsync(RouteBookGridDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var original = await this.GetByIdAsync(dto.RouteBookGridId);

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.RouteBookGrids.UpdateAsync(dto);

                await this.SyncArtistsAsync(dto.RouteBookGridId, dto.Artists, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SyncArtistsAsync(int routeBookGridId, IEnumerable<RouteBookGridArtistDto> updateArtists, IPrincipal user)
        {
            var existingArtists = await this.GetArtistsForGridAsync(routeBookGridId);
            var activeArtists = updateArtists.Where(x => !x.IsDeleted);

            // Get a list of all the existing artists that still exist in the updated list.
            var artistsToKeep =
                from e in existingArtists
                join a in activeArtists on e.RouteBookGridArtistId equals a.RouteBookGridArtistId
                select e;

            // Update the existing artists not being removed.
            foreach (var artistToKeep in artistsToKeep)
            {
                var updates = activeArtists.First(x => x.RouteBookGridArtistId == artistToKeep.RouteBookGridArtistId);

                artistToKeep.DisplayOrder = updates.DisplayOrder;
                artistToKeep.SetAsUpdated(user);

                await this.Context.RouteBookGrids.UpdateArtistAsync(artistToKeep);
            }

            // Add new artists, if necessary.
            // NOTE: Match against artist id since the RouteBookGridArtistId is ZERO for all the new records.
            var artistsToAdd = activeArtists.Except(artistsToKeep, x => x.ArtistId);

            var displayOrder = existingArtists.Select(x => x.DisplayOrder).DefaultIfEmpty().Max();

            foreach (var artistToAdd in artistsToAdd)
            {
                displayOrder += 1;
                if (artistToAdd.DisplayOrder <= 0)
                {
                    artistToAdd.DisplayOrder = displayOrder;
                }
                artistToAdd.RouteBookGridId = routeBookGridId;
                artistToAdd.SetAsCreated(user);

                await this.Context.RouteBookGrids.CreateArtistAsync(artistToAdd);
            }

            // Remove existing artists, if necessary.
            var artistsToRemove = existingArtists.Except(artistsToKeep);

            foreach (var artistToRemove in artistsToRemove)
            {
                await this.Context.RouteBookGrids.DeleteArtistAsync(artistToRemove.RouteBookGridArtistId, user.GetUserId());
            }
        }
    }
}
