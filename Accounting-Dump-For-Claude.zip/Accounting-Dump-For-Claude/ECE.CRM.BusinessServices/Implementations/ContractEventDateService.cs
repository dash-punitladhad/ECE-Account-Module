﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ContractEventDateService : IContractEventDateService
    {
        public ContractEventDateService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public TimeSpan? SingleEventDateChangeDelta(IEnumerable<ContractEventDateDto> oldDates, IEnumerable<ContractEventDateDto> newDates)
        {
            if (oldDates.Count(x => !x.IsDeleted) == 1 && newDates.Count(x => !x.IsDeleted) == 1)
            {
                var oldDate = oldDates.First(x => !x.IsDeleted);
                var newDate = newDates.First(x => !x.IsDeleted);

                var delta = newDate.EventDate - oldDate.EventDate;

                return delta;
            }

            return null;
        }

        public async Task<IEnumerable<ContractEventDateDto>> GetByContractIdAsync(int contractId)
        {
            if (contractId <= 0)
            {
                throw new ArgumentException(nameof(contractId));
            }

            return await this.Context.ContractEventDates.GetByContractIdAsync(contractId);
        }

        public async Task<ContractEventDateDto> GetByIdAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            return await this.Context.ContractEventDates.GetByIdAsync(id);
        }

        public async Task CreateAsync(ContractEventDateDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractEventDates.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractEventDateDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractEventDates.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task DeleteAsync(ContractEventDateDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (dto.ContractEventDateId <= 0)
            {
                throw new ArgumentException($"{dto.ContractEventDateId} is not a valid Contract Event Date Id.");
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractEventDates.DeleteAsync(dto.ContractEventDateId);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task<bool> CheckArefDueDateAsync(ContractTransactionDto dto)
        {
            if (dto.ContractTransactionTypeId != (int)ContractTransactionType.ArtistPayment)
            {
                return true;
            }

            var eventDates = await this.GetByContractIdAsync(dto.ContractId);

            if (eventDates.Any(x => x.EventDate == dto.DueDate))
            {
                return true;
            }

            return false;
        }
    }
}
