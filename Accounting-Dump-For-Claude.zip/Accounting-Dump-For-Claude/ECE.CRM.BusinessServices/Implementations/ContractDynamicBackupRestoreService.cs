﻿namespace ECE.CRM.BusinessServices
{
	using ECE.CRM.BusinessServices.Interfaces;
	using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractDynamicBackupRestoreService : IContractDynamicBackupRestoreService
    {
       

        public ContractDynamicBackupRestoreService(IUnitOfWork context)
        {
            this._context = context;
        }

        public IUnitOfWork _context { get; private set; }
        public async Task<bool> ContractRestoreBackupAsync(int contractVersionId, int userId)
        {

           return await _context.ContractDynamicBackupRestoreDao.ContractRestoreAsync(contractVersionId, userId);
        }
    }
}
