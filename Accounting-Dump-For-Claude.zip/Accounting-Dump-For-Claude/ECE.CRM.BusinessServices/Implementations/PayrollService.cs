﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataAccess.Utilities;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class PayrollService : IPayrollService
    {
        public const int FirstPayrollDayOfMonth = 15;

        private static readonly ContractTransactionType[] PayrollExpenseTypes = new[]
        {
            ContractTransactionType.Commission,
            ContractTransactionType.SharedBonus,
            ContractTransactionType.NonExclusiveContractFee,
            ContractTransactionType.AgentWorking,
        };

        private static readonly ContractEntityType[] PayrollExpenseEntityTypes = new[]
        {
            ContractEntityType.ECE
        };

        private readonly ICommissionManagementService _commissionManagementService;
        IEceCrmEntities _context;
        public PayrollService(
            IUnitOfWork context,
            ILogger logger,
            ICommissionManagementService commissionManagementService, IEceCrmEntities contextModel)
        {
            this.Context = context;
            this.Logger = logger;
            this._commissionManagementService = commissionManagementService;
            this._context = contextModel;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<IList<PayrollPaymentDto>> GetPayrollPaymentsByAgentAndYearAsync(int agentId, int year)
        {
            var payrollPayments = await this.Context.PayrollPayments.GetByAgentAndYearAsync(agentId, year);

            return payrollPayments;
        }

        public async Task<PayrollPaymentDto> GetPayrollPaymentByIdAsync(int id)
        {
            var payrollPayment = await this.Context.PayrollPayments.GetByIdAsync(id);

            return payrollPayment;
        }

        public async Task<IList<AgentPayrollLogViewDto>> GetAgentPayrollLogsByPayrollPaymentIdAsync(int payrollPaymentId)
        {
            var payrollLogTypes = this.Context.Lookups.GetAllPayrollLogTypes().ToDictionary(x => x.PayrollLogTypeId);

            var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByPayrollPaymentIdAsync(payrollPaymentId);

            return agentPayrollLogs;
        }

        public async Task<IList<AgentPayrollLogDto>> GetUnpaidByAgentAsync(int agentId, int year)
        {
            var startDate = new DateTime(year, 1, 1);
            var endDate = new DateTime(year, 12, 31);

            var payrollLogTypes = this.Context.Lookups.GetAllPayrollLogTypes().ToDictionary(x => x.PayrollLogTypeId);

            var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetUnpaidByAgentAsync(agentId, startDate, endDate);

            foreach (var log in agentPayrollLogs)
            {
                log.LuPayrollLogType = payrollLogTypes[log.PayrollLogTypeId];
            }

            return agentPayrollLogs;
        }

        public async Task<IList<AgentPayrollLogDto>> GetAgentPayrollLogsByContractIdAsync(int contractId)
        {
            var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByContractIdAsync(contractId);

            return agentPayrollLogs;
        }

        public async Task<AgentPayrollLogDto> GetAgentPayrollLogByContractTransactionIdAsync(int contractTransactionId)
        {
            var agentPayrollLog = await this.Context.AgentPayrollLogs.GetByContractTransactionIdAsync(contractTransactionId);

            return agentPayrollLog;
        }

        public async Task<AgentPayrollLogDto> GetAgentPayrollLogByIdAsync(int agentPayrollLogId)
        {
            var agentPayrollLog = await this.Context.AgentPayrollLogs.GetByIdAsync(agentPayrollLogId);

            return agentPayrollLog;
        }

        public async Task UpdateCafeteriaPlanAsync(CafeteriaPlanDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var cafePlan = await this.Context.CafeteriaPlans.GetByAgentIdAsync(dto.AppUserId);

                if (cafePlan == null)
                {
                    dto.SetAsCreated(user);
                    await this.Context.CafeteriaPlans.CreateAsync(dto);
                }
                else
                {
                    dto.CafeteriaPlanId = cafePlan.CafeteriaPlanId;
                    dto.SetAsUpdated(user);
                    await this.Context.CafeteriaPlans.UpdateAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(dto, ex);
            }
        }

        public async Task<IList<AgentCafeteriaPlanDto>> GetAgentCafeteriaPlansAsync(int year)
        {
            var cafePlans = await this.Context.CafeteriaPlans.GetAgentCafeteriaPlansAsync(year);

            return cafePlans;
        }

        public async Task<IList<AgentCafeteriaPlanDto>> GetAgentCafeteriaPlansAsync(int year, DateTime currentDate)
        {
            var cafePlans = await this.Context.CafeteriaPlans.GetAgentCafeteriaPlansAsync(year, currentDate);

            return cafePlans;
        }

        public async Task<CafeteriaPlanDto> GetCafeteriaPlanByAgentAsync(int agentId)
        {
            var cafePlan = await this.Context.CafeteriaPlans.GetByAgentIdAsync(agentId);

            return cafePlan;
        }

        public async Task DeleteAgentPayrollLogAsync(int contractTransactionId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var logEntries = await this.Context.AgentPayrollLogs.GetByExpenseAsync(contractTransactionId);

                foreach (var logEntry in logEntries)
                {
                    await this.Context.AgentPayrollLogs.DeleteAsync(logEntry.AgentPayrollLogId);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SynchronizeAgentPayrollLogAsync(ContractTransactionDto contractTransaction, IPrincipal user)
        {
            decimal smallestAllowedCommission = ECEBusinessConstants.CommissionConstants.SmallestAllowedCommission;

            if (contractTransaction == null)
            {
                throw new ArgumentNullException(nameof(contractTransaction));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            // Only synchronize unpaid expenses.
            if (contractTransaction.IsIncome || contractTransaction.PaidDate == null)
            {
                return;
            }

            var contractTransactionType = (ContractTransactionType)contractTransaction.ContractTransactionTypeId;
            var contractEntityType = (ContractEntityType)contractTransaction.ContractEntityTypeId;

            // Only synchronize payroll-related expenses.
            if (PayrollExpenseTypes.Contains(contractTransactionType) == false ||
                PayrollExpenseEntityTypes.Contains(contractEntityType) == false)
            {
                return;
            }

            try
            {
                this.Context.BeginTransaction();

                if (contractTransaction.ParentContract == null)
                {
                    contractTransaction.ParentContract = await this.Context.Contracts.GetByIdAsync(contractTransaction.ContractId);
                }

                var payrollLogType = this.GetPayrollLogType(contractTransactionType);

                var logs = await this.Context.AgentPayrollLogs.GetByExpenseAsync(contractTransaction.ContractTransactionId);

                // Assuming here that there is only one log entry per log type, per expense.
                var payrollLog = logs.FirstOrDefault(x => x.PayrollLogTypeId == (int)payrollLogType);

                var noCommissionToBePaid = false;

                if (contractTransactionType == ContractTransactionType.Commission)
                {
                    var commission = contractTransaction.RequiredAmount.GetValueOrDefault();

                    if (commission >= decimal.Zero && commission < smallestAllowedCommission)
                    {
                        if (contractTransaction.ParentContract.ContractTransactions == null)
                        {
                            contractTransaction.ParentContract.ContractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractTransaction.ContractId);
                        }

                        var totalCommission = contractTransaction.ParentContract.ContractTransactions
                            .Where(x => x.IsExpense && x.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                            .Total(x => x.RequiredAmount);

                        if (totalCommission < smallestAllowedCommission)
                        {
                            noCommissionToBePaid = true;
                        }
                    }

                    if (noCommissionToBePaid)
                    {
                        // Remove the commission payroll log
                        await this.SynchronizeAgentPayrollLogEntryAsync(
                            null,
                            payrollLog,
                            payrollLogType,
                            user);
                    }
                    else
                    {
                        // Synchronize the commission-related log entry
                        await this.SynchronizeAgentPayrollLogEntryAsync(
                            contractTransaction,
                            payrollLog,
                            payrollLogType,
                            user);
                    }

                    // If the contract has a bonus commission program, synchronize it's log entry as well.
                    if (contractTransaction.ParentContract.CommissionProgramId.HasValue)
                    {
                        if (contractTransaction.ParentContract.ContractTransactions == null)
                        {
                            contractTransaction.ParentContract.ContractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractTransaction.ContractId);
                        }

                        var commissionProgramAgentId = contractTransaction.ParentContract.CommissionProgramAgentId.Value;

                        // Don't pay a bonus commission if the agent is receiving agent-earned commission on the contract
                        var agentHasCommissionOnContract = contractTransaction.ParentContract.ContractTransactions
                            .Where(x => x.AgentId == commissionProgramAgentId
                                   && x.IsExpense
                                   && x.ContractTransactionTypeId == (int)ContractTransactionType.Commission)
                            .Select(x => x.RequiredAmount).DefaultIfEmpty()
                            .Sum() != decimal.Zero;

                        var program = (CommissionProgram)contractTransaction.ParentContract.CommissionProgramId.Value;

                        payrollLogType = this.GetPayrollLogType(program);

                        var bonusCommission = logs.FirstOrDefault(x => x.PayrollLogTypeId == (int)payrollLogType);

                        if (agentHasCommissionOnContract || noCommissionToBePaid)
                        {
                            // Remove the bonus commission
                            await this.SynchronizeAgentPayrollLogEntryAsync(
                                null,
                                bonusCommission,
                                payrollLogType,
                                user);
                        }
                        else
                        {
                            // Synchronize the bonus commission-related log entry
                            await this.SynchronizeAgentPayrollLogEntryAsync(
                                contractTransaction,
                                bonusCommission,
                                payrollLogType,
                                user);
                        }
                    }
                }
                else
                {
                    // Synchronize the other ECE expense log entries:
                    // SharedBonus, NonExclusiveContractFee, & AgentWorking
                    await this.SynchronizeAgentPayrollLogEntryAsync(
                        contractTransaction,
                        payrollLog,
                        payrollLogType,
                        user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public PayrollLogType GetPayrollLogType(ContractTransactionType contractTransactionType)
        {
            switch (contractTransactionType)
            {
                case ContractTransactionType.SharedBonus:
                    return PayrollLogType.SharedBonus;

                case ContractTransactionType.Commission:
                    return PayrollLogType.AgentCommission;

                case ContractTransactionType.NonExclusiveContractFee:
                    return PayrollLogType.NonExclusiveArtistFee;

                case ContractTransactionType.AgentWorking:
                    return PayrollLogType.AgentWorking;

                default:
                    throw new Exception($"Unknown contract transaction type {contractTransactionType}");
            }
        }

        public PayrollLogType GetPayrollLogType(CommissionProgram commissionProgram)
        {
            switch (commissionProgram)
            {
                case CommissionProgram.Mentor:
                    return PayrollLogType.MentorshipCommission;

                case CommissionProgram.PresenterTransfer:
                    return PayrollLogType.TransferCommission;

                default:
                    throw new Exception($"Unknown commission program {commissionProgram}");
            }
        }

        /// <summary>
        /// Synchronize the agent payroll log entry.
        /// </summary>
        /// <param name="contractTransaction">The contract transaction.</param>
        /// <param name="payrollLog">The payroll log.</param>
        /// <param name="payrollLogType">Type of the payroll log.</param>
        /// <param name="user">The user.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task SynchronizeAgentPayrollLogEntryAsync(
            ContractTransactionDto contractTransaction,
            AgentPayrollLogDto payrollLog,
            PayrollLogType payrollLogType,
            IPrincipal user)
        {
            var commissionForAgent = payrollLog;

            if (contractTransaction == null)
            {
                if (commissionForAgent == null)
                {
                    return;
                }

                // Delete the log entry.
                await this.Context.AgentPayrollLogs.DeleteAsync(commissionForAgent.AgentPayrollLogId);
            }

            if (commissionForAgent == null)
            {
                // Create new log entry
                commissionForAgent = new AgentPayrollLogDto();

                var agentId = contractTransaction.AgentId ?? contractTransaction.ParentContract.AgentId;
                if (payrollLogType == PayrollLogType.MentorshipCommission || payrollLogType == PayrollLogType.TransferCommission)
                {
                    agentId = contractTransaction.ParentContract.CommissionProgramAgentId.Value;
                }

                commissionForAgent.AgentId = agentId;
                commissionForAgent.ContractId = contractTransaction.ContractId;
                commissionForAgent.ContractTransactionId = contractTransaction.ContractTransactionId;
                commissionForAgent.LineOfBusinessId = contractTransaction.ParentContract.LineOfBusinessId.Value;
                commissionForAgent.PayrollLogTypeId = (int)payrollLogType;

                commissionForAgent.GrossAmount = contractTransaction.RequiredAmount.GetValueOrDefault();
                commissionForAgent.ReceivedDate = contractTransaction.PaidDate.GetValueOrDefault();
                commissionForAgent.SetAsCreated(user);

                await this.Context.AgentPayrollLogs.CreateAsync(commissionForAgent);
            }
            else if (commissionForAgent.PayrollPaymentId == null)
            {
                // Update log entry if not already included in a payroll payment
                commissionForAgent.GrossAmount = contractTransaction.RequiredAmount.GetValueOrDefault();
                commissionForAgent.ReceivedDate = contractTransaction.PaidDate.GetValueOrDefault();
                commissionForAgent.SetAsUpdated(user);

                await this.Context.AgentPayrollLogs.UpdateAsync(commissionForAgent);
            }
            else
            {
                // Create a new log entry for the difference if already included in a payroll payment
                var difference = contractTransaction.RequiredAmount.GetValueOrDefault() - commissionForAgent.GrossAmount;

                commissionForAgent.PayrollPaymentId = null;
                commissionForAgent.PostDate = null;
                commissionForAgent.NetAmount = decimal.Zero;
                commissionForAgent.CommissionRate = decimal.Zero;

                commissionForAgent.GrossAmount = difference;
                commissionForAgent.ReceivedDate = contractTransaction.PaidDate.GetValueOrDefault();

                commissionForAgent.SetAsCreated(user);

                await this.Context.AgentPayrollLogs.CreateAsync(commissionForAgent);
            }
        }

        public async Task<IList<PayrollBatchLogDto>> GetPayrollLogsAsync(int year)
        {
            return await this.Context.PayrollBatches.GetPayrollLogsAsync(year);
        }

        public DateTime GetNextPayrollDate()
        {
            DateTime today = TimeProvider.Current.Today;

            return GetNextPayrollDate(today);
        }

        public DateTime GetNextPayrollDate(DateTime asOfDate)
        {
            // Payroll is on the 15th and the last day of the month
            DateTime nextPayrollDate = new DateTime(asOfDate.Year, asOfDate.Month, FirstPayrollDayOfMonth);

            if (asOfDate.Day > FirstPayrollDayOfMonth)
            {
                nextPayrollDate = new DateTime(asOfDate.Year, asOfDate.Month, DateTime.DaysInMonth(asOfDate.Year, asOfDate.Month));
            }

            return nextPayrollDate;
        }

        public DateTime GetPayrollStartDate(DateTime payrollDate)
        {
            DateTime today = TimeProvider.Current.Today;

            return GetPayrollStartDate(today, payrollDate);
        }

        public DateTime GetPayrollStartDate(DateTime asOfDate, DateTime payrollDate)
        {
            // first payroll is the 22nd of the previous month through the 6th of the current month
            // second payroll is the 7th of the current month through the 21st of the current month
            if (asOfDate.Day <= FirstPayrollDayOfMonth)
            {
                return new DateTime(payrollDate.AddMonths(-1).Year, payrollDate.AddMonths(-1).Month, 22);
            }
            else
            {
                return new DateTime(payrollDate.Year, payrollDate.Month, 7);
            }
        }

        public DateTime GetPayrollEndDate(DateTime payrollDate)
        {
            DateTime today = TimeProvider.Current.Today;

            return GetPayrollEndDate(today, payrollDate);
        }

        public DateTime GetPayrollEndDate(DateTime asOfDate, DateTime payrollDate)
        {
            // first payroll is the 22nd of the previous month through the 6th of the current month
            // second payroll is the 7th of the current month through the 21st of the current month
            if (asOfDate.Day <= FirstPayrollDayOfMonth)
            {
                return new DateTime(payrollDate.Year, payrollDate.Month, 6);
            }
            else
            {
                return new DateTime(payrollDate.Year, payrollDate.Month, 21);
            }
        }

        public async Task<PayrollBatchDto> CalculateNextPayrollBatchAsync(int? agentId = null)
        {
            DateTime today = TimeProvider.Current.Today;

            return await CalculateNextPayrollBatchAsync(today, agentId);
        }

        public async Task<PayrollBatchDto> CalculateNextPayrollBatchAsync(DateTime asOfDate, int? agentId = null)
        {
            var nextPayrollDate = this.GetNextPayrollDate(asOfDate);

            var startDate = this.GetPayrollStartDate(asOfDate, nextPayrollDate);

            var endDate = this.GetPayrollEndDate(asOfDate, nextPayrollDate);

            var lastBatch = await this.Context.PayrollBatches.GetLastPayrollBatchAsync(nextPayrollDate);

            // Check to see if there was a payroll period that was skipped.
            if (lastBatch != null && lastBatch.PayrollPeriodEnd.AddDays(1) < startDate)
            {
                // Move the start date back to ensure there isn't a gap.
                startDate = lastBatch.PayrollPeriodEnd.AddDays(1);
            }

            var batch = await this.PreviewPayrollAsync(startDate, endDate, nextPayrollDate, agentId);

            return batch;
        }

        public IList<AgentPayrollLogDto> FilterPayrollLogs(IList<AgentPayrollLogDto> agentPayrollLogs, DateTime nextPayrollDate, DateTime startDate)
        {
            if (!this.IsLastPayrollInMonth(nextPayrollDate))
            {
                // Programs (shared bonus/non-exclusive artist fees) are currently only paid to Agents on the last payroll run each month.
                return agentPayrollLogs
                    .Where(x => x.PayrollLogTypeId != (int)PayrollLogType.SharedBonus)
                    .Where(x => x.PayrollLogTypeId != (int)PayrollLogType.NonExclusiveArtistFee)
                    .Where(x => ExcludeCommission(nextPayrollDate, x) == false)
                    .ToList();
            }

            return agentPayrollLogs
                .Where(x => ExcludeCommission(nextPayrollDate, x) == false)
                .ToList();
        }

        public bool IsLastPayrollInMonth(DateTime nextPayrollDate)
        {
            var lastDayInMonth = new DateTime(nextPayrollDate.Year, nextPayrollDate.Month, DateTime.DaysInMonth(nextPayrollDate.Year, nextPayrollDate.Month));

            return nextPayrollDate.Date == lastDayInMonth.Date;
        }

        public async Task<PayrollBatchDto> GetPayrollBatchByPayrollPeriodAsync(DateTime payrollDate)
        {
            return await this.Context.PayrollBatches.GetLastPayrollBatchAsync(payrollDate);
        }

        public async Task<PayrollBatchDto> GetPendingPayrollBatchAsync()
        {
            return await this.Context.PayrollBatches.GetPendingPayrollBatchAsync();
        }

        public async Task<PayrollBatchDto> GetNextPayrollBatchAsync(bool preview, int agentId)
        {
            PayrollBatchDto existingBatch = null;

            try
            {
                this.Context.BeginTransaction();

                var nextPayrollDate = this.GetNextPayrollDate();

                // check if record for payroll batch exists
                existingBatch = await this.Context.PayrollBatches.GetPayrollBatchByPayrollPeriodAsync(nextPayrollDate);
                if (existingBatch == null)
                {
                    var newBatch = await this.CalculateNextPayrollBatchAsync(agentId);

                    newBatch.RunDate = TimeProvider.Current.Now;

                    existingBatch = newBatch;
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return existingBatch;
        }

        public async Task CalculateNetAmountsAsync(int agentId, IList<AgentPayrollLogDto> logs, PayrollBatchDto batch)
        {
            var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(agentId, true);
            if (agentCommission == null || agentCommission.AgentCommissionId == null)
            {
                return;
            }

            var typeData = agentCommission.CommissionTiers;

            var mostRecentPayment = await this.Context.PayrollPayments.GetMostRecentByAgentIdAsync(agentId);

            var mentorPrograms = await this.Context.AgentCommissionProgram.GetMentorshipProgramsForCommissionByAppUserAsync(agentId);

            foreach (var log in logs)
            {
                await this.CalculateNetAmountAsync(log, batch, agentCommission, mostRecentPayment, typeData, mentorPrograms);
            }
        }

        public async Task CalculateNetAmountAsync(
            AgentPayrollLogDto log,
            PayrollBatchDto batch,
            AgentCommissionDto agentCommission,
            PayrollPaymentDto mostRecentPayment,
            IEnumerable<AgentCommissionTypeDataDto> typeData,
            IEnumerable<AgentCommissionProgramsDto> mentorPrograms)
        {
            decimal percentage = decimal.Zero;
            decimal commissionAmount = 0;

            this.Logger.LogDebug($"\t\t LOG: {log.AgentPayrollLogId}, TYPE: {((LineOfBusiness)log.LineOfBusinessId).ToString()}");

            // Calculate commissions
            switch ((PayrollLogType)log.PayrollLogTypeId)
            {
                case PayrollLogType.AgentCommission:
                    // if national, event date must be before payroll date
                    if (log.LineOfBusinessId == (int)LineOfBusiness.National && log.LastEventDate != null && log.LastEventDate > batch.PayrollPeriod)
                    {
                        this.Logger.LogDebug($"\t\t National LOB, Future Event Date");

                        // national and event date is after payroll period so quit
                        break;
                    }

                    if (agentCommission == null || agentCommission.AgentCommissionTypeId == null)
                    {
                        this.Logger.LogDebug($"\t\t NO COMMISSION DATA CONFIGURED");

                        break;
                    }

                    switch ((AgentCommissionType)agentCommission.AgentCommissionTypeId)
                    {
                        case AgentCommissionType.TieredCumulativePlan:
                            // From PayrollPayment get Top(1) YTDGrossCommissionAmount OrderBy PostDate where AgentId = AgentId
                            var ytdGrossCommission = mostRecentPayment?.YTDGrossCommissionAmount ?? decimal.Zero;

                            // Get Percentage where PayrollPayment.YTDGrossCommissionAmount is between LowerNumeric & UpperNumeric
                            var cumulativePercentageRecord = typeData.Where(x => x.LowerNumeric <= ytdGrossCommission && x.UpperNumeric >= ytdGrossCommission).FirstOrDefault();
                            if (cumulativePercentageRecord != null)
                            {
                                percentage = cumulativePercentageRecord.Percentage;
                            }

                            this.Logger.LogDebug($"\t\t TieredCumulativePlan");

                            break;

                        case AgentCommissionType.TieredDatesPlan:
                            // Get Percentage where AgentPayrollLog.ReceivedDate is between LowerDate & UpperDate
                            var datesPercentageRecord = typeData.Where(x => x.LowerDate <= log.ReceivedDate && x.UpperDate >= log.ReceivedDate).FirstOrDefault();
                            if (datesPercentageRecord != null)
                            {
                                percentage = datesPercentageRecord.Percentage;
                            }

                            this.Logger.LogDebug($"\t\t TieredDatesPlan");

                            break;

                        case AgentCommissionType.TieredInstancePlan:
                            var grossCommmission = log.GrossAmount;
                            if (grossCommmission != decimal.Zero)
                            {
                                var contractMoney = await this.Context.Contracts.GetContractMoney(log.ContractId);

                                if (contractMoney.CommissionAmount != decimal.Zero)
                                {
                                    grossCommmission = Math.Abs(contractMoney?.CommissionAmount ?? log.GrossAmount);

                                    // Get Percentage where AgentPayrollLog.GrossAmount is between LowerNumeric & UpperNumeric
                                    var instancePercentageRecord = typeData.Where(x => x.LowerNumeric <= grossCommmission && x.UpperNumeric >= grossCommmission).FirstOrDefault();
                                    if (instancePercentageRecord != null)
                                    {
                                        percentage = instancePercentageRecord.Percentage;
                                    }
                                }
                                else
                                {
                                    var logs = await this.Context.AgentPayrollLogs.GetByContractIdAsync(log.ContractId);

                                    var agentCommissions = logs.Where(x => x.AgentId == log.AgentId && x.PayrollLogTypeId == (int)PayrollLogType.AgentCommission);

                                    var netPaid = agentCommissions
                                        .Where(x => x.PostDate != null || (x.PostDate == null && x.AgentPayrollLogId != log.AgentPayrollLogId))
                                        .Total(x => x.NetAmount);

                                    var grossUnpaid = agentCommissions
                                        .Where(x => x.PostDate == null && x.PayrollPaymentId != null)
                                        .Total(x => x.GrossAmount);

                                    if (grossUnpaid == decimal.Zero)
                                    {
                                        grossUnpaid = agentCommissions
                                            .Where(x => x.AgentPayrollLogId == log.AgentPayrollLogId)
                                            .Total(x => x.GrossAmount);
                                    }

                                    percentage = Math.Abs(netPaid / grossUnpaid) * 100;
                                }

                                this.Logger.LogDebug($"\t\t TieredInstancePlan");
                            }

                            break;

                        default:
                            break;
                    }

                    if (log.GrossAmount != decimal.Zero && log.NetAmount != decimal.Zero)
                    {
                        // If the net was already set (manually) then respect it and ensure the commission rate
                        // reflects the correct percentage.
                        percentage = log.NetAmount / log.GrossAmount * 100;
                        log.CommissionRate = percentage.ToFixed();
                    }
                    else
                    {
                        commissionAmount = log.GrossAmount * (percentage / 100);

                        log.NetAmount = commissionAmount.ToFixed();
                        log.CommissionRate = percentage.ToFixed();
                    }

                    break;

                case PayrollLogType.MentorshipCommission:

                    var mentorPercentageRecord = mentorPrograms.Where(x =>
                        x.BonusAgentId == log.ResponsibleAgentId &&
                        x.StartDate <= log.ReceivedDate &&
                        x.EndDate >= log.ReceivedDate).FirstOrDefault();
                    if (mentorPercentageRecord == null)
                    {
                        break;
                    }

                    if (mentorPercentageRecord.SplitPercentage != null)
                    {
                        percentage = mentorPercentageRecord.SplitPercentage.Value;

                        commissionAmount = log.GrossAmount * (percentage / 100);
                    }
                    else if (mentorPercentageRecord.SplitAmount != null)
                    {
                        commissionAmount = mentorPercentageRecord.SplitAmount.Value;
                    }

                    log.NetAmount = commissionAmount.ToFixed();
                    log.CommissionRate = percentage.ToFixed();
                    break;

                case PayrollLogType.TransferCommission:
                    var presenterPrograms = await this.Context.AgentCommissionProgram.GetAgentTransferProgramsByAppUserAsync(log.AgentId, log.PresenterId.Value);
                    var presenterPercentageRecord = presenterPrograms.Where(x => x.StartDate <= log.ReceivedDate && x.EndDate >= log.ReceivedDate).FirstOrDefault();
                    if (presenterPercentageRecord == null)
                    {
                        break;
                    }

                    if (presenterPercentageRecord.SplitPercentage != null)
                    {
                        percentage = presenterPercentageRecord.SplitPercentage.Value;

                        commissionAmount = log.GrossAmount * (percentage / 100);
                    }
                    else if (presenterPercentageRecord.SplitAmount != null)
                    {
                        commissionAmount = presenterPercentageRecord.SplitAmount.Value;
                    }

                    log.NetAmount = commissionAmount.ToFixed();
                    log.CommissionRate = percentage.ToFixed();
                    break;

                case PayrollLogType.SharedBonus:
                    if (log.RequiredAmount.GetValueOrDefault() > decimal.Zero)
                    {
                        log.NetAmount = ECEBusinessConstants.CommissionConstants.SharedBonusFee;
                    }
                    else
                    {
                        log.NetAmount = -ECEBusinessConstants.CommissionConstants.SharedBonusFee;
                    }

                    break;

                case PayrollLogType.NonExclusiveArtistFee:
                    if (log.RequiredAmount.GetValueOrDefault() > decimal.Zero)
                    {
                        log.NetAmount = ECEBusinessConstants.CommissionConstants.NonExclusiveArtistFee;
                    }
                    else
                    {
                        log.NetAmount = -ECEBusinessConstants.CommissionConstants.NonExclusiveArtistFee;
                    }

                    break;

                case PayrollLogType.AgentWorking:
                    log.NetAmount = log.GrossAmount;
                    break;

                default:
                    break;
            }

            this.Logger.LogDebug($"\t\t GROSS {log.GrossAmount}, RATE {log.CommissionRate:N2}, NET {log.NetAmount:C}");
        }

        public bool ExcludeCommission(DateTime nextPayrollDate, AgentPayrollLogDto log)
        {
            if (log.PayrollLogTypeId == (int)PayrollLogType.AgentCommission)
            {
                if (log.LineOfBusinessId == (int)LineOfBusiness.National && log.LastEventDate != null && log.LastEventDate > nextPayrollDate)
                {
                    return true;
                }
            }

            if (log.PayrollLogTypeId == (int)PayrollLogType.AgentWorking)
            {
                if (log.LastEventDate != null && log.LastEventDate > nextPayrollDate)
                {
                    return true;
                }
            }

            if (log.PayrollLogTypeId == (int)PayrollLogType.SharedBonus ||
                log.PayrollLogTypeId == (int)PayrollLogType.NonExclusiveArtistFee)
            {
                if (log.LastEventDate != null && log.LastEventDate > nextPayrollDate)
                {
                    return true;
                }
            }

            return false;
        }

        public async Task<IList<PayrollPaymentDto>> ProcessPayrollAsync(PayrollBatchDto batch, IList<AgentPayrollLogDto> agentPayrollLogs, IPrincipal user, bool preview)
        {
            AgentCommissionDto agentCommission = null;
            PayrollPaymentDto mostRecentPayment = null;
            IEnumerable<AgentCommissionTypeDataDto> typeData = null;
            IEnumerable<AgentCommissionProgramsDto> mentorPrograms = null;

            var payrollPayments = new List<PayrollPaymentDto>();

            if (agentPayrollLogs.Count > 0)
            {
                agentPayrollLogs = FilterPayrollLogs(agentPayrollLogs, batch.PayrollPeriod, batch.PayrollPeriodStart);
                this.Logger.LogDebug($"\t FilterPayrollLogs.Count:  {agentPayrollLogs.Count}");

                // Loop through records by agent
                int prevAgentId = -1;

                // Create PayrollPayment record
                PayrollPaymentDto agentPayment = new PayrollPaymentDto();
                payrollPayments.Add(agentPayment);

                for (int i = 0; i < agentPayrollLogs.Count + 1; i++)
                {
                    AgentPayrollLogDto log = new AgentPayrollLogDto();

                    if (i < agentPayrollLogs.Count)
                    {
                        log = agentPayrollLogs[i];
                    }

                    int curAgentId = log.AgentId;

                    if (!preview && agentPayment.AgentId == 0)
                    {
                        agentPayment.PayrollBatchId = batch.PayrollBatchId;
                        agentPayment.AgentId = curAgentId;
                        agentPayment.SetAsCreated(user.GetUserId());
                        agentPayment.AppUser = await this.Context.Users.GetByIdAsync(curAgentId);

                        await this.Context.PayrollPayments.CreateAsync(agentPayment);
                    }

                    if (prevAgentId == -1)
                    {
                        agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(curAgentId, true);
                        if (agentCommission != null)
                        {
                            typeData = agentCommission.CommissionTiers;
                        }

                        mostRecentPayment = await this.Context.PayrollPayments.GetMostRecentByAgentIdAsync(curAgentId);

                        if (mostRecentPayment != null && mostRecentPayment.PostDate.GetValueOrDefault().Year == TimeProvider.Current.Now.Year)
                        {
                            agentPayment.YTDGrossCommissionAmount = mostRecentPayment.YTDGrossCommissionAmount + mostRecentPayment.GrossCommissionAmount;

                            agentPayment.YTDNetCommissionAmount = mostRecentPayment.YTDNetCommissionAmount + mostRecentPayment.PayrollAmount;
                        }

                        mentorPrograms = await this.Context.AgentCommissionProgram.GetMentorshipProgramsForCommissionByAppUserAsync(curAgentId);
                    }

                    if (prevAgentId != -1 && curAgentId != prevAgentId)
                    {
                        // new agent, save previous agent's payroll payment
                        this.Logger.LogDebug($"\t ProcessPayrollAsync:  Agent: {prevAgentId} Comm: {agentCommission?.CommissionType} Mentorships: {mentorPrograms.Count()}");

                        ////// Check for Cafeteria Plan
                        ////// Get record from CafeteriaPlan where AppUserId = AgentPayrollLog.AgentId
                        ////var cafeteriaPlan = await this.Context.CafeteriaPlans.GetByAgentIdAsync(prevAgentId);

                        ////if (cafeteriaPlan != null)
                        ////{
                        ////    agentPayment.CafeteriaPlanAmount = cafeteriaPlan.CurrentDeductionAmount;
                        ////    this.Logger.LogDebug($"\t ProcessPayrollAsync:  Agent: {prevAgentId} cafeteriaPlan: {cafeteriaPlan.CurrentDeductionAmount:C}");
                        ////}

                        agentPayment.PayrollAmount = agentPayment.NetCommissionAmount
                            + agentPayment.AgentWorkingAmount
                            + agentPayment.SharedBonusAmount
                            + agentPayment.NonExclusiveArtistFeeAmount
                            - agentPayment.CafeteriaPlanAmount;

                        this.Logger.LogDebug($"\t ProcessPayrollAsync:  Payroll Amount: {agentPayment.PayrollAmount:C}");

                        if (!preview)
                        {
                            agentPayment.SetAsUpdated(user.GetUserId());

                            await this.Context.PayrollPayments.UpdateAsync(agentPayment);
                        }

                        if (i == agentPayrollLogs.Count)
                        {
                            break;
                        }

                        agentPayment = new PayrollPaymentDto();
                        agentPayment.AgentId = curAgentId;
                        agentPayment.PayrollBatchId = batch.PayrollBatchId;
                        agentPayment.SetAsCreated(user.GetUserId());
                        payrollPayments.Add(agentPayment);

                        if (!preview)
                        {
                            await this.Context.PayrollPayments.CreateAsync(agentPayment);
                        }

                        agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(curAgentId, true);
                        if (agentCommission != null)
                        {
                            typeData = agentCommission.CommissionTiers;
                        }

                        mostRecentPayment = await this.Context.PayrollPayments.GetMostRecentByAgentIdAsync(curAgentId);

                        if (mostRecentPayment != null && mostRecentPayment.PostDate.GetValueOrDefault().Year == TimeProvider.Current.Now.Year)
                        {
                            agentPayment.YTDGrossCommissionAmount = mostRecentPayment.YTDGrossCommissionAmount + mostRecentPayment.GrossCommissionAmount;

                            agentPayment.YTDNetCommissionAmount = mostRecentPayment.YTDNetCommissionAmount + mostRecentPayment.PayrollAmount;
                        }

                        mentorPrograms = await this.Context.AgentCommissionProgram.GetMentorshipProgramsForCommissionByAppUserAsync(curAgentId);
                    }

                    if (preview)
                    {
                        agentPayment.PayrollBatchId = batch.PayrollBatchId;
                        agentPayment.AgentId = curAgentId;
                        agentPayment.AppUser = await this.Context.Users.GetByIdAsync(curAgentId);
                    }

                    agentPayment.GrossCommissionAmount += log.GrossAmount;

                    await this.CalculateNetAmountAsync(log, batch, agentCommission, agentPayment, typeData, mentorPrograms);

                    // Calculate commissions
                    switch ((PayrollLogType)log.PayrollLogTypeId)
                    {
                        case PayrollLogType.SharedBonus:
                            agentPayment.SharedBonusAmount += log.NetAmount;
                            break;

                        case PayrollLogType.NonExclusiveArtistFee:
                            agentPayment.NonExclusiveArtistFeeAmount += log.NetAmount;
                            break;

                        case PayrollLogType.AgentWorking:
                            agentPayment.AgentWorkingAmount += log.GrossAmount;
                            break;

                        default:
                            agentPayment.NetCommissionAmount += log.NetAmount;
                            break;
                    }

                    if (!preview && log.AgentPayrollLogId > 0)
                    {
                        // Include log entries that have a net amount not zero
                        // but exclude mentorship/transfers that are zero.
                        // Other commission types should never be zero, so including them in the payroll
                        // will give them a chance to be seen and investigated.
                        if (log.NetAmount != decimal.Zero || (log.NetAmount == decimal.Zero &&
                            log.PayrollLogTypeId != (int)PayrollLogType.MentorshipCommission &&
                            log.PayrollLogTypeId != (int)PayrollLogType.TransferCommission))
                        {
                            // Update AgentPayrollLog
                            log.PayrollPaymentId = agentPayment.PayrollPaymentId;

                            log.SetAsUpdated(user.GetUserId());

                            await this.Context.AgentPayrollLogs.SetPayrollPaymentAsync(log);
                        }
                    }

                    prevAgentId = log.AgentId;
                }
            }

            return payrollPayments;
        }

        public async Task<PreviewPayrollBatchDto> PreviewPayrollAsync(DateTime startDate, DateTime endDate, DateTime nextPayrollDate, int? agentId = null)
        {
            this.Logger.LogDebug($"PreviewPayrollAsync");

            var batch = new PreviewPayrollBatchDto();

            batch.PayrollPeriod = nextPayrollDate;
            batch.PayrollPeriodStart = startDate;
            batch.PayrollPeriodEnd = endDate;

            this.Logger.LogDebug($"\t PayrollPeriod:      {batch.PayrollPeriod:MM/dd/yyyy}");
            this.Logger.LogDebug($"\t PayrollPeriodStart: {batch.PayrollPeriodStart:MM/dd/yyyy}");
            this.Logger.LogDebug($"\t PayrollPeriodEnd:   {batch.PayrollPeriodEnd:MM/dd/yyyy}");

            this.Context.BeginTransaction();

            try
            {
                // Get AgentPayrollLog records
                var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByReceivedDateRangeAsync(startDate, endDate);

                if (agentId != null)
                {
                    agentPayrollLogs = agentPayrollLogs
                        .Where(x => x.AgentId == agentId.Value)
                        .ToList();
                }
                var payrollPayments = await this.ProcessPayrollAsync(batch, agentPayrollLogs, null, true);

                // Update PayrollBatch
                batch.RunDate = TimeProvider.Current.Now;
                batch.PayrollPayments = payrollPayments;

                batch.TotalAgentWorkingAmount = batch.PayrollPayments.Total(x => x.AgentWorkingAmount).ToFixed();
                batch.TotalGrossCommissionAmount = batch.PayrollPayments.Total(x => x.GrossCommissionAmount).ToFixed();
                batch.TotalNetCommissionAmount = batch.PayrollPayments.Total(x => x.NetCommissionAmount).ToFixed();
                batch.TotalNonExclusiveArtistFeeAmount = batch.PayrollPayments.Total(x => x.NonExclusiveArtistFeeAmount).ToFixed();
                batch.TotalSharedBonusAmount = batch.PayrollPayments.Total(x => x.SharedBonusAmount).ToFixed();
                batch.TotalPayrollAmount = batch.PayrollPayments.Total(x => x.PayrollAmount).ToFixed();
                batch.TotalCafeteriaPlanAmount = batch.PayrollPayments.Total(x => x.CafeteriaPlanAmount).ToFixed();

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return batch;
        }

        public async Task<PayrollBatchDto> RunPayrollAsync(DateTime asOfDate, IPrincipal user)
        {
            PayrollBatchDto batch = null;

            this.Logger.LogDebug($"RunPayrollAsync: As Of Date: {asOfDate:MM/dd/yyyy}");

            this.Context.BeginTransaction();

            try
            {
                // Create PayrollBatch record if doesn't exist
                var nextPayrollDate = this.GetNextPayrollDate(asOfDate);

                this.Logger.LogDebug($"\t nextPayrollDate: {nextPayrollDate:MM/dd/yyyy}");

                // check if record for payroll batch exists
                batch = await this.Context.PayrollBatches.GetPendingPayrollBatchAsync();
                if (batch == null)
                {
                    //// var newBatch = await this.CalculateNextPayrollBatchAsync(asOfDate);
                    var newBatch = new PayrollBatchDto();

                    var startDate = this.GetPayrollStartDate(asOfDate, nextPayrollDate);

                    var endDate = this.GetPayrollEndDate(asOfDate, nextPayrollDate);

                    var lastBatch = await this.Context.PayrollBatches.GetLastPayrollBatchAsync(nextPayrollDate);

                    // Check to see if there was a payroll period that was skipped.
                    if (lastBatch != null && lastBatch.PayrollPeriodEnd.AddDays(1) < startDate)
                    {
                        // Move the start date back to ensure there isn't a gap.
                        startDate = lastBatch.PayrollPeriodEnd.AddDays(1);
                    }

                    newBatch.PayrollPeriod = nextPayrollDate;
                    newBatch.PayrollPeriodStart = startDate;
                    newBatch.PayrollPeriodEnd = endDate;
                    newBatch.RunDate = TimeProvider.Current.Now;

                    newBatch.SetAsCreated(user.GetUserId());

                    await this.Context.PayrollBatches.CreateAsync(newBatch);

                    batch = newBatch;
                }
                else
                {
                    this.Context.Rollback();
                    return batch;
                }

                this.Logger.LogDebug($"\t PayrollBatchId:     {batch.PayrollBatchId}");
                this.Logger.LogDebug($"\t PayrollPeriod:      {batch.PayrollPeriod:MM/dd/yyyy}");
                this.Logger.LogDebug($"\t PayrollPeriodStart: {batch.PayrollPeriodStart:MM/dd/yyyy}");
                this.Logger.LogDebug($"\t PayrollPeriodEnd:   {batch.PayrollPeriodEnd:MM/dd/yyyy}");

                // Get AgentPayrollLog records
                var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByReceivedDateRangeAsync(batch.PayrollPeriodStart, batch.PayrollPeriodEnd);
                var payrollPayments = await this.ProcessPayrollAsync(batch, agentPayrollLogs, user, false);

                // Update PayrollBatch
                batch.RunDate = TimeProvider.Current.Now;

                batch.TotalGrossCommissionAmount = payrollPayments.Total(x => x.GrossCommissionAmount).ToFixed();
                batch.TotalNetCommissionAmount = payrollPayments.Total(x => x.NetCommissionAmount).ToFixed();
                batch.TotalAgentWorkingAmount = payrollPayments.Total(x => x.AgentWorkingAmount).ToFixed();
                batch.TotalPayrollAmount = payrollPayments.Total(x => x.PayrollAmount + x.CafeteriaPlanAmount).ToFixed();
                batch.TotalProgramsAmount =
                    payrollPayments.Total(x => x.NonExclusiveArtistFeeAmount).ToFixed() +
                    payrollPayments.Total(x => x.SharedBonusAmount).ToFixed();

                batch.SetAsUpdated(user.GetUserId());

                await this.Context.PayrollBatches.UpdateAsync(batch);

                this.Context.Commit();
            }
            catch (NoCommissionProgramException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return batch;
        }

        public async Task PostPayrollAsync(PayrollBatchDto batch, IPrincipal user)
        {
            if (batch == null)
            {
                throw new ArgumentNullException(nameof(batch));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (batch.PostDate != null)
            {
                throw new AlreadyPostedException($"Payroll batch {batch.PayrollBatchId} is already posted.");
            }

            try
            {
                this.Context.BeginTransaction();

                var now = TimeProvider.Current.Now;
                var isApplyPayroll = await Helper.GetApplyPayroll();
                //// Set PostDate on AgentPayrollLog
                var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByPayrollBatchIdAsync(batch.PayrollBatchId);
                foreach (var log in agentPayrollLogs)
                {
                    if (isApplyPayroll)
                    {
                        if (!log.IsExclude)
                        {
                            log.PostDate = now;

                            log.SetAsUpdated(user);
                        }
                        else
                        {
                            log.PayrollPaymentId = null;
                            log.IsExclude = false;
                            log.ExcludeDate = null;
                        }
                    }
                    else
                    {
                        log.IsExclude = false;
                        log.ExcludeDate = null;
                        log.PostDate = now;
                        log.SetAsUpdated(user);
                    }

                    await this.Context.AgentPayrollLogs.UpdateAsync(log);
                }

                //// Set PostDate on PayrollPayment
                var payrollPayments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);

                foreach (var payment in payrollPayments)
                {
                    payment.PostDate = now;

                    payment.SetAsUpdated(user);

                    await this.Context.PayrollPayments.UpdateAsync(payment);
                }

                //// Set PostDate on PayrollBatch
                batch.PostDate = now;

                batch.SetAsUpdated(user);

                await this.Context.PayrollBatches.UpdateAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<PayrollBatchDto> GetPayrollBatchByIdAsync(int id)
        {
            return await this.Context.PayrollBatches.GetPayrollBatchByIdAsync(id);
        }

        public async Task<IList<PayrollDetailsLogDto>> GetPayrollDetailsLogsAsync(int payrollBatchId)
        {
            return await this.Context.PayrollPayments.GetPayrollDetailsLogByPayrollBatchIdAsync(payrollBatchId);
        }

        public async Task<SettingPayrollDto> GetSettingPayrollAsync(int payrollBatchId)
        {
            return await this.Context.PayrollPayments.GetSettingPayrollAsync(payrollBatchId);
        }
        public async Task<AgentPayrollDetailsDto> GetAgentPayrollDetailsAsync(int payrollPaymentId)
        {
            var agentPayrollDetails = new AgentPayrollDetailsDto();

            var payment = await this.Context.PayrollPayments.GetByIdAsync(payrollPaymentId);

            agentPayrollDetails.PayrollPaymentId = payment.PayrollPaymentId;
            agentPayrollDetails.AgentId = payment.AgentId;
            agentPayrollDetails.AgentFullName = payment.AppUser.FullName;

            agentPayrollDetails.PayrollBatchId = payment.PayrollBatchId;

            var batch = await this.Context.PayrollBatches.GetPayrollBatchByIdAsync(payment.PayrollBatchId);

            agentPayrollDetails.PostDate = batch.PostDate;

            agentPayrollDetails.PayrollDate = batch.PayrollPeriod;

            agentPayrollDetails.TotalCollections = payment.GrossCommissionAmount;

            agentPayrollDetails.TotalAgentWorking = payment.AgentWorkingAmount;

            agentPayrollDetails.CafeteriaPlan = payment.CafeteriaPlanAmount;

            agentPayrollDetails.AgentPayrollTotal = payment.PayrollAmount;

            agentPayrollDetails.YTDGross = payment.YTDGrossCommissionAmount + payment.GrossCommissionAmount;

            var agentPayrolls = await this.Context.AgentPayrollLogs.GetByPayrollPaymentIdAsync(payrollPaymentId);

            agentPayrollDetails.AgentEarned = agentPayrolls.Where(x => x.PayrollLogTypeId == (int)PayrollLogType.AgentCommission && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.YTDNet = payment.YTDNetCommissionAmount + agentPayrollDetails.AgentEarned;

            agentPayrollDetails.Mentorships = agentPayrolls.Where(x => x.PayrollLogTypeId == (int)PayrollLogType.MentorshipCommission && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.PresenterTransfers = agentPayrolls.Where(x => x.PayrollLogTypeId == (int)PayrollLogType.TransferCommission && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.SharedBonus = agentPayrolls.Where(x => x.PayrollLogTypeId == (int)PayrollLogType.SharedBonus && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.NonExclusiveArtistFee = agentPayrolls.Where(x => x.PayrollLogTypeId == (int)PayrollLogType.NonExclusiveArtistFee && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.RegularCommissions = agentPayrolls.Where(x => x.LineOfBusinessId == (int)LineOfBusiness.Core && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.NationalCommissions = agentPayrolls.Where(x => x.LineOfBusinessId == (int)LineOfBusiness.National && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.TouringCommissions = agentPayrolls.Where(x => x.LineOfBusinessId == (int)LineOfBusiness.Touring && !x.IsExclude).Sum(x => x.NetAmount);

            agentPayrollDetails.AgentSubtotal = payment.NetCommissionAmount + payment.SharedBonusAmount + payment.NonExclusiveArtistFeeAmount + payment.AgentWorkingAmount;

            agentPayrollDetails.TotalCommissionsPrograms =
                agentPayrollDetails.AgentEarned +
                agentPayrollDetails.Mentorships +
                agentPayrollDetails.PresenterTransfers +
                agentPayrollDetails.SharedBonus +
                agentPayrollDetails.NonExclusiveArtistFee;

            return agentPayrollDetails;
        }

        public async Task<IList<AgentEarnedCommissionsDto>> GetAgentEarnedCommissionsAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetAgentEarnedCommissionsAsync(payrollPaymentId);
        }

        public async Task<IList<MentorshipBonusCommissionsDto>> GetMentorshipBonusCommissionsAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetMentorshipBonusCommissionsAsync(payrollPaymentId);
        }

        public async Task<IList<PresenterTransferBonusCommissionsDto>> GetPresenterTransferBonusCommissionsAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetPresenterTransferBonusCommissionsAsync(payrollPaymentId);
        }

        public async Task<IList<SharedBonusDto>> GetSharedBonusAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetSharedBonusAsync(payrollPaymentId);
        }

        public async Task<IList<NonExclusiveArtistFeeDto>> GetNonExclusiveArtistFeeAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetNonExclusiveArtistFeeAsync(payrollPaymentId);
        }

        public async Task<IList<AgentWorkingDto>> GetAgentWorkingAsync(int payrollPaymentId)
        {
            return await this.Context.AgentPayrollLogs.GetAgentWorkingAsync(payrollPaymentId);
        }

        public async Task<IList<PayrollContractTransactionDto>> GetCommissionTransactionsAsync(ContractTransactionSearchCriteriaDto criteria)
        {
            return await this.Context.ContractTransactions.GetCommissionTransactionsAsync(criteria);
        }
        public async Task<bool> SetPayrollPaymentAsync(PayrollPaymentViewModel viewModel, IPrincipal user)
        {
            return await this.Context.AgentPayrollLogs.SetPayrollPaymentAsync(viewModel, user);

        }
        public async Task<bool> SetAgentPayrollLogAsync(AgentPayrollPaymentLogViewModel viewModel, IPrincipal user)
        {
            return await this.Context.AgentPayrollLogs.SetAgentPayrollLogAsync(viewModel, user);
        }
        public async Task<bool> ExcludePayrollPaymentAsync(int payrollBatchId, IPrincipal user)
        {
            return await this.Context.AgentPayrollLogs.ExcludePayrollPaymentAsync(payrollBatchId, user);
        }

        public async Task CreateAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.AgentPayrollLogs.CreateAsync(dto);

                if (dto.PayrollPaymentId.HasValue)
                {
                    var payment = await this.Context.PayrollPayments.GetByIdAsync(dto.PayrollPaymentId.GetValueOrDefault());
                    if (payment == null)
                    {
                        throw new ArgumentException($"Payroll Payment {dto.PayrollPaymentId.GetValueOrDefault()} not found.");
                    }

                    await this.Context.PayrollPayments.SyncPaymentTotalsAsync(payment.PayrollPaymentId);

                    await this.Context.PayrollBatches.SyncBatchTotalsAsync(payment.PayrollBatchId);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.AgentPayrollLogs.UpdateAsync(dto);

                if (dto.PayrollPaymentId.HasValue)
                {
                    var payment = await this.Context.PayrollPayments.GetByIdAsync(dto.PayrollPaymentId.GetValueOrDefault());
                    if (payment == null)
                    {
                        throw new ArgumentException($"Payroll Payment {dto.PayrollPaymentId.GetValueOrDefault()} not found.");
                    }

                    await this.Context.PayrollPayments.SyncPaymentTotalsAsync(payment.PayrollPaymentId);

                    await this.Context.PayrollBatches.SyncBatchTotalsAsync(payment.PayrollBatchId);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task RemoveAgentPayrollLogFromPayrollAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (dto.PayrollPaymentId == null)
                {
                    throw new ArgumentException($"Agent Payroll Log {dto.AgentPayrollLogId} is not part of a batch.");
                }

                var original = await this.Context.AgentPayrollLogs.GetByIdAsync(dto.AgentPayrollLogId);

                var payment = await this.Context.PayrollPayments.GetByIdAsync(original.PayrollPaymentId.GetValueOrDefault());
                if (payment == null)
                {
                    throw new ArgumentException($"Payroll Payment {dto.PayrollPaymentId.GetValueOrDefault()} not found.");
                }

                original.PayrollPaymentId = null;

                original.SetAsUpdated(user);

                await this.Context.AgentPayrollLogs.UpdateAsync(original);

                await this.Context.PayrollPayments.SyncPaymentTotalsAsync(payment.PayrollPaymentId);

                await this.Context.PayrollBatches.SyncBatchTotalsAsync(payment.PayrollBatchId);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteAgentPayrollLogAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (dto.PayrollPaymentId.HasValue)
                {
                    await this.RemoveAgentPayrollLogFromPayrollAsync(dto, user);
                }

                await this.Context.AgentPayrollLogs.DeleteAsync(dto.AgentPayrollLogId);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task AddAgentPayrollLogToPayrollAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var batch = await this.GetPendingPayrollBatchAsync();
                if (batch == null)
                {
                    throw new ArgumentNullException(nameof(batch));
                }

                var original = await this.Context.AgentPayrollLogs.GetByIdAsync(dto.AgentPayrollLogId);

                var payments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);

                var agentPayment = payments.FirstOrDefault(x => x.AgentId == original.AgentId);
                if (agentPayment == null)
                {
                    agentPayment = new PayrollPaymentDto();
                    agentPayment.AgentId = original.AgentId;
                    agentPayment.PayrollBatchId = batch.PayrollBatchId;
                    agentPayment.SetAsCreated(user);

                    await this.Context.PayrollPayments.CreateAsync(agentPayment);
                }

                var mostRecentPayment = await this.Context.PayrollPayments.GetMostRecentByAgentIdAsync(original.AgentId);

                if (mostRecentPayment != null && mostRecentPayment.PostDate.GetValueOrDefault().Year == TimeProvider.Current.Now.Year)
                {
                    agentPayment.YTDGrossCommissionAmount = mostRecentPayment.YTDGrossCommissionAmount + mostRecentPayment.GrossCommissionAmount;

                    agentPayment.YTDNetCommissionAmount = mostRecentPayment.YTDNetCommissionAmount + mostRecentPayment.PayrollAmount;
                }

                var agentCommission = await this._commissionManagementService.GetAgentCommissionByAgentIdAsync(agentPayment.AgentId, true);
                if (agentCommission == null || agentCommission.AgentCommissionId == null)
                {
                    throw new NoCommissionProgramException();
                }

                var typeData = agentCommission.CommissionTiers;

                var mentorPrograms = await this.Context.AgentCommissionProgram.GetMentorshipProgramsForCommissionByAppUserAsync(agentPayment.AgentId);

                await this.CalculateNetAmountAsync(original, batch, agentCommission, agentPayment, typeData, mentorPrograms);

                original.PayrollPaymentId = agentPayment.PayrollPaymentId;

                original.SetAsUpdated(user);

                await this.Context.AgentPayrollLogs.SetPayrollPaymentAsync(original);

                await this.Context.PayrollPayments.SyncPaymentTotalsAsync(agentPayment.PayrollPaymentId);

                await this.Context.PayrollBatches.SyncBatchTotalsAsync(batch.PayrollBatchId);

                this.Context.Commit();
            }
            catch (NoCommissionProgramException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeletePendingPayrollBatch()
        {
            this.Context.BeginTransaction();

            try
            {
                var batch = await this.GetPendingPayrollBatchAsync();
                if (batch == null)
                {
                    throw new ArgumentNullException(nameof(batch));
                }

                var agentPayrollLogs = await this.Context.AgentPayrollLogs.GetByPayrollBatchIdAsync(batch.PayrollBatchId);
                foreach (var log in agentPayrollLogs)
                {
                    log.PayrollPaymentId = null;
                    await this.Context.AgentPayrollLogs.SetPayrollPaymentAsync(log);
                }

                var payments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);
                foreach (var payment in payments)
                {
                    await this.Context.PayrollPayments.DeleteAsync(payment);
                }

                await this.Context.PayrollBatches.DeleteAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<PayrollPaymentDto>> GetPayrollPaymentsByPayrollBatchIdAsync(PayrollBatchDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            var payments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(dto.PayrollBatchId);

            return payments;
        }

        public async Task AddAgentToPayrollBatchAsync(PayrollBatchDto dto, int agentId, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var batch = await this.GetPendingPayrollBatchAsync();
                if (batch == null || dto.PayrollBatchId != batch.PayrollBatchId)
                {
                    throw new ArgumentNullException(nameof(batch));
                }

                var payments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);

                var agentPayment = payments.FirstOrDefault(x => x.AgentId == agentId);
                if (agentPayment == null)
                {
                    agentPayment = new PayrollPaymentDto();
                    agentPayment.AgentId = agentId;
                    agentPayment.PayrollBatchId = batch.PayrollBatchId;
                    agentPayment.SetAsCreated(user);

                    await this.Context.PayrollPayments.CreateAsync(agentPayment);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task RecalculatePayrollBatchAsync(PayrollBatchDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var batch = await this.GetPendingPayrollBatchAsync();
                if (batch == null || dto.PayrollBatchId != batch.PayrollBatchId)
                {
                    throw new ArgumentNullException(nameof(batch));
                }

                var payments = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);

                foreach (var payment in payments)
                {
                    await this.Context.PayrollPayments.SyncPaymentTotalsAsync(payment.PayrollPaymentId);
                }

                await this.Context.PayrollBatches.SyncBatchTotalsAsync(batch.PayrollBatchId);


                var paymentsUpdate = await this.Context.PayrollPayments.GetPayrollPaymentsByPayrollBatchIdAsync(batch.PayrollBatchId);

                foreach (var payment in paymentsUpdate)
                {
                    var paymentData = await this._context.PayrollPayments.FirstOrDefaultAsync(a => a.PayrollPaymentId == payment.PayrollPaymentId);


                    paymentData.IsExclude = false;

                    var paymentLogs = this._context.AgentPayrollLogs.Where(a => a.PayrollPaymentId == paymentData.PayrollPaymentId);
                    await paymentLogs.ForEachAsync(a =>
                    {
                        a.IsExclude = false;
                        a.ExcludeDate = null;
                    });
                }
                await this._context.SaveChangesAsync();
                this.Context.Commit();



                Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
                keyValuePairsParams.Add("@PayRollInEx", null);
                keyValuePairsParams.Add("@PayrollPaymentInEx", null);
                keyValuePairsParams.Add("@BatchId", batch.PayrollBatchId);
                keyValuePairsParams.Add("@UserId", user.GetUserId());
                await DaoHelper.GetExecuteStoreProcedureParticular("Sp_Set_Include_Exclude_Contract_Payroll", keyValuePairsParams);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }


    }
}