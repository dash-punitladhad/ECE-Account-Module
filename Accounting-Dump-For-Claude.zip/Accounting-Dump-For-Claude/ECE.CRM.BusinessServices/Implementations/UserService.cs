﻿namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using Dapper;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.Logging;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Linq;
    using System.Net;
    using System.Security.Principal;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    /// <summary>
    /// User Service Implementation.
    /// </summary>
    public class UserService : IUserService
    {
        public static readonly string UnknownUser = "Unknown User";

        private readonly IRolePermissionService _rolePermissionService;
        private readonly ILookupService _lookupService;
        private readonly IEmailQueueService _emailQueueService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IAppUserSettingService _appUserSettingService;
        private readonly IEceCrmEntities _eceCrmEntities;
        public ILogger Logger { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="UserService" /> class.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="rolePermissionService">The role permission service.</param>
        /// <param name="lookupService">The lookup service.</param>
        /// <param name="emailQueueService">The email queue service.</param>
        /// <param name="entityHistoryService">The entity history service.</param>
        /// <param name="appUserSettingService">The app user settings service.</param>
        public UserService(IUnitOfWork context,
                           IRolePermissionService rolePermissionService,
                           ILookupService lookupService,
                           IEmailQueueService emailQueueService,
                           IEntityHistoryService entityHistoryService, IEceCrmEntities eceCrmEntities,
                           IAppUserSettingService appUserSettingService = null)
        {
            this.Context = context;

            this._rolePermissionService = rolePermissionService;
            this._lookupService = lookupService;
            this._emailQueueService = emailQueueService;
            this._entityHistoryService = entityHistoryService;
            this._appUserSettingService = appUserSettingService;
            this._eceCrmEntities = eceCrmEntities;
            Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
        }

        /// <summary>
        /// Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public IUnitOfWork Context { get; private set; }

        /// <summary>
        /// Authenticates the user.
        /// </summary>
        /// <param name="userName">The username.</param>
        /// <param name="password">The password.</param>
        /// <returns>An authentication status representing the result.</returns>
        public async Task<AuthenticationStatus> AuthenticateUserAsync(string userName, string password)
        {
            AppUserDto user = null;
            var status = AuthenticationStatus.Unknown;

            int maxAttempts = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Security.MaxInvalidPasswordAttempts"]);
            int attemptWindow = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Security.PasswordAttemptWindowMinutes"]);
            int maxPasswordAge = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Security.MaxPasswordAgeDays"]);

            user = await this.Context.Users.GetByCriteriaAsync(new AppUserDto { Username = userName });

            if (user == null || user.BlockUser)
            {
                // Sad trombone
                return AuthenticationStatus.UserNotFound;
            }

            // Hold on to your butts
            // 1.) Check to see if the account is inactive
            if (!user.IsActive)
            {
                return AuthenticationStatus.InactiveUser;
            }

            // 2.) Check to see if the account is locked
            var lockoutWindow = DateTime.Now.AddHours(-MobiusConfiguration.Current.AppSettings.GetInt32("Security.LockoutWindowHours"));

            if (user.IsLockedOut && (user.LockoutDate > lockoutWindow))
            {
                return AuthenticationStatus.UserLockedOut;
            }

            // Encrypt the provided password using the user's salt
            string encryptedPassword = SecurityHelper.EncryptPassword(password, user.PasswordSalt);

            // 3.) User exists, account is active, and is not locked out
            //     Valid Password
            if (user.Password == encryptedPassword)
            {
                // Reset data
                user.IsLockedOut = false;
                user.InvalidLoginAttempts = 0;
                user.InvalidLoginAttemptWindowStart = null;
                user.LockoutDate = null;
                user.LastLoginDate = DateTime.Now;
                user.PasswordToken = null;
                user.PasswordTokenDate = null;

                // 4.) Determine if user needs to reset password
                if (user.PasswordLastChanged == null ||
                    (DateTime.Now - (DateTime)user.PasswordLastChanged).TotalDays > maxPasswordAge)
                {
                    status = AuthenticationStatus.MustChangePassword;
                }
                else
                {
                    status = AuthenticationStatus.Valid;
                }
            }
            else
            {
                // 5.) Invalid password - You didn't say the magic word
                // First failed attempt since a success
                if (user.InvalidLoginAttemptWindowStart == null)
                {
                    user.InvalidLoginAttempts = 1;
                    user.InvalidLoginAttemptWindowStart = DateTime.Now;
                }
                else if (DateTime.Now > user.InvalidLoginAttemptWindowStart.Value.AddMinutes(attemptWindow))
                {
                    // Reset invalid login attempt after window expires
                    user.InvalidLoginAttempts = 1;
                    user.InvalidLoginAttemptWindowStart = DateTime.Now;
                }
                else
                {
                    user.InvalidLoginAttempts++;
                }

                // 6.) Determine if user has been locked out
                if (user.InvalidLoginAttempts > maxAttempts)
                {
                    user.IsLockedOut = true;
                    user.LockoutDate = DateTime.Now;

                    status = AuthenticationStatus.UserLockedOut;
                }
                else
                {
                    status = AuthenticationStatus.InvalidPassword;
                }
            }

            this.Context.BeginTransaction();

            try
            {
                await this.Context.Users.UpdateAsync(user);

                if (status == AuthenticationStatus.UserLockedOut)
                {
                    var history = new EntityHistoryDto
                    {
                        EntityId = user.AppUserId.Value,
                        Type = EntityType.User,
                        Event = AuditEvent.UserIsLockedOut,
                        Description = "--",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.AppUserId.Value,
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return status;
        }

        /// <summary>
        /// Unlocks the user.
        /// </summary>
        /// <param name="userToUnlockId">The user identifier.</param>
        /// <param name="user">The user.</param>
        /// <returns><c>true</c> if user is unlocked, <c>false</c> otherwise.</returns>
        public async Task<bool> UnlockUserAsync(int userToUnlockId, IPrincipal user)
        {
            var appUser = await this.Context.Users.GetByCriteriaAsync(new AppUserDto { AppUserId = userToUnlockId });
            var result = false;

            appUser.IsLockedOut = false;
            appUser.InvalidLoginAttempts = 0;
            appUser.InvalidLoginAttemptWindowStart = null;
            appUser.LockoutDate = null;

            this.Context.BeginTransaction();

            try
            {
                result = await this.Context.Users.UpdateAsync(appUser);

                var history = new EntityHistoryDto
                {
                    EntityId = appUser.AppUserId.Value,
                    Type = EntityType.User,
                    Event = AuditEvent.UserIsUnlocked,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return result;
        }

        /// <summary>
        /// Initiate the forgot password process.
        /// </summary>
        /// <param name="userToProcess">The user to process.</param>
        /// <param name="user">The user.</param>
        /// <returns><c>true</c> if successful, <c>false</c> otherwise.</returns>
        public async Task<bool> InitiateForgotPasswordAsync(AppUserDto userToProcess, IPrincipal user)
        {
            var result = false;
            string token = SecurityHelper.GeneratePasswordToken();

            var updatedById = user.GetUserId();
            if (updatedById == -1)
            {
                updatedById = userToProcess.AppUserId.Value;
            }

            // Save the new token
            userToProcess.PasswordToken = token;
            userToProcess.PasswordTokenDate = DateTime.Now;
            userToProcess.UpdatedDate = DateTime.Now;
            userToProcess.UpdatedById = updatedById;

            this.Context.BeginTransaction();

            try
            {
                result = await this.Context.Users.UpdateAsync(userToProcess);

                var history = new EntityHistoryDto
                {
                    EntityId = userToProcess.AppUserId.Value,
                    Type = EntityType.User,
                    Event = AuditEvent.UserForgotPassword,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedById
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();

                await this.GenerateForgotPasswordEmail(userToProcess);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return result;
        }

        /// <summary>
        /// Resets the user's password.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns><c>true</c> if reset was successful, <c>false</c> otherwise.</returns>
        public async Task<bool> ResetPasswordAsync(int userId, string newPassword)
        {
            var result = false;
            var user = new AppUserDto { AppUserId = userId };

            user = await this.Context.Users.GetByCriteriaAsync(new AppUserDto { AppUserId = userId });

            // Set everything needed to reset
            user.PasswordSalt = SecurityHelper.GenerateSalt();
            user.Password = SecurityHelper.EncryptPassword(newPassword, user.PasswordSalt);
            user.PasswordLastChanged = DateTime.Now;
            user.IsLockedOut = false;
            user.InvalidLoginAttempts = 0;
            user.InvalidLoginAttemptWindowStart = null;
            user.LockoutDate = null;
            user.PasswordToken = null;
            user.PasswordTokenDate = null;
            user.UpdatedById = userId;
            user.UpdatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                result = await this.Context.Users.UpdateAsync(user);
                await AuditPasswordChangeAsync(user);

                this.Context.Commit();

                await GeneratePasswordChangeNotificationAsync(user);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return result;
        }

        /// <summary>
        /// Changes the password.
        /// </summary>
        /// <param name="username">The user name.</param>
        /// <param name="oldPassword">The old password.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns><c>true</c> if successful, <c>false</c> otherwise.</returns>
        public async Task<bool> ChangePasswordAsync(string username, string oldPassword, string newPassword)
        {
            // 1.) Authenticate user to make sure old password is correct
            // NOTE: This could lockout the user
            AuthenticationStatus status = await AuthenticateUserAsync(username, oldPassword);

            if (status != AuthenticationStatus.Valid)
            {
                return false;
            }

            var user = await GetUserAsync(new AppUserDto { Username = username });

            // Set everything needed to reset
            user.PasswordSalt = SecurityHelper.GenerateSalt();
            user.Password = SecurityHelper.EncryptPassword(newPassword, user.PasswordSalt);
            user.PasswordLastChanged = DateTime.Now;
            user.IsLockedOut = false;
            user.InvalidLoginAttempts = 0;
            user.InvalidLoginAttemptWindowStart = null;
            user.LockoutDate = null;
            user.UpdatedById = user.AppUserId;
            user.UpdatedDate = DateTime.Now;

            this.Context.BeginTransaction();

            try
            {
                // 2.) Save new password
                await this.Context.Users.UpdateAsync(user);

                // 3.) Log the password change and generate an email notification to the user
                await AuditPasswordChangeAsync(user);
                await GeneratePasswordChangeNotificationAsync(user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return true;
        }

        /// <summary>
        /// Generates the password change notification.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        public async Task GeneratePasswordChangeNotificationAsync(AppUserDto user)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.ChangedPassword);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.Current.AppSettings["Application.Name"];
            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
            var body = bodyBuilder.Replace("{Body}", bodyTemplate.Body)
                .Replace("{FirstName}", user.FirstName)
                .Replace("{SupportEmail}", MobiusConfiguration.Current.AppSettings["Email.SupportAddress"])
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("''", "'")
                .ToString();

            // Create the message
            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;
            email.To.Add(user.Username);

            this.Context.BeginTransaction();

            try
            {
                var smtpManager = new SmtpManager(this.Context);

                // Send the message, bypassing the email message queue.
                smtpManager.SendMessage(email, user.AppUserId.Value, SendMessageMode.Directly);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// is valid password token as an asynchronous operation.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns><c>true</c> if the specified token is valid; otherwise, <c>false</c>.</returns>
        public async Task<bool> IsValidPasswordTokenAsync(string token)
        {
            AppUserDto user = new AppUserDto { PasswordToken = token };

            user = await this.Context.Users.GetByCriteriaAsync(user);

            // If token is valid, check expiration date
            if (user != null)
            {
                var expireHours = MobiusConfiguration.Current.AppSettings.GetInt32("Security:TokenTimeoutHours");

                if (DateTime.Now <= user.PasswordTokenDate.Value.AddHours(expireHours))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Determines whether the specified password is valid.
        /// </summary>
        /// <param name="password">The password.</param>
        /// <returns><c>true</c> if password is valid; otherwise, <c>false</c>.</returns>
        public bool IsValidPassword(string password)
        {
            // Note: Assume input string is trimmed
            var minRequiredLength = MobiusConfiguration.Current.AppSettings.GetInt32("Security.MinPasswordLength");
            var complexityCount = 0;

            // Password must be:
            // 1. At least min length characters long
            if (password.Length < minRequiredLength)
            {
                return false;
            }

            // 4. Must contain at least one of the following:
            // a. Number
            if (Regex.IsMatch(password, @"[0-9]", RegexOptions.None))
            {
                complexityCount++;
            }

            // b. Special Characters
            if (Regex.IsMatch(password, @"[~!@#$%\^&*]", RegexOptions.None))
            {
                complexityCount++;
            }

            if (complexityCount != 2)
            {
                return false;
            }

            return true;
        }

        public async Task<AppUserDto> GetUserByIdAsync(int id, bool includeRolesPermissions = false)
        {
            var result = await this.Context.Users.GetByIdAsync(id);

            if (result != null && includeRolesPermissions)
            {
                result.Permissions = await _rolePermissionService.GetPermissionsForUserAsync(id);
                result.Roles = await _rolePermissionService.GetRolesForUserAsync(id);
            }

            return result;
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <param name="includeRolesPermissions">if set to <c>true</c> then include roles and permissions.</param>
        /// <param name="includeSettings">if set to <c>true</c> then include settings.</param>
        /// <returns>The application user data if found; otherwise null.</returns>
        public async Task<AppUserDto> GetUserAsync(AppUserDto criteria, bool includeRolesPermissions = false, bool includeSettings = false)
        {
            var result = await this.Context.Users.GetByCriteriaAsync(criteria);

            if (result != null && includeRolesPermissions)
            {
                result.Permissions = await _rolePermissionService.GetPermissionsForUserAsync((int)result.AppUserId);
                result.Roles = await _rolePermissionService.GetRolesForUserAsync((int)result.AppUserId);
            }

            if (result != null && includeSettings)
            {
                result.Settings = await _appUserSettingService.GetAppUserSettingsAsync((int)result.AppUserId);
            }

            return result;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="updatedUser">The updated user.</param>
        /// <param name="user">The user performing the update.</param>
        /// <param name="isAdminUpdate">if set to <c>true</c> [updated performed by admin].</param>
        /// <returns><c>true</c> if update successful, <c>false</c> otherwise.</returns>
        public async Task<bool> UpdateDetailsAsync(AppUserDto updatedUser, IPrincipal user, bool isAdminUpdate = false)
        {
            if (updatedUser == null)
            {
                throw new ArgumentNullException(nameof(updatedUser));
            }

            var result = false;

            this.Context.BeginTransaction();

            try
            {
                result = await this.Context.Users.UpdateDetailsAsync(updatedUser, isAdminUpdate);

                if (result && updatedUser.Settings != null)
                {
                    await this._appUserSettingService.SyncSettingsAsync(updatedUser.AppUserId.Value, updatedUser.Settings, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return result;
        }

        /// <summary>
        /// Determines the landing page.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The landing page for the user.</returns>
        public async Task<LandingPage?> DetermineLandingPageAsync(AppUserDto user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            // User has a landing page already set
            if (user.LandingPageId.HasValue)
            {
                return (LandingPage)user.LandingPageId.Value;
            }

            // Need the user's role to determine page
            if (user.Roles.Count == 0)
            {
                user.Roles = await this._rolePermissionService.GetRolesForUserAsync((int)user.AppUserId);
            }

            // Get the role with the lowest rank and then the landing page for that role
            var highestRankRole = user.Roles.OrderBy(r => r.RankOrder).FirstOrDefault();
            if (highestRankRole != null)
            {
                var pages = await this._lookupService.GetLandingPagesByCriteriaAsync(new LandingPageDto { RoleId = highestRankRole.RoleId });
                if (pages.Count >= 1)
                {
                    return (LandingPage)pages[0].LandingPageId.GetValueOrDefault();
                }
                if ((highestRankRole.RoleId == (int)ECERole.DOM || highestRankRole.RoleId == (int)ECERole.DOAS) && !highestRankRole.IsDeleted)
                {
                    return (LandingPage)LandingPage.AccountingDashboard;
                }
                
            }

            return null;
        }

        /// <summary>
        /// Determines the landing page.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>The landing page for the user.</returns>
        public async Task<LandingPage?> DetermineDashboardAsync(AppUserDto user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            // Get all the dashboards
            var dashboards = await this._lookupService.GetLandingPagesByCriteriaAsync(new LandingPageDto { IsDashboard = true });

            // User has a landing page already set which is a dashboard
            if (user.LandingPageId.HasValue)
            {
                // Valid match, return
                if (dashboards.Any(x => x.LandingPageId == user.LandingPageId.Value))
                {
                    return (LandingPage)user.LandingPageId.GetValueOrDefault();
                }
            }

            // Need the user's role to determine page
            if (user.Roles.Count == 0)
            {
                user.Roles = await this._rolePermissionService.GetRolesForUserAsync((int)user.AppUserId);
            }

            // Get the role Id for the role with the lowest rank and then the landing page for that role
            var dashboard = (from r in user.Roles
                             join d in dashboards on r.RoleId equals d.RoleId
                             orderby r.RankOrder
                             select d).FirstOrDefault();

            if (dashboard != null)
            {
                return (LandingPage)dashboard.LandingPageId.GetValueOrDefault();
            }

            return null;
        }

        /// <summary>
        /// Gets the user's last X password history.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>A collection of AppUserPasswordHistoryDtos.</returns>
        public async Task<IList<AppUserPasswordHistoryDto>> GetPasswordHistoryAsync(int userId)
        {
            int passwordHistoryCount = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Security.PasswordHistoryCount"]);

            var history = await this.Context.Users.GetPasswordHistoryAsync(userId, passwordHistoryCount);

            return history;
        }

        /// <summary>
        /// Validates the new password against the password history.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="newPassword">The new (unencrypted) password.</param>
        /// <returns><c>true</c> if password does not match any in history, <c>false</c> otherwise.</returns>
        public async Task<bool> ValidatePasswordAgainstHistoryAsync(int userId, string newPassword)
        {
            bool result = true;
            int passwordHistoryCount = Convert.ToInt32(MobiusConfiguration.Current.AppSettings["Security.PasswordHistoryCount"]);

            var history = await this.Context.Users.GetPasswordHistoryAsync(userId, passwordHistoryCount);

            foreach (var record in history)
            {
                // Encrypt the current password with the old salt value
                string testPassword = SecurityHelper.EncryptPassword(newPassword, record.PasswordSalt);

                // Compare new and old password to see if they match
                if (testPassword == record.Password)
                {
                    result = false;
                    break;
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the users by role.
        /// </summary>
        /// <param name="roleId">The role identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> include deleted users.</param>
        /// <returns>A list containing matching users.</returns>
        public IList<AppUserDto> GetUsersByRole(int roleId, bool? isDeleted = null)
        {
            return Context.Users.GetUsersByRole(roleId, isDeleted);
        }

        public async Task<List<AppUserDto>> GetLMDByAgentAsync(int agentId)
        {
            return await Context.Users.GetLMDsByAgentAsync(agentId);
        }

        public IList<AppUserDto> GetAllActive(bool excludeArtistUsers = false)
        {
            return Context.Users.GetAllActive(excludeArtistUsers);
        }

        /// <summary>
        /// check user has role as an asynchronous operation.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="role">The role.</param>
        /// <returns><c>true</c> if the user has the role; otherwise <c>false</c>.</returns>
        public async Task<bool> CheckUserHasRoleAsync(int userId, ECERole role)
        {
            var hasRole = false;

            var user = await this.GetUserAsync(new AppUserDto { AppUserId = userId }, true);

            if (user != null)
            {
                hasRole = user.Roles.Any(x => x.RoleId == (int)role && !x.IsDeleted);
            }

            return hasRole;
        }

        /// <summary>
        /// get user by entity as an asynchronous operation.
        /// </summary>
        /// <param name="entityId">The entity identifier.</param>
        /// <param name="role">The role.</param>
        /// <param name="isActive">The isActive.</param>
        /// <returns>The user data if found; otherwise null.</returns>
        public async Task<AppUserDto> GetUserByEntityAsync(int entityId, ECERole role, bool? isActive = null)
        {
            return await this.Context.Users.GetUserByEntityAsync(entityId, role, isActive);
        }

        public bool UserInRole(int userId, ECERole role)
        {
            return this.Context.Users.UserInRole(userId, role);
        }

        public async Task ToggleUserActiveStatusAsync(int appUserId, bool markAsActive)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.Users.ToggleUserActiveStatusAsync(appUserId, markAsActive);

                var markRolesAsDeleted = !markAsActive;

                await this._rolePermissionService.ToggleUserRoleDeletedStatusAsync(appUserId, markRolesAsDeleted);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// create user as an asynchronous operation.
        /// </summary>
        /// <param name="appUser">The application user to create.</param>
        /// <param name="user">The user creating the new application user.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        public async Task CreateUserAsync(AppUserDto appUser, IPrincipal user)
        {
            if (appUser == null)
            {
                throw new ArgumentNullException(nameof(appUser));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                appUser.SetAsCreated(user);

                var salt = SecurityHelper.GenerateSalt();
                var password = SecurityHelper.GenerateRandomPassword(8, false);

                appUser.PasswordSalt = salt;
                appUser.Password = SecurityHelper.EncryptPassword(password, salt);

                await this.Context.Users.CreateUserAsync(appUser);
                this.Context.Commit();

                await this.GenerateNewUserEmailAsync(appUser, password);
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// load audit information as an asynchronous operation.
        /// </summary>
        /// <param name="dto">The dto.</param>
        /// <returns>A task containing the results of the asynchronous operation.</returns>
        public async Task LoadAuditInfoAsync(BaseDto dto)
        {
            if (dto == null)
            {
                return;
            }

            var createdUser = await this.GetUserAsync(new AppUserDto() { AppUserId = dto.CreatedById });

            dto.CreatedBy = (createdUser == null)
                                ? UserService.UnknownUser
                                : $"{createdUser.FirstName} {createdUser.LastName}";

            if (dto.UpdatedById.HasValue)
            {
                if (dto.UpdatedById.Value == dto.CreatedById)
                {
                    dto.UpdatedBy = dto.CreatedBy;
                }
                else
                {
                    var updatedUser = await this.GetUserAsync(new AppUserDto() { AppUserId = dto.UpdatedById });
                    dto.UpdatedBy = (updatedUser == null)
                                        ? UserService.UnknownUser
                                        : $"{updatedUser.FirstName} {updatedUser.LastName}";
                }
            }
        }

        public async Task<IList<OfficeDto>> GetOfficesForUser(int userId, int? roleId = null)
        {
            return await this.Context.Users.GetOfficesForUserAsync(userId, roleId);
        }

        public async Task<IList<AppUserDto>> GetOfficeCoworkersAsync(int userId, int? roleId = null)
        {
            return await this.Context.Users.GetOfficeCoworkersAsync(userId, roleId);
        }

        public async Task<IList<AppUserDto>> GetByCriteriaAsync(UserSearchCriteriaDto criteria)
        {
            return await this.Context.Users.GetByCriteriaAsync(criteria);
        }

        public IList<AppUserDto> GetByCriteria(UserSearchCriteriaDto criteria)
        {
            return this.Context.Users.GetByCriteria(criteria);
        }

        public async Task<bool> CheckForDuplicatesAsync(int appUserId, string userName, string initials)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                throw new ArgumentNullException(nameof(userName));
            }

            var result = await this.Context.Users.CheckForDuplicatesAsync(appUserId, userName.Trim(), initials);

            return result;
        }


        public async Task CreateAsync(AppUserDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                var userNameTaken = await this.CheckForDuplicatesAsync(-1, dto.Username.Trim(), dto.AgentUserId);
                if (userNameTaken)
                {
                    throw new DuplicateException(EntityType.User, dto.AppUserId);
                }

                if (dto.Roles.Any() && dto.Roles.Count == 1)
                {

                    if (dto.IsInRole(ECERole.DOM) || dto.IsInRole(ECERole.DOAS))
                    {
                        dto.LandingPageId = (int)LandingPage.AccountingDashboard;
                    }
                }

                await this.CreateUserAsync(dto, user);

                var roles = await this._rolePermissionService.SyncRolesAsync(dto.AppUserId.Value, dto.Roles, user);

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.AppUserId.Value,
                    Type = EntityType.User,
                    Event = AuditEvent.Created,
                    Description = "Created",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
                AppUserSettingDto appUserSettingDto = new AppUserSettingDto() { AppUserId = dto.AppUserId.Value, AppUserSettingKey = AppUserSettingKey.HomeOffice.ToString(), AppUserSettingKeyId = (int)AppUserSettingKey.HomeOffice, Value = dto.HomeOfficeId.Value.ToString(), CreatedById = user.GetUserId(), IsDeleted = false, CreatedDate = DateTime.Now };
                if (dto.Settings == null || dto.Settings.Count == 0)
                {
                    dto.Settings.Add(appUserSettingDto);
                    await this._appUserSettingService.SyncSettingsAsync(dto.AppUserId.Value, dto.Settings, user);
                }
                this.Context.Commit();
                //Users Permission Set role wise
                if (roles != null)
                {


                    List<AppUserRoleForPermissionDto> roleList = new List<AppUserRoleForPermissionDto>();
                    foreach (var role in roles)
                    {
                        roleList.Add(new AppUserRoleForPermissionDto() { RoleId = role.RoleId, IsDeleted = role.IsDeleted });
                    }
                    var roleListStr = JsonConvert.SerializeObject(roleList);
                    await this.SetUserRoleWisePermissions(roleListStr, dto.AppUserId.Value, user.GetUserId());

                    try
                    {
                        var artistroleid = (int)ECERole.Artist;
                        var artistserviceroleid = (int)ECERole.ArtistServices;
                        var roleIds = roles.Where(a => !a.IsDeleted).Select(a => a.RoleId);
                        if (!(roleIds.Contains(artistroleid) || roleIds.Contains(artistserviceroleid)))
                        {

                            var biDashboardList = await this._eceCrmEntities.BIDashboards.Where(a => a.IsActive && !a.IsDeleted).ToListAsync();
                            foreach (var item in biDashboardList)
                            {
                                await this.Context.Lookups.UpdateUserWiseBIDashboardAsync(item.BIDashboardId, user);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        Logger.Error(ex);
                    }

                }

            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.User, null, ex);
            }
        }

        public async Task UpdateAsync(AppUserDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var original = await this.Context.Users.GetByCriteriaAsync(new AppUserDto { AppUserId = dto.AppUserId });

                if (original == null)
                {
                    throw new Exception($"User {dto.AppUserId} not found.");
                }
                var userForExistRoles = await this._eceCrmEntities.AppUsers.FirstOrDefaultAsync(a => a.AppUserId == dto.AppUserId);

                var existRoles = new List<int>();
                if (userForExistRoles != null)
                {
                    existRoles = userForExistRoles.AppUserRoles.Where(x => !x.IsDeleted).Select(a => a.RoleId).ToList();
                }
                var userNameTaken = await this.CheckForDuplicatesAsync(dto.AppUserId.Value, dto.Username.Trim(), dto.AgentUserId);
                if (userNameTaken)
                {
                    throw new DuplicateException(EntityType.User, dto.AppUserId.Value);
                }
                dto.ShowInList = original.ShowInList;
                dto.SetAsUpdated(user);

                await this.Context.Users.UpdateAsync(dto);

                var roles = await this._rolePermissionService.SyncRolesAsync(dto.AppUserId.Value, dto.Roles, user);

                await this._appUserSettingService.SyncSettingsAsync(dto.AppUserId.Value, dto.Settings, user);

                await this.AuditUpdatedEntity(original, dto, user);

                this.Context.Commit();

                //Users Permission Set role wise
                if (roles != null)
                {
                    var rolesFilter = roles.Where(a => !existRoles.Contains(a.RoleId) && !a.IsDeleted).ToList();
                    rolesFilter.AddRange(roles.Where(a => a.IsDeleted));
                    List<AppUserRoleForPermissionDto> roleList = new List<AppUserRoleForPermissionDto>();
                    foreach (var role in rolesFilter)
                    {
                        roleList.Add(new AppUserRoleForPermissionDto() { RoleId = role.RoleId, IsDeleted = role.IsDeleted });
                    }
                    var roleListStr = JsonConvert.SerializeObject(roleList);
                    await this.SetUserRoleWisePermissions(roleListStr, dto.AppUserId.Value, user.GetUserId());

                    try
                    {
                       
                            var biDashboardList = await this._eceCrmEntities.BIDashboards.Where(a => a.IsActive && !a.IsDeleted).ToListAsync();
                            foreach (var item in biDashboardList)
                            {
                                await this.Context.Lookups.UpdateUserWiseBIDashboardAsync(item.BIDashboardId, user);
                            }

                        

                    }
                    catch (Exception ex)
                    {
                        var Logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        Logger.Error(ex);
                    }

                }


            }
            catch (DuplicateException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.User, dto.AppUserId, ex);
            }
        }

        public async Task<AppUserDto> GetNonPortalUserAsync(string userName, bool? isActive = null)
        {
            var result = await this.Context.Users.GetNonPortalUserAsync(userName, isActive);
            if (result != null)
            {
                result.Roles = await _rolePermissionService.GetRolesForUserAsync(result.AppUserId.Value, true);
            }

            return result;
        }

        /// <summary>
        /// Audits the password change.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>Task.</returns>
        private async Task AuditPasswordChangeAsync(AppUserDto user)
        {
            await this.Context.Users.CreatePasswordHistoryAsync(new AppUserPasswordHistoryDto
            {
                AppUserId = (int)user.AppUserId,
                Password = user.Password,
                PasswordSalt = user.PasswordSalt,
                CreatedById = (int)user.UpdatedById,
                CreatedDate = DateTime.Now
            });
        }

        private async Task GenerateForgotPasswordEmail(AppUserDto user)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.ForgotPassword);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            int expireHours = MobiusConfiguration.Current.AppSettings.GetInt32("Security:TokenTimeoutHours");
            string url = string.Format("{0}Account/ResetPassword/{1}",
                MobiusConfiguration.Current.AppSettings["Application.Url"],
                WebUtility.UrlEncode(user.PasswordToken));
            string appName = MobiusConfiguration.Current.AppSettings["Application.Name"];

            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
            var body = bodyBuilder
                .Replace("{Body}", bodyTemplate.Body)
                .Replace("{FirstName}", user.FirstName)
                .Replace("{RecoveryURL}", url)
                .Replace("{ValidTime}", expireHours.ToString())
                .Replace("{SupportEmail}", MobiusConfiguration.Current.AppSettings["Email.SupportAddress"])
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("''", "'")
                .ToString();

            // Create the message
            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;
            email.To.Add(user.Username);

            this.Context.BeginTransaction();

            try
            {
                var smtpManager = new SmtpManager(this.Context);

                // Send the message, bypassing the email message queue.
                smtpManager.SendMessage(email, user.AppUserId.Value, SendMessageMode.Directly);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        private async Task GenerateNewUserEmailAsync(AppUserDto appUser, string unencryptedPassword)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.CreateUser);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string url = MobiusConfiguration.GetString("Application.Url");
            string supportEmail = MobiusConfiguration.GetString("Email.SupportAddress");

            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
            var body = bodyBuilder.Replace("{Body}", bodyTemplate.Body)
                .Replace("{FirstName}", appUser.FirstName)
                .Replace("{Url}", url)
                .Replace("{Email}", appUser.Username)
                .Replace("{Password}", unencryptedPassword)
                .Replace("{SupportEmail}", supportEmail)
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("''", "'")
                .ToString();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;
            email.To.Add(appUser.Username);

            this.Context.BeginTransaction();

            try
            {
                var smtpManager = new SmtpManager(this.Context);

                // Send the message, bypassing the email message queue.
                smtpManager.SendMessage(email, appUser.AppUserId.Value, SendMessageMode.Directly);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        private async Task AuditUpdatedEntity(AppUserDto original, AppUserDto updated, IPrincipal user)
        {
            // Audit Is Locked Out Change
            if (!bool.Equals(updated.IsLockedOut, original.IsLockedOut))
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.AppUserId.Value,
                    Type = EntityType.User,
                    Event = updated.IsLockedOut ? AuditEvent.UserIsLockedOut : AuditEvent.UserIsUnlocked,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Is Active Change
            if (!bool.Equals(updated.IsActive, original.IsActive))
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.AppUserId.Value,
                    Type = EntityType.User,
                    Event = updated.IsActive ? AuditEvent.UserIsActive : AuditEvent.UserIsInactive,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }

        public async Task<(bool, string)> GeneratNewPassword(int appUserId)
        {
            var newPassword = SecurityHelper.GenerateRandomPassword(6, true);
            bool isValid = true;
            try
            {
                var user = await this._eceCrmEntities.AppUsers.Where(a => a.AppUserId == appUserId).FirstOrDefaultAsync();
                if (user != null)
                {
                    if (user.IsActive)
                    {
                        var newEncryptedPassword = SecurityHelper.EncryptPassword(newPassword, user.PasswordSalt);
                        user.Password = newEncryptedPassword;
                        user.PasswordLastChanged = DateTime.UtcNow;
                        user.IsLockedOut = false;
                        await this._eceCrmEntities.SaveChangesAsync();
                    }
                    else
                    {
                        isValid = false;
                    }
                }
            }
            catch { isValid = false; }
            return (isValid, newPassword);
        }


        public async Task<bool> ChangeAgentStatus(UserAgentDto userAgentDto,IPrincipal user)
        {
            var result = false;
            var appUser = await this.Context.Users.GetByIdAsync(userAgentDto.AppUserId);
            if (appUser == null)
            {
                return result;
            }

            try
            {
                this.Context.BeginTransaction();
                result = await this.Context.Users.UpdateAgentStatus(userAgentDto);
                if (result)
                {
                    if (appUser.BlockUser != userAgentDto.BlockUser)
                    {
                        var history = new EntityHistoryDto
                        {
                            EntityId = appUser.AppUserId.Value,
                            Type = EntityType.User,
                            Event = userAgentDto.BlockUser ? AuditEvent.BlockUserLogin : AuditEvent.UnblockUserLogin,
                            Description = "--",
                            CreatedDate = DateTime.Now,
                            CreatedById = user.GetUserId()
                        };
                        await this._entityHistoryService.CreateEntityHistoryAsync(history);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
            return result;
        }


        public async Task<List<UserPermissionDto>> GetUserPermission(int appUserId)
        {
            List<UserPermissionDto> userPermissions = new List<UserPermissionDto>();
            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"userid",appUserId}
                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    var userPermissionAwait = await conn.QueryAsync<UserPermissionDto>("Sp_Get_permission_to_list_by_user", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    if (userPermissionAwait != null)
                    {
                        userPermissions = userPermissionAwait.ToList();
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return userPermissions;
        }

        public async Task<List<PermissionUserDto>> GetPermissionUser(int appUserId, int permissionId, int roleId)
        {
            List<PermissionUserDto> permissionUsers = new List<PermissionUserDto>();
            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"permissionid",permissionId},
                    {"roleid",roleId},
                    {"userid",appUserId}

                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    var permissionUserAwait = await conn.QueryAsync<PermissionUserDto>("Sp_Get_user_to_list_by_permission", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    if (permissionUserAwait != null)
                    {
                        permissionUsers = permissionUserAwait.ToList();
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return permissionUsers;
        }


        public async Task SetUsersAndPermissions(string userList, string permissionList, int createdById)
        {

            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"userlist",userList},
                     {"permissionlist",permissionList},
                      {"createdbyid",createdById}
                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    await conn.ExecuteAsync("Sp_Set_permission_to_user_and_user_to_permission", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }

                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

        public async Task SetUserRoleWisePermissions(string roleList, int userId, int createdById)
        {

            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {
                    {"rolelist",roleList},
                     {"userId",userId},
                      {"createdbyid",createdById}
                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    await conn.ExecuteAsync("Sp_Set_user_role_to_permission", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }

                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }


        public async Task<List<PermissionUserOfficeDto>> GetUserPermissionsAnsHisOffices(int UserId)
        {
            List<PermissionUserOfficeDto> permissionUsers = new List<PermissionUserOfficeDto>();
            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var dictionary = new Dictionary<string, object>()
                {

                    {"UserId",UserId}

                };
                    var parameters = new DynamicParameters(dictionary);
                    var conn = sqlConnectionFactory.CreateConnection();
                    var permissionUserAwait = await conn.QueryAsync<PermissionUserOfficeDto>("Sp_Get_Permission_and_office_userwise", parameters, commandTimeout: int.MaxValue, commandType: CommandType.StoredProcedure);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    if (permissionUserAwait != null)
                    {
                        permissionUsers = permissionUserAwait.ToList();
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return permissionUsers;
        }

        public async Task<List<HelpUpdateDto>> GetHelpUpdates()
        {
            List<HelpUpdateDto> helpUpdates = new List<HelpUpdateDto>();
            try
            {
                var result = await this._eceCrmEntities.HelpUpdates.ToListAsync();
                helpUpdates = Mapper.Map<List<HelpUpdateDto>>(result);
            }
            catch
            {

            }
            return helpUpdates;
        }

        public async Task<List<HelpUpdateHtmlDto>> GetHelpUpdatesHtml()
        {
            List<HelpUpdateHtmlDto> helpUpdates = new List<HelpUpdateHtmlDto>();
            try
            {
                var result = await this._eceCrmEntities.HelpUpdateHtmls.ToListAsync();
                helpUpdates = Mapper.Map<List<HelpUpdateHtmlDto>>(result);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return helpUpdates;
        }
        public async Task<HelpUpdateHtmlDto> GetByIdHelpUpdatesHtml(int helpUpdatesHtmlId)
        {
            HelpUpdateHtmlDto helpUpdate = new HelpUpdateHtmlDto();
            try
            {
                var result = await this._eceCrmEntities.HelpUpdateHtmls.FirstOrDefaultAsync(a => a.HelpUpdateHtmlId == helpUpdatesHtmlId);
                helpUpdate = Mapper.Map<HelpUpdateHtmlDto>(result);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
            return helpUpdate;
        }

        public async Task UpdatedHelpUpdatesHtml(HelpUpdateHtmlDto model)
        {

            try
            {
                var result = await this._eceCrmEntities.HelpUpdateHtmls.FirstOrDefaultAsync(a => a.HelpUpdateHtmlId == model.HelpUpdateHtmlId);
                result.Description = model.Description;
                result.UpdatedBy = model.UpdatedBy;
                result.UpdatedDate = DateTime.Now;
                await this._eceCrmEntities.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }
        }

    }
}
