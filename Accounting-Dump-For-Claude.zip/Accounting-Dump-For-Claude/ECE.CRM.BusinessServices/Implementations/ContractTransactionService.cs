namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractTransactionService : IContractTransactionService
    {
        public const decimal ExcessivePaymentLimit = 5000m;

        private readonly IUserService _userService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IExpensePaymentService _expensePaymentService;

        public ContractTransactionService(
            IUnitOfWork context,
            ILogger logger,
            IUserService userService,
            IGeneralLedgerService generalLedgerService,
            IExpensePaymentService expensePaymentService)
        {
            this.Context = context;
            this.Logger = logger;
            this._userService = userService;
            this._generalLedgerService = generalLedgerService;
            this._expensePaymentService = expensePaymentService;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public static bool HasDepositOrSignature(ContractDto dto)
        {
            if (dto.ContractTransactions != null && dto.SignatureProgress != null)
            {
                // If any deposits have been applied to a contract, the RA is not allowed to cancel
                var hasAtLeastOneDeposit = dto.ContractTransactions.Any(x => x.IsIncome && x.PaidAmount > decimal.Zero);

                // If any signatures have been applied to a contract, the RA is not allowed to cancel
                var hasAtLeastOneSignature = dto.SignatureProgress.Any(x => x.SignatureReceived.HasValue);

                if (hasAtLeastOneDeposit || hasAtLeastOneSignature)
                {
                    return true;
                }
            }

            return false;
        }

        public static void RemovePendingExpensePaymentIfNotApproved(ContractTransactionDto dto)
        {
            // Remove the expense from a pending expense payment if it is no longer approved for release
            if (dto.IsExpense && dto.HasPendingExpensePayment && !dto.CanRelease)
            {
                dto.ExpensePaymentId = null;
                dto.ExpensePaymentStatusId = null;
            }
        }

        public bool HasAtLeastOneDeposit(ContractDto dto)
        {
            if (dto.ContractTransactions != null)
            {
                // If any deposits have been applied to a contract, the RA is not allowed to cancel
                var hasAtLeastOneDeposit = dto.ContractTransactions.Any(x => x.IsIncome && x.PaidAmount > decimal.Zero);
                if (hasAtLeastOneDeposit)
                {
                    return true;
                }
            }

            return false;
        }

        public async Task<IList<ContractTransactionDto>> GetByContractIdAsync(int contractId)
        {
            return await this.Context.ContractTransactions.GetByContractIdAsync(contractId);
        }

        public IList<ContractTransactionDto> FilterAdditionalExpenses(IList<ContractTransactionDto> transactions)
        {
            var results = transactions
                .Where(x => x.IsExpense
                    && x.ContractTransactionTypeId != (int)ContractTransactionType.Commission
                    && x.ContractTransactionTypeId != (int)ContractTransactionType.SharedBonus
                    && x.ContractTransactionTypeId != (int)ContractTransactionType.ReserveAllowance
                    && x.ContractTransactionTypeId != (int)ContractTransactionType.ArtistPayment)
                .ToList();

            return results;
        }

        public IList<ContractTransactionDto> FilterDueDeposits(IList<ContractTransactionDto> transactions)
        {
            var results = transactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.Deposit
                    && x.DueAmount != decimal.Zero
                    && x.PaidDate == null)
                .ToList();

            return results;
        }

        public IList<ContractTransactionDto> FilterDeposits(IList<ContractTransactionDto> transactions, int contractEntityTypeId, int contractEntityId)
        {
            var results = transactions
                .Where(x =>
                    x.ContractTransactionTypeId == (int)ContractTransactionType.Deposit &&
                    x.RequiredAmount > decimal.Zero &&
                    x.ContractEntityTypeId == contractEntityTypeId &&
                    x.ContractEntityId == contractEntityId)
                .ToList();

            return results;
        }

        public IList<ContractTransactionDto> FilterCommissions(IList<ContractTransactionDto> transactions)
        {
            var results = transactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.Commission &&
                            x.RequiredPercentage.HasValue &&
                            x.RequiredPercentage.Value > 0)
                .ToList();

            return results;
        }

        public async Task<IList<ContractTransactionDto>> GetPayableByContractTransactionTypeAsync(ContractTransactionType type)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetPayableByContractTransactionTypeAsync(type);

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionDto>> GetOtherPayableArtistTransactionsAsync()
        {
            var contractTransactions = await this.Context.ContractTransactions.GetOtherPayableArtistTransactionsAsync();

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionDto>> GetPayableOtherExpensesAsync()
        {
            var contractTransactions = await this.Context.ContractTransactions.GetPayableOtherExpensesAsync();

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionDto>> GetByExpenseBatchIdAsync(int id)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetByExpenseBatchIdAsync(id);

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionViewDto>> GetViewByExpenseBatchIdAsync(int id)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetViewByExpenseBatchIdAsync(id);

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionDto>> GetByExpensePaymentIdAsync(int id)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(id);

            return contractTransactions;
        }

        public async Task<IList<ContractTransactionDto>> GetByExpensePaymentIdsAsync(int[] ids)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdsAsync(ids);

            return contractTransactions;
        }

        public async Task<ContractTransactionDto> CreateAsync(ContractTransactionDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                dto.SetAsCreated(user);
                this.SynchronizePaidDate(dto);
                await this.Context.ContractTransactions.CreateAsync(dto);

                if (GeneralLedgerService.IsEceExpense(dto.ContractTransactionTypeId))
                {
                    await this._generalLedgerService.PayEceExpensesForContractAsync(dto.ContractId, user);
                }

                this.Context.Commit();

                return dto;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAsync(ContractTransactionDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                // Determine if the transaction will need to update a pending expense payment
                var updatePendingExpensePayment = dto.HasPendingExpensePayment;

                var payInFull = dto.ExpensePaymentStatusId == (int)ExpensePaymentStatus.PayInFull;

                ContractTransactionService.RemovePendingExpensePaymentIfNotApproved(dto);

                dto.SetAsUpdated(user);
                this.SynchronizePaidDate(dto);
                await this.Context.ContractTransactions.UpdateAsync(dto);

                if (updatePendingExpensePayment && !payInFull)
                {
                    await this._expensePaymentService.UpdatePendingExpensePaymentAsync(dto, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return;
        }

        public async Task DeleteAsync(int id, IPrincipal user, bool removeTransaction = false)
        {
            try
            {
                this.Context.BeginTransaction();

                var contractTransaction = await this.GetByIdAsync(id);
                if (contractTransaction == null)
                {
                    throw new ArgumentException($"Contract transaction {id} not found.");
                }

                if (contractTransaction.HasPostedExpensePayment)
                {
                    throw new ArgumentException($"Contract transaction {id} cannot be deleted because it has been paid as part of expense payment {contractTransaction.ExpensePaymentId}.");
                }

                var payrollLogs = await Context.AgentPayrollLogs.GetByExpenseAsync(id);
                if (payrollLogs.Any(x => x.PayrollPaymentId != null))
                {
                    throw new ArgumentException($"Contract transaction {id} cannot be deleted because an agent has been paid for this expense.");
                }

                // Remove unpaid payroll logs
                foreach (var item in payrollLogs)
                {
                    await this.Context.AgentPayrollLogs.DeleteAsync(item.AgentPayrollLogId);
                }

                // Reverse all GL entries.
                var glActivity = await this._generalLedgerService.GetJournalActivityByContractTransactionIdAsync(contractTransaction.ContractTransactionId);

                var glEvents = glActivity.GroupBy(x => new { x.GeneralLedgerEventId, x.JournalTransactionNumber, x.ContractTransactionId, x.PostedAmount }, (key, g) => new { GeneralLedgerEventId = key.GeneralLedgerEventId, JournalTransactionNumber = key.JournalTransactionNumber, ContractTransactionId = key.ContractTransactionId, PostedAmount = key.PostedAmount });

                foreach (var glEvent in glEvents)
                {
                    List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes;

                    var generalLedgerEvent = (GeneralLedgerEvent)glEvent.GeneralLedgerEventId;

                    var reversedEvent = this._generalLedgerService.GetReversedGlEvent(generalLedgerEvent);
                    if (reversedEvent == GeneralLedgerEvent.Unknown)
                    {
                        // Create a list of reverse transaction types.
                        generalLedgerTransactionTypes = new List<GeneralLedgerTransactionTypeDto>();

                        var originalTransactionTypes = await this.Context.GeneralLedgerTransactionTypes.GetTransactionTypesByEventIdAsync((int)generalLedgerEvent, contractTransaction.ContractEntityTypeId);
                        foreach (var originalTransactionType in originalTransactionTypes)
                        {
                            generalLedgerTransactionTypes.Add(originalTransactionType.Reverse());
                        }
                    }
                    else
                    {
                        // Use the list of transaction types for the reverse event.
                        generalLedgerTransactionTypes = await this.Context.GeneralLedgerTransactionTypes.GetTransactionTypesByEventIdAsync((int)reversedEvent, contractTransaction.ContractEntityTypeId);
                    }

                    await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, glEvent.PostedAmount, contractTransaction, user);
                }

                if (removeTransaction)
                {
                    var entries =
                        await this._generalLedgerService.GetJournalActivityByContractTransactionIdAsync(
                            contractTransaction.ContractTransactionId);

                    if (entries.Any())
                    {
                        foreach (var entry in entries)
                        {
                            entry.ContractTransactionId = null;

                            await this._generalLedgerService.UpdateGeneralLedgerJournalAsync(entry);
                        }
                    }
                }

                await this.Context.ContractTransactions.DeleteAsync(id);

                if (contractTransaction.HasPendingExpensePayment)
                {
                    await this._expensePaymentService.UpdatePendingExpensePaymentAsync(contractTransaction, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task RemoveFromPaymentAsync(ContractTransactionDto dto, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                dto.SetAsUpdated(user.GetUserId());

                dto.ExpensePaymentId = null;
                dto.ExpensePaymentStatusId = null;

                await this.Context.ContractTransactions.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateExpensePaymentStatusAsync(ContractTransactionDto dto, ExpensePaymentStatus newStatus, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                dto.ExpensePaymentStatusId = (int)newStatus;

                dto.SetAsUpdated(user);

                await this.Context.ContractTransactions.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ContractTransactionDto> GetByIdAsync(int id)
        {
            return await this.Context.ContractTransactions.GetByIdAsync(id);
        }

        public async Task<ContractTransactionDto> GetByIdWithAuditInfoAsync(int id)
        {
            return await this.Context.ContractTransactions.GetByIdWithAuditInfoAsync(id);
        }

        public async Task<IList<string>> CheckTransactionForWarningAsync(int id)
        {
            var contractTransaction = await this.Context.ContractTransactions.GetByIdAsync(id);
            if (contractTransaction != null)
            {
                return await this.CheckTransactionForWarningAsync(contractTransaction);
            }

            return new List<string>();
        }

        public async Task<IList<string>> CheckTransactionForWarningAsync(ContractTransactionDto contractTransaction)
        {
            if (contractTransaction == null)
            {
                throw new ArgumentNullException(nameof(contractTransaction));
            }

            // Display warning flag if:
            // The payment amount is more than $5,000.00
            // The associated contract is in a cancelled state
            // the current date is ahead of the Pay Date for the associated Expense record
            // the AREF Pay Date is not the same as an Event Date on the contract
            var warnings = new List<string>();

            var paymentAmount = contractTransaction.RequiredAmount.GetValueOrDefault();
            if (paymentAmount > ContractTransactionService.ExcessivePaymentLimit)
            {
                var warning = string.Format(ExpensePaymentWarning.ExcessivePayment, ContractTransactionService.ExcessivePaymentLimit);
                warnings.AddIfNotContains(warning);
            }

            ArtistDto artist = null;

            var payDate = contractTransaction.DueDate;

            if (contractTransaction.ContractEntityTypeId == (int)ContractEntityType.Artist)
            {
                artist = contractTransaction.ExpensePayment?.Artist;
                if (artist == null)
                {
                    artist = await this.Context.Artists.GetByIdAsync(contractTransaction.ContractEntityId);
                }

                if (artist != null && artist.IsW9OnFile == false)
                {
                    warnings.AddIfNotContains(ExpensePaymentWarning.NoW9OnFile);
                }

                if (payDate.HasValue && payDate.Value > DateTime.Today)
                {
                    var isEarly = true;

                    if (artist != null && artist.ExclusiveStartDate < DateTime.Now)
                    {
                        if (DateTime.Now > payDate.Value.AddDays(-7))
                        {
                            isEarly = false;
                        }
                    }

                    if (isEarly)
                    {
                        warnings.AddIfNotContains(ExpensePaymentWarning.CurrentDateAheadOfPayDate);
                    }
                }
            }

            DateTime? cancellationDate = null;

            var contract = contractTransaction.ParentContract;
            if (contract != null)
            {
                cancellationDate = contract.CancellationDate;
            }
            else
            {
                cancellationDate = await this.Context.Contracts.GetCancellationDateByContractIdAsync(contractTransaction.ContractId);
            }

            if (cancellationDate.HasValue)
            {
                warnings.AddIfNotContains(ExpensePaymentWarning.ContractCanceled);
            }

            if (contractTransaction.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment)
            {
                IEnumerable<ContractEventDateDto> contractEventDates = contract?.EventDatesObject;
                if (contractEventDates == null)
                {
                    contractEventDates = await this.Context.ContractEventDates.GetByContractIdAsync(contractTransaction.ContractId);
                }

                foreach (var eventDate in contractEventDates)
                {
                    if (payDate.HasValue && payDate.Value != eventDate.EventDate)
                    {
                        warnings.AddIfNotContains(ExpensePaymentWarning.PayDateNotEventDate);
                        break;
                    }
                }
            }

            switch (contractTransaction.ExpensePaymentStatusId)
            {
                case (int)ExpensePaymentStatus.Insufficient:
                    warnings.AddIfNotContains(ExpensePaymentWarning.InsufficientEscrow);
                    break;

                default:
                    break;
            }

            return warnings;
        }

        public async Task<ContractTransactionExpensePaymentDto> GetExpensePaymentDataAsync(ContractTransactionDto contractTransaction)
        {
            return await this.Context.ContractTransactions.GetExpensePaymentDataAsync(contractTransaction);
        }

        public async Task<IList<ContractTransactionExpensePaymentDto>> GetExpensePaymentDataForPaymentAsync(int expensePaymentId)
        {
            try
            {
                return await this.Context.ContractTransactions.GetExpensePaymentDataForPaymentAsync(expensePaymentId);
            }
            catch (Exception ex)
            {
                ex.Data["expensePaymentId"] = expensePaymentId;
                throw;
            }
        }

        public async Task<IList<ContractTransactionExpensePaymentDto>> GetExpensePaymentDataForBatchAsync(int expenseBatchId)
        {
            return await this.Context.ContractTransactions.GetExpensePaymentDataForBatchAsync(expenseBatchId);
        }

        public async Task<EditTransactionsOnMoneyScreen> CanEditTransactionsOnMoneyScreenAsync(ContractDto dto, IPrincipal user, bool includeHasDepositsCheck = true)
        {
            if (user.IsInRole(ECERole.Accounting) || user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.ArtistServices) || user.IsInRole(ECERole.DOAS))
            {
                // Accounting department users can edit transactions at any time
                return EditTransactionsOnMoneyScreen.Yes;
            }

            var canEdit = dto.AgentId == user.GetUserId();

            if (!canEdit)
            {
                if (user.IsInRole(ECERole.Assistant))
                {
                    // An assistant can edit transactions for contracts 'owned' by agents in the same office as the assistant.
                    var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                    canEdit = agentsInSameOffices.Any(x => x.AppUserId == dto.AgentId);
                }
            }

            if (canEdit)
            {
                // Responsible Agent (or their assistant) can edit transactions as long as no
                // deposits have been received.
                if (includeHasDepositsCheck)
                {
                    if (HasAtLeastOneDeposit(dto))
                    {
                        return EditTransactionsOnMoneyScreen.No;
                    }

                    return EditTransactionsOnMoneyScreen.Yes;
                }

                // The calling program must perform this check manually
                return EditTransactionsOnMoneyScreen.IfHasNoDeposits;
            }

            return EditTransactionsOnMoneyScreen.No;
        }

        public async Task<bool> HasPermissionAsync(ContractDto dto, IPrincipal user)
        {
            if (dto.ContractStatusId > (int)ContractStatus.Created && dto.OfficeId.HasValue)
            {
                var appUserRole = await this._userService.GetUserAsync(new AppUserDto { AppUserId = user.GetUserId() }, true);

                foreach (var role in appUserRole.Roles)
                {
                    if (role.OfficeId == dto.OfficeId && role.RoleId == (int)ECERole.LMD)
                    {
                        return true;
                    }
                }
            }

            if (dto.AgentId == user.GetUserId() || user.IsInRole(ECERole.Accounting) || user.IsInRole(ECERole.AccountingAdmin))
            {
                return true;
            }

            return false;
        }

        public Task<IEnumerable<ContractTransactionDto>> GetByCriteriaAsync(ContractTransactionSearchCriteriaDto dto)
        {
            return this.Context.ContractTransactions.GetByCriteriaAsync(dto);
        }

        public IList<LookupDto> GetPayeeTypes(ContractDto dto)
        {
            var payeeTypes = new List<LookupDto>();

            payeeTypes.Add(new LookupDto((int)PayeeType.Presenter, "Presenter"));
            payeeTypes.Add(new LookupDto((int)PayeeType.Artist, "Artist"));
            payeeTypes.Add(new LookupDto((int)PayeeType.ECECommission, "ECE Commission"));
            payeeTypes.Add(new LookupDto((int)PayeeType.ECEOther, "ECE Other"));
            payeeTypes.Add(new LookupDto((int)PayeeType.Reseller, "Reseller"));
            payeeTypes.Add(new LookupDto((int)PayeeType.Vendor, "Vendor"));
            payeeTypes.Add(new LookupDto((int)PayeeType.OtherArtist, "Non-Contract Artist"));

            return payeeTypes;
        }

        public async Task MarkToBePaidAsync(IList<int> idsToPay, IPrincipal user, bool setDueDateToToday = true)
        {
            this.Context.BeginTransaction();

            try
            {
                if (idsToPay == null)
                {
                    throw new ArgumentNullException(nameof(idsToPay));
                }

                foreach (var id in idsToPay)
                {
                    var contractTransaction = await this.GetByIdAsync(id);

                    contractTransaction.CanRelease = true;
                    if (setDueDateToToday)
                    {
                        contractTransaction.DueDate = DateTime.Today;
                    }

                    await this.UpdateAsync(contractTransaction, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task ToggleExpenseApprovalAsync(int contractTransactionId, bool canRelease, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var contractTransaction = await this.GetByIdAsync(contractTransactionId);
                if (contractTransaction == null)
                {
                    throw new ArgumentException($"Contract transaction {contractTransactionId} not found.");
                }

                contractTransaction.CanRelease = canRelease;

                await this.UpdateAsync(contractTransaction, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<ContractTransactionDto>> GetByArtistIdAsync(int artistId, int contractId)
        {
            return await this.Context.ContractTransactions.GetByArtistIdAsync(artistId, contractId);
        }

        public async Task<IList<ContractTransactionDto>> GetEceContractTransactionsAsync(
            int contractId, List<int> contractTransactionTypes)
        {
            return
                await this.Context.ContractTransactions.GetEceContractTransactionsAsync(contractId, contractTransactionTypes);
        }

        public async Task ShiftArtistPaymentDueDatesAsync(int contractId, TimeSpan delta, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                // Update the Artist Payment due dates by the same delta. This will help reduce the
                // cases where a payment is not approved for release because the due date was not
                // correctly set to coincide with the event date.
                var transactions = await this.GetByContractIdAsync(contractId);

                // Find artist payments not paid and not associated with an Expense Payment
                var artistPayments = transactions
                    .Where(x =>
                        x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                        x.PaidDate == null &&
                        x.ExpensePaymentId == null);

                foreach (var artistPayment in artistPayments)
                {
                    // Adjust the due date by the delta.
                    var newDueDate = artistPayment.DueDate.Value.Add(delta);

                    // Add a note if space allows.
                    var message = $"Due Date automatically updated from {artistPayment.DueDate:MM/dd/yyyy} to {newDueDate:MM/dd/yyyy}";
                    if (string.IsNullOrWhiteSpace(artistPayment.Notes))
                    {
                        artistPayment.Notes = message;
                    }
                    else
                    {
                        const int NotesMaxLength = 1000;

                        if (artistPayment.Notes.Length < NotesMaxLength - message.Length - Environment.NewLine.Length)
                        {
                            artistPayment.Notes += Environment.NewLine + message;
                        }
                    }

                    artistPayment.DueDate = newDueDate;

                    await this.UpdateAsync(artistPayment, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public bool HasUnpaidDeposits(ContractDto contract)
        {
            if (contract.ContractTransactions != null)
            {
                var unreceivedDeposits = contract.ContractTransactions
                    .Where(x => x.IsIncome
                            && x.ContractTransactionTypeId == (int)ContractTransactionType.Deposit
                            && x.RequiredAmount != decimal.Zero
                            && x.PaidDate == null);

                if (unreceivedDeposits.Any())
                {
                    return true;
                }

                return false;
            }
            return false;
        }

        public void SynchronizePaidDate(ContractTransactionDto dto, DateTime? paidDate = null)
        {
            ContractTransactionHelper.SynchronizePaidDate(dto, paidDate);
        }
    }
}
