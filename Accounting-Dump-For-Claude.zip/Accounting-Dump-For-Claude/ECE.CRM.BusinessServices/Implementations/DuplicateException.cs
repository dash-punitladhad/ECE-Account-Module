﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using Newtonsoft.Json;
    using System;
    using System.Runtime.Serialization;

    public class DuplicateException : Exception
    {
        /// <summary>
        /// The default exception message
        /// </summary>
        public const string DefaultExceptionMessage = "Duplicate Exception";

        /// <summary>
        /// The DTO that was used to generate the exception.
        /// </summary>
        private BaseDto _dto = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class.
        /// </summary>
        public DuplicateException()
            : base(DefaultExceptionMessage)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        public DuplicateException(BaseDto dto)
            : base(DefaultExceptionMessage)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public DuplicateException(BaseDto dto, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for a specified entity.
        /// </summary>
        /// <param name="entityType">The type of entity.</param>
        /// <param name="entityKey">The entity key.</param>
        public DuplicateException(string entityType, object entityKey)
            : base(DefaultExceptionMessage)
        {
            this.Data["EntityType"] = entityType;
            this.Data["EntityKey"] = entityKey;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for a specified entity type and key.
        /// </summary>
        /// <param name="entityType">The type of entity.</param>
        /// <param name="entityKey">The entity key.</param>
        public DuplicateException(EntityType entityType, object entityKey)
            : base(DefaultExceptionMessage)
        {
            this.Data["EntityType"] = entityType.ToString();
            this.Data["EntityKey"] = entityKey;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for a specified entity type and key.
        /// </summary>
        /// <param name="entityType">The type of entity.</param>
        /// <param name="entityKey">The entity key.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public DuplicateException(string entityType, object entityKey, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this.Data["EntityType"] = entityType;
            this.Data["EntityKey"] = entityKey;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// for a specified entity type and key.
        /// </summary>
        /// <param name="entityType">The type of entity.</param>
        /// <param name="entityKey">The entity key.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public DuplicateException(EntityType entityType, object entityKey, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this.Data["EntityType"] = entityType.ToString();
            this.Data["EntityKey"] = entityKey;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class
        /// with a specified error message.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        public DuplicateException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class with a
        /// reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public DuplicateException(Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class with a
        /// specified error message and a reference to the inner exception that
        /// is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public DuplicateException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateException" /> class with
        /// serialized data.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source or destination.</param>
        public DuplicateException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        private void SerializeDto()
        {
            if (this._dto == null)
            {
                return;
            }

            var serialized = JsonConvert.SerializeObject(this._dto);

            this.Data["DTO"] = serialized;
        }
    }
}
