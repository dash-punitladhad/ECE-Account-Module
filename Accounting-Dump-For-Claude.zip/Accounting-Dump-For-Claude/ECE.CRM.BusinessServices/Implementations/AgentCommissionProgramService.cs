﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class AgentCommissionProgramService : IAgentCommissionProgramService
    {
        public AgentCommissionProgramService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByMenteeIdAsync(int menteeId)
        {
            if (menteeId <= 0)
            {
                throw new ArgumentException(nameof(menteeId));
            }

            return await this.Context.AgentCommissionProgram.GetAgentMentorProgramsByMenteeIdAsync(menteeId);
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsByAppUserAsync(int appUserId)
        {
            if (appUserId <= 0)
            {
                throw new ArgumentException(nameof(appUserId));
            }

            return await this.Context.AgentCommissionProgram.GetAgentMentorProgramsByAppUserAsync(appUserId);
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramByPresenterAsync(int presenterId)
        {
            if (presenterId <= 0)
            {
                throw new ArgumentException(nameof(presenterId));
            }

            return await this.Context.AgentCommissionProgram.GetAgentTransferProgramByPresenterAsync(presenterId);
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentTransferProgramsByAppUserAsync(int appUserId, int presenterId)
        {
            if (appUserId <= 0)
            {
                throw new ArgumentException(nameof(appUserId));
            }

            if (presenterId <= 0)
            {
                throw new ArgumentException(nameof(presenterId));
            }

            return await this.Context.AgentCommissionProgram.GetAgentTransferProgramsByAppUserAsync(appUserId, presenterId);
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetMentorshipProgramsForCommissionByAppUserAsync(
            int appUserId)
        {
            if (appUserId <= 0)
            {
                throw new ArgumentException(nameof(appUserId));
            }

            return await this.Context.AgentCommissionProgram.GetMentorshipProgramsForCommissionByAppUserAsync(appUserId);
        }
    }
}
