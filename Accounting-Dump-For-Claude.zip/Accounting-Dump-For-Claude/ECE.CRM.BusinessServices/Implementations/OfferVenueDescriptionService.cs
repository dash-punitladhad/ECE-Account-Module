﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class OfferVenueDescriptionService : IOfferVenueDescriptionService
    {
        public OfferVenueDescriptionService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<int> CreateAsync(OfferVenueDescriptionDto venueDescription)
        {
            return await this.Context.OfferVenueDescriptions.CreateAsync(venueDescription);
        }

        public async Task<List<OfferVenueDescriptionDto>> GetVenueTypesByOfferAsync(int id)
        {
            return await this.Context.OfferVenueDescriptions.GetVenueTypesByOfferAsync(id);
        }

        public async Task SyncVenueDescriptionsAsync(int offerId, IEnumerable<string> venueTypes)
        {
            this.Context.BeginTransaction();

            try
            {
                var existingVenueDescriptions = await this.Context.OfferVenueDescriptions.GetVenueTypesByOfferAsync(offerId);

                var listOfSelectedVenueTypes =
                        venueTypes.Select(x => Convert.ToInt32(x.Trim())).ToList();

                var venueTypesToKeep =
                    existingVenueDescriptions.Where(x => listOfSelectedVenueTypes.Contains(x.VenueTypeId)).ToList();

                var venueTypesToAdd = listOfSelectedVenueTypes.Except(
                                    venueTypesToKeep.Select(x => x.VenueTypeId).ToList(),
                                    x => x);

                foreach (int venueTypeId in venueTypesToAdd)
                {
                    var v = new OfferVenueDescriptionDto()
                    {
                        OfferId = offerId,
                        VenueTypeId = venueTypeId,
                        OfferVenueDescriptionId = 0
                    };

                    await this.Context.OfferVenueDescriptions.CreateAsync(v);
                }

                var venueTypesToRemove = existingVenueDescriptions.Except(venueTypesToKeep);

                foreach (var dto in venueTypesToRemove)
                {
                    await this.Context.OfferVenueDescriptions.DeleteAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
