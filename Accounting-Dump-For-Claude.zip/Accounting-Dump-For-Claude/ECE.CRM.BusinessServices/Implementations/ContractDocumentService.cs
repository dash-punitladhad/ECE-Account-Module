namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractDocumentService : IContractDocumentService
    {
        private readonly IDocumentService _documentService;
        private readonly IMessageService _messageService;
        private readonly ILookupService _lookupService;
        private readonly IEceCrmEntities _eceCrmEntities;
        public ContractDocumentService(IUnitOfWork context, IDocumentService documentService, IMessageService messageService,
           ILookupService lookupService, IEceCrmEntities eceCrmEntities)
        {
            this.Context = context;
            this._documentService = documentService;
            this._messageService = messageService;
            this._lookupService = lookupService;
            this._eceCrmEntities = eceCrmEntities;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ContractDocumentDto>> GetByContractIdAsync(int contractId)
        {
            return await this.Context.ContractDocuments.GetByContractIdAsync(contractId);
        }
        public async Task<IList<ContractDocumentDto>> GetByContractIdForContractVersionAsync(int contractId)
        {

            var contractDocuments = await _eceCrmEntities
            .SqlQueryAsync<ContractDocument>(
                "EXEC Sp_Get_ContractVersion_ContractDocument @ContractId = @p0",
                contractId
            );

            return Mapper.Map<List<ContractDocument>, List<ContractDocumentDto>>(contractDocuments);

        }

        public IList<ContractDocumentDto> GetByDocumentId(int documentId)
        {
            return this.Context.ContractDocuments.GetByDocumentId(documentId);
        }

        public Task<IList<ContractDocumentDto>> GetByOriginalEntityIdAndEntityTypeIdAsync(int contractId, int originalEntityId, int originalEntityTypeId)
        {
            return this.Context.ContractDocuments.GetByOriginalEntityIdAndEntityTypeIdAsync(contractId, originalEntityId, originalEntityTypeId);
        }

        public async Task<ContractDocumentDto> GetByIdAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            var result = await this.Context.ContractDocuments.GetByIdAsync(id);

            return result;
        }

        public async Task CreateAsync(ContractDocumentDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            try
            {
                dto.SetAsCreated(user);

                await this.Context.ContractDocuments.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractDocumentDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            try
            {
                dto.SetAsUpdated(user);

                await this.Context.ContractDocuments.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(int id)
        {
            this.Context.BeginTransaction();
            try
            {
                var contractDocument = await this.GetByIdAsync(id);

                contractDocument.IsDeleted = true;

                await this.Context.ContractDocuments.UpdateAsync(contractDocument);

                await this._documentService.DeleteDocumentLinkAsync(
                    contractDocument.DocumentId,
                    contractDocument.ContractId,
                    EntityType.Contract);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(ContractDocumentDto dto)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.IsDeleted = true;

                await this.Context.ContractDocuments.UpdateAsync(dto);

                await this._documentService.DeleteDocumentLinkAsync(
                    dto.DocumentId,
                    dto.ContractId,
                    EntityType.Contract);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<DocumentDto> GetContractDocumentAsync(
            int contractId,
            int contractDocumentId,
            int documentId,
            bool? isRider = null)
        {
            return await this.Context.ContractDocuments.GetContractDocumentAsync(
                       contractId,
                       contractDocumentId,
                       documentId,
                       isRider);
        }

        public async Task<IList<ContractDocumentDto>> GetContractDocumentsAsync(int contractId, bool? isRider = null)
        {
            return await this.Context.ContractDocuments.GetContractDocumentsAsync(contractId, isRider);
        }

        public async Task<IList<ContractDocumentDto>> GetContractDocumentsForArtistAsync(int contractId, int artistId)
        {
            var contract = await this.Context.Contracts.GetByIdAsync(contractId);

            // Get all of the documents associated with the contract
            var documents = await this.Context.ContractDocuments.GetContractDocumentsAsync(contractId);

            if (contract.IsBuySell == true || contract.ContractTypeId == (int)ContractType.Special)
            {
                // Filter to include the following:
                // - Specific artist related documents
                // - Venue related documents
                // - Generic riders
                var artistDocuments = documents.Where(x => x.OriginalEntityId == artistId
                                                        || x.OriginalEntityTypeId == (int)EntityType.Venue
                                                        || (x.OriginalEntityTypeId == (int)EntityType.Contract && x.IsRider))
                                               .ToList();
                return artistDocuments;
            }
            else
            {
                // Filter to include the following:
                // - Specific artist related documents
                // - Venue related documents
                // - Generic riders
                // - Contract PDF
                // - Contract Addendums
                var artistDocuments = documents.Where(x => x.OriginalEntityId == artistId
                                                        || x.OriginalEntityTypeId == (int)EntityType.Venue
                                                        || (x.OriginalEntityTypeId == (int)EntityType.Contract && x.IsRider)
                                                        || (x.OriginalEntityTypeId == (int)EntityType.Contract && x.DocumentTypeId == (int)DocumentType.Contract)
                                                        || (x.OriginalEntityTypeId == (int)EntityType.Contract && x.DocumentTypeId == (int)DocumentType.ContractAddendum))
                                               .ToList();
                return artistDocuments;
            }
        }

        public async Task<IList<ContractDocumentDto>> GetContractDocumentsForPresenterAsync(int contractId)
        {
            // Get all of the documents associated with the contract
            var contract = await this.Context.Contracts.GetByIdAsync(contractId);
            var documents = (await this.Context.ContractDocuments.GetContractDocumentsAsync(contractId)).ToList();
            var getAllContractsPdf = documents.Where(c => c.IsContractPDF && !c.IsDeleted && !c.IsRider).ToList();
            if (contract.IsPandaDoc && getAllContractsPdf.Any())
            {
                var latestContractPDF = getAllContractsPdf.OrderByDescending(a => a.ContractDocumentId).FirstOrDefault();
                documents.RemoveAll(d => getAllContractsPdf.Any(a => a.ContractDocumentId == d.ContractDocumentId));
                documents.Add(latestContractPDF);
            }
            else if (!contract.IsPandaDoc && getAllContractsPdf.Any())
            {
                documents.RemoveAll(d => getAllContractsPdf.Any(a => a.ContractDocumentId == d.ContractDocumentId));

            }
            // ArtistAgreement, Check, CheckReport, ACH
            var docTypesToExclude = new List<int> { 45, 47, 48, 49 };

            // Filter to exclude the following document types
            var presenterDocuments = documents.Where(x => !docTypesToExclude.Contains(x.DocumentTypeId))
                .ToList();

            return presenterDocuments;
        }

        public async Task<IList<ContractDocumentDto>> GetContractRidersAsync(int contractId)
        {
            if (contractId <= 0)
            {
                throw new ArgumentException(nameof(contractId));
            }

            var results = await this.Context.ContractDocuments.GetContractRidersAsync(contractId);

            return results;
        }

        public async Task<IList<ContractDocumentDto>> GetContractInternalDocumentsAsync(int contractId)
        {
            return await this.Context.ContractDocuments.GetContractInternalDocumentsAsync(contractId);
        }

        public async Task<IList<AddendumDocumentDto>> GetAddendumDocumentsAsync(int contractId)
        {
            return await this.Context.ContractDocuments.GetAddendumDocumentsAsync(contractId, false);
        }

        public async Task<IList<AddendumDocumentDto>> GetAddendumDocumentsByLMDAsync(int userId)
        {
            return await this.Context.ContractDocuments.GetAddendumDocumentsByLMDAsync(userId, false);
        }

        public async Task UpdateAddendumDocumentsByLMDAsync(int addendumDocumentId, string status, IPrincipal user, MessageDto messageDto)
        {

            var result = await this.Context.ContractDocuments.UpdateAddendumDocumentsByLMDAsync(addendumDocumentId, status, user);
            if (result && messageDto != null)
            {
                await this._messageService.CreateAsync(messageDto, user);
            }

        }

        public async Task<Tuple<MemoryStream, string>> GetContractPdfMemoryStreamAsync(int contractId)
        {
            var contractDocument = new ContractDocumentDto();
            var contractDocuments = await this.GetByContractIdAsync(contractId);

            if (contractDocuments.Any())
            {
                contractDocument = contractDocuments.Where(a => a.IsContractPDF).OrderByDescending(o => o.ContractDocumentId).FirstOrDefault();
            }
            if (contractDocument == null || contractDocument.OriginalEntityId == null)
            {
                throw new Exception("Unhandled Business Exception : Document Not Found");
            }

            var document = await this.GetContractDocumentAsync(contractDocument.ContractId, contractDocument.ContractDocumentId, contractDocument.DocumentId);
            if (document == null)
            {
                throw new Exception("Unhandled Business Exception : Document Not Found");
            }

            var entityType = ((EntityType)contractDocument.OriginalEntityTypeId).ToString();

            // Override for Artist Agreements since they are associated with an artist but belong to the contract
            if (document.DocumentTypeId == (int)DocumentType.ArtistAgreement)
            {
                entityType = EntityType.Contract.ToString();
            }

            if (document.DocumentTypeId == (int)DocumentType.NationalAgencyRider || document.DocumentTypeId == (int)DocumentType.NationalArtistRider)
            {
                var documentLinks = this._eceCrmEntities.DocumentLinks.FirstOrDefault(a => a.DocumentId == contractDocument.DocumentId && a.EntityId == contractDocument.OriginalEntityId);
                if (documentLinks != null)
                {
                    entityType = ((EntityType)documentLinks.EntityTypeId).ToString();
                }
            }

            var riders = _lookupService.GetGenericRiders();
            var ridersMatch = riders.Any(x => x.DocumentId == contractDocument.DocumentId);

            // Override for generic riders since they are in a separate library.
            if (entityType == EntityType.Contract.ToString() && contractDocument.IsRider && ridersMatch)
            {
                entityType = "GenericRiders";
            }

            var ms = await _documentService.GetFromStorageAsync(document, entityType);
            var fileName = string.Format(
                   "Contract_{0}_{1}.pdf",
                   contractId.ToString(),
                   DateTime.Now.ToString("MM_dd_yyyy"));
            return new Tuple<MemoryStream, string>(ms, fileName);
        }
    
        public async Task<bool> SetTemplateHistoryPDFChangesAsync(int contractId, IPrincipal user, bool IsPDFChanges)
        {
            return await this.Context.ContractDocuments.SetTemplateHistoryPDFChangesAsync(contractId,user,IsPDFChanges);
        }
    }
}
