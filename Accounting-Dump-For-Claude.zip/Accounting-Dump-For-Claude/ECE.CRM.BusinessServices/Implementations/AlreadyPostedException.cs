﻿namespace ECE.CRM.BusinessServices
{
    using System;

    public class AlreadyPostedException : Exception
    {
        public AlreadyPostedException(string message)
            : base(message)
        {
        }

        public AlreadyPostedException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
