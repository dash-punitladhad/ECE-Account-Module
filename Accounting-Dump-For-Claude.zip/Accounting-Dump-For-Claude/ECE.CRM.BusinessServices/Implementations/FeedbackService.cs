﻿namespace ECE.CRM.BusinessServices
{
    using Dapper;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Net.Mail;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class FeedbackService : IFeedbackService
    {

        private readonly IEceCrmEntities _eceCrmEntities;
        private readonly IDocumentService _documentService;
        public IBlobStorageProvider StorageProvider { get; private set; }
        public FeedbackService(
            IUnitOfWork context,
            ILogger logger,
             IDocumentService documentService,
            IEceCrmEntities eceCrmEntities,
            IBlobStorageProvider storageProvider)
        {
            this.Context = context;
            this.Logger = logger;
            this._documentService = documentService;
            this._eceCrmEntities = eceCrmEntities;
            this.StorageProvider = storageProvider;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }


        public async Task<List<FeedbackModelDto>> GetFeedbackFilterAsync(FeedbackRequestModelDto model)
        {

            List<FeedbackModelDto> feedbackModeList = new List<FeedbackModelDto>();
            //var parameters = new object[]
            //    {
            //       model.StartDate.HasValue? model.StartDate.Value.Date:(DateTime?)null,
            //       model.EndDate.HasValue? model.EndDate.Value.Date:(DateTime?)null,
            //        model.FeedbackTypeId,
            //       model.Search,                   
            //        model.IsDeleted

            //    };

            //feedbackModeList = await this._eceCrmEntities.SqlQueryAsync<FeedbackModelDto>("Sp_get_FeedbackList @startDate,@endDate,@feedbackTypeId,@search,@isDeleted", parameters);
            using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
            {
                var dictionary = new Dictionary<string, object>()
                {
                    {"startDate",model.StartDate.HasValue? model.StartDate.Value.Date:(DateTime?)null},
                    {"endDate",model.EndDate.HasValue? model.EndDate.Value.Date:(DateTime?)null},
                    {"feedbackTypeId",model.FeedbackTypeId},
                    {"search",model.Search},
                    {"isDeleted",model.IsDeleted}
                };
                var parameters = new DynamicParameters(dictionary);
                var conn = sqlConnectionFactory.CreateConnection();
                feedbackModeList = (await conn.QueryAsync<FeedbackModelDto>("Sp_get_FeedbackList", parameters, commandType: CommandType.StoredProcedure)).ToList();
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

            return feedbackModeList;

        }

        public async Task AddDocumentTo(FeedbackDto fdto, List<DocumentDto> fdddto, IPrincipal user)
        {
            var blobLibrary = this.StorageProvider.GetBlobLibrary("Feedback");
            var blobsToAdd = new List<IBlob>();
            blobLibrary.CreateIfNotExists();
            MailMessage mailMessage = new MailMessage();
            try
            {

                foreach (var dto in fdddto)
                {

                    Stream fileDocument = null;
                    int userId = 0;
                    if (user != null)
                    {
                        userId = user.GetUserId();
                    }


                    dto.CreatedDate = DateTime.Now;
                    dto.CreatedById = userId;

                    var blob = blobLibrary.NewBlob();



                    blob.SaveFromStream(dto.Contents);
                    blob.Properties.Add("ORIG_FILENAME", dto.StorageFileName);
                    blob.SaveProperties();

                    blobsToAdd.Add(blob);
                    dto.StorageFileName = blob.Id.ToString();
                    //attach file in mail
                    var getBlob = blobLibrary.GetBlob(blob.Id);

                    MemoryStream ms = new MemoryStream();
                    getBlob.RetrieveToStream(ms);
                    ms.Position = 0;
                    Attachment attachment = new Attachment(ms, dto.OriginalFileName + "." + dto.DocumentExtension.ToString().Replace(" ", "").Replace("-", ""));
                    mailMessage.Attachments.Add(attachment);

                    dto.DocumentId = 0;


                    //model.UploadedDocuments.AssignFileStreams(filelist);



                }
                await this.Context.Feedbacks.Create(fdto, fdddto, user);


                await Task.Run(async () =>
                {
                    SmtpManager smtpManager = new SmtpManager();

                    string toEmailAddresses = string.Empty;

                    toEmailAddresses = await DaoHelper.GetConfigurationValue("FeedbackToEmailAddresses");
                    string ccEmailAddresses = string.Empty;

                    ccEmailAddresses = await DaoHelper.GetConfigurationValue("FeedbackCCEmailaddresses");

                    if (!string.IsNullOrEmpty(toEmailAddresses))
                    {
                        foreach (var i in toEmailAddresses.Split(','))
                        {
                            mailMessage.To.Add(new MailAddress(i));
                        }
                    }

                    if (!string.IsNullOrEmpty(ccEmailAddresses))
                    {
                        foreach (var i in ccEmailAddresses.Split(','))
                        {
                            mailMessage.CC.Add(new MailAddress(i));
                        }
                    }


                    mailMessage.Subject = "Feedback";
                    //Fill body for feedback

                    string body = string.Empty;

                    if ((int)FeedbackType.Problem == fdto.FeedbackTypeId)
                    {
                        body += "<p><b>Feedback Type:</b>" + FeedbackType.Problem.ToString() + "</p>";
                    }
                    else if ((int)FeedbackType.Suggestion == fdto.FeedbackTypeId)
                    {
                        body += "<p><b>Feedback Type:</b>" + FeedbackType.Suggestion.ToString() + "</p>";
                    }

                    body += "<p><b>Email Address:</b>" + fdto.EmailId + "</p>";

                    if (!string.IsNullOrEmpty(fdto.PhoneNo))
                    {
                        body += "<p><b>Phone No:</b>" + fdto.PhoneNo + "</p>";
                    }
                    body += "<p><b>Description:</b>" + fdto.FeedbackDetail + "</p>";

                    body += "<p><b>Url:</b>" + fdto.FeedbackUrl + "</p>";


                    mailMessage.IsBodyHtml = true;

                    var tempBody = await this.Context.Lookups.GetEmailTemplateAsync(0);
                    body = tempBody.Body.Replace("{Body}", body);
                    mailMessage.Body = body;

                    SmtpManager.AddChangeEmailPreferencesLink(mailMessage);

                    // smtpManager.SendMessage(mailMessage);
                });



            }
            catch (Exception ex)
            {
                foreach (var blobToAdd in blobsToAdd)
                {
                    blobToAdd.DeleteIfExists();
                }

                throw new Exception("Unhandled Business Exception", ex);
            }
        }


        public async Task<FeedbackDisplayViewDto> GetDocumentToAsync(int feedbackId)
        {
            FeedbackDisplayViewDto model = new FeedbackDisplayViewDto();
            var feedback = this._eceCrmEntities.Feedbacks.Where(a => a.FeedbackId == feedbackId).FirstOrDefault();
            model.FeedbackId = feedback.FeedbackId;
            model.EmailId = feedback.EmailId;
            model.CreatedById = feedback.CreatedById;
            model.CreatedDate = feedback.CreatedDate;
            model.FeedbackDetail = feedback.FeedbackDetail;
            model.FeedbackTypeText = ((FeedbackType)feedback.FeedbackTypeId).ToString();
            model.FeedbackUrl = feedback.FeedbackUrl;
            model.PhoneNo = feedback.PhoneNo;
            List<FeedbackDisplayDocumentViewDto> documentList = new List<FeedbackDisplayDocumentViewDto>();
            try
            {

                var blobLibrary = this.StorageProvider.GetBlobLibrary("Feedback");


                var feedbackDocumentList = this._eceCrmEntities.FeedbackDocuments.Where(a => a.FeedbackId == feedbackId).ToList();
                foreach (var item in feedbackDocumentList)
                {
                    FeedbackDisplayDocumentViewDto document = new FeedbackDisplayDocumentViewDto();


                    document.CreatedById = item.CreatedById;
                    document.CreatedDate = item.CreatedDate;
                    document.DocumentExtensionText = ((DocumentExtension)item.DocumentExtensionId).ToString();
                    document.OriginalFileName = item.OriginalFileName;
                    document.StorageFileName = item.StorageFileName;
                    document.FeedbackDocumentId = item.FeedbackDocumentId;
                    document.FeedbackId = item.FeedbackId;

                    var blobId = Guid.Parse(document.StorageFileName);
                    var blob = blobLibrary.GetBlob(blobId);
                    string fileAsString = string.Empty;
                    if (blob.Size >= 0)
                    {
                        var ms = new MemoryStream();
                        blob.RetrieveToStream(ms);
                        ms.Position = 0;
                        fileAsString = Convert.ToBase64String(ms.ToArray());
                        if (!string.IsNullOrEmpty(fileAsString))
                        {
                            fileAsString = getExtentionwithbase64(document.DocumentExtensionText, fileAsString);
                            document.Url = fileAsString;
                            documentList.Add(document);
                        }
                    }

                }
            }
            catch (Exception ex)
            {

            }
            model.DocumentList = documentList;
            return model;
        }
        public string getExtentionwithbase64(string ext, string base64)
        {
            string file = "";
            if (ext.ToLower().Contains("txt"))
            {
                file = "data:text/plain;base64," + base64;
            }
            else if (ext.ToLower().Contains("pdf"))
            {
                file = "data:application/pdf;base64," + base64;
            }
            else if (ext.ToLower().Contains("docx"))
            {
                file = "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + base64;
            }
            else if (ext.ToLower().Contains("xlsx"))
            {
                file = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64," + base64;
            }
            else if (ext.ToLower().Contains("doc"))
            {
                file = "data:application/msword;base64," + base64;
            }
            else if (ext.ToLower().Contains("xls"))
            {
                file = "data:application/vnd.ms-excel;base64," + base64;
            }
            else if (ext.ToLower().Contains("csv"))
            {
                file = "data:text/csv;base64," + base64;
            }
            else
            {
                file = "data:image/png;base64," + base64;
            }

            return file;
        }
    }
}