﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class DailyCloseoutService : IDailyCloseoutService
    {
        private readonly IExpenseBatchService _expenseBatchService;

        public DailyCloseoutService(IUnitOfWork context, IExpenseBatchService expenseBatchService)
        {
            this.Context = context;
            this._expenseBatchService = expenseBatchService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<DailyCloseoutPendingTransactionsDto>> GetDailyCloseoutPendingTransactionsAsync(DateTime lastCloseoutDate, bool operatingOnly = true)
        {
            var transactions = await this.Context.GeneralLedgers.GetDailyCloseoutPendingTransactionsAsync(lastCloseoutDate);

            if (operatingOnly)
            {
                var pendingTransactions = transactions.Where(x => x.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Operating);

                return pendingTransactions.ToList();
            }

            return transactions;
        }

        public async Task<IList<ContractDepositDto>> GetDailyCloseoutContractDepositsAsync(DateTime lastCloseoutDate, DateTime? lastPostedDate)
        {
            var criteria = new ContractDepositCriteriaDto();

            // Add one day to filter out deposits posted on last closeout date.
            criteria.ReceivedDateFrom = lastCloseoutDate.AddDays(1);

            if (lastPostedDate.HasValue)
            {
                criteria.ReceivedDateFrom = lastCloseoutDate;
                criteria.ReceivedDateTo = lastPostedDate;
            }

            return await this.Context.ContractDeposits.GetByCriteriaAsync(criteria);
        }

        public async Task<DateTime> GetDailyCloseoutLastCloseoutDateAsync()
        {
            return await this.Context.GeneralLedgers.GetDailyCloseoutLastCloseoutDateAsync();
        }

        public async Task<IDictionary<DailyCloseoutAmounts, decimal>> GetDailyCloseoutAmountsAsync()
        {
            return await this.Context.GeneralLedgers.GetDailyCloseoutAmountsAsync();
        }

        public async Task ProcessDailyCloseoutAsync(IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var lastCloseoutDate = await this.GetDailyCloseoutLastCloseoutDateAsync();

                // create the Expense Batch
                var dailyCloseoutBatch = await this.CreateDailyCloseoutBatchAsync(user);

                // create an Expense Payment of type 1 (check) but use 'EB [expensebatchid]' for the reference number (don't actually create a check)
                var dailyCloseoutCheck = new ExpensePaymentDto()
                {
                    ExpenseBatchId = dailyCloseoutBatch.ExpenseBatchId,
                    ExpensePaymentTypeId = (int)ExpensePaymentType.Check,
                    ContractEntityTypeId = (int)ContractEntityType.ECE,
                    ContractEntityId = 100000,
                    DateIssued = DateTime.Now,
                    DatePosted = DateTime.Now,
                    GrossAmount = dailyCloseoutBatch.BatchAmount,
                    DeductionAmount = decimal.Zero,
                    PaymentAmount = dailyCloseoutBatch.BatchAmount,
                    TransactionCount = 0,
                    PayeeName = "ECE-OPERATING ACCNT.",
                    ReferenceNumber = $"EB-{dailyCloseoutBatch.ExpenseBatchId}",
                    Notes = $"Last Closeout Date = {lastCloseoutDate}"
                };

                await this._expenseBatchService.CreateExpensePaymentAsync(dailyCloseoutCheck, user);

                // Get list of all GL entries related to operating GL entries' transactions
                var transactions = await this.GetDailyCloseoutPendingTransactionsAsync(lastCloseoutDate, operatingOnly: false);

                // update the GL entries with the expense batch id
                foreach (var trans in transactions)
                {
                    var journalActivity = await this.Context.GeneralLedgers.GetJournalActivityByIdAsync(trans.GeneralLedgerJournalId);

                    journalActivity.ExpenseBatchId = dailyCloseoutBatch.ExpenseBatchId;

                    journalActivity.SetAsUpdated(user);

                    await this.Context.GeneralLedgers.UpdateGeneralLedgerJournalAsync(journalActivity);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpenseBatchDto> CreateDailyCloseoutBatchAsync(IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var batch = await this.Context.ExpenseBatches.GetPendingBatchByTypeAsync(ExpenseBatchType.ECE, user);

                var batchAmounts = await this.GetDailyCloseoutAmountsAsync();

                batch.BatchAmount = batchAmounts[DailyCloseoutAmounts.Total];

                batch.DatePosted = DateTime.Now;

                batch.SetAsUpdated(user.GetUserId());

                await this.Context.ExpenseBatches.UpdateAsync(batch);

                this.Context.Commit();

                return batch;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
