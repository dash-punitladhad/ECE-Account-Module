﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;

    public class OfferService : IOfferService
    {
        private readonly IOfferWebLinkService _offerWebLinkService;
        private readonly IOfferVenueDescriptionService _offerVenueDescriptionService;
        private readonly IUserService _userService;
        private readonly ILookupService _lookupService;
        private readonly IBlueCardService _blueCardService;
        private readonly IAlertService _alertService;

        public OfferService(IUnitOfWork context,
                            IOfferWebLinkService offerWebLinkService,
                            IUserService userService,
                            ILookupService lookupService,
                            IBlueCardService blueCardService,
                            IAlertService alertService,
                            IOfferVenueDescriptionService offerVenueDescriptionService)
        {
            this.Context = context;

            this._offerWebLinkService = offerWebLinkService;
            this._offerVenueDescriptionService = offerVenueDescriptionService;
            this._userService = userService;
            this._lookupService = lookupService;
            this._blueCardService = blueCardService;
            this._alertService = alertService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task CreateAsync(OfferDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.Offers.CreateAsync(dto);

                await this.Context.OfferTerms.CreateAsync(
                        new OfferTermsDto
                        {
                            OfferId = dto.OfferId,
                            CreatedById = dto.CreatedById,
                            CreatedDate = dto.CreatedDate
                        }
                    );

                await this.Context.OfferFinancial.CreateAsync(
                         new OfferFinancialDto
                         {
                             OfferId = dto.OfferId,
                             CreatedById = dto.CreatedById,
                             CreatedDate = dto.CreatedDate
                         }
                  );

                var eventDates = await this.Context.BlueCards.GetEventDatesAsync(dto.BlueCardId);

                foreach (var offerEventDate in eventDates)
                {
                    await this.Context.OfferEventDate.CreateAsync(
                        new OfferEventDateDto
                        {
                            OfferId = dto.OfferId,
                            EventDate = offerEventDate.EventDate,
                            CreatedById = dto.CreatedById,
                            CreatedDate = dto.CreatedDate
                        }
                 );
                }

                if (dto.PresenterWebLinks != null && dto.PresenterWebLinks.Count > 0)
                {
                    await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, dto.PresenterWebLinks, user, (int)EntityType.Presenter);
                }

                if (dto.VenueWebLinks != null && dto.VenueWebLinks.Count > 0)
                {
                    await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, dto.VenueWebLinks, user, (int)EntityType.Venue);
                }

                if (dto.OfferVenueDescriptions != null)
                {
                    foreach (var venueDescription in dto.OfferVenueDescriptions)
                    {
                        var offerVenueDescription = new OfferVenueDescriptionDto();
                        offerVenueDescription.OfferId = dto.OfferId;
                        offerVenueDescription.VenueTypeId = venueDescription.VenueTypeId;

                        await this._offerVenueDescriptionService.CreateAsync(offerVenueDescription);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task CloneAsync(OfferDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.Offers.CreateAsync(dto);

                // Clone terms
                var offerTerms = await this.Context.OfferTerms.GetOfferTermsByIdAsync(dto.OriginalOfferId);

                offerTerms.OfferId = dto.OfferId;
                offerTerms.CreatedById = dto.CreatedById;
                offerTerms.CreatedDate = dto.CreatedDate;

                await this.Context.OfferTerms.CreateAsync(offerTerms);

                // Clone financial
                var offerFinancial = await this.Context.OfferFinancial.GetOfferFinancialByIdAsync(dto.OriginalOfferId);

                offerFinancial.OfferId = dto.OfferId;
                offerFinancial.CreatedById = dto.CreatedById;
                offerFinancial.CreatedDate = dto.CreatedDate;

                await this.Context.OfferFinancial.CreateAsync(offerFinancial);

                // Clone event dates
                var eventDates = await this.Context.OfferEventDate.GetOfferEventDatesByIdAsync(dto.OriginalOfferId);
                foreach (var offerEventDate in eventDates)
                {
                    offerEventDate.OfferId = dto.OfferId;
                    offerEventDate.CreatedById = dto.CreatedById;
                    offerEventDate.CreatedDate = dto.CreatedDate;

                    await this.Context.OfferEventDate.CreateAsync(offerEventDate);
                }

                // Clone ticket scales
                var offerTicketScales = await this.Context.OfferTicketScale.GetOfferTicketScalesByIdAsync(offerFinancial.OfferFinancialId);
                foreach (var offerTicketScale in offerTicketScales)
                {
                    offerTicketScale.OfferTicketScaleId = 0;
                    offerTicketScale.OfferFinancialId = offerFinancial.OfferFinancialId;
                    offerTicketScale.CreatedById = dto.CreatedById;
                    offerTicketScale.CreatedDate = dto.CreatedDate;

                    await this.Context.OfferTicketScale.CreateAsync(offerTicketScale);
                }

                // Clone Presenter web links
                var presenterWebLinks = await this.Context.OfferWebLinks.GetOfferWebLinksAsync(EntityType.Offer, dto.OriginalOfferId, (int)EntityType.Presenter);
                if (presenterWebLinks.Count > 0)
                {
                    await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, presenterWebLinks, user, (int)EntityType.Presenter);
                }

                // Clone venue web links
                var venueWebLinks = await this.Context.OfferWebLinks.GetOfferWebLinksAsync(EntityType.Offer, dto.OriginalOfferId, (int)EntityType.Venue);
                if (venueWebLinks.Count > 0 || venueWebLinks != null)
                {
                    await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, venueWebLinks, user, (int)EntityType.Venue);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<OfferDto> GetOfferByIdAsync(int id)
        {
            var result = await this.Context.Offers.GetByIdAsync(id);

            return result;
        }

        public async Task<OfferPreviewDetailDto> GetOfferPreviewDetailByIdAsync(int id)
        {
            var result = await this.Context.Offers.GetOfferPreviewDetailByIdAsync(id);

            return result;
        }

        public async Task<BlueCardOfferDetailDto> GetBlueCardOfferDetailByIdAsync(int id)
        {
            var result = await this.Context.Offers.GetBlueCardOfferDetailByIdAsync(id);

            return result;
        }

        public async Task<OfferDetailDto> GetOfferDetailByIdAsync(int id)
        {
            var result = await this.Context.Offers.GetOfferDetailByIdAsync(id);

            return result;
        }

        public async Task<OfferTermsDto> GetOfferTermsByIdAsync(int id)
        {
            var result = await this.Context.OfferTerms.GetOfferTermsByIdAsync(id);

            return result;
        }

        public async Task<OfferFinancialDto> GetOfferFinancialByIdAsync(int id)
        {
            var result = await this.Context.OfferFinancial.GetOfferFinancialByIdAsync(id);

            return result;
        }

        public async Task<List<OfferTicketScaleDto>> GetOfferTicketScalesByIdAsync(int id)
        {
            var result = await this.Context.OfferTicketScale.GetOfferTicketScalesByIdAsync(id);

            return result;
        }

        public async Task<List<OfferEventDateDto>> GetOfferEventDatesByIdAsync(int id)
        {
            var result = await this.Context.OfferEventDate.GetOfferEventDatesByIdAsync(id);

            return result;
        }

        public async Task<List<OfferVenueDescriptionDto>> GetVenueTypesByOfferAsync(int id)
        {
            return await this.Context.OfferVenueDescriptions.GetVenueTypesByOfferAsync(id);
        }

        public async Task UpdateStep1Async(OfferDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.Offers.UpdateStep1Async(dto);

                await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, dto.PresenterWebLinks, user, (int)EntityType.Presenter);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep2Async(OfferDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                if (string.IsNullOrEmpty(dto.UrlKey))
                {
                    dto.UrlKey = SecurityHelper.GeneratePasswordToken();
                }

                await this.Context.Offers.UpdateStep2Async(dto);

                await this._offerWebLinkService.SyncOfferWebLinksAsync(EntityType.Offer, dto.OfferId, dto.VenueWebLinks, user, (int)EntityType.Venue);

                await this._offerVenueDescriptionService.SyncVenueDescriptionsAsync(dto.OfferId, dto.SelectedVenueTypes);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep3Async(OfferTermsDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var termsDto = await this.Context.OfferTerms.GetOfferTermsByIdAsync(dto.OfferId);

                termsDto.SetAsUpdated(user);
                termsDto.Production = dto.Production;
                termsDto.Transportation = dto.Transportation;
                termsDto.Accommodations = dto.Accommodations;
                termsDto.MerchandiseRate = dto.MerchandiseRate;
                termsDto.Advertising = dto.Advertising;
                termsDto.OtherTerms = dto.OtherTerms;
                termsDto.OnSaleDate = dto.OnSaleDate;
                termsDto.AnnounceDate = dto.AnnounceDate;

                termsDto.RadiusClauseMiles = dto.RadiusClauseMiles;
                termsDto.RadiusClauseDaysBeforeEvent = dto.RadiusClauseDaysBeforeEvent;
                termsDto.RadiusClauseDaysAfterEvent = dto.RadiusClauseDaysAfterEvent;

                termsDto.ArtistId = dto.ArtistId;

                await this.Context.Offers.UpdateStep3Async(termsDto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep4Async(OfferEventDateDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                foreach (var date in dto.EventDates)
                {
                    if (date.OfferEventDateId != null)
                    {
                        date.SetAsUpdated(user);
                        await this.Context.OfferEventDate.UpdateAsync(date);
                    }
                    else
                    {
                        date.OfferId = dto.OfferId;
                        date.SetAsCreated(user);
                        await this.Context.OfferEventDate.CreateAsync(date);
                    }
                }

                var termDto = await this.Context.OfferTerms.GetOfferTermsByIdAsync(dto.OfferId);

                termDto.SetAsUpdated(user);
                termDto.EventBilling = dto.EventBilling;
                termDto.EventDescription = dto.EventDescription;
                termDto.EventSupport = dto.EventSupport;
                termDto.OfferId = dto.OfferId;

                await this.Context.OfferTerms.UpdateAsync(termDto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep5Async(OfferTicketScaleDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var existingTicketScales = await this.Context.OfferTicketScale.GetOfferTicketScalesByIdAsync(dto.OfferFinancialId.Value);
                var activeTicketScales = dto.TicketScales;

                var ticketScalesToKeep =
                    (from s in existingTicketScales
                     join a in activeTicketScales on s.OfferTicketScaleId equals a.OfferTicketScaleId
                     select s).ToList();

                foreach (var scaleToKeep in ticketScalesToKeep)
                {
                    var activeScale =
                        activeTicketScales.FirstOrDefault(x => x.OfferTicketScaleId == scaleToKeep.OfferTicketScaleId);

                    if (activeScale != null)
                    {
                        scaleToKeep.OfferTicketTypeId = activeScale.OfferTicketTypeId;
                        scaleToKeep.Allotment = activeScale.Allotment;
                        scaleToKeep.Price = activeScale.Price;
                    }

                    scaleToKeep.SetAsUpdated(user);
                    await this.Context.OfferTicketScale.UpdateAsync(scaleToKeep);
                }

                var ticketScalesToAdd = activeTicketScales.Except(ticketScalesToKeep, x => x.OfferTicketScaleId);

                foreach (var scaleToAdd in ticketScalesToAdd)
                {
                    scaleToAdd.OfferFinancialId = dto.OfferFinancialId;
                    scaleToAdd.SetAsCreated(user);
                    await this.Context.OfferTicketScale.CreateAsync(scaleToAdd);
                }

                var ticketScalesToRemove = existingTicketScales.Except(ticketScalesToKeep);

                foreach (var scaleToRemove in ticketScalesToRemove)
                {
                    this.Context.OfferTicketScale.Delete(scaleToRemove.OfferTicketScaleId);
                }

                var financialDto = new OfferFinancialDto();
                financialDto.OfferFinancialId = dto.OfferFinancialId.Value;
                financialDto.ArtistGuaranteeOffer = dto.ArtistGuaranteeOffer;
                financialDto.SalesTaxRate = dto.SalesTaxRate;
                financialDto.SalesTaxTypeId = dto.SalesTaxTypeId;
                financialDto.OfferRateTypeId = dto.OfferRateTypeId;
                financialDto.NagborRate = dto.NagborRate;
                financialDto.AnticipatedExpenses = dto.AnticipatedExpenses;
                financialDto.TaxesDescription = dto.TaxesDescription;
                financialDto.ArtistPercentageDeal = dto.ArtistPercentageDeal;
                financialDto.StateEntertainmentTaxRate = dto.StateEntertainmentTaxRate;
                financialDto.WalkoutPotential = dto.WalkoutPotential;

                financialDto.SetAsUpdated(user);

                await this.Context.OfferFinancial.UpdateAsync(financialDto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep6Async(OfferTermsDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var termDto = await this.Context.OfferTerms.GetOfferTermsByIdAsync(dto.OfferId);

                var offerValidUntilDate = dto.OfferValidUntilDate.Value;

                var formattedDate = offerValidUntilDate.ToString("MM/dd/yyyy (ddd) 'at' h:mm tt");
                var timezoneLookupName = "Eastern Standard Time";

                var timeZone = _lookupService.GetAllTimeZones()
                    .FirstOrDefault(m => m.TimezoneId == dto.OfferValidUntilTimezoneId);
                if (timeZone != null)
                {
                    timezoneLookupName = timeZone.LookupName;
                }

                formattedDate += " " + TextHelper.GetTimeZoneName(offerValidUntilDate, timezoneLookupName);

                var offerBindingType = await this.Context.Lookups.GetOfferBindingTypeAsync(dto.OfferBindingTypeId.Value);

                termDto.ArtistBindingTerms = offerBindingType.BindingTermsText
                    .Replace("{OfferValidUntilDate}", formattedDate)
                    .Replace("{DepositDueWithin}", $"{dto.DepositDueWithin}");

                termDto.SetAsUpdated(user);
                termDto.OfferValidUntilDate = dto.OfferValidUntilDate;
                termDto.OfferValidUntilTimezoneId = dto.OfferValidUntilTimezoneId;
                termDto.DepositDueWithin = dto.DepositDueWithin;
                termDto.DepositPercentage = dto.DepositPercentage;
                termDto.DepositDueAmount = dto.DepositDueAmount;
                termDto.ECEProcurementFee = dto.ECEProcurementFee;
                termDto.OfferBindingTypeId = dto.OfferBindingTypeId;

                await this.Context.OfferTerms.UpdateAsync(termDto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateStep7Async(OfferPreviewDetailDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);
                await this.Context.Offers.UpdateStep7Async(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateOfferStatusAsync(int offerId, int offerStatus, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.Offers.UpdateOfferStatusAsync(offerId, offerStatus, user.GetUserId());

                var offer = await this.Context.Offers.GetByIdAsync(offerId);

                if (offerStatus == (int)OfferStatus.Signed)
                {
                    var nationalAgents = _userService.GetUsersByRole((int)ECERole.Nationals, false);
                    var appEvent = await _lookupService.GetAppEventTypeAsync(AppEventType.OfferPresenterSigned);
                    var appEventText = string.Empty;

                    switch (offer.LineOfBusinessId)
                    {
                        case (int)LineOfBusiness.National:
                            appEventText = appEvent.Text.Replace("{LineOfBusiness}", "National");
                            break;

                        case (int)LineOfBusiness.Touring:
                            appEventText = appEvent.Text.Replace("{LineOfBusiness}", "Touring");
                            break;

                        default:
                            break;
                    }

                    foreach (var agent in nationalAgents)
                    {
                        AlertDto alert = new AlertDto
                        {
                            AppUserId = agent.AppUserId.Value,
                            Description = appEventText,
                            IsRead = false,
                            EntityTypeId = (int)EntityType.Offer,
                            EntityId = offerId,
                            AppEventTypeId = (int)AppEventType.OfferPresenterSigned
                        };

                        await this._alertService.CreateAsync(alert, user);
                    }
                }

                if (offerStatus == (int)OfferStatus.Accepted
                        || offerStatus == (int)OfferStatus.Rejected
                        || offerStatus == (int)OfferStatus.Countered
                        || offerStatus == (int)OfferStatus.Suspended)
                {
                    var blueCard = await this.Context.BlueCards.GetBlueCardByIdAsync(offer.BlueCardId);

                    var appEventType = AppEventType.OfferAccepted;

                    switch (offerStatus)
                    {
                        case (int)OfferStatus.Rejected:
                            appEventType = AppEventType.OfferRejected;
                            break;

                        case (int)OfferStatus.Countered:
                            appEventType = AppEventType.OfferCountered;
                            break;

                        case (int)OfferStatus.Suspended:
                            appEventType = AppEventType.OfferSuspended;
                            break;
                    }

                    var appEvent = await _lookupService.GetAppEventTypeAsync(appEventType);

                    AlertDto alert = new AlertDto
                    {
                        AppUserId = blueCard.AgentId,
                        Description = appEvent.Text,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Offer,
                        EntityId = offerId,
                        AppEventTypeId = (int)appEventType
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateBindingTermsAsync(OfferTermsDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.Offers.UpdateBindingTermsAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task SendOfferLinkEmailAsync(int id, IPrincipal user)
        {
            var offer = await this.Context.Offers.GetBlueCardOfferDetailByIdAsync(id);

            var agents = _lookupService.GetAllActiveAgents();
            var agent = agents.FirstOrDefault(x => x.AppUserId == offer.BlueCard.AgentId);

            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendOfferLink);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string url = string.Format("{0}{1}{2}",
                            MobiusConfiguration.GetString("Application.Url"),
                            MobiusConfiguration.GetString("Application.BlueCardOfferUrl"),
                            offer.Offer.UrlKey);

            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var eventDate = offer.Offer.OfferEventDates
                                            .Where(x => x.IsIncluded)
                                            .OrderBy(x => x.EventDate)
                                            .First();

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);

            var body = bodyBuilder
                .Replace("{AgentEmailAddress}", agent==null?string.Empty: agent.Username)
                //.Replace("{AgentEmailAddress}", agent?.Username?? "")
                .Replace("{Year}", DateTime.Now.Year.ToString())
                .Replace("{Body}", bodyTemplate.Body)
                .Replace("{URL}", url)
                .Replace("{BuyerName}", offer.Offer.BuyerName)
                .Replace("{ArtistName}", offer.Artist.Name)
                .Replace("{EventDate}", eventDate.EventDate.ToString(DateTimeConstants.StandardDateWithDays))
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("''", "'")
                .ToString();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;
            email.AddRecipient(offer.Offer.BuyerEmail, offer.Offer.BuyerName);

            if (agent != null)
            {
                if (TextHelper.IsValidEmail(agent.Username))
                {
                    email.SetFrom(agent.Username, agent.FullName);
                }
            }

            // Override agent's email address with the no-reply email address
            // We need to leave the call in to get the agent's email address because we'll add it
            // the email body in the future.
            if (MobiusConfiguration.GetBoolean("Email.UseNoReply"))
            {
                var noReplyEmailAddress = MobiusConfiguration.GetString("Email.FromAddress");
                var noReplyEmailName = MobiusConfiguration.GetString("Email.FromName");

                email.SetFrom(noReplyEmailAddress, noReplyEmailName);
            }

            try
            {
                this.Context.BeginTransaction();

                var smtpManager = new SmtpManager(this.Context);

                var pendingReleaseDuration = MobiusConfiguration.GetTimeSpan("Email.PendingReleaseDuration", Constants.PendingReleaseDuration);

                var agentUserWithRoles = await this._userService.GetUserByIdAsync(offer.BlueCard.AgentId, true);

                if (!agentUserWithRoles.UserIsInOffice(Constants.HoustonOfficeId))
                {
                    smtpManager.SendMessage(email, user.GetUserId(), DateTime.Now.Add(pendingReleaseDuration));
                }

                if (offer.Offer.OfferStatusId == (int)OfferStatus.Created)
                {
                    await this.Context.Offers.UpdateOfferStatusAsync(id, (int)OfferStatus.PresenterReview, user.GetUserId());
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<bool> CanAddAsync(int userId, int assignedAgentId)
        {
            return await _blueCardService.CanEditAsync(userId, assignedAgentId);
        }

        public async Task<IList<OfferSearchResultDto>> GetOfferByCriteriaAsync(OfferSearchCriteriaDto criteria)
        {
            var results = await this.Context.Offers.GetOfferByCriteriaAsync(criteria);

            return results;
        }

        public async Task<OfferDto> GetOfferByUrlKeyAsync(string key)
        {
            var offer = await this.Context.Offers.GetOfferByUrlKeyAsync(key);

            return offer;
        }

        public async Task SaveSignatureAsync(int offerId, int signatureId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.Offers.SaveSignatureAsync(offerId, signatureId, user.GetUserId());

                await this.UpdateOfferStatusAsync(offerId, (int)OfferStatus.Signed, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<string> GetByCriteriaExportAsync(OfferSearchCriteriaDto criteriaDto)
        {
            var results = await this.Context.Offers.GetByCriteriaExportAsync(criteriaDto);

            return results;
        }
    }
}
