﻿namespace ECE.CRM.BusinessServices
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class IEnumerableExtensions
    {
        /// <summary>
        /// Computes the total sum of the sequence of System.Decimal values
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam>
        /// <param name="source">A sequence of values that are used to calculate a sum.</param>
        /// <param name="selector">A transform function to apply to each element.</param>
        /// <returns>The total sum of the projected values.</returns>
        public static decimal Total<TSource>(this IEnumerable<TSource> source, Func<TSource, decimal> selector)
        {
            return source.Sum(selector);
        }

        /// <summary>
        /// Computes the total sum of the sequence of nullable System.Decimal values
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam>
        /// <param name="source">A sequence of values that are used to calculate a sum.</param>
        /// <param name="selector">A transform function to apply to each element.</param>
        /// <returns>The total sum of the projected values. If the total is NULL, returns <c>decimal.Zero</c>.</returns>
        public static decimal Total<TSource>(this IEnumerable<TSource> source, Func<TSource, decimal?> selector)
        {
            return source.Sum(selector) ?? decimal.Zero;
        }

        /// <summary>
        /// Computes the total sum of the sequence of System.Decimal values
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam>
        /// <param name="source">A sequence of values that are used to calculate a sum.</param>
        /// <returns>The total sum of the projected values.</returns>
        public static decimal Total<TSource>(this IEnumerable<decimal> source)
        {
            return source.Sum();
        }

        /// <summary>
        /// Computes the total sum of the sequence of nullable System.Decimal values
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam>
        /// <param name="source">A sequence of values that are used to calculate a sum.</param>
        /// <returns>The total sum of the projected values. If the total is NULL, returns <c>decimal.Zero</c>.</returns>
        public static decimal Total<TSource>(this IEnumerable<decimal?> source)
        {
            return source.Sum() ?? decimal.Zero;
        }
    }
}
