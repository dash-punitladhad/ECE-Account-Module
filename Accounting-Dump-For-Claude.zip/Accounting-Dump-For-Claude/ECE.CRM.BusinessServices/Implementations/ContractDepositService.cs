namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;

    public class ContractDepositService : IContractDepositService
    {
        private readonly IAlertService _alertService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly ILookupService _lookupService;
        private readonly IContractSignatureService _contractSignatureService;
        private readonly IContractService _contractService;
        private readonly ICommunicationLogService _communicationLogService;
        private readonly IEntityHistoryService _entityHistoryService;

        public ContractDepositService(IUnitOfWork context,
            IAlertService alertService,
            IContractTransactionService contractTransactionService,
            IGeneralLedgerService generalLedgerService,
            IContractSignatureService contractSignatureService,
            IContractService contractService,
            ILookupService lookupService,
            ICommunicationLogService communicationLogService,
            IEntityHistoryService entityHistoryService)
        {
            this.Context = context;
            this._alertService = alertService;
            this._contractTransactionService = contractTransactionService;
            this._generalLedgerService = generalLedgerService;
            this._lookupService = lookupService;
            this._contractSignatureService = contractSignatureService;
            this._contractService = contractService;
            this._communicationLogService = communicationLogService;
            this._entityHistoryService = entityHistoryService;
        }

        public IUnitOfWork Context { get; private set; }

        public static DateTime GetDepositReceivedReleaseDate(ITimeProvider timeProvider)
        {
            // Release at 9:00 AM tomorrow.
            var defaultValue = TimeSpan.FromDays(1).Add(TimeSpan.FromHours(9));

            var releaseDepositReceivedMessage = MobiusConfiguration.GetTimeSpan("Application.ReleaseDepositReceivedMessage", defaultValue);

            var releaseDate = timeProvider.Today.Add(releaseDepositReceivedMessage);

            return releaseDate;
        }

        public async Task PostContractDepositAsync(ContractDepositDto contractDeposit, IPrincipal user)
        {
            await PostContractDepositAsync(contractDeposit, null, user);
        }

        public async Task PostContractDepositAsync(ContractDepositDto contractDeposit, ExpensePaymentDto payment, IPrincipal user)
        {
            if (contractDeposit == null)
            {
                throw new ArgumentNullException(nameof(contractDeposit));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (contractDeposit.ContractDepositId == 0)
                {
                    contractDeposit.SetAsCreated(user);
                    await this.Context.ContractDeposits.CreateAsync(contractDeposit);
                }

                // Get income transactions for the payee that have not yet been paid in full, ordered by due date.
                var contractTrxCriteria = new ContractTransactionSearchCriteriaDto();
                contractTrxCriteria.ContractId = contractDeposit.ContractId;
                contractTrxCriteria.IsExpense = false;
                contractTrxCriteria.ContractEntityIds.Add(contractDeposit.ContractEntityId);
                contractTrxCriteria.ContractEntityTypeIds.Add(contractDeposit.ContractEntityTypeId);
                contractTrxCriteria.PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.NotPaid;

                var incomeTransactions = await this._contractTransactionService.GetByCriteriaAsync(contractTrxCriteria);

                incomeTransactions = incomeTransactions
                    .OrderBy(x => x.DueDate)
                    .ThenBy(x => x.ContractTransactionId);

                var workingAmount = contractDeposit.AppliedAmount;
                foreach (var transaction in incomeTransactions)
                {
                    if (workingAmount > decimal.Zero)
                    {
                        decimal paidAmount = decimal.Zero;

                        decimal dueAmount = transaction.DueAmount;

                        if (workingAmount >= dueAmount)
                        {
                            // Post the entire income amount due.
                            paidAmount = dueAmount;
                            transaction.PaidAmount = transaction.RequiredAmount.GetValueOrDefault();
                            this._contractTransactionService.SynchronizePaidDate(transaction, contractDeposit.ReceivedDate);
                        }
                        else
                        {
                            // Post as much income amount due as possible.
                            paidAmount = workingAmount;
                            transaction.PaidAmount = transaction.PaidAmount.GetValueOrDefault() + workingAmount;
                            this._contractTransactionService.SynchronizePaidDate(transaction, contractDeposit.ReceivedDate);
                        }

                        // Keep track of the remaining unposted deposit amount.
                        workingAmount -= paidAmount;

                        // Assign the deposit reference number.
                        transaction.ReferenceNumber = contractDeposit.ReferenceNumber;

                        // Update transaction and create GL entry
                        await this._contractTransactionService.UpdateAsync(transaction, user);

                        if (contractDeposit.IsCrossDeduction)
                        {
                            // Add GL Entries for a cross deduction being paid.
                            var glEvent = this._generalLedgerService.GetEventForPayingIncome(transaction);

                            await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(glEvent, paidAmount, transaction, user, transaction.ReferenceNumber, payment?.ExpenseBatchId);
                        }
                        else
                        {
                            await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.DepositReceived, paidAmount, transaction, user, contractDeposit.ReferenceNumber, payment?.ExpenseBatchId);
                        }
                    }
                }

                await this._generalLedgerService.PayEceExpensesForContractAsync(contractDeposit.ContractId, user);

                var contract = await this._contractService.GetByIdAsync(contractDeposit.ContractId, true);

                var agents = _lookupService.GetAllAgents();
                var agent = agents.FirstOrDefault(x => x.AppUserId == contract.AgentId);

                // Generate an alert to the contract agent that the deposit has been posted.
                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractDepositPosted);
                var alertText = appEvent.Text.Replace("{ContractId}", contractDeposit.ContractId.ToString());
                var alert = new AlertDto()
                {
                    EntityTypeId = (int)EntityType.Contract,
                    EntityId = contractDeposit.ContractId,
                    AppUserId = contract.AgentId,
                    AppEventTypeId = (int)AppEventType.ContractDepositPosted,
                    Description = alertText
                };

                await this._alertService.CreateAsync(alert, user);

                // Audit contract event
                var history = new EntityHistoryDto
                {
                    EntityId = contract.ContractId,
                    Type = EntityType.Contract,
                    Event = AuditEvent.ContractDepositReceived,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                // Create alert for nationals users if a contract artist is national.
                if (contract.ContractArtists.Any(x => x.IsNational))
                {
                    var nationalsUsers = this.Context.Users.GetUsersByRole((int)ECERole.Nationals, false);

                    foreach (var appUser in nationalsUsers)
                    {
                        alert = new AlertDto()
                        {
                            EntityTypeId = (int)EntityType.Contract,
                            EntityId = contractDeposit.ContractId,
                            AppUserId = appUser.AppUserId.GetValueOrDefault(),
                            AppEventTypeId = (int)AppEventType.ContractDepositPosted,
                            Description = alertText
                        };

                        await this._alertService.CreateAsync(alert, user);
                    }
                }

                var contractIsIssued = contract.ContractStatusId != (int)ContractStatus.Created;

                if (contractIsIssued || contract.IsNoIssue == false)
                {
                    if (contractIsIssued)
                    {
                        // If the contract is issued, then track status changes based on deposits and signatures
                        await this._contractSignatureService.UpdateContractStatusAsync(contract, user);
                    }

                    // Inform the presenter that their deposit has been received.
                    if (contract.IsNoIssue == false && contractDeposit.ContractEntityTypeId == (int)ContractEntityType.Presenter)
                    {
                        var primaryContact = await this.Context.Contacts.GetPrimaryContactAsync(EntityType.Contract, contractDeposit.ContractId);
                        if (primaryContact != null && !string.IsNullOrWhiteSpace(primaryContact.EmailAddress))
                        {
                            var portal = await this.Context.Contracts.GetPresenterPortalForContractAsync(contract.ContractId);
                            if (portal == null)
                            {
                                // Create a portal for this contract if one does not exist.
                                portal = await this._contractService.CreatePresenterPortalAsync(contract, user);
                            }

                            portal.ParentContract = contract;

                            var message = await this.GenerateDepositReceivedEmailAsync(primaryContact, portal, agent);
                            if (message.HasRecipient)
                            {
                                var smtpManager = new SmtpManager(this.Context);

                                var sentBy = contract.AgentId;

                                var releaseDate = GetDepositReceivedReleaseDate(TimeProvider.Current);
                                try
                                {
                                    if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                                    {
                                        smtpManager.SendMessage(message, sentBy, releaseDate, SendMessageMode.Queued);
                                    }
                                    var commLog = new CommunicationLogDto
                                    {
                                        CommunicationMethodId = (int)CommunicationMethod.Email,
                                        ContactId = primaryContact.ContactId,
                                        EntityId = contract.ContractId,
                                        EntityTypeId = (int)EntityType.Contract,
                                        EmailQueueId = message.EmailQueueId,
                                        LogDate = DateTime.Now,
                                        LogTime = DateTime.Now.ToShortTimeString(),
                                        Notes = "Send Deposit Notification to Presenter"
                                    };

                                    _communicationLogService.AddCommunicationLog(commLog, user);
                                }
                                catch (Exception ex)
                                {
                                    var commLogCatch = new CommunicationLogDto
                                    {
                                        CommunicationMethodId = (int)CommunicationMethod.Email,
                                        ContactId = primaryContact.ContactId,
                                        EntityId = contract.ContractId,
                                        EntityTypeId = (int)EntityType.Contract,
                                        EmailQueueId = message.EmailQueueId,
                                        LogDate = DateTime.Now,
                                        LogTime = DateTime.Now.ToShortTimeString(),
                                        Notes = ex.Message.ToString(),
                                    };

                                    _communicationLogService.AddCommunicationLog(commLogCatch, user);
                                }
                            }
                        }
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UnpostContractDepositAsync(int contractDepositId, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var contractDeposit = await this.Context.ContractDeposits.GetByIdAsync(contractDepositId);
                if (contractDeposit == null)
                {
                    throw new ArgumentException($"Contract deposit {contractDepositId} not found.");
                }

                contractDeposit.SetAsUpdated(user);

                await this.Context.ContractDeposits.DeleteAsync(contractDeposit);

                // Get income transactions for the payee that have been paid, ordered by id (youngest first).
                var contractTrxCriteria = new ContractTransactionSearchCriteriaDto();
                contractTrxCriteria.ContractId = contractDeposit.ContractId;
                contractTrxCriteria.IsExpense = false;
                contractTrxCriteria.ContractEntityIds.Add(contractDeposit.ContractEntityId);
                contractTrxCriteria.ContractEntityTypeIds.Add(contractDeposit.ContractEntityTypeId);
                contractTrxCriteria.PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.PaidSomething;

                var contractTransactions = await this._contractTransactionService.GetByCriteriaAsync(contractTrxCriteria);

                contractTransactions = contractTransactions
                    .OrderByDescending(x => x.DueDate)
                    .ThenByDescending(x => x.ContractTransactionId);

                var workingAmount = contractDeposit.AppliedAmount;
                foreach (var trn in contractTransactions)
                {
                    if (workingAmount > decimal.Zero)
                    {
                        decimal unpaidAmount = decimal.Zero;

                        if (workingAmount >= trn.PaidAmount.GetValueOrDefault())
                        {
                            // Un-post the entire paid amount
                            unpaidAmount = trn.PaidAmount.GetValueOrDefault();
                        }
                        else
                        {
                            // Un-post the portion of the paid amount remaining
                            unpaidAmount = workingAmount;
                        }

                        // Reset the payment details.
                        trn.PaidAmount = trn.PaidAmount.GetValueOrDefault() - unpaidAmount;
                        this._contractTransactionService.SynchronizePaidDate(trn);

                        trn.ReferenceNumber = null;

                        // Reduce the paid amount remaining to unpost
                        workingAmount -= unpaidAmount;

                        // Update transaction and create GL entry
                        trn.SetAsUpdated(user);
                        await this._contractTransactionService.UpdateAsync(trn, user);
                        await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(GeneralLedgerEvent.DepositUnposted, unpaidAmount, trn, user, contractDeposit.ReferenceNumber);
                    }
                }

                contractTransactions = await this._contractTransactionService.GetByContractIdAsync(contractDeposit.ContractId);
                var incomePaid = contractTransactions
                    .Where(x => !x.IsExpense)
                    .Sum(x => x.PaidAmount.GetValueOrDefault());

                var eceExpensesPaid = contractTransactions
                    .Where(x => x.IsExpense && x.ContractEntityTypeId == (int)ContractEntityType.ECE)
                    .Sum(x => x.PaidAmount.GetValueOrDefault());

                // Determine whether ECE expenses should be unpaid. If so, go ahead and unpay them.
                // There is a copy of this logic in the Contract Worksheet Viewmodel.
                var canUnpayECETransactions = !contractTransactions.Any(x => x.IsExpense && x.ContractEntityTypeId != (int)ContractEntityType.ECE && x.PaidDate != null);

                if ((incomePaid < eceExpensesPaid) && canUnpayECETransactions)
                {
                    // Don't unpay ECE expenses unless you have to!
                    await this._generalLedgerService.UnpayEceExpensesForContractAsync(contractDeposit.AppliedAmount, contractDeposit.ContractId, user);
                }

                // Generate an alert to the contract agent that the deposit has been un-posted.
                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractDepositUnposted);
                var alertText = appEvent.Text.Replace("{ContractId}", contractDeposit.ContractId.ToString());
                var contract = await this._contractService.GetByIdAsync(contractDeposit.ContractId, true);
                var alert = new AlertDto()
                {
                    EntityTypeId = (int)EntityType.Contract,
                    EntityId = contractDeposit.ContractId,
                    AppUserId = contract.AgentId,
                    AppEventTypeId = (int)AppEventType.ContractDepositUnposted,
                    Description = alertText
                };

                await this._alertService.CreateAsync(alert, user);

                await this._contractSignatureService.UpdateContractStatusAsync(contract, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<List<ContractDepositDto>> GetContractDepositsByContractIdAsync(int contractId)
        {
            return await this.Context.ContractDeposits.GetAllByContractIdAsync(contractId);
        }

        public async Task<List<ContractDepositDto>> GetByPaymentMethodAndRefAsync(int paymentMethodId, string referenceNumber)
        {
            return await this.Context.ContractDeposits.GetByPaymentMethodAndReferenceNumberAsync(paymentMethodId, referenceNumber);
        }

        public async Task<PreCreateContractDepositResultDto> PreCreateDepositCheckAsync(ContractDepositDto deposit)
        {
            var unpaidIncomeAmount = await this.GetUnpaidIncomeForContractPayeeAsync(
                deposit.ContractId,
                deposit.ContractEntityTypeId,
                deposit.ContractEntityId);

            var criteria = new ContractDepositCriteriaDto();
            criteria.ContractEntityId = deposit.ContractEntityId;
            criteria.ContractEntityTypeId = deposit.ContractEntityTypeId;
            criteria.PaymentMethodId = deposit.PaymentMethodId;
            criteria.ReferenceNumber = deposit.ReferenceNumber;

            var sharedPaymentDeposits = await this.Context.ContractDeposits.GetByCriteriaAsync(criteria);

            var appliedAmount = sharedPaymentDeposits.Sum(x => x.AppliedAmount);
            appliedAmount += deposit.AppliedAmount;

            var result = new PreCreateContractDepositResultDto
            {
                DepositMatchesRequiredAmount = unpaidIncomeAmount == deposit.AppliedAmount,
                IsAppliedToMultipleContracts = false,
                DepositExceedsPaymentTotal = false,
                ExpectedIncomeAmount = unpaidIncomeAmount,
                DepositExceedsDueAmount = false
            };

            if (sharedPaymentDeposits.Any())
            {
                result.IsAppliedToMultipleContracts = true;
                result.DepositExceedsPaymentTotal = appliedAmount > sharedPaymentDeposits[0].ReceivedAmount;
            }

            if (unpaidIncomeAmount < deposit.AppliedAmount)
            {
                result.DepositExceedsDueAmount = true;
            }

            return result;
        }

        public async Task<decimal> GetUnpaidIncomeForContractPayeeAsync(int contractId, int contractEntityTypeId, int contractEntityId)
        {
            var contractTrxCriteria = new ContractTransactionSearchCriteriaDto();
            contractTrxCriteria.ContractId = contractId;
            contractTrxCriteria.IsExpense = false;
            contractTrxCriteria.ContractEntityIds.Add(contractEntityId);
            contractTrxCriteria.ContractEntityTypeIds.Add(contractEntityTypeId);
            contractTrxCriteria.PaidStatus = ContractTransactionSearchCriteriaDto.ContractTransactionPaidStatus.NotPaid;

            var trxs = await this._contractTransactionService.GetByCriteriaAsync(contractTrxCriteria);

            var unpaidAmount = trxs.Sum(x => x.RequiredAmount.GetValueOrDefault() - x.PaidAmount.GetValueOrDefault());

            return unpaidAmount;
        }

        public string GenerateContractLinkUrl(string key)
        {
            string url = string.Format(
                "{0}{1}{2}",
                MobiusConfiguration.GetString("Application.Url"),
                MobiusConfiguration.GetString("Application.EventDetailsUrl"),
                key);

            return url;
        }

        public async Task<TemplateMailMessage> GenerateDepositReceivedEmailAsync(ContactDto primaryContact, PresenterPortalDto portal, AppUserDto agent)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendSignatureDepositNotification);

            var message = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string url = this.GenerateContractLinkUrl(portal.UrlKey);
            var contractId = portal.ContractId.ToString();

            var firstEventDate = portal.ParentContract.FirstEventDate.GetValueOrDefault();

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);

            var subject = bodyTemplate.Subject
                .Replace("{ContractNumber}", contractId)
                .Replace("{EventType}", "Deposit");

            var body = bodyBuilder
                .Replace("{AgentEmailAddress}", agent.Username)
                .Replace("{Year}", DateTime.Now.Year.ToString())
                .Replace("{Body}", bodyTemplate.Body)
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("{EventType}", "deposit")
                .Replace("{ContractId}", contractId)
                .Replace("{ContactName}", primaryContact?.FullName)
                .Replace("{ContractDetailsUrl}", url)
                .Replace("{EventDate}", firstEventDate.ToString(DateTimeConstants.StandardDateWithDays))
                .ToString();

            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = bodyTemplate.IsHtml;

            message.AddRecipient(primaryContact);

            return message;
        }
    }
}
