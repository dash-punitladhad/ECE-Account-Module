﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class LMDLoginHistoryService : ILMDLoginHistoryService
	{
		public IUnitOfWork Context { get; private set; }
		public LMDLoginHistoryService(IUnitOfWork context)
		{
			Context = context;
		}

		public async Task CreateAsync(LMDLoginHistoryDto lMDLoginHistoryDto, IPrincipal user)
		{
			this.Context.BeginTransaction();
			try
			{
				await this.Context.lMDLoginHistoryDao.CreateAsync(lMDLoginHistoryDto);
				this.Context.Commit();
			}
			catch(Exception ex)
			{
				this.Context.Rollback();
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<List<LMDLoginHistoryUserDto>> GetLMDLoginHistoryListAsync(int lMdId, bool isSystemAdmin)
		{
			try
			{
				return await this.Context.lMDLoginHistoryDao.GetLMDLoginHistoryListAsync( lMdId,  isSystemAdmin);
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<bool> CheckLMDLoginHistoryExistsAsync(LMDLoginHistoryDto lMDLoginHistoryDto)
		{
			try
			{
				return await this.Context.lMDLoginHistoryDao.CheckLMDLoginHistoryExistsAsync(lMDLoginHistoryDto);
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<bool> RevereseLMDLoginHistoryAsync(LMDLoginHistoryDto lMDLoginHistoryDto)
		{
			try
			{
				return await this.Context.lMDLoginHistoryDao.RevereseLMDLoginHistoryAsync(lMDLoginHistoryDto);
			}
			catch (Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}
	
		
	}
}
