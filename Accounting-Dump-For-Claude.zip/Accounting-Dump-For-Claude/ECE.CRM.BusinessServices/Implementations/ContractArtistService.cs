﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractArtistService : IContractArtistService
    {
        private readonly IContractArtistEventDateService _contractArtistEventDateService;

        private readonly IContractDocumentService _contractDocumentService;

        public ContractArtistService(
            IUnitOfWork context,
            IContractArtistEventDateService contractArtistEventDateSerivce,
            IContractDocumentService contractDocumentService)
        {
            this.Context = context;
            this._contractArtistEventDateService = contractArtistEventDateSerivce;
            this._contractDocumentService = contractDocumentService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ContractArtistDto>> GetByContractIdAsync(int contractId)
        {
            if (contractId <= 0)
            {
                throw new ArgumentException(nameof(contractId));
            }

            return await this.Context.ContractArtists.GetByContractIdAsync(contractId);
        }

        public async Task<ContractArtistDto> GetByContractAndArtistIdAsync(int contractId, int artistId)
        {
            return await this.Context.ContractArtists.GetByContractAndArtistIdAsync(contractId, artistId);
        }

        public async Task<ContractArtistDto> GetByIdAsync(int id)
        {
            return await this.Context.ContractArtists.GetByIdAsync(id);
        }

        public async Task CreateAsync(ContractArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();
            try
            {
                dto.SetAsCreated(user);

                await this.Context.ContractArtists.CreateAsync(dto);

                if (dto.ArtistEventDates != null && dto.ArtistEventDates.Any())
                {
                    foreach (var eventDate in dto.ArtistEventDates)
                    {
                        eventDate.ContractArtistId = dto.ContractArtistId;
                        eventDate.ContractArtistEventDateId = 0;
                        await this._contractArtistEventDateService.CreateAsync(eventDate);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task UpdateAsync(ContractArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.ContractArtists.UpdateAsync(dto);

                if (dto.ArtistEventDates != null && dto.ArtistEventDates.Any())
                {
                    foreach (var eventDate in dto.ArtistEventDates)
                    {
                        eventDate.ContractArtistId = dto.ContractArtistId;

                        if (eventDate.ContractArtistEventDateId <= 0)
                        {
                            eventDate.ContractArtistEventDateId = 0;
                            await this._contractArtistEventDateService.CreateAsync(eventDate);
                        }
                        else
                        {
                            if (eventDate.IsSelected.HasValue && !eventDate.IsSelected.Value)
                            {
                                await this._contractArtistEventDateService.DeleteAsync(eventDate.ContractArtistEventDateId);
                            }
                            else
                            {
                                await this._contractArtistEventDateService.UpdateAsync(eventDate);
                            }
                        }
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            this.Context.BeginTransaction();

            try
            {
                // Before deleting the ContractArtist we need to "take care of" any event date children it may have.
                var eventDates = await this._contractArtistEventDateService.GetByContractArtistIdAsync(id);

                if (eventDates != null && eventDates.Any())
                {
                    // No witnesses...
                    foreach (var item in eventDates)
                    {
                        await this._contractArtistEventDateService.DeleteAsync(item.ContractArtistEventDateId);
                    }
                }

                await this.Context.ContractArtists.DeleteAsync(id);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task<IList<ContractArtistSearchResultDto>> GetArtistsByCriteria(ContractArtistSearchCriteriaDto criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            var results = await this.Context.ContractArtists.GetArtistsByCriteria(criteria);

            return results;
        }

        public async Task UpdateArtistEventTimeReasonAsync(int contractArtistId, int eventTimeReasonId, IPrincipal user)
        {
            if (contractArtistId <= 0)
            {
                throw new ArgumentException(nameof(contractArtistId));
            }

            if (eventTimeReasonId <= 0)
            {
                throw new ArgumentException(nameof(eventTimeReasonId));
            }

            this.Context.BeginTransaction();

            try
            {
                var contractArtist = await this.GetByIdAsync(contractArtistId);
                contractArtist.EventTimeReasonId = eventTimeReasonId;
                contractArtist.SetAsUpdated(user);
                await this.Context.ContractArtists.UpdateArtistEventTimeReasonAsync(contractArtist);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public async Task AddArtistRidersAsync(ContractArtistDto artist, IList<ContractDocumentDto> availableRiders, IPrincipal user)
        {
            if (artist == null)
            {
                throw new ArgumentNullException(nameof(artist));
            }

            if (availableRiders == null)
            {
                throw new ArgumentNullException(nameof(availableRiders));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var artistRiders = availableRiders.Where(x =>
                        x.OriginalEntityId == artist.ArtistId &&
                        x.OriginalEntityTypeId == (int)EntityType.Artist || x.OriginalEntityTypeId == (int)EntityType.National);
                if (!artistRiders.Any())
                {
                    // Select the Generic Rider – Standard Artist by default
                    // if any Artist on the contract lacks a custom rider
                    artistRiders = availableRiders.Where(x =>
                        x.OriginalEntityTypeId == (int)EntityType.Contract &&
                        x.Description.Contains("Standard Artist"));
                }

                var existing = await this._contractDocumentService.GetContractDocumentsForArtistAsync(artist.ContractId, artist.ArtistId);

                var existingRiders = existing.Where(x => x.IsRider && x.OriginalEntityTypeId == (int)EntityType.Artist);

                var newRiders = artistRiders.Except(existingRiders, (ContractDocumentDto d) =>
                {
                    return d.DocumentId;
                });

                foreach (var newRider in newRiders)
                {
                    await this._contractDocumentService.CreateAsync(newRider, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task AddArtistRidersAsync(IList<ContractArtistDto> artists, IList<ContractDocumentDto> availableRiders, IPrincipal user)
        {
            if (artists == null)
            {
                throw new ArgumentNullException(nameof(artists));
            }

            if (availableRiders == null)
            {
                throw new ArgumentNullException(nameof(availableRiders));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var selectGenericRiderStandardArtist = availableRiders.Any(x =>
                x.ContractDocumentId > 0 &&
                x.OriginalEntityTypeId == (int)EntityType.Contract &&
                x.Description.Contains("Standard Artist"));

            try
            {
                foreach (var artist in artists)
                {
                    var artistRiders = availableRiders.Where(x =>
                            x.OriginalEntityId == artist.ArtistId &&
                            x.OriginalEntityTypeId == (int)EntityType.Artist);
                    if (!artistRiders.Any() && selectGenericRiderStandardArtist == false)
                    {
                        // Select the Generic Rider – Standard Artist by default
                        // if any Artist on the contract lacks a custom rider
                        artistRiders = availableRiders.Where(x =>
                            x.OriginalEntityTypeId == (int)EntityType.Contract &&
                            x.Description.Contains("Standard Artist"));

                        selectGenericRiderStandardArtist = true;
                    }

                    var existing = await this._contractDocumentService.GetContractDocumentsForArtistAsync(artist.ContractId, artist.ArtistId);

                    var existingRiders = existing.Where(x => x.IsRider && x.OriginalEntityTypeId == (int)EntityType.Artist);

                    var newRiders = artistRiders.Except(existingRiders, (ContractDocumentDto d) =>
                    {
                        return d.DocumentId;
                    });

                    foreach (var newRider in newRiders)
                    {
                        await this._contractDocumentService.CreateAsync(newRider, user);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
