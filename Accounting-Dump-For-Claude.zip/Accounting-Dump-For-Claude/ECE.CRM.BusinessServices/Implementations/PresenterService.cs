﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class PresenterService : IPresenterService
    {
        private readonly IContactService _contactService;
        private readonly IWebLinkService _webLinkService;
        private readonly IDocumentService _documentService;
        private readonly IUserService _userService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;
        private readonly ICommissionManagementService _commissionManagementService;
        private readonly IGenreTypeService<PresenterGenreTypeDto> _presenterGenreTypeService;

        private AppUserDto _user = null;
        private AppUserDto _assignedAgent = null;

        public PresenterService(IUnitOfWork context,
                                IContactService contactService,
                                IWebLinkService webLinkService,
                                IDocumentService documentService,
                                IUserService userService,
                                IEntityHistoryService entityHistoryService,
                                ILookupService lookupService,
                                IAlertService alertService,
                                ICommissionManagementService commissionManagementService,
                                IGenreTypeService<PresenterGenreTypeDto> presenterGenreTypeService)
        {
            this.Context = context;

            this._contactService = contactService;
            this._webLinkService = webLinkService;
            this._documentService = documentService;
            this._userService = userService;
            this._entityHistoryService = entityHistoryService;
            this._lookupService = lookupService;
            this._alertService = alertService;
            this._commissionManagementService = commissionManagementService;
            this._presenterGenreTypeService = presenterGenreTypeService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<PresenterDto>> GetPresentersByCharsAsync(string chars)
        {
            var presenters = await this.Context.Presenters.GetPresentersByCharsAsync(chars);

            return presenters;
        }

        public async Task<List<PresenterTypeAheadDto>> GetTypeAheadByCharsAsync(string chars)
        {
            var presenters = await this.Context.Presenters.GetTypeAheadByCharsAsync(chars);

            return presenters;
        }

        public async Task<List<PresenterTypeAheadDto>> GetTypeAheadByCharsAsync(string chars, int[] agents)
        {
            var presenters = await this.Context.Presenters.GetTypeAheadByCharsAsync(chars, agents);

            return presenters;
        }

        public async Task<PresenterDto> GetPresenterByNameAndOrgAsync(string accountName, string orgName)
        {
            var presenters = await this.Context.Presenters.GetPresenterByNameAndOrgAsync(accountName, orgName);

            return presenters;
        }

        public PresenterDto GetPresenterById(int id, bool includeChildren = false)
        {
            var dto = this.Context.Presenters.GetById(id);

            if (includeChildren && dto != null)
            {
                dto.Contacts = this._contactService.GetContacts(EntityType.Presenter, id);
                dto.WebLinks = this._webLinkService.GetWebLinks(EntityType.Presenter, id);
                dto.Documents = this._documentService.GetDocuments(EntityType.Presenter, id);
            }

            return dto;
        }

        public async Task<PresenterDto> GetPresenterByIdAsync(int id, bool includeChildren = false)
        {
            var dto = await this.Context.Presenters.GetByIdAsync(id);

            if (includeChildren && dto != null)
            {
                dto.Contacts = this._contactService.GetContacts(EntityType.Presenter, id);
                dto.WebLinks = this._webLinkService.GetWebLinks(EntityType.Presenter, id);
                dto.Documents = this._documentService.GetDocuments(EntityType.Presenter, id);

                dto.GenreTypesDetail = await this.Context.Presenters.GetGenreTypesAsync(id);
            }

            return dto;
        }

        public async Task CreateAsync(PresenterDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                dto = await this.VerifyGeoCoordinates(dto);

                await this.Context.Presenters.CreateAsync(dto);
                await this._presenterGenreTypeService.SyncChildrenAsync(dto.PresenterId, dto.GenreTypesJson);

                this._contactService.SyncContacts(EntityType.Presenter, dto.PresenterId, dto.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.Presenter, dto.PresenterId, dto.WebLinks, user);

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.PresenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.Created,
                    Description = "Created",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Presenter, dto.PresenterId, ex);
            }
        }

        public async Task UpdateAsync(PresenterDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            dto = await this.VerifyGeoCoordinates(dto);

            var original = await this.GetPresenterByIdAsync(dto.PresenterId);

            var blobsToAdd = new List<IBlob>();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.Presenters.UpdateAsync(dto);
                await this._presenterGenreTypeService.SyncChildrenAsync(dto.PresenterId, dto.GenreTypesJson);

                this._contactService.SyncContacts(EntityType.Presenter, dto.PresenterId, dto.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.Presenter, dto.PresenterId, dto.WebLinks, user);
                this._documentService.SyncDocuments(EntityType.Presenter, dto.PresenterId, dto.Documents, user);

                await this.AuditUpdatedEntity(original, dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Presenter, dto.PresenterId, ex);
            }
        }

        public IList<PresenterSearchResultsDto> GetByCriteria(PresenterSearchCriteriaDto criteria)
        {
            return Context.Presenters.GetByCriteria(criteria);
        }

        public async Task<IList<PresenterSearchResultsDto>> GetByCriteriaAsync(PresenterSearchCriteriaDto criteria)
        {
            var results = await this.Context.Presenters.GetByCriteriaAsync(criteria);

            return results;
        }
        public async Task<IList<PresenterBulkTransferSearchResultsDto>> GetByPresenterBulkTransferCriteriaAsync(PresenterBulkTransferSearchCriteriaDto criteria)
        {
            var results = await this.Context.Presenters.GetByPresenterBulkTransferCriteriaAsync(criteria);

            return results;
        }

        public async Task<bool> ReassignPresenterAgentMultiAsync(ReassignPresenterAgentMultiList criteria, IPrincipal user)
        {
            var task = Task.Run(async () =>
            {
                foreach (var a in criteria.reassignPresentersAgent)
                {
                    await this.ReassignPresenterAgentAsync(a.PresenterId.Value, a.AgentId.Value, user);
                }
            });

            // Wait for the task to complete.
            task.Wait();

            return true;
        }
        public async Task<(string, string)> GetByCriteriaExportAsync(PresenterSearchCriteriaDto criteria)
        {
            var results = await this.Context.Presenters.GetByCriteriaExportAsync(criteria);

            return results;
        }

        public async Task<(bool, string, object)> ImportPresenter(Stream stream, IPrincipal user)
        {
            Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
            bool valid = false;
            string msg = string.Empty;
            DataSet dsResult = new DataSet();
            try
            {
                var dt = await DaoHelper.ImportExceltoDatatable("", "data", stream);

                if (dt != null && dt.Rows.Count > 0)
                {
                    if (dt.Rows.Count <= 20000)
                    {
                        dt.TableName = "presenter";
                        dt.AcceptChanges();
                        string xmlString = await DaoHelper.ConvertDatatableToXML(dt);
                        Dictionary<string, object> keyValuePairsParamsPass = new Dictionary<string, object>();
                        keyValuePairsParamsPass.Add("@xml", xmlString);
                        keyValuePairsParamsPass.Add("@appuserid", user.GetUserId());
                        dsResult = await DaoHelper.GetDataSetStoreProcedureWithDynamicParameters("Sp_Bulk_Import_Presenter", keyValuePairsParamsPass);

                        if (dsResult.Tables.Count > 1)
                        {
                            valid = false;
                            if (Convert.ToBoolean(dsResult.Tables[0].Rows[0][0]))
                            {
                                valid = true;
                                msg = "Bulk insert successful";
                            }
                            else
                            {
                                msg = "Something Went Wrong, Please Try Again";
                            }

                        }
                        else
                        {
                            valid = false;
                            msg = "Something Went Wrong, Please Try Again";
                        }

                    }
                    else
                    {
                        valid = false;
                        msg = "Limit Exceeded! Records more than 20000 are not allowed.";
                    }
                }
                else
                {
                    valid = false;
                    msg = "Record not found!";
                }

            }
            catch (Exception ex)
            {
                valid = false;
                msg = ex.Message;
            }
            return (valid, msg, dsResult);
        }

        public async Task LoadPresenterUsersAsync(int userId, int assignedAgentId)
        {
            if (_user == null)
            {
                _user = await this._userService.GetUserByIdAsync(userId, true);
            }

            if (_assignedAgent == null)
            {
                _assignedAgent = await this._userService.GetUserByIdAsync(assignedAgentId, true);
            }
        }

        public async Task<bool> CanCreateContractAsync(int userId, int assignedAgentId)
        {
            await LoadPresenterUsersAsync(userId, assignedAgentId);

            if (_user != null && _assignedAgent != null && _user.AppUserId == _assignedAgent.AppUserId)
            {
                return true;
            }

            var hasAssistantRole = _user.IsInRole(ECERole.Assistant);
            if (hasAssistantRole)
            {
                return _user.UsersAreInSameOffice(_assignedAgent);
            }

            return false;
        }

        public async Task<bool> CanEditAsync(int userId, int assignedAgentId)
        {
            await LoadPresenterUsersAsync(userId, assignedAgentId);

            if (_user != null && _assignedAgent != null && _user.AppUserId == _assignedAgent.AppUserId)
            {
                return true;
            }

            var hasOwnerRole = _user.IsInRole(ECERole.Owner);
            if (hasOwnerRole)
            {
                return true;
            }

            var hasLmdRole = _user.IsInRole(ECERole.LMD);
            if (hasLmdRole)
            {
                return _user.IsLmdForAgent(_assignedAgent);
            }

            var hasAssistantRole = _user.IsInRole(ECERole.Assistant);
            if (hasAssistantRole)
            {
                return _user.UsersAreInSameOffice(_assignedAgent);
            }

            return false;
        }

        public async Task TogglePresenterStatusAsync(int presenterId, bool isActive, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetPresenterByIdAsync(presenterId);

                await this.Context.Presenters.TogglePresenterStatusAsync(presenterId, isActive, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = presenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.StatusChanged,
                    Description = original.IsActive ? "Active" : "Inactive",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Presenter, presenterId, ex);
            }
        }

        public async Task ReassignPresenterAgentAsync(PresenterDto presenter, int agentId, DateTime endDate, IPrincipal user)
        {
            if (presenter == null)
            {
                throw new ArgumentNullException(nameof(presenter));
            }

            try
            {
                this.Context.BeginTransaction();

                await this.ReassignPresenterAgentAsync(presenter.PresenterId, agentId, user);

                var dto = new AgentCommissionProgramDto();

                dto.CommissionProgramId = (int)CommissionProgram.PresenterTransfer;
                dto.ToAppUserId = presenter.AgentId;
                dto.FromEntityId = presenter.PresenterId;
                dto.FromEntityTypeId = (int)EntityType.Presenter;
                dto.StartDate = DateTime.Today;
                dto.EndDate = endDate.Date;
                dto.SplitPercentage = CommissionManagementService.PresenterTransferCommissionPercentage;

                dto.SetAsCreated(user);

                await this._commissionManagementService.AddPresenterTransferAsync(dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Presenter, presenter.PresenterId, ex);
            }
        }

        public async Task ReassignPresenterAgentAsync(int presenterId, int agentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetPresenterByIdAsync(presenterId);
                var originalAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = original.AgentId }, false);
                var newAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = agentId }, false);

                await this.Context.Presenters.ReassignPresenterAgentAsync(presenterId, agentId, user.GetUserId());

                var criteria = new VenueSearchCriteriaDto
                {
                    PresenterId = presenterId
                };

                var associatedVenues = await this.Context.Venues.GetVenueByCriteriaAsync(criteria);
                foreach (var associatedVenue in associatedVenues)
                {
                    await this.Context.Venues.ReassignVenueAgentAsync(associatedVenue.VenueId, agentId, user.GetUserId());
                }

                var history = new EntityHistoryDto
                {
                    EntityId = presenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.AgentChanged,
                    Description = $"{originalAgent.FirstName} {originalAgent.LastName}",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                if (originalAgent?.AppUserId > 0)
                {
                    // Send an alert to the original agent and the new responsible agent.
                    var reassignAppEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.PresenterReassignedAgent);

                    var presenterName = original.AccountName;
                    if (!string.IsNullOrWhiteSpace(original.OrganizationName))
                    {
                        presenterName = $"{presenterName}/{original.OrganizationName}";
                    }

                    var reassignAppEventText = reassignAppEvent?.Text ?? string.Empty;

                    var description = reassignAppEventText
                        .Replace("{PresenterName}", presenterName)
                        .Replace("{AgentName}", newAgent.FullName);

                    var originalAlert = new AlertDto
                    {
                        AppUserId = originalAgent.AppUserId.Value,
                        Description = description,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Presenter,
                        EntityId = presenterId,
                        AppEventTypeId = (int)AppEventType.PresenterAssigned
                    };

                    await this._alertService.CreateAsync(originalAlert, user);
                }

                // Send an alert to the new responsible agent.
                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.PresenterAssigned);
                var appEventText = appEvent.Text ?? string.Empty;
                var alert = new AlertDto
                {
                    AppUserId = agentId,
                    Description = appEventText,
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Presenter,
                    EntityId = presenterId,
                    AppEventTypeId = (int)AppEventType.PresenterAssigned
                };

                await this._alertService.CreateAsync(alert, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Presenter, presenterId, ex);
            }
        }

        public async Task ToggleArchiveStatusAsync(int presenterId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetPresenterByIdAsync(presenterId);
                DateTime? archiveDate = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;
                }

                await this.Context.Presenters.ToggleArchiveStatusAsync(presenterId, archiveDate, !isArchived, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = presenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task CreateSimilarPresenterAlertAsync(int id, IPrincipal user)
        {
            var appEvent = await _lookupService.GetAppEventTypeAsync(AppEventType.SimilarPresenterCreated);
            var agentLMD = await _userService.GetLMDByAgentAsync(user.GetUserId());
            var agent = await _userService.GetUserAsync(new AppUserDto { AppUserId = user.GetUserId() });

            var agentName = $"{agent.FirstName} {agent.LastName}";

            foreach (var lmd in agentLMD)
            {
                var alert = new AlertDto
                {
                    AppUserId = lmd.AppUserId.Value,
                    Description = appEvent.Text.Replace("{AgentName}", agentName),
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Presenter,
                    EntityId = id,
                    AppEventTypeId = (int)AppEventType.SimilarPresenterCreated
                };

                await this._alertService.CreateAsync(alert, user);
            }
        }

        public async Task CreateNotResponsibleAgentAlertContractAsync(int id, int presenterId, string agentName, IPrincipal user)
        {
            var presenter = await this.GetPresenterByIdAsync(presenterId, false);
            var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractNotAssignedPresenter);
            var presenterName = presenter.AccountName;
            if (!string.IsNullOrEmpty(presenter.OrganizationName))
            {
                presenterName = $"{presenterName} ({presenter.OrganizationName})";
            }

            var message = appEvent.Text;

            message = message.Replace("{PresenterName}", presenterName)
                .Replace("{AgentName}", agentName);

            var alert = new AlertDto
            {
                AppUserId = presenter.AgentId,
                Description = message,
                EntityId = id,
                EntityTypeId = (int)EntityType.Contract,
                AppEventTypeId = (int)AppEventType.ContractNotAssignedPresenter
            };

            await this._alertService.CreateAsync(alert, user);
        }

        public async Task CreateNotResponsibleAgentAlertBlueCardAsync(int id, int presenterId, string agentName, IPrincipal user)
        {
            var presenter = await this.GetPresenterByIdAsync(presenterId, false);
            var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.BlueCardNotAssignedPresenter);
            var presenterName = presenter.AccountName;
            if (!string.IsNullOrEmpty(presenter.OrganizationName))
            {
                presenterName = $"{presenterName} ({presenter.OrganizationName})";
            }

            var message = appEvent.Text;

            message = message.Replace("{PresenterName}", presenterName)
                .Replace("{AgentName}", agentName);

            var alert = new AlertDto
            {
                AppUserId = presenter.AgentId,
                Description = message,
                EntityId = id,
                EntityTypeId = (int)EntityType.BlueCard,
                AppEventTypeId = (int)AppEventType.ContractNotAssignedPresenter
            };

            await this._alertService.CreateAsync(alert, user);
        }

        public async Task<List<PresenterBookDateDto>> GetBookedDatesAsync(int id)
        {
            return await this.Context.Presenters.GetBookedDatesAsync(id);
        }

        public async Task<ICollection<GenreTypeDto>> GetGenreTypesByPresenterAsync(int id)
        {
            return await this.Context.Presenters.GetGenreTypesAsync(id);
        }

        private async Task AuditUpdatedEntity(PresenterDto original, PresenterDto updated, IPrincipal user)
        {
            // Audit Presenter Name change
            if (!string.Equals(updated.AccountName, original.AccountName, StringComparison.OrdinalIgnoreCase))
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.PresenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.PresenterNameChanged,
                    Description = original.AccountName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Organization Name change
            if (!string.Equals(updated.OrganizationName, original.OrganizationName ?? string.Empty, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.OrganizationName))
                {
                    original.OrganizationName = "Added Organization Name";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = updated.PresenterId,
                    Type = EntityType.Presenter,
                    Event = AuditEvent.PresenterOrgNameChanged,
                    Description = original.OrganizationName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }

        private async Task<PresenterDto> VerifyGeoCoordinates(PresenterDto presenter)
        {
            // Assumes Physical zip is present
            if (!presenter.PhysicalGeoLatitude.HasValue || !presenter.PhysicalGeoLongitude.HasValue)
            {
                var zipCoords = await this._lookupService.GetZipCodeGeographyAsync(presenter.PhysicalZip);

                if (zipCoords != null)
                {
                    presenter.PhysicalGeoLatitude = zipCoords.Latitude;
                    presenter.PhysicalGeoLongitude = zipCoords.Longitude;
                }
                else
                {
                    // Can't locate, set to default. this will drive BR to display messages
                    presenter.PhysicalGeoLatitude = decimal.Zero;
                    presenter.PhysicalGeoLongitude = decimal.Zero;
                }
            }

            return presenter;
        }
    }
}
