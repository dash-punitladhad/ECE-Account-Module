﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AppUserSettingService : IAppUserSettingService
    {
        public AppUserSettingService(
            IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<AppUserSettingDto>> GetAppUserSettingsAsync(int appUserId)
        {
            return await this.Context.AppUserSettings.GetAppUserSettingsAsync(appUserId);
        }

        public async Task SyncSettingsAsync(int appUserId, IEnumerable<AppUserSettingDto> updatedSettings, IPrincipal user)
        {
            var existingSettings = await this.Context.AppUserSettings.GetAppUserSettingsAsync(appUserId);
            var activeSettings = updatedSettings.Where(x => !x.IsDeleted);

            // Ensure all new settings have a unique identifier.
            var newSettings = updatedSettings.Where(x => x.AppUserSettingId <= 0).ToArray();
            for (int i = 0; i < newSettings.Length; i++)
            {
                newSettings[i].AppUserSettingId = 0 - i;
            }

            // Get a list of all the existing settings that still exist in the updated list.
            var settingsToKeep =
                from e in existingSettings
                join a in activeSettings on e.AppUserSettingId equals a.AppUserSettingId
                select e;

            // Update the existing settings not being removed.
            foreach (var settingToKeep in settingsToKeep)
            {
                var updates = activeSettings.First(x => x.AppUserSettingId == settingToKeep.AppUserSettingId);

                settingToKeep.AppUserSettingKeyId = updates.AppUserSettingKeyId;
                settingToKeep.Value = updates.Value;

                settingToKeep.SetAsUpdated(user);

                await this.Context.AppUserSettings.UpdateAsync(settingToKeep);
            }

            // Add new settings, if necessary.
            var settingsToAdd = activeSettings.Except(settingsToKeep, x => x.AppUserSettingId);

            foreach (var settingToAdd in settingsToAdd)
            {
                settingToAdd.AppUserSettingId = 0;
                settingToAdd.SetAsCreated(user);

                await this.Context.AppUserSettings.CreateAsync(settingToAdd);
            }

            // Remove existing settings, if necessary.
            var settingsToRemove = existingSettings.Except(settingsToKeep);

            foreach (var settingToRemove in settingsToRemove)
            {
                await this.Context.AppUserSettings.DeleteAsync(settingToRemove.AppUserSettingId, user.GetUserId());
            }
        }
    }
}
