﻿namespace ECE.CRM.BusinessServices
{
	using ECE.CRM.BusinessServices.Interfaces;
	using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.BlobStorage;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class VenueService : IVenueService
    {
        private readonly IContactService _contactService;
        private readonly IWebLinkService _webLinkService;
        private readonly IDocumentService _documentService;
        private readonly IUserService _userService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ILookupService _lookupService;
        private readonly IVenueDescriptionService _venueDescriptionService;
        private readonly IVenueActTypeService _venueActTypeService;
        private readonly IGenreTypeService<VenueGenreTypeDto> _venueGenreTypeService;
        private readonly IAlertService _alertService;
        private readonly IVenueRequirementService _venueRequirementService;

        public VenueService(IUnitOfWork context,
                            IContactService contactService,
                            IWebLinkService webLinkService,
                            IDocumentService documentService,
                            IUserService userService,
                            IEntityHistoryService entityHistoryService,
                            ILookupService lookupService,
                            IVenueDescriptionService venueDescriptionService,
                            IVenueActTypeService venueActTypeService,
                            IGenreTypeService<VenueGenreTypeDto> venueGenreTypeService,
                            IAlertService alertService,
                            IVenueRequirementService venueRequirementService
                            )
        {
            this.Context = context;

            this._contactService = contactService;
            this._webLinkService = webLinkService;
            this._documentService = documentService;
            this._userService = userService;
            this._entityHistoryService = entityHistoryService;
            this._lookupService = lookupService;
            this._venueDescriptionService = venueDescriptionService;
            this._venueActTypeService = venueActTypeService;
            this._venueGenreTypeService = venueGenreTypeService;
            this._alertService = alertService;
            this._venueRequirementService = venueRequirementService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<VenueDto>> GetVenuesByCharsAsync(string chars)
        {
            var dto = await this.Context.Venues.GetVenuesByCharsAsync(chars);

            return dto;
        }

        public VenueDto GetVenueById(int id, bool includeChildren = false)
        {
            var dto = this.Context.Venues.GetById(id);

            if (includeChildren && dto != null)
            {
                dto.Contacts = this._contactService.GetContacts(EntityType.Venue, id);
                dto.WebLinks = this._webLinkService.GetWebLinks(EntityType.Venue, id);
                dto.Documents = this._documentService.GetDocuments(EntityType.Venue, id);
            }

            return dto;
        }

        public async Task<VenueDto> GetVenueByIdAsync(int id, bool includeChildren = false)
        {
            var dto = await this.Context.Venues.GetByIdAsync(id);

            if (includeChildren && dto != null)
            {
                dto.Contacts = this._contactService.GetContacts(EntityType.Venue, id);
                dto.WebLinks = this._webLinkService.GetWebLinks(EntityType.Venue, id);
                dto.Documents = this._documentService.GetDocuments(EntityType.Venue, id);
            }

            return dto;
        }

        public async Task<bool> CanEditAsync(int userId)
        {
            var user = await this._userService.GetUserAsync(new AppUserDto { AppUserId = userId }, true);

            var hasOwnerRole = user.Roles.Any(x => x.RoleId == (int)ECERole.Owner);

            if (hasOwnerRole)
            {
                return true;
            }

            var lmdRoles = user.Roles.Where(x => x.RoleId == (int)ECERole.LMD).ToList();

            if (lmdRoles.Any())
            {
                return true;
            }

            var hasAgentRole = user.Roles.Any(x => x.RoleId == (int)ECERole.Agent);

            if (hasAgentRole)
            {
                return true;
            }

            return false;
        }

        public async Task<int> CreateAsync(VenueDto venue, IPrincipal user)
        {
            if (venue == null)
            {
                throw new ArgumentNullException(nameof(venue));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                venue.SetAsCreated(user);

                venue = await this.VerifyGeoCoordinatesAsync(venue);
                if (venue.PresenterId.HasValue)
                {
                    var presenter = await this.Context.Presenters.GetByIdAsync(venue.PresenterId.Value);
                    if (presenter == null)
                    {
                        throw new Exception($"Presenter {venue.PresenterId} not found.");
                    }

                    // The venue assumes the same assigned agent as it's parent presenter
                    venue.AgentId = presenter.AgentId;
                }

                var newVenueId = await this.Context.Venues.CreateAsync(venue);
                await this._venueGenreTypeService.SyncChildrenAsync(newVenueId, venue.GenreTypesJson);
                await this._venueActTypeService.SyncVenueActTypes(newVenueId, venue.ActTypesJson);
                await this._venueRequirementService.AddVenueRequirement(newVenueId, venue.VenueRequirements.ToList(), user);
                this._contactService.SyncContacts(EntityType.Venue, newVenueId, venue.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.Venue, newVenueId, venue.WebLinks, user);
               
                var venueTypeIds = venue.VenueTypesJson;
                if (venueTypeIds != null)
                {
                    foreach (string s in venueTypeIds)
                    {
                        int newVenueTypeId;
                        var value = int.TryParse(s, out newVenueTypeId);

                        var venueType = new VenueDescriptionDto();
                        venueType.VenueId = newVenueId;
                        venueType.VenueTypeId = newVenueTypeId;

                        await this.Context.VenueDescriptions.CreateAsync(venueType);
                    }
                }

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = newVenueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.Created,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = venue.CreatedById
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                // create an alert for the LMD of the current agent user when a similar venue has been created
                if (venue.SimilarVenueCreated)
                {
                    await CreateSimilarVenueAlertAsync(newVenueId, user);
                }

                this.Context.Commit();
                return newVenueId;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Venue, venue.VenueId, ex);
            }
        }

        public async Task UpdateAsync(VenueDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            dto = await this.VerifyGeoCoordinatesAsync(dto);

            var original = await this.GetVenueByIdAsync(dto.VenueId);

            var blobsToAdd = new List<IBlob>();

            try
            {
                dto.SetAsUpdated(user);

                var actTypes = dto.ActTypesJson;
                var venueTypes = dto.VenueTypesJson;
                var genreTypes = dto.GenreTypesJson;

                await this._venueDescriptionService.SyncVenueDescriptionsAsync(dto.VenueId, venueTypes);

                await this._venueActTypeService.SyncVenueActTypes(dto.VenueId, actTypes);

                await this._venueGenreTypeService.SyncChildrenAsync(dto.VenueId, genreTypes);

                await this.Context.Venues.UpdateAsync(dto);
                
                await this._venueRequirementService.AddVenueRequirement(dto.VenueId,dto.VenueRequirements.ToList(),user);

                if (dto.PresenterId.HasValue && original.PresenterId != dto.PresenterId)
                {
                    var presenter = await this.Context.Presenters.GetByIdAsync(dto.PresenterId.Value);
                    if (presenter == null)
                    {
                        throw new Exception($"Presenter {dto.PresenterId} not found.");
                    }

                    // The venue assumes the same assigned agent as it's parent presenter
                    await this.ReassignVenueAgentAsync(dto.VenueId, presenter.AgentId, user);
                }

                this._contactService.SyncContacts(EntityType.Venue, dto.VenueId, dto.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.Venue, dto.VenueId, dto.WebLinks, user);
                this._documentService.SyncDocuments(EntityType.Venue, dto.VenueId, dto.Documents, user);

                await this.AuditUpdatedEntityAsync(original, dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Venue, dto.VenueId, ex);
            }
        }

        public async Task CreateSimilarVenueAlertAsync(int id, IPrincipal user)
        {
            var appEvent = await _lookupService.GetAppEventTypeAsync(AppEventType.SimilarVenueCreated);
            var agentLMD = await _userService.GetLMDByAgentAsync(user.GetUserId());
            var agent = await _userService.GetUserAsync(new AppUserDto { AppUserId = user.GetUserId() });

            var agentName = $"{agent.FirstName} {agent.LastName}";

            foreach (var lmd in agentLMD)
            {
                var alert = new AlertDto
                {
                    AppUserId = lmd.AppUserId.Value,
                    Description = appEvent.Text.Replace("{AgentName}", agentName),
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Venue,
                    EntityId = id,
                    AppEventTypeId = (int)AppEventType.SimilarVenueCreated
                };

                await this._alertService.CreateAsync(alert, user);
            }
        }

        public async Task<IList<VenueSearchResultDto>> GetVenueByCriteriaAsync(VenueSearchCriteriaDto criteria)
        {
            return await Context.Venues.GetVenueByCriteriaAsync(criteria);
        }
        public async Task<(string, string)> GetVenueByCriteriaExportAsync(VenueSearchCriteriaDto criteria)
        {
            return await Context.Venues.GetVenueByCriteriaExportAsync(criteria);
        }

        public async Task<List<VenueDescriptionDto>> GetVenueTypesByVenueAsync(int id)
        {
            return await this.Context.VenueDescriptions.GetVenueTypesByVenueAsync(id);
        }

        public async Task<List<VenueActTypeDto>> GetVenueActTypesByVenueAsync(int id)
        {
            return await this.Context.VenueActTypes.GetVenueActTypesByVenueAsync(id);
        }

        public async Task ToggleVenueStatusAsync(int venueId, bool isActive, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetVenueByIdAsync(venueId);

                await this.Context.Venues.ToggleVenueStatusAsync(venueId, isActive, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = venueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.StatusChanged,
                    Description = original.IsActive ? "Active" : "Inactive",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Venue, venueId, ex);
            }
        }

        public async Task ReassignVenueAgentAsync(int venueId, int agentId, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetVenueByIdAsync(venueId);
                var originalAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = original.AgentId }, false);

                await this.Context.Venues.ReassignVenueAgentAsync(venueId, agentId, user.GetUserId());

                var originalName = $"--";
                if (originalAgent != null)
                {
                    originalName = $"{originalAgent.FirstName} {originalAgent.LastName}";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = venueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.AgentChanged,
                    Description = originalName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.VenueAssigned);

                // Create alert
                AlertDto alert = new AlertDto
                {
                    AppUserId = agentId,
                    Description = appEvent.Text,
                    IsRead = false,
                    EntityTypeId = (int)EntityType.Venue,
                    EntityId = venueId,
                    AppEventTypeId = (int)AppEventType.VenueAssigned
                };

                await this._alertService.CreateAsync(alert, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Venue, venueId, ex);
            }
        }

        public async Task ToggleArchiveStatusAsync(int venueId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetVenueByIdAsync(venueId);
                DateTime? archiveDate = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;
                }

                await this.Context.Venues.ToggleArchiveStatusAsync(venueId, archiveDate, !isArchived, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = venueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<List<VenueBookDateDto>> GetBookedDatesAsync(int venueId)
        {
            return await this.Context.Venues.GetBookedDatesAsync(venueId);
        }

        public async Task<ICollection<VenueGenreTypeDto>> GetVenueGenreTypesByVenueAsync(int id)
        {
            return await this.Context.Venues.GetGenreTypes(id);
        }

        private async Task AuditUpdatedEntityAsync(VenueDto original, VenueDto updated, IPrincipal user)
        {
            // Audit Venue Name change
            if (!string.Equals(updated.Name, original.Name, StringComparison.OrdinalIgnoreCase))
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.VenueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.VenueNameChanged,
                    Description = original.Name,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Presenter Name change
            if (updated.PresenterId != original.PresenterId)
            {
                var history = new EntityHistoryDto
                {
                    EntityId = updated.VenueId,
                    Type = EntityType.Venue,
                    Event = AuditEvent.VenuePresenterChanged,
                    Description = original.PresenterName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }

        private async Task<VenueDto> VerifyGeoCoordinatesAsync(VenueDto venue)
        {
            // Assumes Physical zip is present
            if (!venue.PhysicalGeoLatitude.HasValue || !venue.PhysicalGeoLongitude.HasValue)
            {
                var zipCoords = await this._lookupService.GetZipCodeGeographyAsync(venue.PhysicalZip);

                if (zipCoords != null)
                {
                    venue.PhysicalGeoLatitude = zipCoords.Latitude;
                    venue.PhysicalGeoLongitude = zipCoords.Longitude;
                }
                else
                {
                    // Can't locate, set to default. this will drive BR to display messages
                    venue.PhysicalGeoLatitude = decimal.Zero;
                    venue.PhysicalGeoLongitude = decimal.Zero;
                }
            }

            return venue;
        }

        public async Task<(bool, string, object)> ImportVenue(Stream stream, IPrincipal user)
        {
            Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
            bool valid = false;
            string msg = string.Empty;
            DataSet dsResult = new DataSet();
            try
            {
                var dt = await DaoHelper.ImportExceltoDatatable("", "data", stream);

                if (dt != null && dt.Rows.Count > 0)
                {
                    if (dt.Rows.Count <= 20000)
                    {
                        dt.TableName = "venue";
                        dt.AcceptChanges();
                        string xmlString = await DaoHelper.ConvertDatatableToXML(dt);
                        Dictionary<string, object> keyValuePairsParamsPass = new Dictionary<string, object>();
                        keyValuePairsParamsPass.Add("@xml", xmlString);
                        keyValuePairsParamsPass.Add("@appuserid", user.GetUserId());
                        dsResult = await DaoHelper.GetDataSetStoreProcedureWithDynamicParameters("Sp_Bulk_Import_Venue", keyValuePairsParamsPass);

                        if (dsResult.Tables.Count > 1)
                        {
                            valid = false;
                            if (Convert.ToBoolean(dsResult.Tables[0].Rows[0][0]))
                            {
                                valid = true;
                                msg = "Bulk insert successful";
                            }
                            else
                            {
                                msg = "Something Went Wrong, Please Try Again";
                            }

                        }
                        else
                        {
                            valid = false;
                            msg = "Something Went Wrong, Please Try Again";
                        }

                    }
                    else
                    {
                        valid = false;
                        msg = "Limit Exceeded! Records more than 20000 are not allowed.";
                    }
                }
                else
                {
                    valid = false;
                    msg = "Record not found!";
                }

            }
            catch (Exception ex)
            {
                valid = false;
                msg = ex.Message;
            }
            return (valid, msg, dsResult);
        }

        public async Task<int> AddVenueRequirement(int venueId, List<VenueRequirementDto> venueRequirements, IPrincipal user)
        {
            if (venueId <= 0)
            {
                throw new ArgumentNullException("VenueId must be greater than zero.");
            }
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            foreach (var req in venueRequirements)
            {
                req.VenueId = venueId;
                req.CreatedBy = user.GetUserId();
                req.CreatedOn = DateTime.Now;
                req.IsActive = true;
            }
            return await this.Context.venueRequirementDao.AddVenueRequirements(venueRequirements);
        }

		public async Task<List<VenueApprovalDto>> GetNotApprovedContracts(int agentId)
		{
            return await this.Context.Venues.GetNotApprovedContracts(agentId);
		}

        public async Task<bool> ApproveContractVenue(VenueApprovalDto venueApprovalDto)
		{
            return await this.Context.Venues.ApproveContractVenue(venueApprovalDto);
		}
    }
}
