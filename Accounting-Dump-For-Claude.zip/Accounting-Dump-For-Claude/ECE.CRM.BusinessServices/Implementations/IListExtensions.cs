﻿namespace ECE.CRM.BusinessServices
{
    using System.Collections.Generic;

    public static class IListExtensions
    {
        public static void AddIfNotContains<T>(this IList<T> list, T item)
        {
            if (list == null)
            {
                return;
            }

            if (!list.Contains(item))
            {
                list.Add(item);
            }
        }
    }
}
