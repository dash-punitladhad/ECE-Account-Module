﻿namespace ECE.CRM.BusinessServices.Implementations
{
    using Dapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using Utilities;

    public class ContractWizardService : IContractWizardService
    {
        private readonly IAgentCommissionProgramService _agentCommissionProgramService;
        private readonly IBlueCardService _blueCardService;
        private readonly IContactService _contactService;
        private readonly IContractArtistEventDateService _contractArtistEventDateService;
        private readonly IContractEventDateService _contractEventDateService;
        private readonly IContractService _contractService;
        private readonly IContractTermService _contractTermService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IPresenterService _presenterService;
        private readonly ILookupService _lookupService;
        private readonly IContractArtistService _contractArtistService;
        private readonly IContractArtistAgreementService _contractArtistAgreementService;
        private readonly IContractDocumentService _contractDocumentService;
        private readonly IContractSignatureService _contractSignatureService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IEceCrmEntities _eceCrmEntities;

        public ContractWizardService(
            IUnitOfWork context,
            IContractService contractService,
            IBlueCardService blueCardService,
            IPresenterService presenterService,
            IContractEventDateService contractEventDateService,
            IContractTransactionService contractTransactionService,
            IContactService contactService,
            ILookupService lookupService,
            IContractArtistService contractArtistService,
            IContractArtistAgreementService contractArtistAgreementService,
            IContractDocumentService contractDocumentService,
            IContractSignatureService contractSignatureService,
            IContractArtistEventDateService contractArtistEventDateService,
            IContractTermService contractTermService,
            IAgentCommissionProgramService agentCommissionProgramService,
            IEntityHistoryService entityHistoryService,
            IEceCrmEntities eceCrmEntities,
            ILogger logger = null)
        {
            Context = context;
            _contractService = contractService;
            _blueCardService = blueCardService;
            _presenterService = presenterService;
            _contractEventDateService = contractEventDateService;
            _contractTransactionService = contractTransactionService;
            _contactService = contactService;
            _lookupService = lookupService;
            _contractArtistService = contractArtistService;
            _contractArtistAgreementService = contractArtistAgreementService;
            _contractDocumentService = contractDocumentService;
            _contractSignatureService = contractSignatureService;
            _contractArtistEventDateService = contractArtistEventDateService;
            _contractTermService = contractTermService;
            _agentCommissionProgramService = agentCommissionProgramService;
            _entityHistoryService = entityHistoryService;
            _eceCrmEntities = eceCrmEntities;
            Logger = logger;
        }

        public IUnitOfWork Context { get; }

        public ILogger Logger { get; }

        public bool ContractHasMoneyReceivedOrReleased(IList<ContractTransactionDto> transactions)
        {
            decimal? amountReceived = transactions.Where(x => x.IsIncome).Select(x => x.PaidAmount).DefaultIfEmpty().Sum();
            decimal? amountReleased = transactions.Where(x => x.IsExpense).Select(x => x.PaidAmount).DefaultIfEmpty().Sum();
            if (amountReceived != decimal.Zero || amountReleased != decimal.Zero)
            {
                return true;
            }

            return false;
        }

        public bool CanMoneyStepEdit(bool HasMoneyTxnOrOriginalGross,ContractDto contract,IPrincipal user)
        {
            if (user != null && (user.IsInRole(ECERole.SysAdmin) || user.IsInRole(ECERole.Accounting) || user.IsInRole(ECERole.AccountingAdmin) || user.IsInRole(ECERole.Assistant)))
            {
                return false;
            }
            var isSigntureRecieved = contract.PresenterSigned || contract.ArtistSigned;
            if (HasMoneyTxnOrOriginalGross || isSigntureRecieved)
            {
                return true;
            }


            return false;
        }

        public async Task<ContractDto> CreateContractAsync(int entityId, EntityType entityType, IPrincipal principal)
        {
            ContractDto contract = new ContractDto();

            switch (entityType)
            {
                case EntityType.Presenter:
                    ContractDto dto1 = await _contractService.CreateFromPresenterAsync(entityId, principal);
                    contract = dto1;
                    break;
                case EntityType.BlueCard:
                    ContractDto dto2 = await _contractService.CreateFromBlueCardAsync(entityId, principal);
                    contract = dto2;
                    break;
                case EntityType.Contract:
                    contract.IsInProgress = true;
                    contract.ContractStatusId = (int)ContractStatus.InProgress;
                    contract.AgentId = principal.GetUserId();
                    await _contractService.CreateAsync(contract, principal);
                    break;
            }

            return contract;
        }

        public async Task SaveContractEventInfoAsync(ContractDto dto, IList<ContractEventDateDto> contractEventDates, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (contractEventDates == null)
            {
                throw new ArgumentNullException(nameof(contractEventDates));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            Context.BeginTransaction();
            try
            {
                // Since this step does not include any venue or presenter information
                // we need to get that from the original record. The alternative to
                // this would be to include all the venue/presenter info on the Step 1
                // viewmodel and store them in hidden fields on the web page.
                ContractDto contract = await _contractService.GetByIdAsync(dto.ContractId, false);

                var oldContractType = contract.ContractTypeId;
                var oldLOB = contract.LineOfBusinessId;

                var oldIsBuySell = contract.IsBuySell ?? contract.IsBuySell;
                TimeZoneDto existingContractZone = _lookupService.GetAllTimeZones().FirstOrDefault(x => x.TimezoneId == dto.TimezoneId);

                if (contract.ContractTypeId != dto.ContractTypeId)
                {
                    IList<ContractTransactionDto> oldContractTransactions =
                        await _contractTransactionService.GetByContractIdAsync(contract.ContractId);

                    foreach (ContractTransactionDto oct in oldContractTransactions)
                    {
                        // Only remove unpaid transactions.
                        if (oct.PaidAmount == decimal.Zero)
                        {
                            oct.ParentContract = contract;
                            await _contractService.DeleteTransactionAsync(oct, true, user);
                        }
                    }

                    IEnumerable<ContractEventDateDto> oldContractEventDates =
                        await _contractEventDateService.GetByContractIdAsync(contract.ContractId);

                    foreach (ContractEventDateDto oced in oldContractEventDates)
                    {
                        IList<ContractArtistEventDateDto> oldContractArtistEventDates =
                            await _contractArtistEventDateService.GetByContractEventDateIdAsync(
                                oced.ContractEventDateId);

                        foreach (ContractArtistEventDateDto ocaed in oldContractArtistEventDates)
                        {
                            await _contractArtistEventDateService.DeleteAsync(ocaed.ContractArtistEventDateId);
                        }
                    }

                    IList<ContractArtistDto> oldContractArtists = await _contractArtistService.GetByContractIdAsync(contract.ContractId);

                    foreach (ContractArtistDto oca in oldContractArtists)
                    {
                        await _contractArtistService.DeleteAsync(oca.ContractArtistId);
                    }

                    IList<ContractTermDto> oldContractTerms = await _contractTermService.GetByContractIdAsync(contract.ContractId);

                    foreach (ContractTermDto oct in oldContractTerms)
                    {
                        await _contractTermService.DeleteAsync(oct.ContractTermId);
                    }

                    IList<ContractDocumentDto> oldContractDocuments =
                        await _contractDocumentService.GetByContractIdAsync(contract.ContractId);

                    foreach (ContractDocumentDto ocd in oldContractDocuments)
                    {
                        await _contractDocumentService.DeleteAsync(ocd);
                    }

                    contract.Gross = null;
                    contract.EceCommissionRate = null;
                    contract.IsCommissionPercentage = null;
                    contract.CommissionProgramAgentId = null;
                    contract.CommissionProgramId = null;
                }

                contract.AgentId = dto.AgentId;
                contract.OfficeId = dto.OfficeId;
                contract.ContractStatusId = dto.ContractStatusId;
                contract.LineOfBusinessId = dto.LineOfBusinessId;
                contract.LeadSourceId = dto.LeadSourceId;
                contract.ContractTypeId = dto.ContractTypeId;
                contract.IsReseller = dto.IsReseller;
                contract.ResellerId = dto.ResellerId;
                contract.ContractDueDate = dto.ContractDueDate;
                contract.ContractDueFromId = dto.ContractDueFromId;
                contract.IsNoIssue = dto.IsNoIssue;
                contract.IsSubstitute = dto.IsSubstitute;
                contract.EventTypeId = dto.EventTypeId;
                contract.TimezoneId = dto.TimezoneId;
                contract.IsPublicEvent = dto.IsPublicEvent;
                contract.IsBuySell = dto.IsBuySell;
                contract.IsBackendDeal = dto.IsBackendDeal;
                contract.BackendDescription = dto.BackendDescription;
                contract.EventDescription = dto.EventDescription;
                contract.IsWillAgentAttendTheEvent = dto.IsWillAgentAttendTheEvent;
                contract.IsPandaDoc = dto.IsPandaDoc;
                if (contract.IsReseller == false && contract.ResellerId <= 0)
                {
                    contract.ResellerId = null;
                }


                await _contractService.UpdateAsync(contract, user);

                if((oldContractType != null && oldContractType != dto.ContractTypeId) || (oldLOB != null && oldLOB != dto.LineOfBusinessId))
                {
                    await _contractService.UpdateContractTermsCondition(contract);
                }

                if (contractEventDates.Any())
                {
                    TimeZoneDto updatedContractZone = _lookupService.GetAllTimeZones().FirstOrDefault(x => x.TimezoneId == contract.TimezoneId);
                    TimeZoneInfo updatedTimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(updatedContractZone.LookupName);

                    bool changeFound = false;

                    IEnumerable<ContractEventDateDto> eventDates = await _contractEventDateService.GetByContractIdAsync(dto.ContractId);
                    TimeSpan? delta = _contractEventDateService.SingleEventDateChangeDelta(eventDates, contractEventDates);

                    // The delta is the relative change in the event date
                    if (delta.HasValue && delta.Value.Days != 0D)
                    {
                        changeFound = true;
                        await _contractTransactionService.ShiftArtistPaymentDueDatesAsync(dto.ContractId, delta.Value, user);
                    }

                    List<ContractEventDateDto> updatedEventDates = new List<ContractEventDateDto>();
                    List<ContractEventDateDto> newEventDates = new List<ContractEventDateDto>();
                    List<ContractEventDateDto> removeEventDates = new List<ContractEventDateDto>();

                    // Separate the new EventDates from the Existing
                    foreach (ContractEventDateDto eventDate in contractEventDates)
                    {
                        if (eventDate.ContractEventDateId > 0)
                        {
                            updatedEventDates.Add(eventDate);
                        }
                        else
                        {
                            newEventDates.Add(eventDate);
                        }
                    }

                    // Get the existing event dates that will be deleted.
                    foreach (ContractEventDateDto eed in updatedEventDates)
                    {
                        if (eed.IsDeleted)
                        {
                            removeEventDates.Add(eed);
                        }
                    }

                    // Update Existing Dates
                    if (updatedEventDates.Any() && existingContractZone != null)
                    {
                        TimeZoneInfo existingTimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(existingContractZone.LookupName);
                        if (await UpdateExistingEventDatesAsync(
                            eventDates,
                            existingTimeZoneInfo,
                            updatedEventDates,
                            updatedTimeZoneInfo))
                        {
                            changeFound = true;
                        }
                    }

                    // Create new Dates
                    if (newEventDates.Any())
                    {
                        changeFound = true;
                        foreach (ContractEventDateDto ned in newEventDates)
                        {
                            if (!ned.IsDeleted)
                            {
                                await _contractEventDateService.CreateAsync(ned);
                            }
                        }
                    }

                    // Delete existing Dates
                    if (removeEventDates.Any())
                    {
                        changeFound = true;
                        foreach (ContractEventDateDto red in removeEventDates)
                        {
                            IList<ContractArtistEventDateDto> results = await _contractArtistEventDateService.GetByContractEventDateIdAsync(red.ContractEventDateId);

                            if (results.Any())
                            {
                                foreach (ContractArtistEventDateDto r in results)
                                {
                                    await _contractArtistEventDateService.DeleteAsync(r.ContractArtistEventDateId);
                                }
                            }

                            await _contractEventDateService.DeleteAsync(red);
                        }
                    }

                    if (changeFound && dto.IssueDate.HasValue)
                    {
                        // Audit contract event
                        EntityHistoryDto history = new EntityHistoryDto
                        {
                            EntityId = dto.ContractId,
                            Type = EntityType.Contract,
                            Event = AuditEvent.ContractEventDateChanged,
                            Description = "--",
                            CreatedDate = DateTime.Now,
                            CreatedById = user.GetUserId()
                        };

                        await _entityHistoryService.CreateEntityHistoryAsync(history);
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public Tuple<string, string> GetEventTimes(TimeZoneInfo timeZoneInfo, DateTime? eventDate, TimeSpan? startTime, TimeSpan? endTime, int contractId)
        {
            if (eventDate == null || startTime == null)
            {
                return null;
            }
            string sql = string.Format(" select top 1 * from Contract with(nolock) where Contractid={0} ", contractId.ToString());

            DataTable dt = DaoHelper.GetDataSet(sql).GetAwaiter().GetResult();

            string value = DaoHelper.GetConfigurationValue("BypassDaylightLogic").GetAwaiter().GetResult();

            DateTime contractDate = DateTime.Now.AddYears(-10);
            if (dt != null && dt.Rows.Count > 0)
            {
                contractDate = Convert.ToDateTime(dt.Rows[0]["CreatedDate"]);
            }
            DateTime dateTime = contractDate.AddDays(10);
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    dateTime = Convert.ToDateTime(value);
                }
            }
            catch { }

            //If Part:Timezoneinfo decodetime convert is not set and does include direct database values.
            //Else Part:Timezoneinfo decodetime convert is set.
            if (contractDate.Date >= dateTime.Date)
            {

                //var eventStartTime = timeZoneInfo.DecodeTime(eventDate.Value, startTime.Value).Value;

                //var endDateTime = eventDate.Value.Add(endTime.Value);

                //var eventEndTime = timeZoneInfo.DecodeTime(endDateTime, endTime.Value).Value;

                return new Tuple<string, string>(Convert.ToDateTime(startTime.Value).ToString("HH:mm"), Convert.ToDateTime(endTime).ToString("HH:mm"));

            }
            else
            {

                DateTime eventStartTime = timeZoneInfo.DecodeTime(eventDate.Value, startTime.Value).Value;

                DateTime endDateTime = eventDate.Value.Add(endTime.Value);

                DateTime eventEndTime = timeZoneInfo.DecodeTime(endDateTime, endTime.Value).Value;

                return new Tuple<string, string>(eventStartTime.ToString("HH:mm"), eventEndTime.ToString("HH:mm"));
            }


        }

        public void DecodeEventTimes(TimeZoneInfo timeZoneInfo, ArtistEventTimeDto aed, int contractId)
        {
            Tuple<string, string> existingTimes = GetEventTimes(timeZoneInfo, DateTime.Parse(aed.EventDate), aed.EndcodedStartTime, aed.EncodedEndTime, contractId);

            aed.StartTime = existingTimes.Item1;
            aed.EndTime = existingTimes.Item2;
        }

        public void EncodeEventTimes(TimeZoneInfo timeZoneInfo, ArtistEventTimeDto aed, int contractId)
        {
            timeZoneInfo.EncodeEventTimes(aed, contractId);
        }

        public async Task<bool> UpdateExistingEventDatesAsync(
            IEnumerable<ContractEventDateDto> existingEventDates,
            TimeZoneInfo existingTimeZoneInfo,
            IEnumerable<ContractEventDateDto> updatedEventDates,
            TimeZoneInfo updatedTimeZoneInfo)
        {
            bool changeFound = false;
            bool timeChange = false;

            foreach (ContractEventDateDto ued in updatedEventDates)
            {
                if (!ued.IsDeleted)
                {
                    ContractEventDateDto existing = existingEventDates.FirstOrDefault(x => x.ContractEventDateId == ued.ContractEventDateId);
                    if (existing != null && (existing.EventDate != ued.EventDate || existingTimeZoneInfo.Id != updatedTimeZoneInfo.Id))
                    {
                        changeFound = true;

                        timeChange = existingTimeZoneInfo.Id != updatedTimeZoneInfo.Id;

                        if (updatedTimeZoneInfo.IsDaylightSavingTime(existing.EventDate) !=
                            updatedTimeZoneInfo.IsDaylightSavingTime(ued.EventDate))
                        {
                            timeChange = true;
                        }
                    }

                    await this._contractEventDateService.UpdateAsync(ued);
                    if (timeChange && existing != null)
                    {
                        IList<ContractArtistEventDateDto> results = await _contractArtistEventDateService.GetByContractEventDateIdAsync(ued.ContractEventDateId);
                        foreach (ContractArtistEventDateDto r in results)
                        {
                            ArtistEventTimeDto updatedTimes = new ArtistEventTimeDto
                            {
                                EventDate = $"{existing.EventDate:MM/dd/yyyy}",
                                EndcodedStartTime = r.EventStartTimeSpan.Value,
                                EncodedEndTime = r.EventEndTimeSpan.Value
                            };

                            DecodeEventTimes(existingTimeZoneInfo, updatedTimes, ued.ContractId);

                            updatedTimes.EventDate = $"{ued.EventDate:MM/dd/yyyy}";

                            EncodeEventTimes(updatedTimeZoneInfo, updatedTimes, ued.ContractId);

                            r.EventStartTimeSpan = updatedTimes.EndcodedStartTime;
                            r.EventEndTimeSpan = updatedTimes.EncodedEndTime;

                            await _contractArtistEventDateService.UpdateAsync(r);
                        }
                    }
                }
            }

            return changeFound;
        }

        public async Task SaveContractPresenterAsync(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            Context.BeginTransaction();

            try
            {
                ContractDto contract = await _contractService.GetByIdAsync(dto.ContractId, false);

                contract.PresenterId = dto.PresenterId;
                contract.PresenterAccountName = dto.PresenterAccountName;
                contract.PresenterOrganizationName = dto.PresenterOrganizationName;
                contract.PresenterMailingAddress1 = dto.PresenterMailingAddress1;
                contract.PresenterMailingAddress2 = dto.PresenterMailingAddress2;
                contract.PresenterMailingCity = dto.PresenterMailingCity;
                contract.PresenterMailingStateId = dto.PresenterMailingStateId;
                contract.PresenterMailingZip = dto.PresenterMailingZip;
                contract.PresenterMailingCountryId = dto.PresenterMailingCountryId;
                contract.PresenterTypeId = dto.PresenterTypeId;

                await _contractService.UpdateAsync(contract, user);

                if (dto.Contacts.Any())
                {
                    _contactService.SyncContacts(EntityType.Contract, dto.ContractId, dto.Contacts, user);
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractVenueAsync(ContractDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            Context.BeginTransaction();

            try
            {
                // get the original contract to fill in some missing data.
                ContractDto contract = await _contractService.GetByIdAsync(dto.ContractId, false);

                bool includeNewRiders = dto.VenueId > 0 && contract.VenueId != dto.VenueId;

                dto = await VerifyGeoCoordinates(dto);
                contract.VenueId = dto.VenueId;
                contract.VenueName = dto.VenueName;
                contract.VenuePhysicalAddress1 = dto.VenuePhysicalAddress1;
                contract.VenuePhysicalAddress2 = dto.VenuePhysicalAddress2;
                contract.VenuePhysicalCity = dto.VenuePhysicalCity;
                contract.VenuePhysicalStateId = dto.VenuePhysicalStateId;
                contract.VenuePhysicalZip = dto.VenuePhysicalZip;
                contract.VenuePhysicalCountryId = dto.VenuePhysicalCountryId;
                contract.VenueCapacity = dto.VenueCapacity;
                contract.VenueSettingId = dto.VenueSettingId;
                contract.IsSettingCovered = dto.IsSettingCovered;
                contract.VenueContactName = dto.VenueContactName;
                contract.VenueContactTitle = dto.VenueContactTitle;
                contract.VenueContactEmail = dto.VenueContactEmail;
                contract.VenueContactPhone = dto.VenueContactPhone;
                contract.VenueContactFax = dto.VenueContactFax;
                contract.VenueGeoLatitude = dto.VenueGeoLatitude;
                contract.VenueGeoLongitude = dto.VenueGeoLongitude;

                await _contractService.UpdateAsync(contract, user);

                if (includeNewRiders)
                {
                    IList<ContractDocumentDto> availableRiders = await _contractService.GetAvailableRidersForContractAsync(contract.ContractId);
                    IEnumerable<ContractDocumentDto> venueRiders = availableRiders.Where(x =>
                            x.OriginalEntityId == contract.VenueId &&
                            x.OriginalEntityTypeId == (int)EntityType.Venue);

                    IList<ContractDocumentDto> existing = await _contractDocumentService.GetByOriginalEntityIdAndEntityTypeIdAsync(contract.ContractId, contract.VenueId.Value, (int)EntityType.Venue);

                    IEnumerable<ContractDocumentDto> newRiders = venueRiders.Except(existing, (ContractDocumentDto d) =>
                    {
                        return d.DocumentId;
                    });

                    foreach (ContractDocumentDto newRider in newRiders)
                    {
                        await _contractDocumentService.CreateAsync(newRider, user);
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractStandardArtistAsync(
            ContractDto dto,
            ContractArtistDto artist,
            IList<ContractArtistEventDateDto> artistEventDates,
            IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentException(nameof(dto));
            }

            if (artist == null)
            {
                throw new ArgumentNullException(nameof(artist));
            }

            if (artistEventDates == null)
            {
                throw new ArgumentNullException(nameof(artistEventDates));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            Context.BeginTransaction();

            try
            {
                ContractDto contract = await _contractService.GetByIdAsync(artist.ContractId, false);

                if (artist.ContractArtistId <= 0)
                {
                    IList<ContractTransactionDto> transactions = await _contractTransactionService.GetByContractIdAsync(contract.ContractId);
                    bool hasMoneyOnContract = ContractHasMoneyReceivedOrReleased(transactions);

                    IList<ContractArtistDto> oldArtists = await _contractArtistService.GetByContractIdAsync(artist.ContractId);

                    // Making an assumption here that there will only be 1 Artist associated to the Contract.
                    if (oldArtists != null && oldArtists.Any())
                    {
                        ContractArtistDto oldArtist = oldArtists.First();

                        IList<ContractTransactionDto> contractTransactions =
                            await _contractTransactionService.GetByContractIdAsync(dto.ContractId);

                        if (hasMoneyOnContract)
                        {
                            // Map the existing expense records to the new artist.
                            foreach (ContractTransactionDto ct in contractTransactions)
                            {
                                if (ct.IsExpense == true &&
                                    ct.PaidAmount == decimal.Zero &&
                                    ct.ContractEntityId == oldArtist.ArtistId &&
                                    ct.ContractEntityTypeId == (int)ContractEntityType.Artist)
                                {
                                    ct.ContractEntityId = artist.ArtistId;
                                    ct.ArtistId = artist.ArtistId;
                                    ct.PayeeName = artist.ArtistName;
                                    ct.SetAsUpdated(user);
                                    await Context.ContractTransactions.UpdateAsync(ct);
                                }
                            }
                        }
                        else
                        {
                            // Remove any existing transactions from the contract.
                            foreach (ContractTransactionDto ct in contractTransactions)
                            {
                                // Only remove unpaid transactions.
                                if (ct.PaidAmount == decimal.Zero)
                                {
                                    ct.ParentContract = contract;
                                    await _contractService.DeleteTransactionAsync(ct, true, user);
                                }
                            }
                        }

                        ContractArtistAgreementDto artistAgreements =
                            await _contractArtistAgreementService.GetByContractArtistIdAsync(oldArtist
                                .ContractArtistId);

                        if (artistAgreements != null)
                        {
                            await _contractArtistAgreementService.DeleteAsync(artistAgreements, user);
                        }

                        IList<ContractTermDto> oldContractTerms = await _contractTermService.GetByContractIdAsync(dto.ContractId);

                        foreach (ContractTermDto oct in oldContractTerms)
                        {
                            await _contractTermService.DeleteAsync(oct.ContractTermId);
                        }

                        IList<ContractDocumentDto> oldContractDocuments =
                            await _contractDocumentService.GetByContractIdAsync(dto.ContractId);

                        foreach (ContractDocumentDto ocd in oldContractDocuments)
                        {
                            await _contractDocumentService.DeleteAsync(ocd);
                        }

                        IEnumerable<ContractSignatureDto> contractSignatures =
                            await Context.ContractSignatures.GetByEntityIdAndEntityTypeAsync(oldArtist.ContractId,
                                oldArtist.ArtistId,
                                (int)EntityType.Artist);

                        if (contractSignatures.Any())
                        {
                            foreach (ContractSignatureDto cs in contractSignatures)
                            {
                                await _contractSignatureService.DeleteAsync(cs.ContractSignatureId);
                            }
                        }

                        IList<ContractArtistEventDateDto> results =
                            await _contractArtistEventDateService.GetByContractArtistIdAsync(oldArtist
                                .ContractArtistId);

                        if (results.Any())
                        {
                            foreach (ContractArtistEventDateDto r in results)
                            {
                                await _contractArtistEventDateService.DeleteAsync(r.ContractArtistEventDateId);
                            }
                        }

                        await _contractArtistService.DeleteAsync(oldArtist.ContractArtistId);

                        if (hasMoneyOnContract == false)
                        {
                            // Reset the contract when money has not been exchanged
                            contract.Gross = null;
                            contract.EceCommissionRate = null;
                            contract.IsCommissionPercentage = null;
                            contract.CommissionProgramAgentId = null;
                            contract.CommissionProgramId = null;
                        }

                        await _contractService.UpdateAsync(contract, user);
                    }

                    await _contractArtistService.CreateAsync(artist, user);

                    IList<ContractDocumentDto> availableRiders = await _contractService.GetAvailableRidersForContractAsync(contract.ContractId);
                    await _contractArtistService.AddArtistRidersAsync(artist, availableRiders, user);

                    if (hasMoneyOnContract)
                    {
                        await _contractService.UpdateArtistPickupAmountsAsync(contract, user);
                    }

                    if (dto.IssueDate.HasValue)
                    {
                        // Audit contract event
                        EntityHistoryDto history = new EntityHistoryDto
                        {
                            EntityId = artist.ContractId,
                            Type = EntityType.Contract,
                            Event = AuditEvent.ContractArtistChanged,
                            Description = "--",
                            CreatedDate = DateTime.Now,
                            CreatedById = user.GetUserId()
                        };

                        await _entityHistoryService.CreateEntityHistoryAsync(history);
                    }
                }
                else
                {
                    await _contractArtistService.UpdateAsync(artist, user);

                    await _contractService.UpdateArtistPickupAmountsAsync(contract, user);
                }

                var existingEventDates = (await _contractArtistEventDateService
                    .GetByContractArtistIdAsync(artist.ContractArtistId))
                    .ToList();

                foreach (var aed in artistEventDates)
                {
                    var existingEventDate = existingEventDates
                        .FirstOrDefault(e => e.ContractEventDateId == aed.ContractEventDateId);

                    if (aed.ContractArtistEventDateId <= 0 && existingEventDate == null)
                    {
                        // New record
                        aed.ContractArtistId = artist.ContractArtistId;
                        await _contractArtistEventDateService.CreateAsync(aed);
                    }
                    else
                    {
                        // Existing record → ensure correct ID before update
                        aed.ContractArtistEventDateId = existingEventDate.ContractArtistEventDateId;
                        await _contractArtistEventDateService.UpdateAsync(aed);
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractSpecialArtistInfoAsync(ContractDto dto, IList<ContractArtistDto> artists, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentException(nameof(dto));
            }

            if (artists == null)
            {
                throw new ArgumentException(nameof(artists));
            }

            if (user == null)
            {
                throw new ArgumentException(nameof(user));
            }

            Context.BeginTransaction();

            try
            {
                bool changeFound = false;

                List<ContractArtistDto> newArtists = new List<ContractArtistDto>();

                foreach (ContractArtistDto a in artists)
                {
                    if (a.ContractArtistId <= 0)
                    {
                        await _contractArtistService.CreateAsync(a, user);

                        newArtists.Add(a);

                        changeFound = true;
                    }
                    else
                    {
                        if (a.IsDeleted.HasValue && a.IsDeleted.Value)
                        {
                            IList<ContractArtistEventDateDto> artistEventDates = await _contractArtistEventDateService.GetByContractArtistIdAsync(a.ContractArtistId);

                            if (artistEventDates.Any())
                            {
                                foreach (ContractArtistEventDateDto aed in artistEventDates)
                                {
                                    await _contractArtistEventDateService.DeleteAsync(aed.ContractArtistEventDateId);
                                }
                            }

                            ContractArtistAgreementDto artistAgreements = await _contractArtistAgreementService.GetByContractArtistIdAsync(a.ContractArtistId);

                            if (artistAgreements != null)
                            {
                                await _contractArtistAgreementService.DeleteAsync(artistAgreements, user);
                            }

                            IList<ContractTransactionDto> contractTransactions =
                                await _contractTransactionService.GetByArtistIdAsync(a.ArtistId, a.ContractId);

                            if (contractTransactions.Any())
                            {
                                IList<ContractTransactionDto> eceContractTransactions =
                                    await _contractTransactionService.GetEceContractTransactionsAsync(
                                        a.ContractId,
                                        new List<int> { (int)ContractTransactionType.ContractFee, (int)ContractTransactionType.NonExclusiveContractFee, (int)ContractTransactionType.AR });

                                if (eceContractTransactions.Any())
                                {
                                    foreach (ContractTransactionDto ect in eceContractTransactions)
                                    {
                                        contractTransactions.Add(ect);
                                    }
                                }

                                foreach (ContractTransactionDto ct in contractTransactions)
                                {
                                    // Only remove unpaid transactions.
                                    if (ct.PaidAmount == decimal.Zero)
                                    {
                                        ct.ParentContract = dto;
                                        await _contractService.DeleteTransactionAsync(ct, true, user);
                                    }
                                }
                            }

                            IList<ContractDocumentDto> contractDocuments = await _contractDocumentService.GetByOriginalEntityIdAndEntityTypeIdAsync(a.ContractId, a.ArtistId, (int)EntityType.Artist);

                            if (contractDocuments.Any())
                            {
                                foreach (ContractDocumentDto cd in contractDocuments)
                                {
                                    await _contractDocumentService.DeleteAsync(cd);
                                }
                            }

                            IEnumerable<ContractSignatureDto> contractSignatures = await Context.ContractSignatures.GetByEntityIdAndEntityTypeAsync(a.ContractId, a.ArtistId, (int)EntityType.Artist);

                            if (contractSignatures.Any())
                            {
                                foreach (ContractSignatureDto cs in contractSignatures)
                                {
                                    await Context.ContractSignatures.DeleteAsync(cs.ContractSignatureId);
                                }
                            }

                            await _contractArtistService.DeleteAsync(a.ContractArtistId);

                            changeFound = true;
                        }
                        else
                        {
                            await _contractArtistService.UpdateAsync(a, user);
                        }
                    }
                }

                if (newArtists.Any())
                {
                    IList<ContractDocumentDto> availableRiders = await _contractService.GetAvailableRidersForContractAsync(dto.ContractId);

                    await _contractArtistService.AddArtistRidersAsync(newArtists, availableRiders, user);
                }

                await _contractService.UpdateArtistPickupAmountsAsync(dto, user);

                if (changeFound && dto.IssueDate.HasValue)
                {
                    // Audit contract event
                    EntityHistoryDto history = new EntityHistoryDto
                    {
                        EntityId = dto.ContractId,
                        Type = EntityType.Contract,
                        Event = AuditEvent.ContractArtistChanged,
                        Description = "--",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await _entityHistoryService.CreateEntityHistoryAsync(history);
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractSpecialArtistEventInfoAsync(IList<ContractArtistDto> artists,
            IList<ContractArtistEventDateDto> artistEventDates,
            IPrincipal user)
        {
            Logger.LogDebug($"Service TimeZone: {TimeZoneInfo.Local}");

            if (artists == null || !artists.Any())
            {
                throw new ArgumentNullException(nameof(artistEventDates));
            }

            if (artistEventDates == null || !artistEventDates.Any())
            {
                throw new ArgumentNullException(nameof(artistEventDates));
            }

            Context.BeginTransaction();

            try
            {
                foreach (ContractArtistDto a in artists)
                {
                    if (a.EventTimeReasonId.HasValue && a.EventTimeReasonId > 0)
                    {
                        await _contractArtistService.UpdateArtistEventTimeReasonAsync(a.ContractArtistId,
                            a.EventTimeReasonId.Value,
                            user);
                    }
                }

                foreach (ContractArtistEventDateDto ed in artistEventDates)
                {
                    if (!ed.IsSelected.Value && ed.ContractArtistEventDateId > 0)
                    {
                        // Delete
                        await _contractArtistEventDateService.DeleteAsync(ed.ContractArtistEventDateId);
                    }
                    else if (ed.IsSelected.Value && ed.ContractArtistEventDateId <= 0)
                    {
                        // Create
                        ed.ContractArtistEventDateId = 0;
                        await _contractArtistEventDateService.CreateAsync(ed);
                    }
                    else
                    {
                        // Update
                        Logger.LogDebug($"ed.EventStartTimeSpan = {ed.EventStartTimeSpan}");
                        Logger.LogDebug($"ed.EventEndTimeSpan = {ed.EventEndTimeSpan}");
                        await _contractArtistEventDateService.UpdateAsync(ed);
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractStandardMoneyAsync(int contractId,
            DateTime? initialDepositDueDate,
            decimal eceCommissionRatePercentage,
            decimal contractGross,
            int? contractProgramId,
            int? contractAgentProgramId,
            IPrincipal user,
            ContractArtistDto contractArtist,
            IList<ContractTransactionDto> contractTransactionsForDelete,
            IList<ContractTransactionDto> contractTransactionsForSave)
        {
            if (contractArtist == null)
            {
                throw new ArgumentNullException(nameof(contractArtist));
            }

            Context.BeginTransaction();

            try
            {
                ContractDto contract = await _contractService.GetByIdAsync(contractId);

                contract.EceCommissionRate = eceCommissionRatePercentage;
                contract.IsCommissionPercentage = true;
                contract.Gross = contractGross;
                contract.CommissionProgramId = contractProgramId;
                contract.CommissionProgramAgentId = contractAgentProgramId;

                await _contractService.UpdateAsync(contract, user);

                IList<ContractTransactionDto> existingContractTransactions = await _contractTransactionService.GetByContractIdAsync(contractId);

                if (contract.ContractStatusId == (int)ContractStatus.InProgress)
                {
                    // When in-progress, simply remove any existing transactions and recreate
                    // them using the data submitted
                    foreach (ContractTransactionDto item in existingContractTransactions)
                    {
                        await Context.ContractTransactions.DeleteAsync(item.ContractTransactionId);
                    }

                    existingContractTransactions.Clear();

                    foreach (ContractTransactionDto item in contractTransactionsForSave)
                    {
                        item.ContractTransactionId = 0;
                    }
                }

                bool artistHasTransaction = existingContractTransactions.Any(x =>
                    x.ContractEntityId == contractArtist.ArtistId &&
                    x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                    x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);

                IList<ContractArtistEventDateDto> artistEventDates = await _contractArtistEventDateService.GetByContractArtistIdAsync(contractArtist.ContractArtistId);

                var eventDate = (DateTime?)null;
                if (artistEventDates != null && artistEventDates.Any())
                {
                    var contractArtistEventDates = artistEventDates.OrderBy(x => x.EventDate).ToList();
                    var contractArtistEventDate = contractArtistEventDates.FirstOrDefault();
                    eventDate = contractArtistEventDate == null ? (DateTime?)null : contractArtistEventDate.EventDate;
                }

                if (!artistHasTransaction)
                {
                    ContractTransactionDto arefTransaction = new ContractTransactionDto()
                    {
                        AgentId = contract.AgentId,
                        ArtistId = contractArtist.ArtistId,
                        ContractEntityId = contractArtist.ArtistId,
                        ContractEntityTypeId = (int)ContractEntityType.Artist,
                        ContractTransactionTypeId = (int)ContractTransactionType.ArtistPayment,
                        RequiredAmount = contractArtist.Aref.GetValueOrDefault(),
                        PaidAmount = decimal.Zero,
                        PayeeName = contractArtist.ArtistName,
                        IsExpense = true,
                        DueDate = eventDate
                    };

                    contractTransactionsForSave.Add(arefTransaction);
                }
                else
                {
                    ContractTransactionDto arefTransaction = existingContractTransactions.FirstOrDefault(x =>
                        x.ContractEntityId == contractArtist.ArtistId &&
                        x.ContractEntityTypeId == (int)ContractEntityType.Artist &&
                        x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);

                    // Only update the Required AREF amount if the transaction has not been paid.
                    if (arefTransaction != null && arefTransaction.PaidAmount == decimal.Zero)
                    {
                        arefTransaction.RequiredAmount = contractArtist.Aref.GetValueOrDefault();
                        contractTransactionsForSave.Add(arefTransaction);
                    }
                }

                ContractArtistDto artist = await _contractArtistService.GetByIdAsync(contractArtist.ContractArtistId);
                artist.Gross = contractArtist.Gross;
                artist.Pickup = contractArtist.Pickup.GetValueOrDefault();
                artist.ProgramsTotal = contractArtist.ProgramsTotal.GetValueOrDefault();
                artist.Aref = contractArtist.Aref.GetValueOrDefault();
                artist.EceCommission = contractArtist.EceCommission.GetValueOrDefault();

                await _contractArtistService.UpdateAsync(artist, user);

                if (contract.ContractStatusId != (int)ContractStatus.InProgress)
                {
                    if (contractTransactionsForDelete.Any())
                    {
                        foreach (ContractTransactionDto ctd in contractTransactionsForDelete)
                        {
                            // Only remove unpaid transactions.
                            if (ctd.ContractTransactionId > 0 && ctd.PaidAmount == decimal.Zero)
                            {
                                ctd.ParentContract = contract;
                                await _contractService.DeleteTransactionAsync(ctd, true, user);
                            }
                        }
                    }
                }

                if (contractTransactionsForSave.Any())
                {
                    foreach (ContractTransactionDto cts in contractTransactionsForSave)
                    {
                        cts.ContractId = contractId;
                        if (cts.AgentId == null)
                        {
                            cts.AgentId = contract.AgentId;
                        }

                        if (cts.ContractTransactionId <= 0)
                        {
                            cts.OfficeId = contract.OfficeId;
                            cts.LineOfBusinessId = contract.LineOfBusinessId;

                            _contractService.SetTransactionPayeeName(contract, cts);

                            if (cts.ArtistId == null && cts.DueDate == null && initialDepositDueDate != null)
                            {
                                cts.DueDate = initialDepositDueDate;
                            }

                            if (cts.ArtistId == null && cts.DueDate < initialDepositDueDate)
                            {
                                cts.DueDate = initialDepositDueDate;
                            }

                            cts.ParentContract = contract;
                            await _contractService.CreateTransactionAsync(cts, true, user);
                        }
                        else
                        {
                            ContractTransactionDto transaction =
                                await _contractTransactionService.GetByIdAsync(cts.ContractTransactionId);
                            transaction.AgentId = cts.AgentId;
                            transaction.DueDate = cts.DueDate;
                            transaction.ContractEntityTypeId = cts.ContractEntityTypeId;
                            transaction.PayeeName = cts.PayeeName;
                            transaction.RequiredAmount = cts.RequiredAmount.GetValueOrDefault();
                            transaction.RequiredPercentage = cts.RequiredPercentage;
                            transaction.IsInitialDeposit = cts.IsInitialDeposit;
                            transaction.ContractEntityId = cts.ContractEntityId;
                            transaction.ArtistId = cts.ArtistId;
                            transaction.IsExpense = cts.IsExpense;
                            transaction.ParentContract = contract;

                            _contractService.SetTransactionPayeeName(contract, transaction);

                            await _contractService.UpdateTransactionAsync(transaction, true, user);
                        }
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractSpecialMoneyAsync(int contractId,
            decimal eceCommissionRate,
            decimal contractGross,
            int? contractProgramId,
            int? contractAgentProgramId,
            DateTime dueDate,
            IPrincipal user,
            IList<ContractArtistDto> contractArtists,
            IList<ContractTransactionDto> contractTransactionsForDelete,
            IList<ContractTransactionDto> contractTransactionsForSave)
        {
            if (contractArtists == null)
            {
                throw new ArgumentNullException(nameof(contractArtists));
            }

            if (!contractArtists.Any())
            {
                throw new ArgumentException(nameof(contractArtists));
            }

            Context.BeginTransaction();

            try
            {
                ContractDto contract = await _contractService.GetByIdAsync(contractId);

                contract.EceCommissionRate = eceCommissionRate;
                contract.IsCommissionPercentage = false;
                contract.Gross = contractGross;
                contract.CommissionProgramId = contractProgramId;
                contract.CommissionProgramAgentId = contractAgentProgramId;
                await _contractService.UpdateAsync(contract, user);

                foreach (ContractArtistDto ca in contractArtists)
                {
                    ContractArtistDto artist = await _contractArtistService.GetByIdAsync(ca.ContractArtistId);
                    artist.Gross = ca.Gross;
                    artist.Pickup = ca.Pickup.GetValueOrDefault();
                    artist.ProgramsTotal = ca.ProgramsTotal.GetValueOrDefault();
                    artist.Aref = ca.Aref.GetValueOrDefault();
                    artist.EceCommission = ca.EceCommission.GetValueOrDefault();

                    await _contractArtistService.UpdateAsync(artist, user);
                }

                if (contract.ContractStatusId == (int)ContractStatus.InProgress)
                {
                    IList<ContractTransactionDto> existingContractTransactions = await _contractTransactionService.GetByContractIdAsync(contractId);

                    // When in-progress, simply remove any existing transactions and recreate
                    // them using the data submitted
                    foreach (ContractTransactionDto item in existingContractTransactions)
                    {
                        await Context.ContractTransactions.DeleteAsync(item.ContractTransactionId);
                    }

                    foreach (ContractTransactionDto item in contractTransactionsForSave)
                    {
                        item.ContractTransactionId = 0;
                    }
                }
                else
                {
                    if (contractTransactionsForDelete.Any())
                    {
                        foreach (ContractTransactionDto ctd in contractTransactionsForDelete)
                        {
                            if (ctd.ContractTransactionId > 0)
                            {
                                // Only remove unpaid transactions.
                                if (ctd.PaidAmount == decimal.Zero)
                                {
                                    ctd.ParentContract = contract;
                                    await _contractService.DeleteTransactionAsync(ctd, true, user);
                                }
                            }
                        }
                    }
                }

                if (contractTransactionsForSave.Any())
                {
                    foreach (ContractTransactionDto cts in contractTransactionsForSave)
                    {
                        if (cts.ContractTransactionId <= 0)
                        {
                            cts.ContractId = contractId;
                            if (cts.AgentId == null)
                            {
                                cts.AgentId = contract.AgentId;
                            }

                            if (!cts.OfficeId.HasValue)
                            {
                                cts.OfficeId = contract.OfficeId;
                            }

                            cts.LineOfBusinessId = contract.LineOfBusinessId;
                            cts.ParentContract = contract;
                            await _contractService.CreateTransactionAsync(cts, true, user);
                        }
                        else
                        {
                            ContractTransactionDto transaction =
                                await _contractTransactionService.GetByIdAsync(cts.ContractTransactionId);
                            transaction.AgentId = cts.AgentId;
                            transaction.DueDate = cts.DueDate;
                            transaction.ContractEntityTypeId = cts.ContractEntityTypeId;
                            transaction.PayeeName = cts.PayeeName;
                            transaction.RequiredAmount = cts.RequiredAmount.GetValueOrDefault();
                            transaction.RequiredPercentage = cts.RequiredPercentage;
                            transaction.IsInitialDeposit = cts.IsInitialDeposit;
                            transaction.ContractEntityId = cts.ContractEntityId;
                            transaction.ArtistId = cts.ArtistId;
                            transaction.IsExpense = cts.IsExpense;
                            transaction.OfficeId = cts.OfficeId;

                            transaction.ParentContract = contract;
                            await _contractService.UpdateTransactionAsync(transaction, true, user);
                        }
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveContractTermsAndRidersAsync(int contractId,
            string additionalTerms,
            IList<ContractTermDto> contractTermsForSave,
            IList<ContractTermDto> contractTermsForDelete,
            IList<ContractDocumentDto> contractRidersForSave,
            IList<ContractDocumentDto> contractRidersForDelete,
            IPrincipal user)
        {
            if (contractId <= 0)
            {
                throw new ArgumentException(nameof(contractId));
            }

            Context.BeginTransaction();

            try
            {
                ContractDto contract = await _contractService.GetByIdAsync(contractId);
                contract.Terms = additionalTerms;

                await _contractService.UpdateAsync(contract, user);

                if (contractTermsForSave.Any())
                {
                    foreach (ContractTermDto ctfs in contractTermsForSave)
                    {
                        if (ctfs.ContractTermId <= 0)
                        {
                            ctfs.ContractTermId = 0;
                            ctfs.IsActive = true;
                            await _contractTermService.CreateAsync(ctfs, user);
                        }
                        else
                        {
                            await _contractTermService.UpdateAsync(ctfs, user);
                        }
                    }
                }

                if (contractTermsForDelete.Any())
                {
                    foreach (ContractTermDto ctfd in contractTermsForDelete)
                    {
                        await _contractTermService.DeleteAsync(ctfd.ContractTermId);
                    }
                }

                if (contractRidersForSave.Any())
                {
                    foreach (ContractDocumentDto crfs in contractRidersForSave)
                    {
                        if (crfs.ContractDocumentId <= 0)
                        {
                            crfs.ContractDocumentId = 0;
                            await _contractDocumentService.CreateAsync(crfs, user);
                        }
                        else
                        {
                            await _contractDocumentService.UpdateAsync(crfs, user);
                        }
                    }
                }

                if (contractRidersForDelete.Any())
                {
                    foreach (ContractDocumentDto crfd in contractRidersForDelete)
                    {
                        await _contractDocumentService.DeleteAsync(crfd);
                    }
                }

                Context.Commit();
            }
            catch (Exception ex)
            {
                Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> VerifyCreateAsync(int entityId, EntityType entityType, IPrincipal principal)
        {
            switch (entityType)
            {
                case EntityType.Presenter:
                    PresenterDto presenter = await _presenterService.GetPresenterByIdAsync(entityId, false);
                    if (presenter == null)
                    {
                        throw new Exception($"Presenter {entityId} not found.");
                    }

                    return await _presenterService.CanCreateContractAsync(principal.GetUserId(), presenter.AgentId);

                case EntityType.BlueCard:
                    BlueCardDto blueCard = await _blueCardService.GetBlueCardByIdAsync(entityId);
                    if (blueCard == null)
                    {
                        throw new Exception($"Blue Card {entityId} not found.");
                    }

                    return await _blueCardService.CanCreateContractAsync(principal.GetUserId(), blueCard.AgentId);

                case EntityType.Contract:
                    return true;

                default:
                    throw new Exception($"Entity type {entityType} not valid.");
            }
        }

        public async Task<bool> ValidateFirstArtistEventDateHasChangedAsync(int contractId, DateTime oldEventDate, DateTime? eventDate)
        {
            bool isAssociatedToArtistEventDate = false;
            bool isAssociatedToArtistPayment = false;

            IEnumerable<ContractEventDateDto> contractEventDates = await _contractEventDateService.GetByContractIdAsync(contractId);

            if (contractEventDates == null || !contractEventDates.Any())
            {
                return false;
            }

            contractEventDates = contractEventDates.OrderBy(x => x.EventDate).ToList();

            ContractEventDateDto originalEventDate = contractEventDates.First();

            if (!DateTime.Equals(originalEventDate.EventDate.Date, oldEventDate.Date))
            {
                return false;
            }

            if (eventDate == null)
            {
                // If the new Event Date is null then the Old Event Date was removed.
                return true;
            }

            IList<ContractArtistDto> contractArtists = await _contractArtistService.GetByContractIdAsync(contractId);

            foreach (ContractArtistDto ca in contractArtists)
            {
                IList<ContractArtistEventDateDto> contractArtistEventDates = await
                    _contractArtistEventDateService.GetByContractArtistIdAsync(ca.ContractArtistId);

                isAssociatedToArtistEventDate =
                    contractArtistEventDates.Any(x => x.ContractEventDateId == originalEventDate.ContractEventDateId);

                if (isAssociatedToArtistEventDate)
                {
                    break;
                }
            }

            IList<ContractTransactionDto> contractTransactions = await _contractTransactionService.GetEceContractTransactionsAsync(
                contractId, new List<int> { (int)ContractTransactionType.ArtistPayment });

            isAssociatedToArtistPayment = contractTransactions.Any(x =>
                x.DueDate.HasValue && DateTime.Equals(x.DueDate.Value.Date, originalEventDate.EventDate.Date));

            if (!isAssociatedToArtistPayment && !isAssociatedToArtistEventDate)
            {
                return false;
            }

            return true;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetAgentMentorProgramsAsync(int agentId, DateTime? currentDate)
        {
            if (agentId <= 0)
            {
                throw new ArgumentException(nameof(agentId));
            }

            if (!currentDate.HasValue)
            {
                throw new ArgumentException(nameof(currentDate));
            }

            List<AgentCommissionProgramsDto> mentors = new List<AgentCommissionProgramsDto>();
            IList<AgentCommissionProgramsDto> mentorPrograms =
                await _agentCommissionProgramService.GetAgentMentorProgramsByMenteeIdAsync(agentId);

            foreach (AgentCommissionProgramsDto mp in mentorPrograms)
            {
                if (mp.StartDate <= currentDate.Value && mp.EndDate >= currentDate.Value)
                {
                    mentors.Add(mp);
                }
            }

            return mentors.OrderBy(x => x.StartDate).ToList();
        }

        public async Task<ContractCommissionProgramDto> GetContractCommissionProgramAsync(ContractDto contract, DateTime? eventDate)
        {
            if (contract == null)
            {
                throw new ArgumentException(nameof(contract));
            }

            ContractCommissionProgramDto result = new ContractCommissionProgramDto { ContractId = contract.ContractId };

            IEnumerable<ContractTransactionDto> commissions = contract.ContractTransactions
                .Where(x => x.ContractTransactionTypeId == (int)ContractTransactionType.Commission &&
                    x.IsExpense &&
                    x.RequiredPercentage > decimal.Zero);

            // Find any transfer programs for the Contract Presenter
            IList<AgentCommissionProgramsDto> transferPrograms = await GetPresentTransfersAsync(contract.PresenterId.GetValueOrDefault(), eventDate);

            // Check to see if the Contract Event date falls within the timeframe of the presenter transfer.
            if (transferPrograms.Any())
            {
                // Get the First Transfer
                AgentCommissionProgramsDto transfer = transferPrograms.First();

                // Check to make sure the Bonus Agent is not listed within the Commission.
                if (commissions.All(x => x.AgentId != transfer.BonusAgentId))
                {
                    result.CommissionProgramId = (int)CommissionProgram.PresenterTransfer;
                    result.CommissionProgramAgentId = transfer.BonusAgentId;
                }
                else
                {
                    // Find any mentors for the Contract Agent.
                    AgentCommissionProgramsDto mentor = await GetMentorPrograms(contract.AgentId, eventDate);

                    // Check to make sure the mentor is not on the Contract to recieve commission.
                    if (mentor != null && commissions.All(x => x.AgentId != mentor.BonusAgentId))
                    {
                        // If the mentor is not in the Commission lets add there ID to the Contract.
                        result.CommissionProgramId = (int)CommissionProgram.Mentor;
                        result.CommissionProgramAgentId = mentor.BonusAgentId;
                    }
                }
            }
            else
            {
                // Find any mentors for the Contract Agent.
                AgentCommissionProgramsDto mentor = await GetMentorPrograms(contract.AgentId, eventDate);

                // Check to make sure the mentor is not on the Contract to recieve commission.
                if (mentor != null && commissions.All(x => x.AgentId != mentor.BonusAgentId))
                {
                    // If the mentor is not in the Commission lets add there ID to the Contract.
                    result.CommissionProgramId = (int)CommissionProgram.Mentor;
                    result.CommissionProgramAgentId = mentor.BonusAgentId;
                }
            }

            return result;
        }

        public async Task<IList<AgentCommissionProgramsDto>> GetPresentTransfersAsync(int presenterId, DateTime? currentDate)
        {
            if (!currentDate.HasValue)
            {
                throw new ArgumentException(nameof(currentDate));
            }

            List<AgentCommissionProgramsDto> transfers = new List<AgentCommissionProgramsDto>();
            IList<AgentCommissionProgramsDto> transferPrograms =
                await _agentCommissionProgramService.GetAgentTransferProgramByPresenterAsync(presenterId);

            foreach (AgentCommissionProgramsDto tp in transferPrograms)
            {
                if (tp.StartDate <= currentDate.Value && tp.EndDate >= currentDate.Value)
                {
                    transfers.Add(tp);
                }
            }

            return transfers.OrderBy(x => x.StartDate).ToList();
        }

        private async Task<ContractDto> VerifyGeoCoordinates(ContractDto contract)
        {
            // Assumes Physical zip is present
            if (!contract.VenueGeoLatitude.HasValue || !contract.VenueGeoLongitude.HasValue)
            {
                ZipCodeGeographyDto zipCoords = await _lookupService.GetZipCodeGeographyAsync(contract.VenuePhysicalZip);

                if (zipCoords != null)
                {
                    contract.VenueGeoLatitude = zipCoords.Latitude;
                    contract.VenueGeoLongitude = zipCoords.Longitude;
                }
                else
                {
                    // Can't locate, set to default. this will drive BR to display messages
                    contract.VenueGeoLatitude = decimal.Zero;
                    contract.VenueGeoLongitude = decimal.Zero;
                }
            }

            return contract;
        }

        private async Task<AgentCommissionProgramsDto> GetMentorPrograms(int agentId, DateTime? eventDate)
        {
            IList<AgentCommissionProgramsDto> mentorPrograms = await GetAgentMentorProgramsAsync(agentId, eventDate);

            if (mentorPrograms.Any())
            {
                return mentorPrograms.First();
            }

            return null;
        }

        public async Task Step1UpdateEventInfo(ContractDto contractNew, ContractDto contractOld, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();
                if (contractNew != null && contractOld != null)
                {
                    if (contractNew.ContractId != contractOld.ContractId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ContractId",
                            Old = Convert.ToString(contractOld.ContractId),
                            New = Convert.ToString(contractNew.ContractId),
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.ContractStatusId != contractOld.ContractStatusId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ContractStatusId",
                            Old = Convert.ToString(contractOld.ContractStatusId),
                            New = Convert.ToString(contractNew.ContractStatusId),
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.AgentId != contractOld.AgentId)
                    {
                        string oldAgentName = string.Empty;
                        AppUser oldAgentUser = _eceCrmEntities.AppUsers.FirstOrDefault(a => a.AppUserId == contractOld.AgentId);
                        if (oldAgentUser != null)
                        {
                            oldAgentName = oldAgentUser.FirstName + " " + oldAgentUser.LastName;
                        }

                        string newAgentName = string.Empty;
                        AppUser newAgentUser = _eceCrmEntities.AppUsers.FirstOrDefault(a => a.AppUserId == contractNew.AgentId);
                        if (newAgentUser != null)
                        {
                            newAgentName = newAgentUser.FirstName + " " + newAgentUser.LastName;
                        }
                        contractChanges.Add(new ContractChangesDto()
                        {

                            Name = "AgentName",
                            Old = oldAgentName,
                            New = newAgentName,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    if (contractNew.OfficeId != contractOld.OfficeId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "OfficeId",
                            Old = contractOld.OfficeId != null ? Convert.ToString(contractOld.OfficeId.Value) : "",
                            New = contractNew.OfficeId != null ? Convert.ToString(contractNew.OfficeId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.LineOfBusinessId != contractOld.LineOfBusinessId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "LineOfBusinessId",
                            Old = contractOld.LineOfBusinessId != null ? Convert.ToString(contractOld.LineOfBusinessId.Value) : "",
                            New = contractNew.LineOfBusinessId != null ? Convert.ToString(contractNew.LineOfBusinessId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }


                    if (contractNew.LeadSourceId != contractOld.LeadSourceId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "LeadSourceId",
                            Old = contractOld.LeadSourceId != null ? Convert.ToString(contractOld.LeadSourceId.Value) : "",
                            New = contractNew.LeadSourceId != null ? Convert.ToString(contractNew.LeadSourceId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.ContractTypeId != contractOld.ContractTypeId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ContractTypeId",
                            Old = contractOld.ContractTypeId != null ? Convert.ToString(contractOld.ContractTypeId.Value) : "",
                            New = contractNew.ContractTypeId != null ? Convert.ToString(contractNew.ContractTypeId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.BlueCardId != contractOld.BlueCardId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "BlueCardId",
                            Old = contractOld.BlueCardId != null ? Convert.ToString(contractOld.BlueCardId.Value) : "",
                            New = contractNew.BlueCardId != null ? Convert.ToString(contractNew.BlueCardId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.IsReseller != contractOld.IsReseller)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsReseller",
                            Old = contractOld.IsReseller != null ? Convert.ToString(contractOld.IsReseller.Value) : "",
                            New = contractNew.IsReseller != null ? Convert.ToString(contractNew.IsReseller.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.ResellerId != contractOld.ResellerId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ResellerId",
                            Old = contractOld.ResellerId != null ? Convert.ToString(contractOld.ResellerId.Value) : "",
                            New = contractNew.ResellerId != null ? Convert.ToString(contractNew.ResellerId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.ContractDueDate != contractOld.ContractDueDate)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ContractDueDate",
                            Old = contractOld.ContractDueDate != null ? contractOld.ContractDueDate.Value.ToString("yyyy-MM-dd") : "",
                            New = contractNew.ContractDueDate != null ? contractNew.ContractDueDate.Value.ToString("yyyy-MM-dd") : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.ContractDueFromId != contractOld.ContractDueFromId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "ContractDueFromId",
                            Old = contractOld.ContractDueFromId != null ? Convert.ToString(contractOld.ContractDueFromId.Value) : "",
                            New = contractNew.ContractDueFromId != null ? Convert.ToString(contractNew.ContractDueFromId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }
                    if (contractNew.IsBuySell != contractOld.IsBuySell)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsBuySell",
                            Old = contractOld.IsBuySell != null ? Convert.ToString(contractOld.IsBuySell.Value) : "",
                            New = contractNew.IsBuySell != null ? Convert.ToString(contractNew.IsBuySell.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }
                    if (contractNew.IsNoIssue != contractOld.IsNoIssue)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsNoIssue",
                            Old = contractOld.IsNoIssue != null ? Convert.ToString(contractOld.IsNoIssue.Value) : "",
                            New = contractNew.IsNoIssue != null ? Convert.ToString(contractNew.IsNoIssue.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.IsSubstitute != contractOld.IsSubstitute)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsSubstitute",
                            Old = contractOld.IsSubstitute != null ? Convert.ToString(contractOld.IsSubstitute.Value) : "",
                            New = contractNew.IsSubstitute != null ? Convert.ToString(contractNew.IsSubstitute.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.IsBackendDeal != contractOld.IsBackendDeal)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsBackendDeal",
                            Old = contractOld.IsBackendDeal != null ? Convert.ToString(contractOld.IsBackendDeal.Value) : "",
                            New = contractNew.IsBackendDeal != null ? Convert.ToString(contractNew.IsBackendDeal.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }
                    contractOld.BackendDescription = contractOld.BackendDescription != null ? Convert.ToString(contractOld.BackendDescription) : "";
                    contractNew.BackendDescription = contractNew.BackendDescription != null ? Convert.ToString(contractNew.BackendDescription) : "";
                    if (!string.Equals(contractOld.BackendDescription, contractNew.BackendDescription))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "BackendDescription",
                            Old = contractOld.BackendDescription != null ? Convert.ToString(contractOld.BackendDescription) : "",
                            New = contractNew.BackendDescription != null ? Convert.ToString(contractNew.BackendDescription) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.TimezoneId != contractOld.TimezoneId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "TimezoneId",
                            Old = contractOld.TimezoneId != null ? Convert.ToString(contractOld.TimezoneId.Value) : "",
                            New = contractNew.TimezoneId != null ? Convert.ToString(contractNew.TimezoneId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.EventTypeId != contractOld.EventTypeId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "EventTypeId",
                            Old = contractOld.EventTypeId != null ? Convert.ToString(contractOld.EventTypeId.Value) : "",
                            New = contractNew.EventTypeId != null ? Convert.ToString(contractNew.EventTypeId.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.IsPublicEvent != contractOld.IsPublicEvent)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsPublicEvent",
                            Old = contractOld.IsPublicEvent != null ? Convert.ToString(contractOld.IsPublicEvent.Value) : "",
                            New = contractNew.IsPublicEvent != null ? Convert.ToString(contractNew.IsPublicEvent.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }
                    contractOld.EventDescription = contractOld.EventDescription != null ? Convert.ToString(contractOld.EventDescription) : "";
                    contractNew.EventDescription = contractNew.EventDescription != null ? Convert.ToString(contractNew.EventDescription) : "";

                    if (!string.Equals(contractOld.EventDescription, contractNew.EventDescription))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "EventDescription",
                            Old = contractOld.EventDescription != null ? Convert.ToString(contractOld.EventDescription) : "",
                            New = contractNew.EventDescription != null ? Convert.ToString(contractNew.EventDescription) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.IsWillAgentAttendTheEvent != contractOld.IsWillAgentAttendTheEvent)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsWillAgentAttendTheEvent",
                            Old = contractOld.IsWillAgentAttendTheEvent != null ? Convert.ToString(contractOld.IsWillAgentAttendTheEvent.Value) : "",
                            New = contractNew.IsWillAgentAttendTheEvent != null ? Convert.ToString(contractNew.IsWillAgentAttendTheEvent.Value) : "",
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (contractNew.EventDatesObject != null && contractOld.EventDatesObject != null)
                    {
                        string oldEventDatesObject = string.Empty;
                        foreach (ContractEventDateDto i in contractOld.EventDatesObject.Where(a => !a.IsDeleted).OrderBy(a => a.EventDate))
                        {
                            if (string.IsNullOrWhiteSpace(oldEventDatesObject))
                            {
                                oldEventDatesObject = i.EventDate.ToString("yyyy-MM-dd");
                            }
                            else
                            {
                                oldEventDatesObject += ", " + i.EventDate.ToString("yyyy-MM-dd");
                            }
                        }

                        string newEventDatesObject = string.Empty;
                        foreach (ContractEventDateDto i in contractNew.EventDatesObject.Where(a => !a.IsDeleted).OrderBy(a => a.EventDate))
                        {
                            if (string.IsNullOrWhiteSpace(newEventDatesObject))
                            {
                                newEventDatesObject = i.EventDate.ToString("yyyy-MM-dd");
                            }
                            else
                            {
                                newEventDatesObject += ", " + i.EventDate.ToString("yyyy-MM-dd");
                            }
                        }

                        if (oldEventDatesObject != newEventDatesObject)
                        {

                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "EventDates",
                                Old = oldEventDatesObject,
                                New = newEventDatesObject,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = true
                            });
                        }

                    }
                }

                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }

        public async Task Step2UpdatePresenter(ContractDto contractNew, ContractDto contractOld, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();


                if (contractNew != null && contractOld != null)
                {

                    if (contractNew.PresenterId != contractOld.PresenterId)
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterId",
                            Old = contractOld.PresenterId.HasValue ? Convert.ToString(contractOld.PresenterId.Value) : "",
                            New = contractNew.PresenterId.HasValue ? Convert.ToString(contractNew.PresenterId.Value) : "",
                            Createddate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }
                    string presenterAccountNameNew = contractNew.PresenterAccountName != null ? Convert.ToString(contractNew.PresenterAccountName) : "";
                    string presenterAccountNameOld = contractOld.PresenterAccountName != null ? Convert.ToString(contractOld.PresenterAccountName) : "";
                    if (!string.Equals(presenterAccountNameNew, presenterAccountNameOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterAccountName",
                            Old = presenterAccountNameOld,
                            New = presenterAccountNameNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterOrganizationNameNew = contractNew.PresenterOrganizationName != null ? Convert.ToString(contractNew.PresenterOrganizationName) : "";
                    string presenterOrganizationNameOld = contractOld.PresenterOrganizationName != null ? Convert.ToString(contractOld.PresenterOrganizationName) : "";
                    if (!string.Equals(presenterOrganizationNameNew, presenterOrganizationNameOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterOrganizationName",
                            Old = presenterOrganizationNameOld,
                            New = presenterOrganizationNameNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingAddress1New = contractNew.PresenterMailingAddress1 != null ? Convert.ToString(contractNew.PresenterMailingAddress1) : "";
                    string presenterMailingAddress1Old = contractOld.PresenterMailingAddress1 != null ? Convert.ToString(contractOld.PresenterMailingAddress1) : "";
                    if (!string.Equals(presenterMailingAddress1New, presenterMailingAddress1Old))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingAddress1",
                            Old = presenterMailingAddress1Old,
                            New = presenterMailingAddress1New,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingAddress2New = contractNew.PresenterMailingAddress2 != null ? Convert.ToString(contractNew.PresenterMailingAddress2) : "";
                    string presenterMailingAddress2Old = contractOld.PresenterMailingAddress2 != null ? Convert.ToString(contractOld.PresenterMailingAddress2) : "";
                    if (!string.Equals(presenterMailingAddress2New, presenterMailingAddress2Old))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingAddress2",
                            Old = presenterMailingAddress2Old,
                            New = presenterMailingAddress2New,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingCityNew = contractNew.PresenterMailingCity != null ? Convert.ToString(contractNew.PresenterMailingCity) : "";
                    string presenterMailingCityOld = contractOld.PresenterMailingCity != null ? Convert.ToString(contractOld.PresenterMailingCity) : "";
                    if (!string.Equals(presenterMailingCityNew, presenterMailingCityOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingCity",
                            Old = presenterMailingCityOld,
                            New = presenterMailingCityNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingStateIdNew = contractNew.PresenterMailingStateId != null ? Convert.ToString(contractNew.PresenterMailingStateId.Value) : "";
                    string presenterMailingStateIdOld = contractOld.PresenterMailingStateId != null ? Convert.ToString(contractOld.PresenterMailingStateId.Value) : "";
                    if (!string.Equals(presenterMailingStateIdNew, presenterMailingStateIdOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingStateId",
                            Old = presenterMailingStateIdOld,
                            New = presenterMailingStateIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingZipNew = contractNew.PresenterMailingZip != null ? Convert.ToString(contractNew.PresenterMailingZip) : "";
                    string presenterMailingZipOld = contractOld.PresenterMailingZip != null ? Convert.ToString(contractOld.PresenterMailingZip) : "";
                    if (!string.Equals(presenterMailingZipNew, presenterMailingZipOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingZip",
                            Old = presenterMailingZipOld,
                            New = presenterMailingZipNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterMailingCountryIdNew = contractNew.PresenterMailingCountryId != null ? Convert.ToString(contractNew.PresenterMailingCountryId.Value) : "";
                    string presenterMailingCountryIdOld = contractOld.PresenterMailingCountryId != null ? Convert.ToString(contractOld.PresenterMailingCountryId.Value) : "";
                    if (!string.Equals(presenterMailingCountryIdNew, presenterMailingCountryIdOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterMailingCountryId",
                            Old = presenterMailingCountryIdOld,
                            New = presenterMailingCountryIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string presenterTypeIdNew = contractNew.PresenterTypeId != null ? Convert.ToString(contractNew.PresenterTypeId.Value) : "";
                    string presenterTypeIdOld = contractOld.PresenterTypeId != null ? Convert.ToString(contractOld.PresenterTypeId.Value) : "";
                    if (!string.Equals(presenterTypeIdNew, presenterTypeIdOld))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "PresenterTypeId",
                            Old = presenterTypeIdOld,
                            New = presenterTypeIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    string contactOld = string.Empty;
                    string contactNew = string.Empty;

                    string oldFirstName = string.Empty;
                    string oldLastName = string.Empty;
                    string oldPreferredContactMethodId = string.Empty;
                    string oldContactTypeId = string.Empty;
                    string oldEmailAddress = string.Empty;
                    string oldNotes = string.Empty;
                    string oldIsPrimary = string.Empty;
                    string oldIsSigner = string.Empty;
                    string oldIsEmailDisabled = string.Empty;
                    string oldPhoneValue = string.Empty;
                    string oldPrimaryPhoneValue = string.Empty;


                    string newFirstName = string.Empty;
                    string newLastName = string.Empty;
                    string newPreferredContactMethodId = string.Empty;
                    string newContactTypeId = string.Empty;
                    string newEmailAddress = string.Empty;
                    string newNotes = string.Empty;
                    string newIsPrimary = string.Empty;
                    string newIsSigner = string.Empty;
                    string newIsEmailDisabled = string.Empty;
                    string newPhoneValue = string.Empty;
                    string newPrimaryPhoneValue = string.Empty;
                    try
                    {
                        if (contractOld.Contacts.Any())
                        {
                            ContactDto contactPrimary = contractOld.Contacts.FirstOrDefault(a => a.IsPrimary && !a.IsDeleted);
                            if (contactPrimary != null)
                            {
                                oldFirstName = Convert.ToString(contactPrimary.FirstName);
                                oldLastName = Convert.ToString(contactPrimary.LastName);
                                oldPreferredContactMethodId = Convert.ToString(contactPrimary.PreferredContactMethodId);
                                oldContactTypeId = Convert.ToString(contactPrimary.ContactTypeId);
                                oldEmailAddress = Convert.ToString(contactPrimary.EmailAddress);
                                oldNotes = Convert.ToString(contactPrimary.Notes);

                                oldIsPrimary = Convert.ToString(contactPrimary.IsPrimary);
                                oldIsSigner = Convert.ToString(contactPrimary.IsSigner);
                                oldIsEmailDisabled = Convert.ToString(contactPrimary.IsEmailDisabled);

                                if (contactPrimary.PhoneNumbers != null && contactPrimary.PhoneNumbers.Any())
                                {

                                    ContactPhoneNumberDto primaryPhoneNumber = contactPrimary.PhoneNumbers.FirstOrDefault(a => a.IsPrimaryPhone);

                                    if (primaryPhoneNumber != null)
                                    {
                                        oldPrimaryPhoneValue = Convert.ToString(primaryPhoneNumber.Value);
                                    }

                                    foreach (ContactPhoneNumberDto c in contactPrimary.PhoneNumbers.OrderByDescending(a => a.IsPrimaryPhone))
                                    {
                                        if (!string.IsNullOrWhiteSpace(c.Value))
                                        {
                                            oldPhoneValue += @" PhoneNumber: " + Convert.ToString(c.Value) + ", "
                                            + " PhoneNumberTypeId: " + Convert.ToString(c.PhoneNumberTypeId) + ", "
                                            + " IsPrimaryPhone: " + Convert.ToString(c.IsPrimaryPhone) + ", "
                                            + " Extension: " + Convert.ToString(c.Extension) + ", ";
                                        }
                                    }

                                }

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        log.Error(ex.Message);
                    }
                    try
                    {
                        if (contractNew.Contacts.Any())
                        {
                            ContactDto contactPrimary = contractNew.Contacts.FirstOrDefault(a => a.IsPrimary && !a.IsDeleted);
                            if (contactPrimary != null)
                            {
                                newFirstName = Convert.ToString(contactPrimary.FirstName);
                                newLastName = Convert.ToString(contactPrimary.LastName);
                                newPreferredContactMethodId = Convert.ToString(contactPrimary.PreferredContactMethodId);
                                newContactTypeId = Convert.ToString(contactPrimary.ContactTypeId);
                                newEmailAddress = Convert.ToString(contactPrimary.EmailAddress);
                                newNotes = Convert.ToString(contactPrimary.Notes);

                                newIsPrimary = Convert.ToString(contactPrimary.IsPrimary);
                                newIsSigner = Convert.ToString(contactPrimary.IsSigner);
                                newIsEmailDisabled = Convert.ToString(contactPrimary.IsEmailDisabled);

                                if (contactPrimary.PhoneNumbers != null && contactPrimary.PhoneNumbers.Any())
                                {

                                    ContactPhoneNumberDto primaryPhoneNumber = contactPrimary.PhoneNumbers.FirstOrDefault(a => a.IsPrimaryPhone);

                                    if (primaryPhoneNumber != null)
                                    {
                                        newPrimaryPhoneValue = Convert.ToString(primaryPhoneNumber.Value);
                                    }

                                    foreach (ContactPhoneNumberDto c in contactPrimary.PhoneNumbers.OrderByDescending(a => a.IsPrimaryPhone))
                                    {
                                        if (!string.IsNullOrWhiteSpace(c.Value))
                                        {
                                            newPhoneValue += @" PhoneNumber: " + Convert.ToString(c.Value) + ", "
                                                + " PhoneNumberTypeId: " + Convert.ToString(c.PhoneNumberTypeId) + ", "
                                                + " IsPrimaryPhone: " + Convert.ToString(c.IsPrimaryPhone) + ", "
                                                + " Extension: " + Convert.ToString(c.Extension) + ", ";
                                        }
                                    }

                                }

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        log.Error(ex.Message);
                    }

                    if (!string.Equals(newFirstName, oldFirstName))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact FirstName",
                            Old = oldFirstName,
                            New = newFirstName,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    if (!string.Equals(newLastName, oldLastName))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact LastName",
                            Old = oldLastName,
                            New = newLastName,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }
                    if (!string.Equals(newEmailAddress, oldEmailAddress))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact EmailAddress",
                            Old = oldEmailAddress,
                            New = newEmailAddress,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    if (!string.Equals(newPrimaryPhoneValue, oldPrimaryPhoneValue))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact PhoneNumber",
                            Old = oldPrimaryPhoneValue,
                            New = newPrimaryPhoneValue,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });

                    }

                    if (!string.Equals(newPreferredContactMethodId, oldPreferredContactMethodId))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact PreferredContactMethodId",
                            Old = oldPreferredContactMethodId,
                            New = newPreferredContactMethodId,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (!string.Equals(newContactTypeId, oldContactTypeId))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact TypeId",
                            Old = oldContactTypeId,
                            New = newContactTypeId,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (!string.Equals(newNotes, oldNotes))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact Notes",
                            Old = oldNotes,
                            New = newNotes,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }


                    if (!string.Equals(newIsPrimary, oldIsPrimary))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact IsPrimary",
                            Old = oldIsPrimary,
                            New = newIsPrimary,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (!string.Equals(newIsSigner, oldIsSigner))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact IsSigner",
                            Old = oldIsSigner,
                            New = newIsSigner,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (!string.Equals(newIsEmailDisabled, oldIsEmailDisabled))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact IsEmailDisabled",
                            Old = oldIsEmailDisabled,
                            New = newIsEmailDisabled,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                    if (!string.Equals(newPhoneValue, oldPhoneValue))
                    {

                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contact PhoneNumber Info",
                            Old = oldPhoneValue,
                            New = newPhoneValue,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });

                    }

                }

                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }

        public async Task Step3UpdateVenue(ContractDto contractNew, ContractDto contractOld, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();


                if (contractNew != null && contractOld != null)
                {

                    string venueIdNew = contractNew.VenueId != null ? Convert.ToString(contractNew.VenueId.Value) : "";
                    string venueIdOld = contractOld.VenueId != null ? Convert.ToString(contractOld.VenueId.Value) : "";
                    if (!string.Equals(venueIdNew, venueIdOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueId",
                            Old = venueIdOld,
                            New = venueIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });
                    }
                    string venueNameNew = contractNew.VenueName != null ? Convert.ToString(contractNew.VenueName) : "";
                    string venueNameOld = contractOld.VenueName != null ? Convert.ToString(contractOld.VenueName) : "";
                    if (!string.Equals(venueNameNew, venueNameOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueName",
                            Old = venueNameOld,
                            New = venueNameNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalAddress1New = contractNew.VenuePhysicalAddress1 != null ? Convert.ToString(contractNew.VenuePhysicalAddress1) : "";
                    string venuePhysicalAddress1Old = contractOld.VenuePhysicalAddress1 != null ? Convert.ToString(contractOld.VenuePhysicalAddress1) : "";
                    if (!string.Equals(venuePhysicalAddress1New, venuePhysicalAddress1Old))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalAddress1",
                            Old = venuePhysicalAddress1Old,
                            New = venuePhysicalAddress1New,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalAddress2New = contractNew.VenuePhysicalAddress2 != null ? Convert.ToString(contractNew.VenuePhysicalAddress2) : "";
                    string venuePhysicalAddress2Old = contractOld.VenuePhysicalAddress2 != null ? Convert.ToString(contractOld.VenuePhysicalAddress2) : "";
                    if (!string.Equals(venuePhysicalAddress2New, venuePhysicalAddress2Old))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalAddress2",
                            Old = venuePhysicalAddress2Old,
                            New = venuePhysicalAddress2New,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalCityNew = contractNew.VenuePhysicalCity != null ? Convert.ToString(contractNew.VenuePhysicalCity) : "";
                    string venuePhysicalCityOld = contractOld.VenuePhysicalCity != null ? Convert.ToString(contractOld.VenuePhysicalCity) : "";
                    if (!string.Equals(venuePhysicalCityNew, venuePhysicalCityOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalCity",
                            Old = venuePhysicalCityOld,
                            New = venuePhysicalCityNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalStateIdNew = contractNew.VenuePhysicalStateId != null ? Convert.ToString(contractNew.VenuePhysicalStateId.Value) : "";
                    string venuePhysicalStateIdOld = contractOld.VenuePhysicalStateId != null ? Convert.ToString(contractOld.VenuePhysicalStateId.Value) : "";
                    if (!string.Equals(venuePhysicalStateIdNew, venuePhysicalStateIdOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalStateId",
                            Old = venuePhysicalStateIdOld,
                            New = venuePhysicalStateIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalZipNew = contractNew.VenuePhysicalZip != null ? Convert.ToString(contractNew.VenuePhysicalZip) : "";
                    string venuePhysicalZipOld = contractOld.VenuePhysicalZip != null ? Convert.ToString(contractOld.VenuePhysicalZip) : "";
                    if (!string.Equals(venuePhysicalZipNew, venuePhysicalZipOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalZip",
                            Old = venuePhysicalZipOld,
                            New = venuePhysicalZipNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venuePhysicalCountryIdNew = contractNew.VenuePhysicalCountryId != null ? Convert.ToString(contractNew.VenuePhysicalCountryId.Value) : "";
                    string venuePhysicalCountryIdOld = contractOld.VenuePhysicalCountryId != null ? Convert.ToString(contractOld.VenuePhysicalCountryId.Value) : "";
                    if (!string.Equals(venuePhysicalCountryIdNew, venuePhysicalCountryIdOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenuePhysicalCountryId",
                            Old = venuePhysicalCountryIdOld,
                            New = venuePhysicalCountryIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });
                    }


                    string venueCapacityNew = contractNew.VenueCapacity != null ? Convert.ToString(contractNew.VenueCapacity.Value) : "";
                    string venueCapacityOld = contractOld.VenueCapacity != null ? Convert.ToString(contractOld.VenueCapacity.Value) : "";
                    if (!string.Equals(venueCapacityNew, venueCapacityOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueCapacity",
                            Old = venueCapacityOld,
                            New = venueCapacityNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });
                    }

                    string venueSettingIdNew = contractNew.VenueSettingId != null ? Convert.ToString(contractNew.VenueSettingId.Value) : "";
                    string venueSettingIdOld = contractOld.VenueSettingId != null ? Convert.ToString(contractOld.VenueSettingId.Value) : "";
                    if (!string.Equals(venueSettingIdNew, venueSettingIdOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueSettingId",
                            Old = venueSettingIdOld,
                            New = venueSettingIdNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string isSettingCoveredNew = contractNew.IsSettingCovered != null ? Convert.ToString(contractNew.IsSettingCovered.Value) : "";
                    string isSettingCoveredOld = contractOld.IsSettingCovered != null ? Convert.ToString(contractOld.IsSettingCovered.Value) : "";
                    if (!string.Equals(isSettingCoveredNew, isSettingCoveredOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "IsSettingCovered",
                            Old = isSettingCoveredOld,
                            New = isSettingCoveredNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });
                    }

                    string venueContactNameNew = contractNew.VenueContactName != null ? Convert.ToString(contractNew.VenueContactName) : "";
                    string venueContactNameOld = contractOld.VenueContactName != null ? Convert.ToString(contractOld.VenueContactName) : "";
                    if (!string.Equals(venueContactNameNew, venueContactNameOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueContactName",
                            Old = venueContactNameOld,
                            New = venueContactNameNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venueContactTitleNew = contractNew.VenueContactTitle != null ? Convert.ToString(contractNew.VenueContactTitle) : "";
                    string venueContactTitleOld = contractOld.VenueContactTitle != null ? Convert.ToString(contractOld.VenueContactTitle) : "";
                    if (!string.Equals(venueContactTitleNew, venueContactTitleOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueContactTitle",
                            Old = venueContactTitleOld,
                            New = venueContactTitleNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    string venueContactPhoneNew = contractNew.VenueContactPhone != null ? Convert.ToString(contractNew.VenueContactPhone) : "";
                    string venueContactPhoneOld = contractOld.VenueContactPhone != null ? Convert.ToString(contractOld.VenueContactPhone) : "";
                    if (!string.Equals(venueContactPhoneNew, venueContactPhoneOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueContactPhone",
                            Old = venueContactPhoneOld,
                            New = venueContactPhoneNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }


                    string venueContactFaxNew = contractNew.VenueContactFax != null ? Convert.ToString(contractNew.VenueContactFax) : "";
                    string venueContactFaxOld = contractOld.VenueContactFax != null ? Convert.ToString(contractOld.VenueContactFax) : "";
                    if (!string.Equals(venueContactFaxNew, venueContactFaxOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueContactFax",
                            Old = venueContactFaxOld,
                            New = venueContactFaxNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = false
                        });
                    }


                    string venueContactEmailNew = contractNew.VenueContactEmail != null ? Convert.ToString(contractNew.VenueContactEmail) : "";
                    string venueContactEmailOld = contractOld.VenueContactEmail != null ? Convert.ToString(contractOld.VenueContactEmail) : "";
                    if (!string.Equals(venueContactFaxNew, venueContactFaxOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "VenueContactEmail",
                            Old = venueContactEmailOld,
                            New = venueContactEmailNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                }



                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }

        public async Task Step4UpdateArtist(ContractDto contractNew, ContractDto contractOld, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();


                if (contractNew != null && contractOld != null)
                {
                    var contractArtistsOld = contractOld.ContractArtists.OrderBy(a => a.ArtistName).ToList();
                    var contractArtistsNew = contractNew.ContractArtists.OrderBy(a => a.ArtistName).ToList();

                    if (contractArtistsNew != null || contractArtistsOld != null)
                    {
                        if (!contractArtistsNew.Any())
                        {
                            contractArtistsNew = new List<ContractArtistDto>();
                        }

                        if (!contractArtistsOld.Any())
                        {
                            contractArtistsOld = new List<ContractArtistDto>();
                        }


                        bool isNewMore = false;

                        if (contractArtistsNew.Count >= contractArtistsOld.Count)
                        {
                            isNewMore = true;
                        }


                        if (isNewMore)
                        {
                            int index = 0;
                            foreach (var i in contractArtistsNew)
                            {
                                var contractArtistNew = i;
                                var contractArtistOld = new ContractArtistDto();
                                try
                                {
                                    contractArtistOld = contractArtistsOld[index];
                                }
                                catch { contractArtistOld = new ContractArtistDto(); }



                                try
                                {

                                    string contractArtistIdNew = contractArtistNew.ContractArtistId != null ? Convert.ToString(contractArtistNew.ContractArtistId) : "";
                                    string contractArtistIdOld = contractArtistOld.ContractArtistId != null ? Convert.ToString(contractArtistOld.ContractArtistId) : "";
                                    if (!string.Equals(contractArtistIdNew, contractArtistIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "contractArtistId",
                                            Old = contractArtistIdOld,
                                            New = contractArtistIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string artistIdNew = contractArtistNew.ArtistId != null ? Convert.ToString(contractArtistNew.ArtistId) : "";
                                    string artistIdOld = contractArtistOld.ArtistId != null ? Convert.ToString(contractArtistOld.ArtistId) : "";
                                    if (!string.Equals(artistIdNew, artistIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ArtistId",
                                            Old = artistIdOld,
                                            New = artistIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string artistNameNew = contractArtistNew.ArtistName != null ? Convert.ToString(contractArtistNew.ArtistName) : "";
                                    string artistNameOld = contractArtistOld.ArtistName != null ? Convert.ToString(contractArtistOld.ArtistName) : "";
                                    if (!string.Equals(artistNameNew, artistNameOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Artist Name",
                                            Old = artistNameOld,
                                            New = artistNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }


                                    string isExclusiveNew = contractArtistNew.IsExclusive != null ? Convert.ToString(contractArtistNew.IsExclusive) : "";
                                    string isExclusiveOld = contractArtistOld.IsExclusive != null ? Convert.ToString(contractArtistOld.IsExclusive) : "";
                                    if (!string.Equals(isExclusiveNew, isExclusiveOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsExclusive",
                                            Old = isExclusiveOld,
                                            New = isExclusiveNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    string isNationalNew = contractArtistNew.IsNational != null ? Convert.ToString(contractArtistNew.IsNational) : "";
                                    string isNationalOld = contractArtistOld.IsNational != null ? Convert.ToString(contractArtistOld.IsNational) : "";
                                    if (!string.Equals(isNationalNew, isNationalOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsNational",
                                            Old = isNationalOld,
                                            New = isNationalNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    string paymentInstructionsNew = contractArtistNew.PaymentInstructions != null ? Convert.ToString(contractArtistNew.PaymentInstructions) : "";
                                    string paymentInstructionsOld = contractArtistOld.PaymentInstructions != null ? Convert.ToString(contractArtistOld.PaymentInstructions) : "";
                                    if (!string.Equals(paymentInstructionsNew, paymentInstructionsOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "PaymentInstructions",
                                            Old = paymentInstructionsOld,
                                            New = paymentInstructionsNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string isTaxInfoHiddenNew = contractArtistNew.IsTaxInfoHidden != null ? Convert.ToString(contractArtistNew.IsTaxInfoHidden) : "";
                                    string isTaxInfoHiddenOld = contractArtistOld.IsTaxInfoHidden != null ? Convert.ToString(contractArtistOld.IsTaxInfoHidden) : "";
                                    if (!string.Equals(isTaxInfoHiddenNew, isTaxInfoHiddenOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsTaxInfoHidden",
                                            Old = isTaxInfoHiddenOld,
                                            New = isTaxInfoHiddenNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }


                                    string setDescriptionNew = contractArtistNew.SetDescription != null ? Convert.ToString(contractArtistNew.SetDescription) : "";
                                    string setDescriptionOld = contractArtistOld.SetDescription != null ? Convert.ToString(contractArtistOld.SetDescription) : "";
                                    if (!string.Equals(setDescriptionNew, setDescriptionOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "SetDescription",
                                            Old = setDescriptionOld,
                                            New = setDescriptionNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string eventTimeReasonIdNew = contractArtistNew.EventTimeReasonId != null ? Convert.ToString(contractArtistNew.EventTimeReasonId) : "";
                                    string eventTimeReasonIdOld = contractArtistOld.EventTimeReasonId != null ? Convert.ToString(contractArtistOld.EventTimeReasonId) : "";
                                    if (!string.Equals(eventTimeReasonIdNew, eventTimeReasonIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "EventTimeReasonId",
                                            Old = eventTimeReasonIdOld,
                                            New = eventTimeReasonIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    var artistEventDatesNew = contractArtistNew.ArtistEventDates.OrderBy(a => a.EventDate).ToList();
                                    var artistEventDatesOld = contractArtistOld.ArtistEventDates.OrderBy(a => a.EventDate).ToList();

                                    if (artistEventDatesNew.Any() && artistEventDatesOld.Any())
                                    {
                                        bool isMoreEventDateNew = false;

                                        if (artistEventDatesNew.Count >= artistEventDatesOld.Count)
                                        {
                                            isMoreEventDateNew = true;
                                        }

                                        if (isMoreEventDateNew)
                                        {
                                            int indexEvent = 0;
                                            foreach (var artistEventDate in artistEventDatesNew)
                                            {
                                                var artistEventDateNew = artistEventDate;
                                                var artistEventDateOld = new ContractArtistEventDateDto();
                                                try
                                                {
                                                    artistEventDateOld = artistEventDatesOld[indexEvent];
                                                }
                                                catch { artistEventDateOld = new ContractArtistEventDateDto(); }


                                                string isSelectedNew = artistEventDateNew.IsSelected != null ? Convert.ToString(artistEventDateNew.IsSelected.Value) : "";
                                                string isSelectedOld = artistEventDateOld.IsSelected != null ? Convert.ToString(artistEventDateOld.IsSelected.Value) : "";
                                                if (!string.Equals(isSelectedNew, isSelectedOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "IsSelected",
                                                        Old = isSelectedOld,
                                                        New = isSelectedNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = false
                                                    });
                                                }


                                                string contractArtistEventDateIdNew = artistEventDateNew.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateNew.ContractArtistEventDateId) : "";
                                                string contractArtistEventDateIdOld = artistEventDateOld.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateOld.ContractArtistEventDateId) : "";
                                                if (!string.Equals(contractArtistEventDateIdNew, contractArtistEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractArtistEventDateId",
                                                        Old = contractArtistEventDateIdOld,
                                                        New = contractArtistEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = false
                                                    });
                                                }


                                                string contractArtistIdForEventNew = artistEventDateNew.ContractArtistId != null ? Convert.ToString(artistEventDateNew.ContractArtistId) : "";
                                                string contractArtistIdForEventOld = artistEventDateOld.ContractArtistId != null ? Convert.ToString(artistEventDateOld.ContractArtistId) : "";
                                                if (!string.Equals(contractArtistIdForEventNew, contractArtistIdForEventOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "contractArtistId For Event",
                                                        Old = contractArtistIdForEventOld,
                                                        New = contractArtistIdForEventNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = false
                                                    });
                                                }

                                                string contractEventDateIdNew = artistEventDateNew.ContractEventDateId != null ? Convert.ToString(artistEventDateNew.ContractEventDateId) : "";
                                                string contractEventDateIdOld = artistEventDateOld.ContractEventDateId != null ? Convert.ToString(artistEventDateOld.ContractEventDateId) : "";
                                                if (!string.Equals(contractEventDateIdNew, contractEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractEventDateId",
                                                        Old = contractEventDateIdOld,
                                                        New = contractEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string migContractHoursNew = artistEventDateNew.MigContractHours != null ? Convert.ToString(artistEventDateNew.MigContractHours) : "";
                                                string migContractHoursOld = artistEventDateOld.MigContractHours != null ? Convert.ToString(artistEventDateOld.MigContractHours) : "";
                                                if (!string.Equals(migContractHoursNew, migContractHoursOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "MigContractHours",
                                                        Old = migContractHoursOld,
                                                        New = migContractHoursNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                var contractEventdateTimeInfoOld = string.Empty;
                                                var contractEventdateTimeInfoNew = string.Empty;

                                                contractEventdateTimeInfoOld = "EventDate :" + (artistEventDateOld.EventDate.HasValue ? artistEventDateOld.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateOld.EventStartTimeSpan.HasValue ? artistEventDateOld.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateOld.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateOld.EventEndTimeSpan.HasValue ? artistEventDateOld.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateOld.ShowNumber));


                                                contractEventdateTimeInfoNew = "EventDate :" + (artistEventDateNew.EventDate.HasValue ? artistEventDateNew.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateNew.EventStartTimeSpan.HasValue ? artistEventDateNew.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateNew.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateNew.EventEndTimeSpan.HasValue ? artistEventDateNew.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateNew.ShowNumber));

                                                if (!string.Equals(contractEventdateTimeInfoNew, contractEventdateTimeInfoOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "Contract Event Date Time Info",
                                                        Old = contractEventdateTimeInfoOld,
                                                        New = contractEventdateTimeInfoNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                indexEvent++;
                                            }

                                        }
                                        else
                                        {

                                            int indexEvent = 0;
                                            foreach (var artistEventDate in artistEventDatesOld)
                                            {
                                                var artistEventDateOld = artistEventDate;
                                                var artistEventDateNew = new ContractArtistEventDateDto();
                                                try
                                                {
                                                    artistEventDateNew = artistEventDatesNew[indexEvent];
                                                }
                                                catch { artistEventDateNew = new ContractArtistEventDateDto(); }


                                                string isSelectedNew = artistEventDateNew.IsSelected != null ? Convert.ToString(artistEventDateNew.IsSelected.Value) : "";
                                                string isSelectedOld = artistEventDateOld.IsSelected != null ? Convert.ToString(artistEventDateOld.IsSelected.Value) : "";
                                                if (!string.Equals(isSelectedNew, isSelectedOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "IsSelected",
                                                        Old = isSelectedOld,
                                                        New = isSelectedNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistEventDateIdNew = artistEventDateNew.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateNew.ContractArtistEventDateId) : "";
                                                string contractArtistEventDateIdOld = artistEventDateOld.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateOld.ContractArtistEventDateId) : "";
                                                if (!string.Equals(contractArtistEventDateIdNew, contractArtistEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractArtistEventDateId",
                                                        Old = contractArtistEventDateIdOld,
                                                        New = contractArtistEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistIdForEventNew = artistEventDateNew.ContractArtistId != null ? Convert.ToString(artistEventDateNew.ContractArtistId) : "";
                                                string contractArtistIdForEventOld = artistEventDateOld.ContractArtistId != null ? Convert.ToString(artistEventDateOld.ContractArtistId) : "";
                                                if (!string.Equals(contractArtistIdForEventNew, contractArtistIdForEventOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "contractArtistId For Event",
                                                        Old = contractArtistIdForEventOld,
                                                        New = contractArtistIdForEventNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                string contractEventDateIdNew = artistEventDateNew.ContractEventDateId != null ? Convert.ToString(artistEventDateNew.ContractEventDateId) : "";
                                                string contractEventDateIdOld = artistEventDateOld.ContractEventDateId != null ? Convert.ToString(artistEventDateOld.ContractEventDateId) : "";
                                                if (!string.Equals(contractEventDateIdNew, contractEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractEventDateId",
                                                        Old = contractEventDateIdOld,
                                                        New = contractEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string migContractHoursNew = artistEventDateNew.MigContractHours != null ? Convert.ToString(artistEventDateNew.MigContractHours) : "";
                                                string migContractHoursOld = artistEventDateOld.MigContractHours != null ? Convert.ToString(artistEventDateOld.MigContractHours) : "";
                                                if (!string.Equals(migContractHoursNew, migContractHoursOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "MigContractHours",
                                                        Old = migContractHoursOld,
                                                        New = migContractHoursNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                var contractEventdateTimeInfoOld = string.Empty;
                                                var contractEventdateTimeInfoNew = string.Empty;

                                                contractEventdateTimeInfoOld = "EventDate :" + (artistEventDateOld.EventDate.HasValue ? artistEventDateOld.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateOld.EventStartTimeSpan.HasValue ? artistEventDateOld.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateOld.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateOld.EventEndTimeSpan.HasValue ? artistEventDateOld.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateOld.ShowNumber));


                                                contractEventdateTimeInfoNew = "EventDate :" + (artistEventDateNew.EventDate.HasValue ? artistEventDateNew.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateNew.EventStartTimeSpan.HasValue ? artistEventDateNew.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateNew.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateNew.EventEndTimeSpan.HasValue ? artistEventDateNew.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateNew.ShowNumber));

                                                if (!string.Equals(contractEventdateTimeInfoNew, contractEventdateTimeInfoOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "Contract Event Date Time Info",
                                                        Old = contractEventdateTimeInfoOld,
                                                        New = contractEventdateTimeInfoNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                indexEvent++;
                                            }


                                        }
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }


                        }
                        else
                        {
                            int index = 0;
                            foreach (var i in contractArtistsOld)
                            {
                                var contractArtistOld = i;
                                var contractArtistNew = new ContractArtistDto();
                                try
                                {
                                    contractArtistNew = contractArtistsNew[index];
                                }
                                catch { contractArtistNew = new ContractArtistDto(); }



                                try
                                {

                                    string contractArtistIdNew = contractArtistNew.ContractArtistId != null ? Convert.ToString(contractArtistNew.ContractArtistId) : "";
                                    string contractArtistIdOld = contractArtistOld.ContractArtistId != null ? Convert.ToString(contractArtistOld.ContractArtistId) : "";
                                    if (!string.Equals(contractArtistIdNew, contractArtistIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "contractArtistId",
                                            Old = contractArtistIdOld,
                                            New = contractArtistIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string artistIdNew = contractArtistNew.ArtistId != null ? Convert.ToString(contractArtistNew.ArtistId) : "";
                                    string artistIdOld = contractArtistOld.ArtistId != null ? Convert.ToString(contractArtistOld.ArtistId) : "";
                                    if (!string.Equals(artistIdNew, artistIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ArtistId",
                                            Old = artistIdOld,
                                            New = artistIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string artistNameNew = contractArtistNew.ArtistName != null ? Convert.ToString(contractArtistNew.ArtistName) : "";
                                    string artistNameOld = contractArtistOld.ArtistName != null ? Convert.ToString(contractArtistOld.ArtistName) : "";
                                    if (!string.Equals(artistIdNew, artistIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Artist Name",
                                            Old = artistNameOld,
                                            New = artistNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }


                                    string isExclusiveNew = contractArtistNew.IsExclusive != null ? Convert.ToString(contractArtistNew.IsExclusive) : "";
                                    string isExclusiveOld = contractArtistOld.IsExclusive != null ? Convert.ToString(contractArtistOld.IsExclusive) : "";
                                    if (!string.Equals(isExclusiveNew, isExclusiveOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsExclusive",
                                            Old = isExclusiveOld,
                                            New = isExclusiveNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    string isNationalNew = contractArtistNew.IsNational != null ? Convert.ToString(contractArtistNew.IsNational) : "";
                                    string isNationalOld = contractArtistOld.IsNational != null ? Convert.ToString(contractArtistOld.IsNational) : "";
                                    if (!string.Equals(isNationalNew, isNationalOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsNational",
                                            Old = isNationalOld,
                                            New = isNationalNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    string paymentInstructionsNew = contractArtistNew.PaymentInstructions != null ? Convert.ToString(contractArtistNew.PaymentInstructions) : "";
                                    string paymentInstructionsOld = contractArtistOld.PaymentInstructions != null ? Convert.ToString(contractArtistOld.PaymentInstructions) : "";
                                    if (!string.Equals(paymentInstructionsNew, paymentInstructionsOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "PaymentInstructions",
                                            Old = paymentInstructionsOld,
                                            New = paymentInstructionsNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string isTaxInfoHiddenNew = contractArtistNew.IsTaxInfoHidden != null ? Convert.ToString(contractArtistNew.IsTaxInfoHidden) : "";
                                    string isTaxInfoHiddenOld = contractArtistOld.IsTaxInfoHidden != null ? Convert.ToString(contractArtistOld.IsTaxInfoHidden) : "";
                                    if (!string.Equals(isTaxInfoHiddenNew, isTaxInfoHiddenOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsTaxInfoHidden",
                                            Old = isTaxInfoHiddenOld,
                                            New = isTaxInfoHiddenNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }


                                    string setDescriptionNew = contractArtistNew.SetDescription != null ? Convert.ToString(contractArtistNew.SetDescription) : "";
                                    string setDescriptionOld = contractArtistOld.SetDescription != null ? Convert.ToString(contractArtistOld.SetDescription) : "";
                                    if (!string.Equals(setDescriptionNew, setDescriptionOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "SetDescription",
                                            Old = setDescriptionOld,
                                            New = setDescriptionNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string eventTimeReasonIdNew = contractArtistNew.EventTimeReasonId != null ? Convert.ToString(contractArtistNew.EventTimeReasonId) : "";
                                    string eventTimeReasonIdOld = contractArtistOld.EventTimeReasonId != null ? Convert.ToString(contractArtistOld.EventTimeReasonId) : "";
                                    if (!string.Equals(eventTimeReasonIdNew, eventTimeReasonIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "EventTimeReasonId",
                                            Old = eventTimeReasonIdOld,
                                            New = eventTimeReasonIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = false
                                        });
                                    }

                                    var artistEventDatesNew = contractArtistNew.ArtistEventDates.OrderBy(a => a.EventDate).ToList();
                                    var artistEventDatesOld = contractArtistOld.ArtistEventDates.OrderBy(a => a.EventDate).ToList();

                                    if (artistEventDatesNew.Any() && artistEventDatesOld.Any())
                                    {
                                        bool isMoreEventDateNew = false;

                                        if (artistEventDatesNew.Count >= artistEventDatesOld.Count)
                                        {
                                            isMoreEventDateNew = true;
                                        }

                                        if (isMoreEventDateNew)
                                        {
                                            int indexEvent = 0;
                                            foreach (var artistEventDate in artistEventDatesNew)
                                            {
                                                var artistEventDateNew = artistEventDate;
                                                var artistEventDateOld = new ContractArtistEventDateDto();
                                                try
                                                {
                                                    artistEventDateOld = artistEventDatesOld[indexEvent];
                                                }
                                                catch { artistEventDateOld = new ContractArtistEventDateDto(); }


                                                string isSelectedNew = artistEventDateNew.IsSelected != null ? Convert.ToString(artistEventDateNew.IsSelected.Value) : "";
                                                string isSelectedOld = artistEventDateOld.IsSelected != null ? Convert.ToString(artistEventDateOld.IsSelected.Value) : "";
                                                if (!string.Equals(isSelectedNew, isSelectedOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "IsSelected",
                                                        Old = isSelectedOld,
                                                        New = isSelectedNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistEventDateIdNew = artistEventDateNew.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateNew.ContractArtistEventDateId) : "";
                                                string contractArtistEventDateIdOld = artistEventDateOld.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateOld.ContractArtistEventDateId) : "";
                                                if (!string.Equals(contractArtistEventDateIdNew, contractArtistEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractArtistEventDateId",
                                                        Old = contractArtistEventDateIdOld,
                                                        New = contractArtistEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistIdForEventNew = artistEventDateNew.ContractArtistId != null ? Convert.ToString(artistEventDateNew.ContractArtistId) : "";
                                                string contractArtistIdForEventOld = artistEventDateOld.ContractArtistId != null ? Convert.ToString(artistEventDateOld.ContractArtistId) : "";
                                                if (!string.Equals(contractArtistIdForEventNew, contractArtistIdForEventOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "contractArtistId For Event",
                                                        Old = contractArtistIdForEventOld,
                                                        New = contractArtistIdForEventNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                string contractEventDateIdNew = artistEventDateNew.ContractEventDateId != null ? Convert.ToString(artistEventDateNew.ContractEventDateId) : "";
                                                string contractEventDateIdOld = artistEventDateOld.ContractEventDateId != null ? Convert.ToString(artistEventDateOld.ContractEventDateId) : "";
                                                if (!string.Equals(contractEventDateIdNew, contractEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractEventDateId",
                                                        Old = contractEventDateIdOld,
                                                        New = contractEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string migContractHoursNew = artistEventDateNew.MigContractHours != null ? Convert.ToString(artistEventDateNew.MigContractHours) : "";
                                                string migContractHoursOld = artistEventDateOld.MigContractHours != null ? Convert.ToString(artistEventDateOld.MigContractHours) : "";
                                                if (!string.Equals(migContractHoursNew, migContractHoursOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "MigContractHours",
                                                        Old = migContractHoursOld,
                                                        New = migContractHoursNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                var contractEventdateTimeInfoOld = string.Empty;
                                                var contractEventdateTimeInfoNew = string.Empty;

                                                contractEventdateTimeInfoOld = "EventDate :" + (artistEventDateOld.EventDate.HasValue ? artistEventDateOld.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateOld.EventStartTimeSpan.HasValue ? artistEventDateOld.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateOld.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateOld.EventEndTimeSpan.HasValue ? artistEventDateOld.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateOld.ShowNumber));


                                                contractEventdateTimeInfoNew = "EventDate :" + (artistEventDateNew.EventDate.HasValue ? artistEventDateNew.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateNew.EventStartTimeSpan.HasValue ? artistEventDateNew.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateNew.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateNew.EventEndTimeSpan.HasValue ? artistEventDateNew.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateNew.ShowNumber));

                                                if (!string.Equals(contractEventdateTimeInfoNew, contractEventdateTimeInfoOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "Contract Event Date Time Info",
                                                        Old = contractEventdateTimeInfoOld,
                                                        New = contractEventdateTimeInfoNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                indexEvent++;
                                            }

                                        }
                                        else
                                        {

                                            int indexEvent = 0;
                                            foreach (var artistEventDate in artistEventDatesOld)
                                            {
                                                var artistEventDateOld = artistEventDate;
                                                var artistEventDateNew = new ContractArtistEventDateDto();
                                                try
                                                {
                                                    artistEventDateNew = artistEventDatesNew[indexEvent];
                                                }
                                                catch { artistEventDateNew = new ContractArtistEventDateDto(); }


                                                string isSelectedNew = artistEventDateNew.IsSelected != null ? Convert.ToString(artistEventDateNew.IsSelected.Value) : "";
                                                string isSelectedOld = artistEventDateOld.IsSelected != null ? Convert.ToString(artistEventDateOld.IsSelected.Value) : "";
                                                if (!string.Equals(isSelectedNew, isSelectedOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "IsSelected",
                                                        Old = isSelectedOld,
                                                        New = isSelectedNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistEventDateIdNew = artistEventDateNew.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateNew.ContractArtistEventDateId) : "";
                                                string contractArtistEventDateIdOld = artistEventDateOld.ContractArtistEventDateId != null ? Convert.ToString(artistEventDateOld.ContractArtistEventDateId) : "";
                                                if (!string.Equals(contractArtistEventDateIdNew, contractArtistEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractArtistEventDateId",
                                                        Old = contractArtistEventDateIdOld,
                                                        New = contractArtistEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string contractArtistIdForEventNew = artistEventDateNew.ContractArtistId != null ? Convert.ToString(artistEventDateNew.ContractArtistId) : "";
                                                string contractArtistIdForEventOld = artistEventDateOld.ContractArtistId != null ? Convert.ToString(artistEventDateOld.ContractArtistId) : "";
                                                if (!string.Equals(contractArtistIdForEventNew, contractArtistIdForEventOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "contractArtistId For Event",
                                                        Old = contractArtistIdForEventOld,
                                                        New = contractArtistIdForEventNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                string contractEventDateIdNew = artistEventDateNew.ContractEventDateId != null ? Convert.ToString(artistEventDateNew.ContractEventDateId) : "";
                                                string contractEventDateIdOld = artistEventDateOld.ContractEventDateId != null ? Convert.ToString(artistEventDateOld.ContractEventDateId) : "";
                                                if (!string.Equals(contractEventDateIdNew, contractEventDateIdOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "ContractEventDateId",
                                                        Old = contractEventDateIdOld,
                                                        New = contractEventDateIdNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                string migContractHoursNew = artistEventDateNew.MigContractHours != null ? Convert.ToString(artistEventDateNew.MigContractHours) : "";
                                                string migContractHoursOld = artistEventDateOld.MigContractHours != null ? Convert.ToString(artistEventDateOld.MigContractHours) : "";
                                                if (!string.Equals(migContractHoursNew, migContractHoursOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "MigContractHours",
                                                        Old = migContractHoursOld,
                                                        New = migContractHoursNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }

                                                var contractEventdateTimeInfoOld = string.Empty;
                                                var contractEventdateTimeInfoNew = string.Empty;

                                                contractEventdateTimeInfoOld = "EventDate :" + (artistEventDateOld.EventDate.HasValue ? artistEventDateOld.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateOld.EventStartTimeSpan.HasValue ? artistEventDateOld.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateOld.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateOld.EventEndTimeSpan.HasValue ? artistEventDateOld.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateOld.ShowNumber));


                                                contractEventdateTimeInfoNew = "EventDate :" + (artistEventDateNew.EventDate.HasValue ? artistEventDateNew.EventDate.Value.ToString("yyyy-MM-dd") : "")
                                                + ", EventStartTime :" + (artistEventDateNew.EventStartTimeSpan.HasValue ? artistEventDateNew.EventStartTimeSpan.Value.ToString(@"hh\:mm") : Convert.ToString(artistEventDateNew.MigContractHours))
                                                + ", EventEndTime :" + (artistEventDateNew.EventEndTimeSpan.HasValue ? artistEventDateNew.EventEndTimeSpan.Value.ToString(@"hh\:mm") : "")
                                                + ", # of Shows :" + (Convert.ToString(artistEventDateNew.ShowNumber));

                                                if (!string.Equals(contractEventdateTimeInfoNew, contractEventdateTimeInfoOld))
                                                {
                                                    contractChanges.Add(new ContractChangesDto()
                                                    {
                                                        Name = "Contract Event Date Time Info",
                                                        Old = contractEventdateTimeInfoOld,
                                                        New = contractEventdateTimeInfoNew,
                                                        Createddate = datetime,
                                                        Createdby = user.Identity.Name,
                                                        IsPDFChange = true
                                                    });
                                                }


                                                indexEvent++;
                                            }


                                        }
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }


                        }

                    }

                }



                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }

        public async Task Step5UpdateMoney(ContractDto contractNew, ContractDto contractOld, List<ContractTransactionDto> contractTransactionDtoDeletes, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();

                if (contractNew != null && contractOld != null)
                {

                    var contractTransactionsNew = contractNew.ContractTransactions.Any() ? contractNew.ContractTransactions.OrderByDescending(a => a.ContractTransactionId).ToList() : (new List<ContractTransactionDto>());
                    var contractTransactionsOld = contractOld.ContractTransactions.Any() ? contractOld.ContractTransactions.OrderByDescending(a => a.ContractTransactionId).ToList() : (new List<ContractTransactionDto>());
                    if (contractTransactionsNew != null || contractTransactionsOld != null)
                    {
                        if (!contractTransactionsNew.Any())
                        {
                            contractTransactionsNew = new List<ContractTransactionDto>();
                        }
                        if (!contractTransactionsOld.Any())
                        {
                            contractTransactionsOld = new List<ContractTransactionDto>();
                        }



                        string eceCommissionRateNew = contractNew.EceCommissionRate != null && contractNew.EceCommissionRate.HasValue ? Convert.ToString(contractNew.EceCommissionRate.Value.ToString("f2")) : "0.00";
                        string eceCommissionRateOld = contractOld.EceCommissionRate != null && contractOld.EceCommissionRate.HasValue ? Convert.ToString(contractOld.EceCommissionRate.Value.ToString("f2")) : "0.00";
                        if (!string.Equals(eceCommissionRateNew, eceCommissionRateOld))
                        {
                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "EceCommissionRate",
                                Old = eceCommissionRateOld,
                                New = eceCommissionRateNew,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = true
                            });
                        }

                        string isCommissionPercentageNew = contractNew.IsCommissionPercentage != null ? Convert.ToString(contractNew.IsCommissionPercentage.Value) : "";
                        string isCommissionPercentageOld = contractOld.IsCommissionPercentage != null ? Convert.ToString(contractOld.IsCommissionPercentage.Value) : "";
                        if (!string.Equals(eceCommissionRateNew, eceCommissionRateOld))
                        {
                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "IsCommissionPercentage",
                                Old = isCommissionPercentageOld,
                                New = isCommissionPercentageNew,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = true
                            });
                        }

                        string grossNew = contractNew.Gross != null && contractNew.Gross.HasValue ? Convert.ToString(contractNew.Gross.Value.ToString("f2")) : "0.00";
                        string grossOld = contractOld.Gross != null && contractNew.Gross.HasValue ? Convert.ToString(contractOld.Gross.Value.ToString("f2")) : "0.00";
                        if (!string.Equals(grossNew, grossOld))
                        {
                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "Gross",
                                Old = grossOld,
                                New = grossNew,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = true
                            });
                        }

                        string commissionProgramIdNew = contractNew.CommissionProgramId != null ? Convert.ToString(contractNew.CommissionProgramId.Value) : "";
                        string commissionProgramIdOld = contractOld.CommissionProgramId != null ? Convert.ToString(contractOld.CommissionProgramId.Value) : "";
                        if (!string.Equals(commissionProgramIdNew, commissionProgramIdOld))
                        {
                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "CommissionProgramId",
                                Old = commissionProgramIdOld,
                                New = commissionProgramIdNew,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = false
                            });
                        }

                        string commissionProgramAgentIdNew = contractNew.CommissionProgramAgentId != null ? Convert.ToString(contractNew.CommissionProgramAgentId.Value) : "";
                        string commissionProgramAgentIdOld = contractOld.CommissionProgramAgentId != null ? Convert.ToString(contractOld.CommissionProgramAgentId.Value) : "";
                        if (!string.Equals(commissionProgramAgentIdNew, commissionProgramAgentIdOld))
                        {
                            contractChanges.Add(new ContractChangesDto()
                            {
                                Name = "CommissionProgramAgentId",
                                Old = commissionProgramAgentIdOld,
                                New = commissionProgramAgentIdNew,
                                Createddate = datetime,
                                Createdby = user.Identity.Name,
                                IsPDFChange = false
                            });
                        }




                        var contractArtistsOld = contractOld.ContractArtists.OrderBy(a => a.ArtistName).ToList();
                        var contractArtistsNew = contractNew.ContractArtists.OrderBy(a => a.ArtistName).ToList();

                        if (contractArtistsNew != null || contractArtistsOld != null)
                        {
                            if (!contractArtistsNew.Any())
                            {
                                contractArtistsNew = new List<ContractArtistDto>();
                            }

                            if (!contractArtistsOld.Any())
                            {
                                contractArtistsOld = new List<ContractArtistDto>();
                            }


                            bool isArtistNewMore = false;

                            if (contractArtistsNew.Count >= contractArtistsOld.Count)
                            {
                                isArtistNewMore = true;
                            }


                            if (isArtistNewMore)
                            {
                                int index = 0;
                                foreach (var i in contractArtistsNew)
                                {
                                    var contractArtistNew = i;
                                    if (contractArtistNew == null)
                                    {
                                        contractArtistNew = new ContractArtistDto();
                                    }
                                    var contractArtistOld = new ContractArtistDto();
                                    try
                                    {
                                        contractArtistOld = contractArtistsOld[index];
                                    }
                                    catch { contractArtistOld = new ContractArtistDto(); }



                                    try
                                    {

                                        string artistGrossNew = contractArtistNew.Gross != null ? Convert.ToString(contractArtistNew.Gross.ToString("f2")) : "0.00";
                                        string artistGrossOld = contractArtistOld.Gross != null ? Convert.ToString(contractArtistOld.Gross.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistGrossNew, artistGrossOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistGross",
                                                Old = artistGrossOld,
                                                New = artistGrossNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistPickupNew = contractArtistNew.Pickup != null && contractArtistNew.Pickup.HasValue ? Convert.ToString(contractArtistNew.Pickup.Value.ToString("f2")) : "0.00";
                                        string artistPickupOld = contractArtistOld.Pickup != null && contractArtistOld.Pickup.HasValue ? Convert.ToString(contractArtistOld.Pickup.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistPickupNew, artistPickupOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistPickup",
                                                Old = artistPickupOld,
                                                New = artistPickupNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistProgramsTotalNew = contractArtistNew.ProgramsTotal != null && contractArtistNew.ProgramsTotal.HasValue ? Convert.ToString(contractArtistNew.ProgramsTotal.Value.ToString("f2")) : "0.00";
                                        string artistProgramsTotalOld = contractArtistOld.ProgramsTotal != null && contractArtistOld.ProgramsTotal.HasValue ? Convert.ToString(contractArtistOld.ProgramsTotal.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistProgramsTotalNew, artistProgramsTotalOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistProgramsTotal",
                                                Old = artistProgramsTotalOld,
                                                New = artistProgramsTotalNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistArefNew = contractArtistNew.Aref != null && contractArtistNew.Aref.HasValue ? Convert.ToString(contractArtistNew.Aref.Value.ToString("f2")) : "0.00";
                                        string artistArefOld = contractArtistOld.Aref != null && contractArtistOld.Aref.HasValue ? Convert.ToString(contractArtistOld.Aref.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistArefNew, artistArefOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistAref",
                                                Old = artistArefOld,
                                                New = artistArefNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistEceCommissionNew = contractArtistNew.EceCommission != null && contractArtistNew.EceCommission.HasValue ? Convert.ToString(contractArtistNew.EceCommission.Value.ToString("f2")) : "0.00";
                                        string artistEceCommissionOld = contractArtistOld.EceCommission != null && contractArtistOld.EceCommission.HasValue ? Convert.ToString(contractArtistOld.EceCommission.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistEceCommissionNew, artistEceCommissionOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistEceCommission",
                                                Old = artistEceCommissionOld,
                                                New = artistEceCommissionNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }


                                    }
                                    catch (Exception ex)
                                    {

                                        Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        log.Error(ex.Message);
                                    }


                                    index++;
                                }


                            }
                            else
                            {
                                int index = 0;
                                foreach (var i in contractArtistsOld)
                                {
                                    var contractArtistOld = i;
                                    if (contractArtistOld == null)
                                    {
                                        contractArtistOld = new ContractArtistDto();
                                    }
                                    var contractArtistNew = new ContractArtistDto();
                                    try
                                    {
                                        contractArtistNew = contractArtistsOld[index];
                                    }
                                    catch { contractArtistNew = new ContractArtistDto(); }




                                    try
                                    {

                                        string artistGrossNew = contractArtistNew.Gross != null ? Convert.ToString(contractArtistNew.Gross.ToString("f2")) : "0.00";
                                        string artistGrossOld = contractArtistOld.Gross != null ? Convert.ToString(contractArtistOld.Gross.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistGrossNew, artistGrossOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistGross",
                                                Old = artistGrossOld,
                                                New = artistGrossNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistPickupNew = contractArtistNew.Pickup != null && contractArtistNew.Pickup.HasValue ? Convert.ToString(contractArtistNew.Pickup.Value.ToString("f2")) : "0.00";
                                        string artistPickupOld = contractArtistOld.Pickup != null && contractArtistOld.Pickup.HasValue ? Convert.ToString(contractArtistOld.Pickup.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistPickupNew, artistPickupOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistPickup",
                                                Old = artistPickupOld,
                                                New = artistPickupNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistProgramsTotalNew = contractArtistNew.ProgramsTotal != null && contractArtistNew.ProgramsTotal.HasValue ? Convert.ToString(contractArtistNew.ProgramsTotal.Value.ToString("f2")) : "0.00";
                                        string artistProgramsTotalOld = contractArtistOld.ProgramsTotal != null && contractArtistOld.ProgramsTotal.HasValue ? Convert.ToString(contractArtistOld.ProgramsTotal.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistProgramsTotalNew, artistProgramsTotalOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistProgramsTotal",
                                                Old = artistProgramsTotalOld,
                                                New = artistProgramsTotalNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistArefNew = contractArtistNew.Aref != null && contractArtistNew.Aref.HasValue ? Convert.ToString(contractArtistNew.Aref.Value.ToString("f2")) : "0.00";
                                        string artistArefOld = contractArtistOld.Aref != null && contractArtistOld.Aref.HasValue ? Convert.ToString(contractArtistOld.Aref.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistArefNew, artistArefOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistAref",
                                                Old = artistArefOld,
                                                New = artistArefNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }

                                        string artistEceCommissionNew = contractArtistNew.EceCommission != null && contractArtistNew.EceCommission.HasValue ? Convert.ToString(contractArtistNew.EceCommission.Value.ToString("f2")) : "0.00";
                                        string artistEceCommissionOld = contractArtistOld.EceCommission != null && contractArtistOld.EceCommission.HasValue ? Convert.ToString(contractArtistOld.EceCommission.Value.ToString("f2")) : "0.00";
                                        if (!string.Equals(artistEceCommissionNew, artistEceCommissionOld))
                                        {
                                            contractChanges.Add(new ContractChangesDto()
                                            {
                                                Name = "ArtistEceCommission",
                                                Old = artistEceCommissionOld,
                                                New = artistEceCommissionNew,
                                                Createddate = datetime,
                                                Createdby = user.Identity.Name,
                                                IsPDFChange = false
                                            });
                                        }


                                    }
                                    catch (Exception ex)
                                    {

                                        Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        log.Error(ex.Message);
                                    }


                                    index++;
                                }


                            }

                        }

                        bool isNewMore = false;

                        if (contractTransactionsNew.Count >= contractTransactionsOld.Count)
                        {
                            isNewMore = true;
                        }


                        if (isNewMore)
                        {
                            int index = 0;
                            foreach (var i in contractTransactionsNew)
                            {
                                var contractTransactionNew = i;
                                if (contractTransactionNew == null)
                                {
                                    contractTransactionNew = new ContractTransactionDto();
                                }
                                var contractTransactionOld = new ContractTransactionDto();
                                try
                                {
                                    contractTransactionOld = contractTransactionsOld[index];
                                }
                                catch { contractTransactionOld = new ContractTransactionDto(); }



                                try
                                {

                                    string newContractTransactionString = string.Empty;
                                    string oldContractTransactionString = string.Empty;

                                    string escrowAmountNew = contractTransactionNew.EscrowAmount != null ? Convert.ToString(contractTransactionNew.EscrowAmount.ToString("f2")) : "0.00";
                                    string escrowAmountOld = contractTransactionOld.EscrowAmount != null ? Convert.ToString(contractTransactionOld.EscrowAmount.ToString("f2")) : "0.00";
                                    if (!string.Equals(escrowAmountNew, escrowAmountOld))
                                    {
                                        newContractTransactionString += ", EscrowAmount:" + escrowAmountNew;
                                        oldContractTransactionString += ", EscrowAmount:" + escrowAmountOld;
                                    }

                                    string artistIdNew = contractTransactionNew.ArtistId != null && contractTransactionNew.ArtistId.HasValue ? Convert.ToString(contractTransactionNew.ArtistId.Value) : "";
                                    string artistIdOld = contractTransactionOld.ArtistId != null && contractTransactionOld.ArtistId.HasValue ? Convert.ToString(contractTransactionOld.ArtistId.Value) : "";
                                    if (!string.Equals(artistIdNew, artistIdOld))
                                    {
                                        newContractTransactionString += ", ArtistId:" + artistIdNew;
                                        oldContractTransactionString += ", ArtistId:" + artistIdOld;
                                    }

                                    string vendorIdNew = contractTransactionNew.VendorId != null ? Convert.ToString(contractTransactionNew.VendorId) : "";
                                    string vendorIdOld = contractTransactionOld.VendorId != null ? Convert.ToString(contractTransactionOld.VendorId) : "";
                                    if (!string.Equals(vendorIdNew, vendorIdOld))
                                    {
                                        newContractTransactionString += ", VendorId:" + vendorIdNew;
                                        oldContractTransactionString += ", VendorId:" + vendorIdOld;
                                    }

                                    string resellerIdNew = contractTransactionNew.ResellerId != null ? Convert.ToString(contractTransactionNew.ResellerId) : "";
                                    string resellerIdOld = contractTransactionOld.ResellerId != null ? Convert.ToString(contractTransactionOld.ResellerId) : "";
                                    if (!string.Equals(resellerIdNew, resellerIdOld))
                                    {
                                        newContractTransactionString += ", ResellerId:" + resellerIdNew;
                                        oldContractTransactionString += ", ResellerId:" + resellerIdOld;
                                    }

                                    string lineOfBusinessIdNew = contractTransactionNew.LineOfBusinessId != null && contractTransactionNew.LineOfBusinessId.HasValue ? Convert.ToString(contractTransactionNew.LineOfBusinessId.Value) : "";
                                    string lineOfBusinessIdOld = contractTransactionOld.LineOfBusinessId != null && contractTransactionOld.LineOfBusinessId.HasValue ? Convert.ToString(contractTransactionOld.LineOfBusinessId.Value) : "";
                                    if (!string.Equals(lineOfBusinessIdNew, lineOfBusinessIdOld))
                                    {
                                        newContractTransactionString += ", LineOfBusinessId:" + lineOfBusinessIdNew;
                                        oldContractTransactionString += ", LineOfBusinessId:" + lineOfBusinessIdOld;
                                    }

                                    string agentIdNew = contractTransactionNew.AgentId != null && contractTransactionNew.AgentId.HasValue ? Convert.ToString(contractTransactionNew.AgentId.Value) : "";
                                    string agentIdOld = contractTransactionOld.AgentId != null && contractTransactionOld.AgentId.HasValue ? Convert.ToString(contractTransactionOld.AgentId.Value) : "";
                                    if (!string.Equals(agentIdNew, agentIdOld))
                                    {
                                        newContractTransactionString += ", AgentId:" + agentIdNew;
                                        oldContractTransactionString += ", AgentId:" + agentIdOld;
                                    }


                                    string officeIdNew = contractTransactionNew.OfficeId != null && contractTransactionNew.OfficeId.HasValue ? Convert.ToString(contractTransactionNew.OfficeId.Value) : "";
                                    string officeIdOld = contractTransactionOld.OfficeId != null && contractTransactionOld.OfficeId.HasValue ? Convert.ToString(contractTransactionOld.OfficeId.Value) : "";
                                    if (!string.Equals(officeIdNew, officeIdOld))
                                    {
                                        newContractTransactionString += ", OfficeId:" + officeIdNew;
                                        oldContractTransactionString += ", OfficeId:" + officeIdOld;
                                    }

                                    string contractEntityIdNew = contractTransactionNew.ContractEntityId != null ? Convert.ToString(contractTransactionNew.ContractEntityId) : "";
                                    string contractEntityIdOld = contractTransactionOld.ContractEntityId != null ? Convert.ToString(contractTransactionOld.ContractEntityId) : "";
                                    if (!string.Equals(contractEntityIdNew, contractEntityIdOld))
                                    {
                                        newContractTransactionString += ", ContractEntityId:" + contractEntityIdNew;
                                        oldContractTransactionString += ", ContractEntityId:" + contractEntityIdOld;
                                    }

                                    string contractEntityTypeIdNew = contractTransactionNew.ContractEntityTypeId != null ? Convert.ToString(contractTransactionNew.ContractEntityTypeId) : "";
                                    string contractEntityTypeIdOld = contractTransactionOld.ContractEntityTypeId != null ? Convert.ToString(contractTransactionOld.ContractEntityTypeId) : "";
                                    if (!string.Equals(contractEntityTypeIdNew, contractEntityTypeIdOld))
                                    {
                                        newContractTransactionString += ", ContractEntityTypeId:" + contractEntityTypeIdNew;
                                        oldContractTransactionString += ", ContractEntityTypeId:" + contractEntityTypeIdOld;
                                    }

                                    string contractTransactionTypeIdNew = contractTransactionNew.ContractTransactionTypeId != null ? Convert.ToString(contractTransactionNew.ContractTransactionTypeId) : "";
                                    string contractTransactionTypeIdOld = contractTransactionOld.ContractTransactionTypeId != null ? Convert.ToString(contractTransactionOld.ContractTransactionTypeId) : "";
                                    if (!string.Equals(contractTransactionTypeIdNew, contractTransactionTypeIdOld))
                                    {
                                        newContractTransactionString += ", ContractTransactionTypeId:" + contractTransactionTypeIdNew;
                                        oldContractTransactionString += ", ContractTransactionTypeId:" + contractTransactionTypeIdOld;
                                    }

                                    string payeeNameNew = contractTransactionNew.PayeeName != null ? Convert.ToString(contractTransactionNew.PayeeName) : "";
                                    string payeeNameOld = contractTransactionOld.PayeeName != null ? Convert.ToString(contractTransactionOld.PayeeName) : "";
                                    if (!string.Equals(payeeNameNew, payeeNameOld))
                                    {
                                        newContractTransactionString += ", PayeeName:" + payeeNameNew;
                                        oldContractTransactionString += ", PayeeName:" + payeeNameOld;
                                    }

                                    string referenceNumberNew = contractTransactionNew.ReferenceNumber != null ? Convert.ToString(contractTransactionNew.ReferenceNumber) : "";
                                    string referenceNumberOld = contractTransactionOld.ReferenceNumber != null ? Convert.ToString(contractTransactionOld.ReferenceNumber) : "";
                                    if (!string.Equals(referenceNumberNew, referenceNumberOld))
                                    {
                                        newContractTransactionString += ", ReferenceNumber:" + referenceNumberNew;
                                        oldContractTransactionString += ", ReferenceNumber:" + referenceNumberOld;
                                    }

                                    string isExpenseNew = contractTransactionNew.IsExpense != null ? Convert.ToString(contractTransactionNew.IsExpense) : "";
                                    string isExpenseOld = contractTransactionOld.IsExpense != null ? Convert.ToString(contractTransactionOld.IsExpense) : "";
                                    if (!string.Equals(isExpenseNew, isExpenseOld))
                                    {
                                        newContractTransactionString += ", IsExpense:" + isExpenseNew;
                                        oldContractTransactionString += ", IsExpense:" + isExpenseOld;
                                    }

                                    string dueDateNew = contractTransactionNew.DueDate != null && contractTransactionNew.DueDate.HasValue ? Convert.ToString(contractTransactionNew.DueDate.Value) : "";
                                    string dueDateOld = contractTransactionOld.DueDate != null && contractTransactionOld.DueDate.HasValue ? Convert.ToString(contractTransactionOld.DueDate.Value) : "";
                                    if (!string.Equals(dueDateNew, dueDateOld))
                                    {
                                        newContractTransactionString += ", DueDate:" + dueDateNew;
                                        oldContractTransactionString += ", DueDate:" + dueDateOld;
                                    }

                                    string requiredAmountNew = contractTransactionNew.RequiredAmount != null && contractTransactionNew.RequiredAmount.HasValue ? Convert.ToString(contractTransactionNew.RequiredAmount.Value.ToString("f2")) : "0.00";
                                    string requiredAmountOld = contractTransactionOld.RequiredAmount != null && contractTransactionOld.RequiredAmount.HasValue ? Convert.ToString(contractTransactionOld.RequiredAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(requiredAmountNew, requiredAmountOld))
                                    {
                                        newContractTransactionString += ", RequiredAmount:" + requiredAmountNew;
                                        oldContractTransactionString += ", RequiredAmount:" + requiredAmountOld;
                                    }

                                    string originalRequiredAmountNew = contractTransactionNew.OriginalRequiredAmount != null && contractTransactionNew.OriginalRequiredAmount.HasValue ? Convert.ToString(contractTransactionNew.OriginalRequiredAmount.Value.ToString("f2")) : "0.00";
                                    string originalRequiredAmountOld = contractTransactionOld.OriginalRequiredAmount != null && contractTransactionOld.OriginalRequiredAmount.HasValue ? Convert.ToString(contractTransactionOld.OriginalRequiredAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(originalRequiredAmountNew, originalRequiredAmountOld))
                                    {
                                        newContractTransactionString += ", OriginalRequiredAmount:" + originalRequiredAmountNew;
                                        oldContractTransactionString += ", OriginalRequiredAmount:" + originalRequiredAmountOld;
                                    }

                                    string requiredPercentageNew = contractTransactionNew.RequiredPercentage != null && contractTransactionNew.RequiredPercentage.HasValue ? Convert.ToString(contractTransactionNew.RequiredPercentage.Value.ToString("f2")) : "0.00";
                                    string requiredPercentageOld = contractTransactionOld.RequiredPercentage != null && contractTransactionOld.RequiredPercentage.HasValue ? Convert.ToString(contractTransactionOld.RequiredPercentage.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(requiredPercentageNew, requiredPercentageOld))
                                    {
                                        newContractTransactionString += ", RequiredPercentage:" + requiredPercentageNew;
                                        oldContractTransactionString += ", RequiredPercentage:" + requiredPercentageOld;
                                    }

                                    string paidDateNew = contractTransactionNew.PaidDate != null && contractTransactionNew.PaidDate.HasValue ? Convert.ToString(contractTransactionNew.PaidDate.Value) : "";
                                    string paidDateOld = contractTransactionOld.PaidDate != null && contractTransactionOld.PaidDate.HasValue ? Convert.ToString(contractTransactionOld.PaidDate.Value) : "";
                                    if (!string.Equals(paidDateNew, paidDateOld))
                                    {
                                        newContractTransactionString += ", PaidDate:" + paidDateNew;
                                        oldContractTransactionString += ", PaidDate:" + paidDateOld;
                                    }

                                    string paidAmountNew = contractTransactionNew.PaidAmount != null && contractTransactionNew.PaidAmount.HasValue ? Convert.ToString(contractTransactionNew.PaidAmount.Value.ToString("f2")) : "0.00";
                                    string paidAmountOld = contractTransactionOld.PaidAmount != null && contractTransactionOld.PaidAmount.HasValue ? Convert.ToString(contractTransactionOld.PaidAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(paidAmountNew, paidAmountOld))
                                    {
                                        newContractTransactionString += ", PaidAmount:" + paidAmountNew;
                                        oldContractTransactionString += ", PaidAmount:" + paidAmountOld;
                                    }

                                    string notesNew = contractTransactionNew.Notes != null ? Convert.ToString(contractTransactionNew.Notes) : "";
                                    string notesOld = contractTransactionOld.Notes != null ? Convert.ToString(contractTransactionOld.Notes) : "";
                                    if (!string.Equals(notesNew, notesOld))
                                    {
                                        newContractTransactionString += ", Notes:" + notesNew;
                                        oldContractTransactionString += ", Notes:" + notesOld;
                                    }

                                    string isInitialDepositNew = contractTransactionNew.IsInitialDeposit != null ? Convert.ToString(contractTransactionNew.IsInitialDeposit) : "";
                                    string isInitialDepositOld = contractTransactionOld.IsInitialDeposit != null ? Convert.ToString(contractTransactionOld.IsInitialDeposit) : "";
                                    if (!string.Equals(isInitialDepositNew, isInitialDepositOld))
                                    {
                                        newContractTransactionString += ", IsInitialDeposit:" + isInitialDepositNew;
                                        oldContractTransactionString += ", IsInitialDeposit:" + isInitialDepositOld;
                                    }

                                    string canReleaseNew = contractTransactionNew.CanRelease != null ? Convert.ToString(contractTransactionNew.CanRelease) : "";
                                    string canReleaseOld = contractTransactionOld.CanRelease != null ? Convert.ToString(contractTransactionOld.CanRelease) : "";
                                    if (!string.Equals(canReleaseNew, canReleaseOld))
                                    {
                                        newContractTransactionString += ", CanRelease:" + canReleaseNew;
                                        oldContractTransactionString += ", CanRelease:" + canReleaseOld;
                                    }


                                    string expensePaymentIdNew = contractTransactionNew.ExpensePaymentId != null && contractTransactionNew.ExpensePaymentId.HasValue ? Convert.ToString(contractTransactionNew.ExpensePaymentId) : "";
                                    string expensePaymentIdOld = contractTransactionOld.ExpensePaymentId != null && contractTransactionOld.ExpensePaymentId.HasValue ? Convert.ToString(contractTransactionOld.ExpensePaymentId) : "";
                                    if (!string.Equals(expensePaymentIdNew, expensePaymentIdOld))
                                    {
                                        newContractTransactionString += ", ExpensePaymentId:" + expensePaymentIdNew;
                                        oldContractTransactionString += ", ExpensePaymentId:" + expensePaymentIdOld;
                                    }

                                    string expensePaymentStatusIdNew = contractTransactionNew.ExpensePaymentStatusId != null && contractTransactionNew.ExpensePaymentStatusId.HasValue ? Convert.ToString(contractTransactionNew.ExpensePaymentStatusId) : "";
                                    string expensePaymentStatusIdOld = contractTransactionOld.ExpensePaymentStatusId != null && contractTransactionOld.ExpensePaymentStatusId.HasValue ? Convert.ToString(contractTransactionOld.ExpensePaymentStatusId) : "";
                                    if (!string.Equals(expensePaymentStatusIdNew, expensePaymentStatusIdOld))
                                    {
                                        newContractTransactionString += ", ExpensePaymentStatusId:" + expensePaymentStatusIdNew;
                                        oldContractTransactionString += ", ExpensePaymentStatusId:" + expensePaymentStatusIdOld;
                                    }

                                    string isIncomeNew = contractTransactionNew.IsIncome != null ? Convert.ToString(contractTransactionNew.IsIncome) : "";
                                    string isIncomeOld = contractTransactionOld.IsIncome != null ? Convert.ToString(contractTransactionOld.IsIncome) : "";
                                    if (!string.Equals(isIncomeNew, isIncomeOld))
                                    {
                                        newContractTransactionString += ", IsIncome:" + isIncomeNew;
                                        oldContractTransactionString += ", IsIncome:" + isIncomeOld;
                                    }

                                    string dueAmountNew = contractTransactionNew.DueAmount != null ? Convert.ToString(contractTransactionNew.DueAmount.ToString("f2")) : "0.00";
                                    string dueAmountOld = contractTransactionOld.DueAmount != null ? Convert.ToString(contractTransactionOld.DueAmount.ToString("f2")) : "0.00";
                                    if (!string.Equals(dueAmountNew, dueAmountOld))
                                    {
                                        newContractTransactionString += ", DueAmount:" + dueAmountNew;
                                        oldContractTransactionString += ", DueAmount:" + dueAmountOld;
                                    }

                                    string hasPendingExpensePaymentNew = contractTransactionNew.HasPendingExpensePayment != null ? Convert.ToString(contractTransactionNew.HasPendingExpensePayment) : "";
                                    string hasPendingExpensePaymentOld = contractTransactionOld.HasPendingExpensePayment != null ? Convert.ToString(contractTransactionOld.HasPendingExpensePayment) : "";

                                    if (!string.Equals(hasPendingExpensePaymentNew, hasPendingExpensePaymentOld))
                                    {
                                        newContractTransactionString += ", HasPendingExpensePayment:" + hasPendingExpensePaymentNew;
                                        oldContractTransactionString += ", HasPendingExpensePayment:" + hasPendingExpensePaymentOld;
                                    }
                                    string hasPostedExpensePaymentNew = contractTransactionNew.HasPostedExpensePayment != null ? Convert.ToString(contractTransactionNew.HasPostedExpensePayment) : "";
                                    string hasPostedExpensePaymentOld = contractTransactionOld.HasPostedExpensePayment != null ? Convert.ToString(contractTransactionOld.HasPostedExpensePayment) : "";

                                    if (!string.Equals(hasPostedExpensePaymentNew, hasPostedExpensePaymentOld))
                                    {
                                        newContractTransactionString += ", HasPostedExpensePayment:" + hasPostedExpensePaymentNew;
                                        oldContractTransactionString += ", HasPostedExpensePayment:" + hasPostedExpensePaymentOld;
                                    }

                                    if (!string.Equals(newContractTransactionString, oldContractTransactionString))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractTransaction Details",
                                            Old = oldContractTransactionString,
                                            New = newContractTransactionString,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }
                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }

                                index++;
                            }
                        }
                        else

                        {
                            int index = 0;
                            foreach (var i in contractTransactionsOld)
                            {
                                var contractTransactionOld = i;
                                if (contractTransactionOld == null)
                                {
                                    contractTransactionOld = new ContractTransactionDto();
                                }
                                var contractTransactionNew = new ContractTransactionDto();
                                try
                                {
                                    contractTransactionNew = contractTransactionsNew[index];
                                }
                                catch { contractTransactionNew = new ContractTransactionDto(); }



                                try
                                {


                                    string newContractTransactionString = string.Empty;
                                    string oldContractTransactionString = string.Empty;

                                    string escrowAmountNew = contractTransactionNew.EscrowAmount != null ? Convert.ToString(contractTransactionNew.EscrowAmount.ToString("f2")) : "0.00";
                                    string escrowAmountOld = contractTransactionOld.EscrowAmount != null ? Convert.ToString(contractTransactionOld.EscrowAmount.ToString("f2")) : "0.00";
                                    if (!string.Equals(escrowAmountNew, escrowAmountOld))
                                    {
                                        newContractTransactionString += ", EscrowAmount:" + escrowAmountNew;
                                        oldContractTransactionString += ", EscrowAmount:" + escrowAmountNew;
                                    }

                                    string artistIdNew = contractTransactionNew.ArtistId != null && contractTransactionNew.ArtistId.HasValue ? Convert.ToString(contractTransactionNew.ArtistId.Value) : "";
                                    string artistIdOld = contractTransactionOld.ArtistId != null && contractTransactionOld.ArtistId.HasValue ? Convert.ToString(contractTransactionOld.ArtistId.Value) : "";
                                    if (!string.Equals(artistIdNew, artistIdOld))
                                    {
                                        newContractTransactionString += ", ArtistId:" + artistIdNew;
                                        oldContractTransactionString += ", ArtistId:" + artistIdOld;
                                    }

                                    string vendorIdNew = contractTransactionNew.VendorId != null ? Convert.ToString(contractTransactionNew.VendorId) : "";
                                    string vendorIdOld = contractTransactionOld.VendorId != null ? Convert.ToString(contractTransactionOld.VendorId) : "";
                                    if (!string.Equals(vendorIdNew, vendorIdOld))
                                    {
                                        newContractTransactionString += ", VendorId:" + vendorIdNew;
                                        oldContractTransactionString += ", VendorId:" + vendorIdOld;
                                    }

                                    string resellerIdNew = contractTransactionNew.ResellerId != null ? Convert.ToString(contractTransactionNew.ResellerId) : "";
                                    string resellerIdOld = contractTransactionOld.ResellerId != null ? Convert.ToString(contractTransactionOld.ResellerId) : "";
                                    if (!string.Equals(resellerIdNew, resellerIdOld))
                                    {
                                        newContractTransactionString += ", ResellerId:" + resellerIdNew;
                                        oldContractTransactionString += ", ResellerId:" + resellerIdOld;
                                    }

                                    string lineOfBusinessIdNew = contractTransactionNew.LineOfBusinessId != null && contractTransactionNew.LineOfBusinessId.HasValue ? Convert.ToString(contractTransactionNew.LineOfBusinessId.Value) : "";
                                    string lineOfBusinessIdOld = contractTransactionOld.LineOfBusinessId != null && contractTransactionOld.LineOfBusinessId.HasValue ? Convert.ToString(contractTransactionOld.LineOfBusinessId.Value) : "";
                                    if (!string.Equals(resellerIdNew, resellerIdOld))
                                    {
                                        newContractTransactionString += ", LineOfBusinessId:" + lineOfBusinessIdNew;
                                        oldContractTransactionString += ", LineOfBusinessId:" + lineOfBusinessIdOld;
                                    }

                                    string agentIdNew = contractTransactionNew.AgentId != null && contractTransactionNew.AgentId.HasValue ? Convert.ToString(contractTransactionNew.AgentId.Value) : "";
                                    string agentIdOld = contractTransactionOld.AgentId != null && contractTransactionOld.AgentId.HasValue ? Convert.ToString(contractTransactionOld.AgentId.Value) : "";
                                    if (!string.Equals(agentIdNew, agentIdOld))
                                    {
                                        newContractTransactionString += ", AgentId:" + agentIdNew;
                                        oldContractTransactionString += ", AgentId:" + agentIdOld;
                                    }


                                    string officeIdNew = contractTransactionNew.OfficeId != null && contractTransactionNew.OfficeId.HasValue ? Convert.ToString(contractTransactionNew.OfficeId.Value) : "";
                                    string officeIdOld = contractTransactionOld.OfficeId != null && contractTransactionOld.OfficeId.HasValue ? Convert.ToString(contractTransactionOld.OfficeId.Value) : "";
                                    if (!string.Equals(officeIdNew, officeIdOld))
                                    {
                                        newContractTransactionString += ", OfficeId:" + officeIdNew;
                                        oldContractTransactionString += ", OfficeId:" + officeIdOld;
                                    }

                                    string contractEntityIdNew = contractTransactionNew.ContractEntityId != null ? Convert.ToString(contractTransactionNew.ContractEntityId) : "";
                                    string contractEntityIdOld = contractTransactionOld.ContractEntityId != null ? Convert.ToString(contractTransactionOld.ContractEntityId) : "";
                                    if (!string.Equals(contractEntityIdNew, contractEntityIdOld))
                                    {
                                        newContractTransactionString += ", ContractEntityId:" + contractEntityIdNew;
                                        oldContractTransactionString += ", ContractEntityId:" + contractEntityIdOld;
                                    }

                                    string contractEntityTypeIdNew = contractTransactionNew.ContractEntityTypeId != null ? Convert.ToString(contractTransactionNew.ContractEntityTypeId) : "";
                                    string contractEntityTypeIdOld = contractTransactionOld.ContractEntityTypeId != null ? Convert.ToString(contractTransactionOld.ContractEntityTypeId) : "";
                                    if (!string.Equals(contractEntityTypeIdNew, contractEntityTypeIdOld))
                                    {
                                        newContractTransactionString += ", ContractEntityTypeId:" + contractEntityTypeIdNew;
                                        oldContractTransactionString += ", ContractEntityTypeId:" + contractEntityTypeIdOld;
                                    }

                                    string contractTransactionTypeIdNew = contractTransactionNew.ContractTransactionTypeId != null ? Convert.ToString(contractTransactionNew.ContractTransactionTypeId) : "";
                                    string contractTransactionTypeIdOld = contractTransactionOld.ContractTransactionTypeId != null ? Convert.ToString(contractTransactionOld.ContractTransactionTypeId) : "";
                                    if (!string.Equals(contractTransactionTypeIdNew, contractTransactionTypeIdOld))
                                    {
                                        newContractTransactionString += ", ContractTransactionTypeId:" + contractTransactionTypeIdNew;
                                        oldContractTransactionString += ", ContractTransactionTypeId:" + contractTransactionTypeIdOld;
                                    }




                                    string payeeNameNew = contractTransactionNew.PayeeName != null ? Convert.ToString(contractTransactionNew.PayeeName) : "";
                                    string payeeNameOld = contractTransactionOld.PayeeName != null ? Convert.ToString(contractTransactionOld.PayeeName) : "";
                                    if (!string.Equals(payeeNameNew, payeeNameOld))
                                    {
                                        newContractTransactionString += ", PayeeName:" + payeeNameNew;
                                        oldContractTransactionString += ", PayeeName:" + payeeNameOld;
                                    }

                                    string referenceNumberNew = contractTransactionNew.ReferenceNumber != null ? Convert.ToString(contractTransactionNew.ReferenceNumber) : "";
                                    string referenceNumberOld = contractTransactionOld.ReferenceNumber != null ? Convert.ToString(contractTransactionOld.ReferenceNumber) : "";
                                    if (!string.Equals(referenceNumberNew, referenceNumberOld))
                                    {
                                        newContractTransactionString += ", ReferenceNumber:" + referenceNumberNew;
                                        oldContractTransactionString += ", ReferenceNumber:" + referenceNumberOld;
                                    }

                                    string isExpenseNew = contractTransactionNew.IsExpense != null ? Convert.ToString(contractTransactionNew.IsExpense) : "";
                                    string isExpenseOld = contractTransactionOld.IsExpense != null ? Convert.ToString(contractTransactionOld.IsExpense) : "";
                                    if (!string.Equals(isExpenseNew, isExpenseOld))
                                    {
                                        newContractTransactionString += ", IsExpense:" + isExpenseNew;
                                        oldContractTransactionString += ", IsExpense:" + isExpenseOld;
                                    }

                                    string dueDateNew = contractTransactionNew.DueDate != null && contractTransactionNew.DueDate.HasValue ? Convert.ToString(contractTransactionNew.DueDate.Value) : "";
                                    string dueDateOld = contractTransactionOld.DueDate != null && contractTransactionOld.DueDate.HasValue ? Convert.ToString(contractTransactionOld.DueDate.Value) : "";
                                    if (!string.Equals(dueDateNew, dueDateOld))
                                    {
                                        newContractTransactionString += ", DueDate:" + dueDateNew;
                                        oldContractTransactionString += ", DueDate:" + dueDateOld;
                                    }

                                    string requiredAmountNew = contractTransactionNew.RequiredAmount != null && contractTransactionNew.RequiredAmount.HasValue ? Convert.ToString(contractTransactionNew.RequiredAmount.Value.ToString("f2")) : "0.00";
                                    string requiredAmountOld = contractTransactionOld.RequiredAmount != null && contractTransactionOld.RequiredAmount.HasValue ? Convert.ToString(contractTransactionOld.RequiredAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(requiredAmountNew, requiredAmountOld))
                                    {
                                        newContractTransactionString += ", RequiredAmount:" + requiredAmountNew;
                                        oldContractTransactionString += ", RequiredAmount:" + requiredAmountOld;
                                    }

                                    string originalRequiredAmountNew = contractTransactionNew.OriginalRequiredAmount != null && contractTransactionNew.OriginalRequiredAmount.HasValue ? Convert.ToString(contractTransactionNew.OriginalRequiredAmount.Value.ToString("f2")) : "0.00";
                                    string originalRequiredAmountOld = contractTransactionOld.OriginalRequiredAmount != null && contractTransactionOld.OriginalRequiredAmount.HasValue ? Convert.ToString(contractTransactionOld.OriginalRequiredAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(originalRequiredAmountNew, originalRequiredAmountOld))
                                    {
                                        newContractTransactionString += ", OriginalRequiredAmount:" + originalRequiredAmountNew;
                                        oldContractTransactionString += ", OriginalRequiredAmount:" + originalRequiredAmountOld;
                                    }

                                    string requiredPercentageNew = contractTransactionNew.RequiredPercentage != null && contractTransactionNew.RequiredPercentage.HasValue ? Convert.ToString(contractTransactionNew.RequiredPercentage.Value.ToString("f2")) : "0.00";
                                    string requiredPercentageOld = contractTransactionOld.RequiredPercentage != null && contractTransactionOld.RequiredPercentage.HasValue ? Convert.ToString(contractTransactionOld.RequiredPercentage.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(requiredPercentageNew, requiredPercentageOld))
                                    {
                                        newContractTransactionString += ", RequiredPercentage:" + requiredPercentageNew;
                                        oldContractTransactionString += ", RequiredPercentage:" + requiredPercentageOld;
                                    }

                                    string paidDateNew = contractTransactionNew.PaidDate != null && contractTransactionNew.PaidDate.HasValue ? Convert.ToString(contractTransactionNew.PaidDate.Value) : "";
                                    string paidDateOld = contractTransactionOld.PaidDate != null && contractTransactionOld.PaidDate.HasValue ? Convert.ToString(contractTransactionOld.PaidDate.Value) : "";
                                    if (!string.Equals(paidDateNew, paidDateOld))
                                    {
                                        newContractTransactionString += ", PaidDate:" + paidDateNew;
                                        oldContractTransactionString += ", PaidDate:" + paidDateOld;
                                    }

                                    string paidAmountNew = contractTransactionNew.PaidAmount != null && contractTransactionNew.PaidAmount.HasValue ? Convert.ToString(contractTransactionNew.PaidAmount.Value.ToString("f2")) : "0.00";
                                    string paidAmountOld = contractTransactionOld.PaidAmount != null && contractTransactionOld.PaidAmount.HasValue ? Convert.ToString(contractTransactionOld.PaidAmount.Value.ToString("f2")) : "0.00";
                                    if (!string.Equals(paidAmountNew, paidAmountOld))
                                    {
                                        newContractTransactionString += ", PaidAmount:" + paidAmountNew;
                                        oldContractTransactionString += ", PaidAmount:" + paidAmountOld;
                                    }

                                    string notesNew = contractTransactionNew.Notes != null ? Convert.ToString(contractTransactionNew.Notes) : "";
                                    string notesOld = contractTransactionOld.Notes != null ? Convert.ToString(contractTransactionOld.Notes) : "";
                                    if (!string.Equals(notesNew, notesOld))
                                    {
                                        newContractTransactionString += ", Notes:" + notesNew;
                                        oldContractTransactionString += ", Notes:" + notesOld;
                                    }

                                    string isInitialDepositNew = contractTransactionNew.IsInitialDeposit != null ? Convert.ToString(contractTransactionNew.IsInitialDeposit) : "";
                                    string isInitialDepositOld = contractTransactionOld.IsInitialDeposit != null ? Convert.ToString(contractTransactionOld.IsInitialDeposit) : "";
                                    if (!string.Equals(isInitialDepositNew, isInitialDepositOld))
                                    {
                                        newContractTransactionString += ", IsInitialDeposit:" + isInitialDepositNew;
                                        oldContractTransactionString += ", IsInitialDeposit:" + isInitialDepositOld;
                                    }

                                    string canReleaseNew = contractTransactionNew.CanRelease != null ? Convert.ToString(contractTransactionNew.CanRelease) : "";
                                    string canReleaseOld = contractTransactionOld.CanRelease != null ? Convert.ToString(contractTransactionOld.CanRelease) : "";
                                    if (!string.Equals(canReleaseNew, canReleaseOld))
                                    {
                                        newContractTransactionString += ", CanRelease:" + canReleaseNew;
                                        oldContractTransactionString += ", CanRelease:" + canReleaseOld;
                                    }


                                    string expensePaymentIdNew = contractTransactionNew.ExpensePaymentId != null && contractTransactionNew.ExpensePaymentId.HasValue ? Convert.ToString(contractTransactionNew.ExpensePaymentId) : "";
                                    string expensePaymentIdOld = contractTransactionOld.ExpensePaymentId != null && contractTransactionOld.ExpensePaymentId.HasValue ? Convert.ToString(contractTransactionOld.ExpensePaymentId) : "";
                                    if (!string.Equals(expensePaymentIdNew, expensePaymentIdOld))
                                    {
                                        newContractTransactionString += ", ExpensePaymentId:" + expensePaymentIdNew;
                                        oldContractTransactionString += ", ExpensePaymentId:" + expensePaymentIdOld;
                                    }

                                    string expensePaymentStatusIdNew = contractTransactionNew.ExpensePaymentStatusId != null && contractTransactionNew.ExpensePaymentStatusId.HasValue ? Convert.ToString(contractTransactionNew.ExpensePaymentStatusId) : "";
                                    string expensePaymentStatusIdOld = contractTransactionOld.ExpensePaymentStatusId != null && contractTransactionOld.ExpensePaymentStatusId.HasValue ? Convert.ToString(contractTransactionOld.ExpensePaymentStatusId) : "";
                                    if (!string.Equals(expensePaymentStatusIdNew, expensePaymentStatusIdOld))
                                    {
                                        newContractTransactionString += ", ExpensePaymentStatusId:" + expensePaymentStatusIdNew;
                                        oldContractTransactionString += ", ExpensePaymentStatusId:" + expensePaymentStatusIdOld;
                                    }

                                    string isIncomeNew = contractTransactionNew.IsIncome != null ? Convert.ToString(contractTransactionNew.IsIncome) : "";
                                    string isIncomeOld = contractTransactionOld.IsIncome != null ? Convert.ToString(contractTransactionOld.IsIncome) : "";
                                    if (!string.Equals(isIncomeNew, isIncomeOld))
                                    {
                                        newContractTransactionString += ", IsIncome:" + isIncomeNew;
                                        oldContractTransactionString += ", IsIncome:" + isIncomeOld;
                                    }

                                    string dueAmountNew = contractTransactionNew.DueAmount != null ? Convert.ToString(contractTransactionNew.DueAmount.ToString("f2")) : "0.00";
                                    string dueAmountOld = contractTransactionOld.DueAmount != null ? Convert.ToString(contractTransactionOld.DueAmount.ToString("f2")) : "0.00";
                                    if (!string.Equals(dueAmountNew, dueAmountOld))
                                    {
                                        newContractTransactionString += ", DueAmount:" + dueAmountNew;
                                        oldContractTransactionString += ", DueAmount:" + dueAmountOld;
                                    }

                                    string hasPendingExpensePaymentNew = contractTransactionNew.HasPendingExpensePayment != null ? Convert.ToString(contractTransactionNew.HasPendingExpensePayment) : "";
                                    string hasPendingExpensePaymentOld = contractTransactionOld.HasPendingExpensePayment != null ? Convert.ToString(contractTransactionOld.HasPendingExpensePayment) : "";

                                    if (!string.Equals(hasPendingExpensePaymentNew, hasPendingExpensePaymentOld))
                                    {
                                        newContractTransactionString += ", HasPendingExpensePayment:" + hasPendingExpensePaymentNew;
                                        oldContractTransactionString += ", HasPendingExpensePayment:" + hasPendingExpensePaymentOld;
                                    }
                                    string hasPostedExpensePaymentNew = contractTransactionNew.HasPostedExpensePayment != null ? Convert.ToString(contractTransactionNew.HasPostedExpensePayment) : "";
                                    string hasPostedExpensePaymentOld = contractTransactionOld.HasPostedExpensePayment != null ? Convert.ToString(contractTransactionOld.HasPostedExpensePayment) : "";

                                    if (!string.Equals(hasPostedExpensePaymentNew, hasPostedExpensePaymentOld))
                                    {
                                        newContractTransactionString += ", HasPostedExpensePayment:" + hasPostedExpensePaymentNew;
                                        oldContractTransactionString += ", HasPostedExpensePayment:" + hasPostedExpensePaymentOld;
                                    }


                                    if (!string.Equals(newContractTransactionString, oldContractTransactionString))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractTransaction Details",
                                            Old = oldContractTransactionString,
                                            New = newContractTransactionString,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }
                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }
                                index++;
                            }
                        }


                        if (contractTransactionDtoDeletes != null && contractTransactionDtoDeletes.Any())
                        {
                            foreach (var i in contractTransactionDtoDeletes)
                            {

                                try
                                {

                                    string newContractTransactionString = string.Empty;
                                    string oldContractTransactionString = string.Empty;

                                    string escrowAmountOld = i.EscrowAmount != null ? Convert.ToString(i.EscrowAmount) : "";
                                    oldContractTransactionString += ", EscrowAmount:" + escrowAmountOld;


                                    string artistIdOld = i.ArtistId != null ? Convert.ToString(i.ArtistId.Value) : "";
                                    oldContractTransactionString += ", ArtistId:" + artistIdOld;


                                    string vendorIdOld = i.VendorId != null ? Convert.ToString(i.VendorId) : "";
                                    oldContractTransactionString += ", VendorId:" + vendorIdOld;



                                    string resellerIdOld = i.ResellerId != null ? Convert.ToString(i.ResellerId) : "";
                                    oldContractTransactionString += ", ResellerId:" + resellerIdOld;


                                    string lineOfBusinessIdOld = i.LineOfBusinessId != null ? Convert.ToString(i.LineOfBusinessId.Value) : "";
                                    oldContractTransactionString += ", LineOfBusinessId:" + lineOfBusinessIdOld;


                                    string agentIdOld = i.AgentId != null ? Convert.ToString(i.AgentId.Value) : "";
                                    oldContractTransactionString += ", AgentId:" + agentIdOld;



                                    string officeIdOld = i.OfficeId != null ? Convert.ToString(i.OfficeId.Value) : "";
                                    oldContractTransactionString += ", OfficeId:" + officeIdOld;


                                    string contractEntityIdOld = i.ContractEntityId != null ? Convert.ToString(i.ContractEntityId) : "";
                                    oldContractTransactionString += ", ContractEntityId:" + contractEntityIdOld;

                                    string contractEntityTypeIdOld = i.ContractEntityTypeId != null ? Convert.ToString(i.ContractEntityTypeId) : "";
                                    oldContractTransactionString += ", ContractEntityTypeId:" + contractEntityTypeIdOld;

                                    string contractTransactionTypeIdOld = i.ContractTransactionTypeId != null ? Convert.ToString(i.ContractTransactionTypeId) : "";
                                    oldContractTransactionString += ", ContractTransactionTypeId:" + contractTransactionTypeIdOld;


                                    string payeeNameOld = i.PayeeName != null ? Convert.ToString(i.PayeeName) : "";
                                    oldContractTransactionString += ", PayeeName:" + payeeNameOld;


                                    string referenceNumberOld = i.ReferenceNumber != null ? Convert.ToString(i.ReferenceNumber) : "";
                                    oldContractTransactionString += ", ReferenceNumber:" + referenceNumberOld;


                                    string isExpenseOld = i.IsExpense != null ? Convert.ToString(i.IsExpense) : "";
                                    oldContractTransactionString += ", IsExpense:" + isExpenseOld;


                                    string dueDateOld = i.DueDate != null ? Convert.ToString(i.DueDate.Value) : "";
                                    oldContractTransactionString += ", DueDate:" + dueDateOld;


                                    string requiredAmountOld = i.RequiredAmount != null ? Convert.ToString(i.RequiredAmount.Value.ToString("f2")) : "0.00";
                                    oldContractTransactionString += ", RequiredAmount:" + requiredAmountOld;


                                    string originalRequiredAmountOld = i.OriginalRequiredAmount != null ? Convert.ToString(i.OriginalRequiredAmount.Value.ToString("f2")) : "0.00";
                                    oldContractTransactionString += ", OriginalRequiredAmount:" + originalRequiredAmountOld;


                                    string requiredPercentageOld = i.RequiredPercentage != null ? Convert.ToString(i.RequiredPercentage.Value.ToString("f2")) : "0.00";
                                    oldContractTransactionString += ", RequiredPercentage:" + requiredPercentageOld;


                                    string paidDateOld = i.PaidDate != null ? Convert.ToString(i.PaidDate.Value) : "";
                                    oldContractTransactionString += ", PaidDate:" + paidDateOld;


                                    string paidAmountOld = i.PaidAmount != null ? Convert.ToString(i.PaidAmount.Value) : "";
                                    oldContractTransactionString += ", PaidAmount:" + paidAmountOld;


                                    string notesOld = i.Notes != null ? Convert.ToString(i.Notes) : "";
                                    oldContractTransactionString += ", Notes:" + notesOld;


                                    string isInitialDepositOld = i.IsInitialDeposit != null ? Convert.ToString(i.IsInitialDeposit) : "";
                                    oldContractTransactionString += ", IsInitialDeposit:" + isInitialDepositOld;


                                    string canReleaseOld = i.CanRelease != null ? Convert.ToString(i.CanRelease) : "";
                                    oldContractTransactionString += ", CanRelease:" + canReleaseOld;


                                    string expensePaymentIdOld = i.ExpensePaymentId != null ? Convert.ToString(i.ExpensePaymentId) : "";
                                    oldContractTransactionString += ", ExpensePaymentId:" + expensePaymentIdOld;

                                    string expensePaymentStatusIdOld = i.ExpensePaymentStatusId != null ? Convert.ToString(i.ExpensePaymentStatusId) : "";
                                    oldContractTransactionString += ", ExpensePaymentStatusId:" + expensePaymentStatusIdOld;


                                    string isIncomeOld = i.IsIncome != null ? Convert.ToString(i.IsIncome) : "";
                                    oldContractTransactionString += ", IsIncome:" + isIncomeOld;


                                    string dueAmountOld = i.DueAmount != null ? Convert.ToString(i.DueAmount) : "";
                                    oldContractTransactionString += ", DueAmount:" + dueAmountOld;


                                    string hasPendingExpensePaymentOld = i.HasPendingExpensePayment != null ? Convert.ToString(i.HasPendingExpensePayment) : "";
                                    oldContractTransactionString += ", HasPendingExpensePayment:" + hasPendingExpensePaymentOld;

                                    string hasPostedExpensePaymentOld = i.HasPostedExpensePayment != null ? Convert.ToString(i.HasPostedExpensePayment) : "";

                                    oldContractTransactionString += ", HasPostedExpensePayment:" + hasPostedExpensePaymentOld;








                                    if (!string.Equals(newContractTransactionString, oldContractTransactionString))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractTransaction Details",
                                            Old = oldContractTransactionString,
                                            New = "Deleted",
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }
                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }

                            }
                        }


                    }
                }


                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }


        public async Task Step6UpdateTerms(ContractDto contractNew, ContractDto contractOld, List<ContractTermDto> contractTermsForDeletes, IPrincipal user)
        {
            try
            {
                string datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                List<ContractChangesDto> contractChanges = new List<ContractChangesDto>();

                if (contractNew != null && contractOld != null)
                {
                    string termsNew = contractNew.Terms != null ? Convert.ToString(contractNew.Terms) : "";
                    string termsOld = contractOld.Terms != null ? Convert.ToString(contractOld.Terms) : "";
                    if (!string.Equals(termsNew, termsOld))
                    {
                        contractChanges.Add(new ContractChangesDto()
                        {
                            Name = "Contract Terms",
                            Old = termsOld,
                            New = termsNew,
                            Createddate = datetime,
                            Createdby = user.Identity.Name,
                            IsPDFChange = true
                        });
                    }

                    var contractDocumentsOld = contractOld.ContractDocuments.Any() ? contractOld.ContractDocuments.OrderBy(a => a.OriginalFileName).ToList() : (new List<ContractDocumentDto>());
                    var contractDocumentsNew = contractNew.ContractDocuments.Any() ? contractNew.ContractDocuments.OrderBy(a => a.OriginalFileName).ToList() : (new List<ContractDocumentDto>());

                    if (contractDocumentsNew != null || contractDocumentsOld != null)
                    {
                        if (!contractDocumentsNew.Any())
                        {
                            contractDocumentsNew = new List<ContractDocumentDto>();
                        }

                        if (!contractDocumentsOld.Any())
                        {
                            contractDocumentsOld = new List<ContractDocumentDto>();
                        }


                        bool isDocumentNewMore = false;

                        if (contractDocumentsNew.Count >= contractDocumentsOld.Count)
                        {
                            isDocumentNewMore = true;
                        }


                        if (isDocumentNewMore)
                        {
                            int index = 0;
                            foreach (var i in contractDocumentsNew)
                            {
                                var contractDocumentNew = i;
                                if (contractDocumentNew == null)
                                {
                                    contractDocumentNew = new ContractDocumentDto();
                                }
                                var contractDocumentOld = new ContractDocumentDto();
                                try
                                {
                                    contractDocumentOld = contractDocumentsOld[index];
                                }
                                catch { contractDocumentOld = new ContractDocumentDto(); }



                                try
                                {

                                    string contractDocumentIdNew = contractDocumentNew.ContractDocumentId != null ? Convert.ToString(contractDocumentNew.ContractDocumentId) : "";
                                    string contractDocumentIdOld = contractDocumentOld.ContractDocumentId != null ? Convert.ToString(contractDocumentOld.ContractDocumentId) : "";
                                    if (!string.Equals(contractDocumentIdNew, contractDocumentIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractDocumentId",
                                            Old = contractDocumentIdOld,
                                            New = contractDocumentIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string documentIdNew = contractDocumentNew.DocumentId != null ? Convert.ToString(contractDocumentNew.DocumentId) : "";
                                    string documentIdOld = contractDocumentOld.DocumentId != null ? Convert.ToString(contractDocumentOld.DocumentId) : "";
                                    if (!string.Equals(documentIdNew, documentIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "DocumentId",
                                            Old = documentIdOld,
                                            New = documentIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string isRiderNew = contractDocumentNew.IsRider != null ? Convert.ToString(contractDocumentNew.IsRider) : "";
                                    string isRiderOld = contractDocumentOld.IsRider != null ? Convert.ToString(contractDocumentOld.IsRider) : "";
                                    if (!string.Equals(isRiderNew, isRiderOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsRider",
                                            Old = isRiderOld,
                                            New = isRiderNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalEntityIdNew = contractDocumentNew.OriginalEntityId != null ? Convert.ToString(contractDocumentNew.OriginalEntityId) : "";
                                    string originalEntityIdOld = contractDocumentOld.OriginalEntityId != null ? Convert.ToString(contractDocumentOld.OriginalEntityId) : "";
                                    if (!string.Equals(originalEntityIdNew, originalEntityIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "OriginalEntityId",
                                            Old = originalEntityIdOld,
                                            New = originalEntityIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalEntityTypeIdNew = contractDocumentNew.OriginalEntityTypeId != null ? Convert.ToString(contractDocumentNew.OriginalEntityTypeId) : "";
                                    string originalEntityTypeIdOld = contractDocumentOld.OriginalEntityTypeId != null ? Convert.ToString(contractDocumentOld.OriginalEntityTypeId) : "";
                                    if (!string.Equals(originalEntityTypeIdNew, originalEntityTypeIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "OriginalEntityTypeId",
                                            Old = originalEntityTypeIdOld,
                                            New = originalEntityTypeIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }
                                    string isDeletedNew = contractDocumentNew.IsDeleted != null ? Convert.ToString(contractDocumentNew.IsDeleted) : "";
                                    string isDeletedOld = contractDocumentOld.IsDeleted != null ? Convert.ToString(contractDocumentOld.IsDeleted) : "";
                                    if (!string.Equals(isDeletedNew, isDeletedOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Document IsDeleted",
                                            Old = isDeletedOld,
                                            New = isDeletedNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalFileNameNew = contractDocumentNew.OriginalFileName != null ? Convert.ToString(contractDocumentNew.OriginalFileName) : "";
                                    string originalFileNameOld = contractDocumentOld.OriginalFileName != null ? Convert.ToString(contractDocumentOld.OriginalFileName) : "";
                                    if (!string.Equals(originalFileNameNew, originalFileNameOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Document OriginalFileName",
                                            Old = originalFileNameOld,
                                            New = originalFileNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }


                        }
                        else
                        {
                            int index = 0;
                            foreach (var i in contractDocumentsOld)
                            {
                                var contractDocumentOld = i;
                                if (contractDocumentOld == null)
                                {
                                    contractDocumentOld = new ContractDocumentDto();
                                }
                                var contractDocumentNew = new ContractDocumentDto();
                                try
                                {
                                    contractDocumentNew = contractDocumentsNew[index];
                                }
                                catch { contractDocumentNew = new ContractDocumentDto(); }



                                try
                                {

                                    string contractDocumentIdNew = contractDocumentNew.ContractDocumentId != null ? Convert.ToString(contractDocumentNew.ContractDocumentId) : "";
                                    string contractDocumentIdOld = contractDocumentOld.ContractDocumentId != null ? Convert.ToString(contractDocumentOld.ContractDocumentId) : "";
                                    if (!string.Equals(contractDocumentIdNew, contractDocumentIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractDocumentId",
                                            Old = contractDocumentIdOld,
                                            New = contractDocumentIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string documentIdNew = contractDocumentNew.DocumentId != null ? Convert.ToString(contractDocumentNew.DocumentId) : "";
                                    string documentIdOld = contractDocumentOld.DocumentId != null ? Convert.ToString(contractDocumentOld.DocumentId) : "";
                                    if (!string.Equals(documentIdNew, documentIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "DocumentId",
                                            Old = documentIdOld,
                                            New = documentIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string isRiderNew = contractDocumentNew.IsRider != null ? Convert.ToString(contractDocumentNew.IsRider) : "";
                                    string isRiderOld = contractDocumentOld.IsRider != null ? Convert.ToString(contractDocumentOld.IsRider) : "";
                                    if (!string.Equals(isRiderNew, isRiderOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "IsRider",
                                            Old = isRiderOld,
                                            New = isRiderNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalEntityIdNew = contractDocumentNew.OriginalEntityId != null ? Convert.ToString(contractDocumentNew.OriginalEntityId) : "";
                                    string originalEntityIdOld = contractDocumentOld.OriginalEntityId != null ? Convert.ToString(contractDocumentOld.OriginalEntityId) : "";
                                    if (!string.Equals(originalEntityIdNew, originalEntityIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "OriginalEntityId",
                                            Old = originalEntityIdOld,
                                            New = originalEntityIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalEntityTypeIdNew = contractDocumentNew.OriginalEntityTypeId != null ? Convert.ToString(contractDocumentNew.OriginalEntityTypeId) : "";
                                    string originalEntityTypeIdOld = contractDocumentOld.OriginalEntityTypeId != null ? Convert.ToString(contractDocumentOld.OriginalEntityTypeId) : "";
                                    if (!string.Equals(originalEntityTypeIdNew, originalEntityTypeIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "OriginalEntityTypeId",
                                            Old = originalEntityTypeIdOld,
                                            New = originalEntityTypeIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }
                                    string isDeletedNew = contractDocumentNew.IsDeleted != null ? Convert.ToString(contractDocumentNew.IsDeleted) : "";
                                    string isDeletedOld = contractDocumentOld.IsDeleted != null ? Convert.ToString(contractDocumentOld.IsDeleted) : "";
                                    if (!string.Equals(isDeletedNew, isDeletedOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Document IsDeleted",
                                            Old = isDeletedOld,
                                            New = isDeletedNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string originalFileNameNew = contractDocumentNew.OriginalFileName != null ? Convert.ToString(contractDocumentNew.OriginalFileName) : "";
                                    string originalFileNameOld = contractDocumentOld.OriginalFileName != null ? Convert.ToString(contractDocumentOld.OriginalFileName) : "";
                                    if (!string.Equals(originalFileNameNew, originalFileNameOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "Document OriginalFileName",
                                            Old = originalFileNameOld,
                                            New = originalFileNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }


                        }

                    }


                    var contractTermsOld = contractOld.ContractTerms.Any() ? contractOld.ContractTerms.OrderBy(a => a.TermName).ToList() : (new List<ContractTermDto>());
                    var contractTermsNew = contractNew.ContractTerms.Any() ? contractNew.ContractTerms.OrderBy(a => a.TermName).ToList() : (new List<ContractTermDto>());

                    if (contractTermsNew != null || contractTermsOld != null)
                    {
                        if (!contractTermsNew.Any())
                        {
                            contractTermsNew = new List<ContractTermDto>();
                        }

                        if (!contractTermsOld.Any())
                        {
                            contractTermsOld = new List<ContractTermDto>();
                        }


                        bool isTermNewMore = false;

                        if (contractTermsNew.Count >= contractTermsOld.Count)
                        {
                            isTermNewMore = true;
                        }


                        if (isTermNewMore)
                        {
                            int index = 0;
                            foreach (var i in contractTermsNew)
                            {
                                var contractTermNew = i;
                                if (contractTermNew == null)
                                {
                                    contractTermNew = new ContractTermDto();
                                }
                                var contractTermOld = new ContractTermDto();
                                try
                                {
                                    contractTermOld = contractTermsOld[index];
                                }
                                catch { contractTermOld = new ContractTermDto(); }



                                try
                                {
                                    string contractTermIdNew = contractTermNew.ContractTermId != null ? Convert.ToString(contractTermNew.ContractTermId) : "";
                                    string contractTermIdOld = contractTermOld.ContractTermId != null ? Convert.ToString(contractTermOld.ContractTermId) : "";
                                    if (!string.Equals(contractTermIdNew, contractTermIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractTermId",
                                            Old = contractTermIdOld,
                                            New = contractTermIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termIdNew = contractTermNew.TermId != null ? Convert.ToString(contractTermNew.TermId) : "";
                                    string termIdOld = contractTermOld.TermId != null ? Convert.ToString(contractTermOld.TermId) : "";
                                    if (!string.Equals(termIdNew, termIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermId",
                                            Old = termIdOld,
                                            New = termIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termNameNew = contractTermNew.TermName != null ? Convert.ToString(contractTermNew.TermName) : "";
                                    string termNameOld = contractTermOld.TermName != null ? Convert.ToString(contractTermOld.TermName) : "";
                                    if (!string.Equals(termNameNew, termNameOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermName",
                                            Old = termNameOld,
                                            New = termNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termTextNew = contractTermNew.TermText != null ? Convert.ToString(contractTermNew.TermText) : "";
                                    string termTextOld = contractTermOld.TermText != null ? Convert.ToString(contractTermOld.TermText) : "";
                                    if (!string.Equals(termTextNew, termTextOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermText",
                                            Old = termTextOld,
                                            New = termTextNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }


                        }
                        else
                        {
                            int index = 0;
                            foreach (var i in contractTermsOld)
                            {
                                var contractTermOld = i;
                                if (contractTermOld == null)
                                {
                                    contractTermOld = new ContractTermDto();
                                }
                                var contractTermNew = new ContractTermDto();
                                try
                                {
                                    contractTermNew = contractTermsNew[index];
                                }
                                catch { contractTermNew = new ContractTermDto(); }



                                try
                                {
                                    string contractTermIdNew = contractTermNew.ContractTermId != null ? Convert.ToString(contractTermNew.ContractTermId) : "";
                                    string contractTermIdOld = contractTermOld.ContractTermId != null ? Convert.ToString(contractTermOld.ContractTermId) : "";
                                    if (!string.Equals(contractTermIdNew, contractTermIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "ContractTermId",
                                            Old = contractTermIdOld,
                                            New = contractTermIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termIdNew = contractTermNew.TermId != null ? Convert.ToString(contractTermNew.TermId) : "";
                                    string termIdOld = contractTermOld.TermId != null ? Convert.ToString(contractTermOld.TermId) : "";
                                    if (!string.Equals(termIdNew, termIdOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermId",
                                            Old = termIdOld,
                                            New = termIdNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termNameNew = contractTermNew.TermName != null ? Convert.ToString(contractTermNew.TermName) : "";
                                    string termNameOld = contractTermOld.TermName != null ? Convert.ToString(contractTermOld.TermName) : "";
                                    if (!string.Equals(termNameNew, termNameOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermName",
                                            Old = termNameOld,
                                            New = termNameNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                    string termTextNew = contractTermNew.TermText != null ? Convert.ToString(contractTermNew.TermText) : "";
                                    string termTextOld = contractTermOld.TermText != null ? Convert.ToString(contractTermOld.TermText) : "";
                                    if (!string.Equals(termTextNew, termTextOld))
                                    {
                                        contractChanges.Add(new ContractChangesDto()
                                        {
                                            Name = "TermText",
                                            Old = termTextOld,
                                            New = termTextNew,
                                            Createddate = datetime,
                                            Createdby = user.Identity.Name,
                                            IsPDFChange = true
                                        });
                                    }

                                }
                                catch (Exception ex)
                                {

                                    Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    log.Error(ex.Message);
                                }


                                index++;
                            }

                        }

                    }


                }


                if (contractChanges.Any() && contractChanges.Count > 0)
                {
                    string json = Newtonsoft.Json.JsonConvert.SerializeObject(contractChanges);
                    bool isPDFChanges = contractChanges.Where(a => a.IsPDFChange).Any();
                    using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                    {
                        Dictionary<string, object> dictionary = new Dictionary<string, object>()
                        {
                            {"ContractId",contractNew.ContractId},
                            {"Json",json},
                            {"IsPDFChanges",isPDFChanges}
                        };
                        DynamicParameters parameters = new DynamicParameters(dictionary);
                        IDbConnection conn = sqlConnectionFactory.CreateConnection();
                        await conn.ExecuteAsync("Sp_Set_ContractChangesHistory", parameters, commandType: CommandType.StoredProcedure, commandTimeout: int.MaxValue);
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Close();
                        }
                    }

                }


            }
            catch (Exception ex)
            {

                Infinity.Mobius.Logging.Log4net.Log4netLogger log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex.Message);
            }
        }

    }
}
