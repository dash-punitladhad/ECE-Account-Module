﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class EntityHistoryLMDLogService : IEntityHistoryLMDLogService
	{
		public IUnitOfWork Context { get; private set; }
		public EntityHistoryLMDLogService(IUnitOfWork context)
		{
			Context = context;
		}

		public async Task CreateAsync(EntityHistoryLMDLogDto entityHistoryLMDLogDto, IPrincipal user)
		{
			this.Context.BeginTransaction();
			try
			{
				await this.Context.entityHistoryLMDLogDao.CreateAsync(entityHistoryLMDLogDto);
				this.Context.Commit();
			}
			catch(Exception ex)
			{
				this.Context.Rollback();
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<List<EntityHistoryLMDLogUserDto>> GetEntityHistoryLMDLogListAsync(int lMdId, bool isSystemAdmin)
		{
			try
			{
				return await this.Context.entityHistoryLMDLogDao.GetEntityHistoryLMDLogListAsync( lMdId,  isSystemAdmin);
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}
	}
}
