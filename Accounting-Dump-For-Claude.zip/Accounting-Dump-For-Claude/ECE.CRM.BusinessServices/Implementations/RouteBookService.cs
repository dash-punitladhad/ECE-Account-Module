﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class RouteBookService : IRouteBookService
    {
        public RouteBookService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<LocationDto>> GetPresentersWithinDistanceAsync(RouteBookSearchCriteriaDto dto)
        {
            return await this.Context.RouteBooks.GetPresentersWithinDistanceAsync(dto);
        }

        public async Task<List<LocationDto>> GetVenuesWithinDistanceAsync(RouteBookSearchCriteriaDto dto)
        {
            return await this.Context.RouteBooks.GetVenuesWithinDistanceAsync(dto);
        }

        public async Task<List<LocationDto>> GetLocationsBetweenDatesAsync(RouteBookSearchCriteriaDto dto)
        {
            return await this.Context.RouteBooks.GetLocationsBetweenDatesAsync(dto);
        }

        public async Task<List<RouteBookSearchResultsDto>> GetByCriteriaAsync(RouteBookSearchCriteriaDto criteria)
        {
            var results = await this.Context.RouteBooks.GetByCriteriaAsync(criteria);

            return results;
        }

        public async Task<List<RouteBookSearchResultsDto>> GetByGridIdAsync(int id)
        {
            var results = await this.Context.RouteBooks.GetByGridIdAsync(id);

            return results;
        }

        public async Task<List<RouteBookSearchResultsDto>> GetByOfficeIdAsync(int id)
        {
            var results = await this.Context.RouteBooks.GetByOfficeIdAsync(id);

            return results;
        }

        public async Task<List<RouteBookSearchResultsDto>> GetExclusiveAsync()
        {
            var results = await this.Context.RouteBooks.GetExclusiveAsync();

            return results;
        }

        public async Task<List<RouteBookSearchResultsDto>> GetMineAsync(int id)
        {
            var results = await this.Context.RouteBooks.GetMineAsync(id);

            return results;
        }

        public async Task<List<RouteBookSearchResultsDto>> GetRouteBookDatesAsync(List<RouteBookSearchResultsDto> searchResults, DateTime startDate, DateTime endDate)
        {
            var artistIds = searchResults.Select(x => x.ArtistId).ToList();

            var routeBookDates = await this.Context.RouteBooks.GetRouteBookDatesAsync(startDate, endDate, artistIds);

            foreach (var artist in searchResults)
            {
                var artistDates = routeBookDates.Where(x => x.ArtistId == artist.ArtistId).ToList();
                artist.ArtistDates = artistDates;
            }

            return searchResults;
        }

        public async Task<RouteBookSearchResultsDto> GetRouteBookDetailsAsync(RouteBookSearchResultsDto artist, int month, int year)
        {
            var startDate = new DateTime(year, month, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);
            var artistIds = new List<int>();

            artistIds.Add(artist.ArtistId);

            var routeBookDates = await this.Context.RouteBooks.GetRouteBookDatesAsync(startDate, endDate, artistIds);

            var artistDates = routeBookDates.Where(x => x.ArtistId == artist.ArtistId).ToList();
            artist.ArtistDates = artistDates;

            return artist;
        }

        public async Task<RouteBookSearchResultsDto> GetRouteBookDetailsArtistPortalAsync(RouteBookSearchResultsDto artist, int month, int year)
        {
            var startDate = new DateTime(year, month, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);
            var artistIds = new List<int>();

            artistIds.Add(artist.ArtistId);

            var routeBookDates = await this.Context.RouteBooks.GetRouteBookDatesArtistPortalAsync(startDate, endDate, artistIds);

            var artistDates = routeBookDates.Where(x => x.ArtistId == artist.ArtistId).ToList();
            artist.ArtistDates = artistDates;

            return artist;
        }

        public async Task<IList<EventDetailDto>> GetEventDetailAsync(int id, DateTime eventDate)
        {
            var results = await this.Context.RouteBooks.GetEventDetailAsync(id, eventDate);

            return results;
        }

        public async Task<IList<EventDetailDto>> GetEventDetailArtistPortalAsync(int id, DateTime eventDate)
        {
            var results = await this.Context.RouteBooks.GetEventDetailArtistPortalAsync(id, eventDate);

            return results;
        }

        public async Task AddArtistItemAsync(RouteBookArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);
                await this.Context.RouteBooks.AddArtistItemAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task CreateCustomGridAsync(RouteBookGridDto dto, List<RouteBookArtistDto> artistDtos, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.RouteBooks.CreateCustomGridAsync(dto);

                foreach (var artistDto in artistDtos)
                {
                    artistDto.RouteBookGridId = dto.RouteBookGridId;
                    await this.AddArtistsToGridAsync(artistDto, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task DeleteCustomGridAsync(int id, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.RouteBooks.DeleteCustomGridAsync(id, user.GetUserId());
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Error deleting Custom Grid", id, ex);
            }
        }

        public async Task AddArtistsToGridAsync(RouteBookArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);
                await this.Context.RouteBooks.AddArtistsToGridAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<List<RouteBookGridDto>> GetGridsForAgentAsync(int id)
        {
            var results = await this.Context.RouteBooks.GetGridsForAgentAsync(id);

            return results;
        }

        public async Task<string> GetByCriteriaExportAsync(RouteBookSearchCriteriaDto criteriaDto)
        {
            var results = await this.Context.RouteBooks.GetByCriteriaExportAsync(criteriaDto);

            return results;
        }
    }
}