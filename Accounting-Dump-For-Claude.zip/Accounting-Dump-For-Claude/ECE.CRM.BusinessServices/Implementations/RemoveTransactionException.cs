﻿namespace ECE.CRM.BusinessServices
{
    using System;

    public class RemoveTransactionException : Exception
    {
        public RemoveTransactionException(string message)
            : base(message)
        {
        }

        public RemoveTransactionException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
