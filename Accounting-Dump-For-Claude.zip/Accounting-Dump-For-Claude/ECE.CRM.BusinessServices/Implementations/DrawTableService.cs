﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class DrawTableService : IDrawTableService
	{
		public IUnitOfWork Context { get; private set; }
		public DrawTableService(IUnitOfWork context)
		{
			this.Context = context;
		}

		public async Task<List<LuQuarterDto>> GetAllQuarters()
		{
			var dto = await this.Context.DrawTableDao.GetAllQuarters();
			return dto;
		}

		public List<int> GetYears()
		{
			var years = this.Context.DrawTableDao.GetYears();
			return years;
		}

		public async Task<bool> AddDrawData(DrawTableDto drawTableDto, IPrincipal user)
		{
			drawTableDto.CreatedBy = user.GetUserId();
			drawTableDto.CreatedOn = DateTime.Now;
			if (drawTableDto.DrawID > 0)
			{
				drawTableDto.UpdatedBy = user.GetUserId();
				drawTableDto.UpdatedOn = DateTime.Now;
			}
			return await this.Context.DrawTableDao.AddDrawData(drawTableDto);
		}

		public async Task<List<AgentDrawTableDTO>> GetAgentDrawData(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.GetAgentDrawData(filterModel);
		}

		public async Task<decimal> GetAgentQuarterlyCommission(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.GetAgentQuarterlyCommission(filterModel);
		}

		public async Task<decimal> GetAgentStartingAmount(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.GetAgentStartingAmount(filterModel);
		}

		public async Task<PreviousDrawDto> GetAgentPreviousQuarterlyCommission(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.GetAgentPreviousQuarterlyCommission(filterModel);
		}

		public async Task<bool> SettleTransaction(DrawTableDto drawTableDto, IPrincipal user)
		{
			if (drawTableDto.DrawID > 0)
			{
				drawTableDto.UpdatedBy = user.GetUserId();
				drawTableDto.UpdatedOn = DateTime.Now;
				return await this.Context.DrawTableDao.SettleTransaction(drawTableDto);
			}
			else
			{
				return false;
			}
		}

		public async Task<AgentDrawTableDTO> CheckDrawData(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.CheckDrawData(filterModel);
		}

		public async Task<List<AgentYearlyDrawDTO>> GetAgentYearlyDrawData(AgentDrawFilterModel filterModel)
		{
			return await this.Context.DrawTableDao.GetAgentYearlyDrawData(filterModel);
		}

		public async Task<bool> DeleteDrawData(int drawID, IPrincipal user)
		{
			return await this.Context.DrawTableDao.DeleteDrawData(drawID, user.GetUserId());
		}

	}
}
