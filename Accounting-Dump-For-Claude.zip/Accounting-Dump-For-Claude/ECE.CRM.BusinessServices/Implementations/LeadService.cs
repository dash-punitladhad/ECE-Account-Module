﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;

    public class LeadService : ILeadService
    {
        private readonly IUserService _userService;
        private readonly ILookupService _lookupService;
        private readonly IAlertService _alertService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IArtistService _artistService;

        public LeadService(IUnitOfWork context,
                           IUserService userService,
                           ILookupService lookupService,
                           IAlertService alertService,
                           IEntityHistoryService entityHistoryService,
                           IArtistService artistService)
        {
            this.Context = context;

            this._userService = userService;
            this._lookupService = lookupService;
            this._alertService = alertService;
            this._entityHistoryService = entityHistoryService;
            this._artistService = artistService;
        }

        private enum MappedEventTypes
        {
            WeddingReception = 36,

            Unassigned = 99,

            AssociationConferenceConvention = 101,

            BarNightclub = 102,

            Corporate = 103,

            FairsFestivals = 104,

            PerformingArts = 105,

            PrivateSocial = 106,

            SchoolUniversity = 107
        }

        public IUnitOfWork Context { get; private set; }

        public static int? GetEventTypeFromJson(string eventTypeName)
        {
            if (string.IsNullOrWhiteSpace(eventTypeName))
            {
                return (int)MappedEventTypes.Unassigned;
            }

            switch (eventTypeName.ToUpper())
            {
                case "ASSOCIATION/CONFERENCE/CONVENTION":
                case "ASSOCIATION, CONFERENCE OR CONVENTION EVENT":
                    return (int)MappedEventTypes.AssociationConferenceConvention;

                case "BAR OR NIGHTCLUB EVENT":
                case "BAR/NIGHTCLUB":
                    return (int)MappedEventTypes.BarNightclub;

                case "CORPORATE EVENT":
                case "CORPORATE":
                    return (int)MappedEventTypes.Corporate;

                case "FAIR OR FESTIVAL":
                case "FAIRS/FESTIVALS":
                    return (int)MappedEventTypes.FairsFestivals;

                case "PERFORMING ARTS EVENT":
                case "PERFORMING ARTS":
                    return (int)MappedEventTypes.PerformingArts;

                case "PRIVATE OR SOCIAL EVENT":
                case "PRIVATE/SOCIAL":
                    return (int)MappedEventTypes.PrivateSocial;

                case "SCHOOL OR UNIVERSITY EVENT":
                case "SCHOOL/UNIVERSITY":
                    return (int)MappedEventTypes.SchoolUniversity;

                case "WEDDING":
                    return (int)MappedEventTypes.WeddingReception;

                default:
                    return (int)MappedEventTypes.Unassigned;
            }
        }

        public async Task<string> GetByCriteriaExportAsync(LeadSearchCriteriaDto criteriaDto)
        {
            var results = await this.Context.Leads.GetByCriteriaExportAsync(criteriaDto);

            return results;
        }
        public async Task CreateAsync(LeadDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (!dto.EventTypeId.HasValue)
                {
                    dto.EventTypeId = (int)MappedEventTypes.Unassigned;
                }

                dto.SetAsCreated(user);
                if (user.IsInRole(ECERole.Agent))
                {
                    dto.AgentId = user.GetUserId();
                }
                await this.Context.Leads.CreateAsync(dto,user.GetUserId());

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, dto.LeadId, ex);
            }
        }

        public async Task<LeadDto> GetLeadByIdAsync(int id)
        {
            var result = await this.Context.Leads.GetByIdAsync(id);

            return result;
        }

        public async Task UpdateAsync(LeadDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (!dto.EventTypeId.HasValue)
                {
                    dto.EventTypeId = (int)MappedEventTypes.Unassigned;
                }

                dto.SetAsUpdated(user);

                await this.Context.Leads.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, dto.LeadId, ex);
            }
        }

        public async Task AssignLeadAsync(LeadDto dto, IList<AppUserDto> carbonCopyUsers, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var previousLead = this.Context.Leads.GetById(dto.LeadId);
                if (previousLead == null)
                {
                    throw new ArgumentException($"Lead {dto.LeadId} not found");
                }

                var previousAgent = "--";

                if (previousLead.AgentId.HasValue)
                {
                    var agent = await this._userService.GetUserByIdAsync(previousLead.AgentId.Value);
                    previousAgent = agent.FullName;
                }

                dto.SetAsUpdated(user);

                await this.Context.Leads.UpdateAsync(dto);

                var entityHistory = new EntityHistoryDto()
                {
                    EntityId = dto.LeadId,
                    Type = EntityType.Lead,
                    Event = AuditEvent.AgentChanged,
                    Description = previousAgent,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                this._entityHistoryService.CreateEntityHistory(entityHistory);

                AppUserDto responsibleAgent = null;

                if (dto.AgentId.HasValue)
                {
                    // Send an alert to the assigned agent
                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.LeadAssigned);
                    var alertText = appEvent.Text.Replace("{SubmitterName}", $"{dto.FirstName} {dto.LastName}");

                    var alert = new AlertDto
                    {
                        AppUserId = dto.AgentId.Value,
                        Description = alertText,
                        IsRead = false,
                        EntityTypeId = (int)EntityType.Lead,
                        EntityId = dto.LeadId,
                        AppEventTypeId = (int)AppEventType.LeadAssigned
                    };

                    await this._alertService.CreateAsync(alert, user);

                    // Send an e-mail message to assigned agent.
                    responsibleAgent = await this._userService.GetUserByIdAsync(dto.AgentId.Value, true);

                    var message = await this.GenerateLeadAssignedEmailAsync(responsibleAgent, dto, EmailTemplate.SendLeadAssignment);
                    if (message.HasRecipient)
                    {
                        var smtpManager = new SmtpManager(this.Context);

                        var sentBy = user.GetUserId();
                        if (!responsibleAgent.UserIsInOffice(Constants.HoustonOfficeId))
                        {
                            smtpManager.SendMessage(message, sentBy, SendMessageMode.Queued);
                        }
                    }
                }

                if (responsibleAgent != null && carbonCopyUsers != null && carbonCopyUsers.Any())
                {
                    var smtpManager = new SmtpManager(this.Context);

                    var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.LeadAssignedCC);
                    var alertText = appEvent.Text
                        .Replace("{SubmitterName}", $"{dto.FirstName} {dto.LastName}")
                        .Replace("{AgentName}", $"{responsibleAgent.FullName}");

                    var message = await this.GenerateLeadAssignedEmailAsync(responsibleAgent, dto, EmailTemplate.SendLeadAssignmentCC);

                    foreach (var carbonCopyUser in carbonCopyUsers)
                    {
                        // Send an alert to the CC user.
                        var alert = new AlertDto
                        {
                            AppUserId = dto.AgentId.Value,
                            Description = alertText,
                            IsRead = false,
                            EntityTypeId = (int)EntityType.Lead,
                            EntityId = dto.LeadId,
                            AppEventTypeId = (int)AppEventType.LeadAssigned
                        };

                        await this._alertService.CreateAsync(alert, user);

                        // Send an e-mail message to CC user.
                        message.Body = message.Body.Replace("{CarbonCopyName}", $"{carbonCopyUser.FullName}");
                        message.To.Clear();
                        message.AddRecipient(carbonCopyUser.Username, carbonCopyUser.FullName);

                        if (message.HasRecipient)
                        {
                            var sentBy = user.GetUserId();
                            if (!responsibleAgent.UserIsInOffice(Constants.HoustonOfficeId))
                            {
                                smtpManager.SendMessage(message, sentBy, SendMessageMode.Queued);
                            }
                        }
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, dto.LeadId, ex);
            }
        }

        public async Task<IList<LeadSearchResultsDto>> GetByCriteriaAsync(LeadSearchCriteriaDto criteria)
        {
            var results = await this.Context.Leads.GetByCriteriaAsync(criteria);
            
            return results;
        }

        public async Task<IList<PotentialReferralResultDto>> GetPotentialReferralsAsync(
            PotentialReferralCriteriaDto criteria)
        {
            var potentialReferrals = new List<PotentialReferralResultDto>();

            var presenterContacts = new List<int>();
            var presenterOutList = new List<int>();

            var artistContacts = new List<int>();
            var artistOutList = new List<int>();

            var venueContacts = new List<int>();
            var venueOutList = new List<int>();

            var blueCardContacts = new List<int>();
            var contractContacts = new List<int>();

            // Get Contacts based on Contact Criteria.
            // Criteria: Referral Contact, Participant1, and Participant2.
            var contacts = await this.Context.Leads.GetPotentialReferralContactsAsync(
                criteria.ReferralContact,
                criteria.Participant1,
                criteria.Participant2,
                criteria.LeadEmail);

            // Filter contacts by entity types.
            // EntityTypes: Presenter, Artist, Venue, BlueCard, Contract.
            if (contacts.Any())
            {
                presenterContacts.AddRange(
                    contacts.Where(x => x.EntityTypeId == (int)EntityType.Presenter).Select(y => y.EntityId).Distinct());

                artistContacts.AddRange(
                    contacts.Where(x => x.EntityTypeId == (int)EntityType.Artist).Select(y => y.EntityId).Distinct());

                venueContacts.AddRange(
                    contacts.Where(x => x.EntityTypeId == (int)EntityType.Venue).Select(y => y.EntityId).Distinct());

                blueCardContacts.AddRange(
                    contacts.Where(x => x.EntityTypeId == (int)EntityType.BlueCard).Select(y => y.EntityId).Distinct());

                contractContacts.AddRange(
                    contacts.Where(x => x.EntityTypeId == (int)EntityType.Contract).Select(y => y.EntityId).Distinct());
            }

            // Get Presenters based on Presenter Criteria.
            // Criteria: Presenter Name, Agent Id, and Presenter Contacts.
            // Outputs: List of Presenter Ids.
            if (!string.IsNullOrEmpty(criteria.PresenterName) || criteria.AgentId.HasValue || presenterContacts.Any())
            {
                var presenterResults = await this.Context.Leads.GetPotentialReferralPresentersAsync(
                                           criteria.PresenterName,
                                           criteria.AgentId,
                                           presenterContacts,
                                           presenterOutList);

                potentialReferrals.AddRange(presenterResults);
            }

            // Get Artists based on Artist Criteria.
            // Criteria: Artist Name, Agent Id, and Artist Contacts.
            // Outputs: List of Artist Ids.
            if (!string.IsNullOrEmpty(criteria.ArtistName) || criteria.AgentId.HasValue || artistContacts.Any())
            {
                var artistResults = await this.Context.Leads.GetPotentialReferralArtistsAsync(
                                        criteria.ArtistName,
                                        criteria.AgentId,
                                        artistContacts,
                                        artistOutList);

                potentialReferrals.AddRange(artistResults);
            }

            // Get Venues based on Venue Criteria.
            // Criteria: Venue Name and VenueContacts.
            // Outputs: List of Venue Ids.
            if (!string.IsNullOrEmpty(criteria.VenueName) || venueContacts.Any())
            {
                var venueResults = await this.Context.Leads.GetPotentialReferralVenuesAsync(
                                       criteria.VenueName,
                                       venueContacts,
                                       venueOutList);

                potentialReferrals.AddRange(venueResults);
            }

            // Get BlueCards based on multiple Criteria.
            // Criteria: Presenter List, Presenter Name, Artist List, Venue List, Venue Name, Event Date, Agent, and BlueCard Contacts
            var blueCardResults = await this.Context.Leads.GetPotentialReferralBlueCardsAsync(
                           criteria.PresenterName,
                           criteria.VenueName,
                           criteria.EventDate,
                           criteria.AgentId,
                           presenterOutList,
                           artistOutList,
                           venueOutList,
                           blueCardContacts);

            potentialReferrals.AddRange(blueCardResults);

            // Get Contracts based on multiple Criteria.
            // Criteria: Presenter List, Presenter Name, Artist List, Venue List, Venue Name, Event Date, Agent, and Contract Contacts
            var contractResults = await this.Context.Leads.GetPotentialReferralContractsAsync(
                                      criteria.PresenterName,
                                      criteria.VenueName,
                                      criteria.EventDate,
                                      criteria.AgentId,
                                      presenterOutList,
                                      artistOutList,
                                      venueOutList,
                                      contractContacts);

            potentialReferrals.AddRange(contractResults);

            var leadResults = await this.Context.Leads.GetPotentialReferralLeadsAsync(criteria.LeadId, criteria.LeadEmail);

            if (leadResults.Any())
            {
                potentialReferrals.InsertRange(0, leadResults);
            }

            return potentialReferrals;
        }

        public LeadDto GetLeadById(int id)
        {
            var result = this.Context.Leads.GetById(id);

            return result;
        }

        public async Task CloseLeadAsync(int leadId, IPrincipal user)
        {
            if (leadId < 0)
            {
                throw new ArgumentException();
            }

            this.Context.BeginTransaction();

            try
            {
                var lead = await this.GetLeadByIdAsync(leadId);

                lead.IsClosed = true;
                lead.ClosedDate = DateTime.Now;
                lead.SetAsUpdated(user);

                await this.UpdateAsync(lead, user);

                var entityHistory = new EntityHistoryDto()
                {
                    EntityId = lead.LeadId,
                    Type = EntityType.Lead,
                    Event = AuditEvent.StatusChanged,
                    Description = "Closed",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                this._entityHistoryService.CreateEntityHistory(entityHistory);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, leadId, ex);
            }
        }

        public void CloseLead(int leadId, IPrincipal user)
        {
            if (leadId < 0)
            {
                throw new ArgumentException();
            }

            this.Context.BeginTransaction();

            try
            {
                var lead = this.GetLeadById(leadId);

                lead.IsClosed = true;
                lead.ClosedDate = DateTime.Now;
                lead.SetAsUpdated(user);

                this.Context.Leads.Update(lead);

                var entityHistory = new EntityHistoryDto()
                {
                    EntityId = lead.LeadId,
                    Type = EntityType.Lead,
                    Event = AuditEvent.StatusChanged,
                    Description = "Closed",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                this._entityHistoryService.CreateEntityHistory(entityHistory);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, leadId, ex);
            }
        }

        public async Task CreateLeadFromWebDataAsync(string json)
        {
            var webData = JObject.Parse(json);

            var lead = new LeadDto();
            lead.FirstName = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("first_name", webData), " ");
            lead.LastName = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("last_name", webData), " ");
            lead.PhoneNumber = this.GetJsonValue<string>("phone", webData);
            lead.CanText = this.ConvertYesNoToBool(this.GetJsonValue<string>("okay_to_text", webData));
            lead.EmailAddress = this.GetJsonValue<string>("email_address", webData);
            lead.EventDate = this.GetJsonValue<DateTime?>("event_date", webData);
            lead.EventVenueName = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("event_venue", webData), " ");
            lead.EventCity = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("event_city", webData), " ");
            lead.EventStateId = this.GetStateIdFromJson(this.CleanUnderScoresFromJson(this.GetJsonValue<string>("event_state", webData), " "));
            lead.EventTypeId = GetEventTypeFromJson(this.CleanUnderScoresFromJson(this.GetJsonValue<string>("event_type", webData), " "));
            lead.EventNotes = this.GetJsonValue<string>("comments", webData);
            lead.ArtistName = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("artist_interested_in", webData), " ");
            lead.ArtistId = await this.GetArtistIdFromJson(this.CleanUnderScoresFromJson(this.GetJsonValue<string>("artist_interested_in", webData), " "));
            var pastEventArtist = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("past_event_artist", webData), " ");

            if (!string.IsNullOrEmpty(pastEventArtist))
            {
                lead.ReferralArtistName = pastEventArtist;
            }

            var pastEventVenue = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("past_event_venue", webData), " ");

            if (!string.IsNullOrEmpty(pastEventVenue))
            {
                lead.ReferralVenueName = pastEventVenue;
            }

            var pastEventDate = this.GetJsonValue<string>("past_event_date", webData);
            this.SetReferralDateFromJson(pastEventDate, lead);

            var eventPlanner = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("past_event_planner", webData), " ");
            var eventPlannerCompany = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("past_event_planner_company", webData), " ");
            var who = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("who", webData), " ");
            this.SetReferralPresenterFromJson(eventPlanner, eventPlannerCompany, who, lead);

            this.SetReferralSourceFromJson(lead, webData);

            var agentName = string.Empty;
            var priorAgent = this.GetJsonValue<string>("prior_agent", webData);
            var pastAgent = this.GetJsonValue<string>("past_agent", webData);

            if (!string.IsNullOrEmpty(priorAgent))
            {
                agentName = this.CleanUnderScoresFromJson(priorAgent, " ");
            }

            if (!string.IsNullOrEmpty(pastAgent))
            {
                agentName = this.CleanUnderScoresFromJson(pastAgent, " ");
            }

            var agentNotListed = this.CleanUnderScoresFromJson(this.GetJsonValue<string>("agent_not_listed", webData), " ");

            lead.Participant1Name = this.GetJsonValue<string>("wedding_name", webData);
            lead.Participant2Name = this.GetJsonValue<string>("wedding_name2", webData);

            lead.Participant1TypeId = this.GetParticpantLeadTypeIdFromJson(this.GetJsonValue<string>("spousetype", webData));
            lead.Participant2TypeId = this.GetParticpantLeadTypeIdFromJson(this.GetJsonValue<string>("spousetype2", webData));

            this.SetReferralAgentFromJson(agentName, agentNotListed, lead);
            //Assign the lead source using the user_came_from_url field.
            this.SetLeadSourceFromJson(lead, webData);
            //lead.LeadSourceId = (int)LeadSourceType.ECEWebsite;
            lead.IsClosed = false;
            lead.SubmissionDate = DateTime.Now;
            lead.WebData = json;

            // Add the submitting person as a referral if one was not provided
            if (string.IsNullOrEmpty(lead.ReferralContact))
            {
                lead.ReferralContact = $"{lead.FirstName} {lead.LastName}";
            }

            this.Context.BeginTransaction();
            try
            {
                lead.CreatedById = 999999;      // System account
                lead.CreatedDate = DateTime.Now;

                await this.Context.Leads.CreateAsync(lead, lead.CreatedById);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Lead, lead.LeadId, ex);
            }
        }

        public async Task<bool> CanView(int userId, int leadId)
        {
            var user = await this._userService.GetUserAsync(new AppUserDto { AppUserId = userId }, true);

            var lead = await this.GetLeadByIdAsync(leadId);

            if (lead.AgentId.HasValue && lead.AgentId == userId)
            {
                return true;
            }

            var lmdRoles = user.Roles.Where(x => x.RoleId == (int)ECERole.LMD).ToList();

            if (lmdRoles.Any() && lead.AgentId.HasValue)
            {
                var assignedAgent = await this._userService.GetUserAsync(new AppUserDto { AppUserId = lead.AgentId.Value }, true);

                var assignedAgentOfficeIds = assignedAgent.Roles.Select(x => x.OfficeId).ToList();

                foreach (var r in lmdRoles)
                {
                    foreach (var o in assignedAgentOfficeIds)
                    {
                        if (r.OfficeId == o)
                        {
                            return true;
                        }
                    }
                }
            }

            var leadAdminRole = user.Roles.FirstOrDefault(x => x.RoleId == (int)ECERole.LeadAdmin);

            if (leadAdminRole != null)
            {
                return true;
            }

            if (user.Permissions.Contains(ECEPermissions.LEAD_READ))
            {
                return true;
            }
            return false;
        }

        public async Task<TemplateMailMessage> GenerateLeadAssignedEmailAsync(AppUserDto responsibleAgent, LeadDto lead, EmailTemplate emailTemplate)
        {
            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)emailTemplate);

            var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string url = this.GenerateLeadLinkUrl(lead.LeadId);

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);

            var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

            var body = bodyBuilder
                .Replace("{Body}", bodyTemplate.Body)
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("{AgentName}", responsibleAgent.FullName)
                .Replace("{LeadDetailsUrl}", url)
                .ToString();

            email.Subject = subject;
            email.Body = body;
            email.IsBodyHtml = bodyTemplate.IsHtml;

            email.AddRecipient(responsibleAgent.Username, responsibleAgent.FullName);

            return email;
        }

        public string GenerateLeadLinkUrl(int id)
        {
            string url = string.Format(
                "{0}{1}/{2}",
                MobiusConfiguration.GetString("Application.Url"),
                "Lead/Details",
                id);

            return url;
        }

        public async Task ToggleArchiveStatusAsync(int leadId, bool isArchived, int updatedBy)
        {
            try
            {
                this.Context.BeginTransaction();

                var original = await this.GetLeadByIdAsync(leadId);
                DateTime? archiveDate = null;

                if (isArchived)
                {
                    archiveDate = DateTime.Now;
                }

                await this.Context.Leads.ToggleArchiveStatusAsync(leadId, archiveDate, !isArchived, updatedBy);

                var history = new EntityHistoryDto
                {
                    EntityId = leadId,
                    Type = EntityType.Lead,
                    Event = AuditEvent.ArchiveStatusChanged,
                    Description = original.ArchiveDate.HasValue ? "Unarchived" : "Archived",
                    CreatedDate = DateTime.Now,
                    CreatedById = updatedBy
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }


        public async Task<(bool, string, object)> ImportLead(Stream stream, IPrincipal user)
        {
            Dictionary<string, object> keyValuePairsParams = new Dictionary<string, object>();
            bool valid = false;
            string msg = string.Empty;
            DataSet dsResult = new DataSet();
            try
            {
                var dt = await DaoHelper.ImportExceltoDatatable("", "data", stream);

                if (dt != null && dt.Rows.Count > 0)
                {
                    if (dt.Rows.Count <= 20000)
                    {
                        dt.TableName = "lead";
                        dt.AcceptChanges();
                        string jsonString = await DaoHelper.ConvertDatatableToJSON(dt);
                        Dictionary<string, object> keyValuePairsParamsPass = new Dictionary<string, object>();
                        keyValuePairsParamsPass.Add("@Json", jsonString);
                        keyValuePairsParamsPass.Add("@UserId", user.GetUserId());
                        dsResult = await DaoHelper.GetDataSetStoreProcedureWithDynamicParameters("Sp_Bulk_Import_Lead", keyValuePairsParamsPass);

                        if (dsResult.Tables.Count > 1)
                        {
                            valid = false;
                            if (Convert.ToBoolean(dsResult.Tables[0].Rows[0][0]))
                            {
                                valid = true;
                                msg = "Bulk insert successful";
                            }
                            else
                            {
                                msg = "Something Went Wrong, Please Try Again";
                            }

                        }
                        else
                        {
                            valid = false;
                            msg = "Something Went Wrong, Please Try Again";
                        }

                    }
                    else
                    {
                        valid = false;
                        msg = "Limit Exceeded! Records more than 20000 are not allowed.";
                    }
                }
                else
                {
                    valid = false;
                    msg = "Record not found!";
                }

            }
            catch (Exception ex)
            {
                valid = false;
                msg = ex.Message;
            }
            return (valid, msg, dsResult);
        }


        private T GetJsonValue<T>(string key, JToken json)
        {
            try
            {
                var obj = json.Value<T>(key);
                return obj;
            }
            catch (Exception)
            {
                // Eat exception and return default for now
                return default(T);
            }
        }

        private bool ConvertYesNoToBool(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return false;
            }

            return value.ToUpper() == "YES";
        }

        private string CleanUnderScoresFromJson(string value, string replacementCharacter)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            if (replacementCharacter == null)
            {
                return value;
            }

            var clean = value.Replace("_", replacementCharacter);
            return clean;
        }

        private int? GetStateIdFromJson(string stateName)
        {
            if (string.IsNullOrEmpty(stateName))
            {
                return null;
            }

            var states = _lookupService.GetAllStates(true);

            var state =
                states.FirstOrDefault(s => s
                    .Name.ToUpper() == stateName.ToUpper() || s.Abbreviation.ToUpper() == stateName.ToUpper());

            if (state == null)
            {
                return null;
            }

            return state.StateId;
        }

        private async Task<int?> GetArtistIdFromJson(string artistName)
        {
            if (string.IsNullOrEmpty(artistName))
            {
                return null;
            }

            var artists = await _artistService.GetByCriteriaAsync(new ArtistSearchCriteriaDto() { Name = artistName });

            var artist = artists.OrderByDescending(x => x.IsActive).ThenByDescending(y => y.IsExclusive).ThenBy(z => z.Name).FirstOrDefault();

            return artist?.ArtistId;
        }

        private void SetReferralDateFromJson(string pastEventDate, LeadDto lead)
        {
            if (!string.IsNullOrEmpty(pastEventDate))
            {
                DateTime result;
                var ped = DateTime.TryParse(pastEventDate, out result);

                if (ped)
                {
                    lead.ReferralEventDate = result.ToShortDateString();
                }
            }
        }

        private void SetReferralSourceFromJson(LeadDto lead, JToken webData)
        {
            var source = this.GetJsonValue<string>("how_they_heard", webData);

            switch (source)
            {
                case "Referred_by_Friend_or_Family_Member_3":
                    lead.ReferralSource = "Friend or Family Member";
                    break;

                case "Worked_with_ECE_in_the_Past_8":
                    lead.ReferralSource = "Worked with ECE in the Past";
                    break;

                case "Referred_by_Venue_5":
                    lead.ReferralSource = "Venue";
                    break;

                case "Referred_by_Event_Planner_6":
                    lead.ReferralSource = "Event Planner";
                    break;

                case "Found_on_web_or_Social_media_1":
                    var socialSource = this.GetJsonValue<string>("heard_from_social_media", webData);
                    lead.ReferralSource = !string.IsNullOrEmpty(socialSource) ? socialSource : "Web or Social Media";
                    break;

                case "Found_on_Knot_2":
                    lead.ReferralSource = "The Knot";
                    break;

                case "Found_on_Wedding_Wire4":
                    lead.ReferralSource = "Wedding Wire";
                    break;

                case "Found_on_Southern_Weddings":
                    lead.ReferralSource = "Southern Weddings";
                    break;

                case "Found_on_Borrowed_and_blue":
                    lead.ReferralSource = "Borrowed and Blue";
                    break;

                case "Saw_Band_or_Artist_7":
                    lead.ReferralSource = "Artist";
                    break;

                case "Saw_an_Advertisement_9":
                    var adSource = this.GetJsonValue<string>("heard_from_ad", webData);
                    lead.ReferralSource = !string.IsNullOrEmpty(adSource) ? adSource : "Advertisement";
                    break;

                case "Saw_on_ECE_blog":
                    lead.ReferralSource = "ECE Blog";
                    break;

                case "Other_11":
                    var otherSource = this.GetJsonValue<string>("heard_from_other", webData);
                    lead.ReferralSource = !string.IsNullOrEmpty(otherSource) ? otherSource : "Other";
                    break;

                case "Comedy_Form":
                    lead.ReferralSource = "Comedy Form";
                    break;

                case "South_Florida_Form":
                    lead.ReferralSource = "South Florida Form";
                    break;

                case "Central_Florida_Form":
                    lead.ReferralSource = "Central Florida Form";
                    break;

                case "Wedding_Form":
                    lead.ReferralSource = "Wedding Form";
                    break;

                default:
                    lead.ReferralSource = "Unknown";
                    break;
            }

            // Possible enhancement: extend the database field and update the UI/Validation to support at least 1000 chars.
            if (lead.ReferralSource.Length > 500)
            {
                lead.ReferralSource = lead.ReferralSource.Substring(0, 500);
            }
        }

        private void SetReferralPresenterFromJson(string eventPlanner, string eventPlannerCompany, string who, LeadDto lead)
        {
            if (string.IsNullOrEmpty(who))
            {
                if (!string.IsNullOrEmpty(eventPlanner) && !string.IsNullOrEmpty(eventPlannerCompany))
                {
                    lead.ReferralPresenterName = eventPlannerCompany;
                    lead.ReferralContact = eventPlanner;
                }
            }
            else
            {
                lead.ReferralPresenterName = who;
            }
        }

        private void SetReferralAgentFromJson(string priorAgent, string agentNotListed, LeadDto lead)
        {
            if (!string.IsNullOrEmpty(priorAgent))
            {
                if (priorAgent.Equals("Other", StringComparison.InvariantCultureIgnoreCase)
                    && !string.IsNullOrEmpty(agentNotListed))
                {
                    lead.ReferralAgentName = agentNotListed;
                }
                else if (!priorAgent.Equals("Other", StringComparison.InvariantCultureIgnoreCase) && !priorAgent.Equals(
                             "I Don't Know",
                             StringComparison.InvariantCultureIgnoreCase))
                {
                    lead.ReferralAgentName = priorAgent;
                }
            }
        }

        
        private int? GetParticpantLeadTypeIdFromJson(string source)
        {
            if (string.IsNullOrEmpty(source))
            {
                return null;
            }

            switch (source.ToUpper())
            {
                case "BRIDE":
                    return 1;

                case "GROOM":
                    return 2;

                default:
                    return null;
            }
        }

        private void SetLeadSourceFromJson(LeadDto lead, JToken webData)
        {
            var sourceValue = this.GetJsonValue<string>("user_came_from_url", webData);

            var source = (sourceValue ?? string.Empty).ToLowerInvariant();

            if (source.Contains("ecenational"))
            {
                lead.LeadSourceId = (int)LeadSourceType.ECEWebsiteNational;
            }
            else if (source.Contains("ecetouring"))
            {
                lead.LeadSourceId = (int)LeadSourceType.ECEWebsiteTouring;
            }
            else
            {
                lead.LeadSourceId = (int)LeadSourceType.ECEWebsite;
            }

        }
    }
}
