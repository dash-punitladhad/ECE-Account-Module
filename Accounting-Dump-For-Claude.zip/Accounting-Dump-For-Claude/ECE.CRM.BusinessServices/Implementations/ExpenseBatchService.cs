﻿namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.Logging;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using EntitySequenceConstants = ECE.CRM.DataTransferObjects.ECEBusinessConstants.EntitySequenceConstants;

    public class ExpenseBatchService : IExpenseBatchService
    {
        public static Expression<Func<ContractDepositDto, ContractTransactionDto>> MapCrossDeduction = (crossDeduction) => new ContractTransactionDto
        {
            ContractEntityTypeId = crossDeduction.ContractEntityTypeId,
            ContractTransactionId = crossDeduction.ContractDepositId,
            ContractEntityId = crossDeduction.ContractEntityId,
            ContractId = crossDeduction.ContractId,
            RequiredAmount = crossDeduction.AppliedAmount * decimal.MinusOne,
            PaidAmount = crossDeduction.AppliedAmount * decimal.MinusOne,
            DueDate = GetCrossDeductionDueDate(crossDeduction),
            ContractTransactionTypeName = "Deposit (XDED.)",
            ContractTransactionTypeId = (int)ContractTransactionType.CrossDeductionDeposit,
            Notes = crossDeduction.Note,
            ExpensePaymentId = crossDeduction.ExpensePaymentId,
            ExpensePaymentStatusId = crossDeduction.ExpensePaymentStatusId,
        };

        public static Expression<Func<ArtistChargeTransactionDto, ContractTransactionDto>> MapRepayments = (loanRepayment) => new ContractTransactionDto
        {
            ContractEntityTypeId = (int)ContractEntityType.Unknown,
            ContractTransactionId = loanRepayment.ArtistChargeTransactionId,
            ContractEntityId = loanRepayment.ArtistChargeId,
            RequiredAmount = loanRepayment.TransactionAmount * decimal.MinusOne,
            PaidAmount = loanRepayment.TransactionAmount * decimal.MinusOne,
            ContractTransactionTypeName = "Loan Repayment",
            ContractTransactionTypeId = (int)ContractTransactionType.LoanRepayment,
            ExpensePaymentId = loanRepayment.ExpensePaymentId,
            ExpensePaymentStatusId = loanRepayment.ExpensePaymentStatusId,
        };

        private readonly IUserService _userService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IArtistChargeService _artistChargeService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IDocumentService _documentService;
        private readonly IArtistService _artistService;
        private readonly ICheckGenerationService _checkGenerationService;
        private readonly IExpensePaymentService _expensePaymentService;
        private readonly IContractDepositService _contractDepositService;
        private readonly ICommunicationLogService _communicationLogService;
        private readonly ILookupService _lookupService;

        public ExpenseBatchService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public ExpenseBatchService(
            IUnitOfWork context,
            ILogger logger,
            IUserService userService,
            IContractTransactionService contractTransactionService,
            IArtistChargeService artistChargeService,
            IGeneralLedgerService generalLedgerService,
            IDocumentService documentService,
            IArtistService artistService,
            IExpensePaymentService expensePaymentService,
            ICheckGenerationService checkGenerationService,
            IContractDepositService contractDepositService,
            ICommunicationLogService communicationLogService,
            ILookupService lookupService)
        {
            this.Context = context;
            this.Logger = logger;
            this._userService = userService;
            this._contractTransactionService = contractTransactionService;
            this._artistChargeService = artistChargeService;
            this._generalLedgerService = generalLedgerService;
            this._documentService = documentService;
            this._artistService = artistService;
            this._checkGenerationService = checkGenerationService;
            this._expensePaymentService = expensePaymentService;
            this._contractDepositService = contractDepositService;
            this._communicationLogService = communicationLogService;
            this._lookupService = lookupService;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public static string GetCrossDeductionNote(ContractTransactionDto transaction)
        {
            return $"XDED. for {transaction.ContractTransactionId}-{transaction.DueDate:MM/dd/yyyy}";
        }

        public static DateTime? GetCrossDeductionDueDate(ContractDepositDto deposit)
        {
            var note = deposit.Note;
            if (note == null)
            {
                return null;
            }

            var index = note.IndexOf("-");
            if (index > 0)
            {
                note = note.Substring(index + 1);
            }

            DateTime dueDate;

            if (DateTime.TryParse(note, out dueDate))
            {
                return dueDate;
            }

            return null;
        }

        public static IEnumerable<IGrouping<ExpenseGroupKey, ContractTransactionDto>> GroupsExpenses(IEnumerable<ContractTransactionDto> expenses)
        {
            var expenseGroups = from e in expenses
                                group e by new ExpenseGroupKey(e.ContractEntityId, e.ContractEntityTypeId, e.PayeeName);

            return expenseGroups;
        }

        public async Task<ExpenseBatchDto> GetByIdAsync(int id, bool includeChildren = true)
        {
            var dto = await this.Context.ExpenseBatches.GetByIdAsync(id, includeChildren);

            return dto;
        }

        public async Task<Dictionary<ContractTransactionType, decimal>> GetBatchTransactionTypeTotalsAsync(int id)
        {
            var contractTransactions = await this._contractTransactionService.GetByExpenseBatchIdAsync(id);

            return this.GetBatchTransactionTypeTotals(contractTransactions);
        }

        public Dictionary<ContractTransactionType, decimal> GetBatchTransactionTypeTotals(IList<ContractTransactionDto> contractTransactions)
        {
            var groupedTrans = from p in contractTransactions
                               where p.IsExpense == true
                               group p by new { p.ContractTransactionTypeId };

            var transSums = new Dictionary<ContractTransactionType, decimal>();

            // get transaction type totals - need clarification on this
            foreach (var trans in groupedTrans)
            {
                transSums.Add((ContractTransactionType)trans.Key.ContractTransactionTypeId, trans.Total(p => p.RequiredAmount));
            }

            return transSums;
        }

        public async Task<IList<ExpensePaymentDto>> GetExpensePaymentsByBatchIdAsync(int id)
        {
            var results = await this.Context.ExpensePayments.GetByBatchIdAsync(id);

            return results;
        }

        public async Task UpdateNotesAsync(int id, string notes)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.ExpenseBatches.UpdateNotesAsync(id, notes);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return;
        }

        public async Task<string> CheckExpensePaymentForWarningsAsync(int expensePaymentId)
        {
            var contractTransactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePaymentId);

            var message = await this.CheckExpensePaymentForWarningsAsync(contractTransactions);

            return message;
        }

        public async Task<string> CheckExpensePaymentForWarningsAsync(IList<ContractTransactionDto> contractTransactions)
        {
            if (contractTransactions == null)
            {
                throw new ArgumentNullException(nameof(contractTransactions));
            }

            var warnings = new List<string>();

            foreach (var contractTransaction in contractTransactions)
            {
                var transWarnings = await this._contractTransactionService.CheckTransactionForWarningAsync(contractTransaction);
                foreach (var warning in transWarnings)
                {
                    warnings.AddIfNotContains(warning);
                }
            }

            var message = string.Join(" ", warnings);

            return message;
        }

        public async Task<ExpenseBatchDto> GetOrCreateIfNotExistsAsync(ExpenseBatchType batchType, bool isManual, IPrincipal user)
        {
            var batch = await this.Context.ExpenseBatches.GetOrCreateIfNotExistsAsync(batchType, isManual, user);

            return batch;
        }

        public async Task<ExpensePaymentDto> GetExpensePaymentByPayeeAsync(int expenseBatchId, int contractEntityTypeId, int contractEntityId)
        {
            var payment = await this.Context.ExpensePayments.GetByPayeeAsync(expenseBatchId, contractEntityTypeId, contractEntityId);

            return payment;
        }

        public async Task<ExpensePaymentDto> GetExpensePaymentByReferenceNumberAsync(string referenceNumber)
        {
            var payment = await this.Context.ExpensePayments.GetByReferenceNumberAsync(referenceNumber);

            return payment;
        }

        public async Task<ExpensePaymentDto> GetExpensePaymentByReferenceNumberAndAmountAsync(string referenceNumber, decimal amount)
        {
            var payment = await this.Context.ExpensePayments.GetByReferenceNumberAndAmountAsync(referenceNumber, amount);

            return payment;
        }

        [Obsolete]
        public async Task CreateExpensePaymentAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            await this._expensePaymentService.CreateAsync(payment, user);
        }

        public async Task UpdateExpensePaymentAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            await this._expensePaymentService.UpdateAsync(payment, user);
        }

        public async Task UpdateAsync(ExpenseBatchDto batch, IPrincipal user)
        {
            if (batch == null)
            {
                throw new ArgumentNullException(nameof(batch));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                batch.SetAsUpdated(user.GetUserId());

                await this.Context.ExpenseBatches.UpdateAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpenseBatchDto> ResetPendingBatchAsync(int id, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var batch = await this.GetByIdAsync(id);
                if (batch == null)
                {
                    this.Context.Rollback();
                    return null;
                }

                await this.DeletePendingBatchAsync(id, user);

                var options = new CreatePaymentBatchDto
                {
                    IsManual = batch.IsManual,
                    ExpenseBatchType = (ExpenseBatchType)batch.ExpenseBatchTypeId,
                    IncludeSharedBonus = batch.IncludeSharedBonus,
                    IncludeGasCard = batch.IncludeGasCard,
                    IncludeNational = batch.IncludeNational,
                };

                batch = await this.CreateExpenseBatchAsync(options, user);

                this.Context.Commit();

                return batch;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeletePendingBatchAsync(int id, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var batch = await this.Context.ExpenseBatches.GetByIdAsync(id);
                if (batch == null)
                {
                    throw new Exception($"Expense Batch # {id} not found");
                }

                if (batch.IsPosted)
                {
                    throw new AlreadyPostedException($"Expense batch {batch.ExpenseBatchId} is already posted.");
                }

                var transactions = await Context.ContractTransactions.GetByExpenseBatchIdAsync(id);
                foreach (var transaction in transactions)
                {
                    transaction.ExpensePaymentId = null;
                    transaction.ExpensePaymentStatusId = null;
                    transaction.SetAsUpdated(user);

                    await Context.ContractTransactions.UpdateAsync(transaction);
                }

                var loanRepayments = await Context.ArtistCharges.GetLoanRepaymentsByExpenseBatchIdAsync(id);
                foreach (var loanRepayment in loanRepayments)
                {
                    loanRepayment.IsDeleted = true;
                    loanRepayment.ExpensePaymentId = null;
                    loanRepayment.ExpensePaymentStatusId = null;
                    loanRepayment.SetAsUpdated(user);

                    await Context.ArtistCharges.UpdateArtistChargeTransactionAsync(loanRepayment);
                }

                var crossDeductions = await Context.ContractDeposits.GetCrossDeductionsByExpenseBatchIdAsync(id);
                foreach (var crossDeduction in crossDeductions)
                {
                    crossDeduction.IsDeleted = true;
                    crossDeduction.ExpensePaymentId = null;
                    crossDeduction.ExpensePaymentStatusId = null;
                    crossDeduction.SetAsUpdated(user);

                    await Context.ContractDeposits.UpdateCrossDeductionDepositAsync(crossDeduction);
                }

                var userId = user.GetUserId();

                var expensePayments = await GetExpensePaymentsByBatchIdAsync(id);
                foreach (var expensePayment in expensePayments)
                {
                    await this.Context.ExpensePayments.DeleteAsync(expensePayment.ExpensePaymentId, userId);
                }

                batch.SetAsUpdated(user);

                await this.Context.ExpenseBatches.DeleteAsync(batch);

                this.Context.Commit();
            }
            catch (AlreadyPostedException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteExpensePaymentAsync(int id, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var payment = await this.Context.ExpensePayments.GetByIdAsync(id);
                if (payment == null)
                {
                    throw new ArgumentException($"Expense payment {id} not found.");
                }

                await this._expensePaymentService.DeleteAsync(payment, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentDto> GetExpensePaymentByIdAsync(int id)
        {
            var payment = await this._expensePaymentService.GetByIdAsync(id);
            if (payment != null && payment.ContractEntityTypeId == (int)ContractEntityType.Presenter)
            {
                payment.Refund = await this.Context.PresenterRefunds.GetByExpensePaymentIdAsync(id);
            }

            return payment;
        }

        public async Task CreateLoanRepaymentTransactionsAsync(int expensePaymentId, IEnumerable<ArtistChargeDto> loansToRepay, IPrincipal user)
        {
            if (loansToRepay == null)
            {
                return;
            }

            try
            {
                this.Context.BeginTransaction();

                var existingTransactions = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(expensePaymentId);

                foreach (var loanToRepay in loansToRepay)
                {
                    var existingTransaction = existingTransactions.FirstOrDefault(x => x.ArtistChargeId == loanToRepay.ArtistChargeId);

                    if (existingTransaction == null)
                    {
                        await this._artistChargeService.CreateArtistChargeRepaymentAsync(loanToRepay, expensePaymentId, user);
                    }
                    else if (existingTransaction.TransactionAmount != loanToRepay.DeductionAmount)
                    {
                        // Keep the amount of the loan repayment synchronized
                        existingTransaction.TransactionAmount = loanToRepay.DeductionAmount;
                        existingTransaction.SetAsUpdated(user);

                        await this.Context.ArtistCharges.UpdateArtistChargeTransactionAsync(existingTransaction);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateCrossDeductionTransactionsAsync(ExpensePaymentDto expensePayment, IPrincipal user)
        {
            /*
             * If money remains owed to the artist, use it to pay income records the artist
             * has not fully paid and are past due.
             */

            try
            {
                this.Context.BeginTransaction();

                var unpaidIncomeRecords = await this.GetUnpaidIncomeRecordsByPayeeAsync(expensePayment.ContractEntityId, (ContractEntityType)expensePayment.ContractEntityTypeId);

                var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsAsync(expensePayment.ExpensePaymentId);

                var depositsToPay = ExpensePaymentService.GetDepositsToPay(unpaidIncomeRecords, expensePayment.PaymentAmount);

                foreach (var depositToPay in depositsToPay)
                {
                    var unpaidIncomeRecord = depositToPay.Item1;
                    var unpaidDepositAmount = depositToPay.Item2;

                    var crossDeductionNote = GetCrossDeductionNote(unpaidIncomeRecord);

                    var match = crossDeductionDeposits
                        .Where(x => x.Note == crossDeductionNote)
                        .FirstOrDefault();

                    if (match == null)
                    {
                        this.Logger.LogDebug($"\tXDED {crossDeductionNote}\t{unpaidDepositAmount}");

                        expensePayment.DeductionAmount += unpaidDepositAmount;

                        await this._contractTransactionService.UpdateAsync(unpaidIncomeRecord, user);

                        var crossDeductionDeposit = new ContractDepositDto();

                        crossDeductionDeposit.ContractId = unpaidIncomeRecord.ContractId;
                        crossDeductionDeposit.ContractEntityId = unpaidIncomeRecord.ContractEntityId;
                        crossDeductionDeposit.ContractEntityTypeId = unpaidIncomeRecord.ContractEntityTypeId;
                        crossDeductionDeposit.ReceivedDate = DateTime.Now;
                        crossDeductionDeposit.ReceivedAmount = unpaidDepositAmount;
                        crossDeductionDeposit.PaymentMethodId = (int)PaymentMethod.CrossDeduction;
                        crossDeductionDeposit.ExpensePaymentId = expensePayment.ExpensePaymentId;
                        crossDeductionDeposit.ExpensePaymentStatusId = (int)ExpensePaymentStatus.CrossDeduct;
                        crossDeductionDeposit.ReferenceNumber = $"XDED. for {expensePayment.ExpensePaymentId}";
                        crossDeductionDeposit.Note = crossDeductionNote;
                        crossDeductionDeposit.AllocatedAmount = unpaidDepositAmount;
                        crossDeductionDeposit.AppliedAmount = unpaidDepositAmount;

                        crossDeductionDeposit.SetAsCreated(user);

                        await this.Context.ContractDeposits.CreateAsync(crossDeductionDeposit);
                    }
                }

                expensePayment.PaymentAmount = expensePayment.GrossAmount - expensePayment.DeductionAmount;

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<decimal> CheckForDeductionAsync(int artistId, decimal amount)
        {
            var deductionAmount = decimal.Zero;

            var artistLoans = await this._artistChargeService.GetArtistChargesByArtistIdAsync(artistId);
            var arefPaymentAmount = amount;

            foreach (var loan in artistLoans)
            {
                var loanDeductionAmount = loan.DeductionAmount;

                if (arefPaymentAmount >= loanDeductionAmount)
                {
                    deductionAmount += loanDeductionAmount;

                    arefPaymentAmount -= loanDeductionAmount;
                }
            }

            return deductionAmount;
        }

        public async Task<IList<ContractTransactionDto>> GetUnpaidIncomeRecordsByPayeeAsync(int contractEntityId, ContractEntityType contractEntityType)
        {
            var incomeRecords = await this.Context.ContractTransactions.GetUnpaidIncomeRecordsByPayeeAsync(contractEntityId, contractEntityType);

            return incomeRecords;
        }

        public async Task<List<ExpensePaymentDto>> ProcessExpenseBatchAsync(int expenseBatchId, IEnumerable<ContractTransactionDto> expenses, IEnumerable<ExpensePaymentDto> existingPayments)
        {
            var resultingPayments = new List<ExpensePaymentDto>(existingPayments);

            // Group records by Payee (ContractEntityTypeId, ContractEntityId) to get Payments
            var expenseGroups = from p in expenses
                                group p by new { p.ContractEntityTypeId, p.ContractEntityId, p.PayeeName };

            foreach (var expenseGroup in expenseGroups)
            {
                var contractEntityTypeId = expenseGroup.Key.ContractEntityTypeId;
                var contractEntityId = expenseGroup.Key.ContractEntityId;

                decimal deductionAmount = 0;

                var hasArtistPaymentExpense = contractEntityTypeId == (int)ContractEntityType.Artist &&
                    expenseGroup.Any(x => x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);

                var expensePayment = existingPayments.FirstOrDefault(x => x.ContractEntityId == contractEntityId && x.ContractEntityTypeId == contractEntityTypeId);

                // Non-ECE Expenses are paid in full, so the PaidAmount should always be zero for these expenses.
                var grossPaymentAmount = expenseGroup.Total(p => p.RequiredAmount);

                IEnumerable<ArtistChargeDto> loansToRepay = null;

                if (hasArtistPaymentExpense)
                {
                    // Get any outstanding loans for the artist.
                    var outstandingLoans = await this._artistChargeService.GetArtistChargesByArtistIdAsync(contractEntityId);

                    // Filter out all but the loans there is sufficient money to pay.
                    loansToRepay = ExpensePaymentService.GetLoansToRepay(outstandingLoans, grossPaymentAmount);

                    // Get the total loan repayment amount to deduct from the artist payment.
                    deductionAmount = loansToRepay.Total(x => x.DeductionAmount);
                }

                var netPaymentAmount = grossPaymentAmount - deductionAmount;

                if (expensePayment == null)
                {
                    var transactionCount = expenseGroup.Count();
                    var payeeName = expenseGroup.Key.PayeeName;

                    var newPayment = new ExpensePaymentDto()
                    {
                        ExpenseBatchId = expenseBatchId,
                        ExpensePaymentTypeId = (int)ExpensePaymentType.Check, // Check by Default
                        ContractEntityTypeId = contractEntityTypeId,
                        ContractEntityId = contractEntityId,
                        DateIssued = DateTime.Now,
                        GrossAmount = grossPaymentAmount,
                        DeductionAmount = deductionAmount,
                        PaymentAmount = netPaymentAmount,
                        TransactionCount = transactionCount,
                        PayeeName = payeeName
                    };

                    resultingPayments.Add(newPayment);

                    expensePayment = newPayment;
                }
                else
                {
                    expensePayment.GrossAmount = grossPaymentAmount;
                    expensePayment.DeductionAmount = deductionAmount;
                    expensePayment.PaymentAmount = netPaymentAmount;
                }

                var paymentAvailable = netPaymentAmount;

                var unpaidPayeeDeposits = await this.CheckForIncomeRecordsAsync(contractEntityId, (ContractEntityType)contractEntityTypeId, paymentAvailable);

                foreach (var unpaidPayeeDeposit in unpaidPayeeDeposits)
                {
                    var unpaidDepositAmount = unpaidPayeeDeposit.RequiredAmount.GetValueOrDefault();
                    if (paymentAvailable >= unpaidDepositAmount)
                    {
                        paymentAvailable -= unpaidDepositAmount;
                        deductionAmount += unpaidDepositAmount;

                        unpaidPayeeDeposit.ExpensePaymentId = expensePayment.ExpensePaymentId;
                        unpaidPayeeDeposit.ExpensePaymentStatusId = (int)ExpensePaymentStatus.CrossDeduct;
                    }
                }

                netPaymentAmount = grossPaymentAmount - deductionAmount;

                expensePayment.DeductionAmount = deductionAmount;
                expensePayment.PaymentAmount = netPaymentAmount;

                foreach (var contractTrans in expenseGroup)
                {
                    // update ContractTransaction record with expense payment data
                    contractTrans.ExpensePaymentId = expensePayment.ExpensePaymentId;
                    contractTrans.ExpensePaymentStatusId = (int)ExpensePaymentStatus.HasSufficientEscrow;
                }
            }

            return resultingPayments;
        }

        public async Task<ExpenseBatchDto> CreateExpenseBatchAsync(ExpenseBatchType batchType, bool sharedBonusOption, bool gasCardOption, bool payNationalsOption, IPrincipal user)
        {
            var options = new CreatePaymentBatchDto
            {
                ExpenseBatchType = batchType,
                IncludeSharedBonus = sharedBonusOption,
                IncludeGasCard = gasCardOption,
                IncludeNational = payNationalsOption
            };

            return await CreateExpenseBatchAsync(options, user);
        }

        public async Task<ExpenseBatchDto> CreateExpenseBatchAsync(CreatePaymentBatchDto options, IPrincipal user)
        {
            if (options.ExpenseBatchType == ExpenseBatchType.ECE)
            {
                throw new ArgumentException($"Invalid batch type: {options.ExpenseBatchType}");
            }

            ExpenseBatchDto batch = null;

            try
            {
                this.Context.BeginTransaction();

                this.Logger.LogDebug($"Begin CreateExpenseBatchAsync");

                this.Logger.LogInformation($"CreateExpenseBatch: {options.ExpenseBatchType} IsManual {options.IsManual} IncludeSharedBonus {options.IncludeSharedBonus} IncludeGasCard {options.IncludeGasCard} IncludeNational {options.IncludeNational}");

                batch = await this.GetOrCreateIfNotExistsAsync(options.ExpenseBatchType, options.IsManual, user);

                this.Logger.LogDebug($"After GetOrCreateIfNotExistsAsync ExpenseBatchId {batch.ExpenseBatchId}");

                batch.IsManual = options.IsManual;
                batch.IncludeSharedBonus = options.IncludeSharedBonus;
                batch.IncludeGasCard = options.IncludeGasCard;
                batch.IncludeNational = options.IncludeNational;

                var existingPayments = await this.GetExpensePaymentsByBatchIdAsync(batch.ExpenseBatchId);

                this.Logger.LogDebug($"After GetExpensePaymentsByBatchIdAsync");

                var expenseGroups = await this.GetExpenseGroupsAsync(
                    batch,
                    options,
                    user);

                this.Logger.LogDebug($"After GetExpenseGroupsAsync");

                var expenseBatchId = batch.ExpenseBatchId;

                var expenseBatchAmount = decimal.Zero;

                this.Logger.LogDebug($"Processing Expense Batch {batch.ExpenseBatchId}");

                foreach (var expenseGroup in expenseGroups)
                {
                    /*
                     * An expense group is a collection of expense contract transactions for a contract entity (payee).
                     */

                    var contractEntityTypeId = expenseGroup.Key.ContractEntityTypeId;
                    var contractEntityId = expenseGroup.Key.ContractEntityId;

                    var amounts = new ExpensePaymentAmounts();

                    amounts.GrossAmount = expenseGroup.Total(p => p.RequiredAmount);

                    amounts.PaymentAmount = amounts.GrossAmount;

                    this.Logger.LogDebug($"Processing Expense For {expenseGroup.Key.PayeeName} {expenseGroup.Key.ContractEntityId}");

                    this.Logger.LogDebug($"\tEXPENSE before processing\t{amounts.GrossAmount}\t{amounts.DeductionAmount}\t{amounts.PaymentAmount}\t{expenseGroup.Count()}");

                    IEnumerable<ArtistChargeDto> loansToRepay = null;

                    var expensePayment = this.GetOrCreateExpensePayment(existingPayments, expenseGroup.Key, amounts);
                    if (expensePayment.ExpensePaymentId == 0)
                    {
                        expensePayment.ExpenseBatchId = expenseBatchId;
                        expensePayment.TransactionCount = expenseGroup.Count();

                        if (contractEntityTypeId == (int)ContractEntityType.Artist)
                        {
                            var artist = await this.Context.Artists.GetByIdAsync(contractEntityId);
                            if (this._artistService.CanUseDirectDeposit(artist))
                            {
                                expensePayment.ExpensePaymentTypeId = (int)ExpensePaymentType.DirectDeposit;
                            }
                        }

                        await this._expensePaymentService.CreateAsync(expensePayment, user);
                    }

                    if (expensePayment.PaymentAmount > decimal.Zero)
                    {
                        await this.CreateCrossDeductionTransactionsAsync(expensePayment, user);
                    }

                    this.Logger.LogDebug($"\tEXPENSE after processing XDED to repay\t{expensePayment.GrossAmount}\t{expensePayment.DeductionAmount}\t{expensePayment.RepaymentAmount}\t{expensePayment.PaymentAmount}");

                    if (contractEntityTypeId == (int)ContractEntityType.Artist)
                    {
                        // Get any outstanding loans for the artist.
                        var outstandingLoans = await this._artistChargeService.GetArtistChargesByArtistIdAsync(contractEntityId);

                        // Filter out all but the loans there is sufficient money to pay.
                        loansToRepay = ExpensePaymentService.GetLoansToRepay(outstandingLoans, expensePayment.PaymentAmount);

                        // Deduct the total loan repayment amount from the artist payment. This might
                        // result in the payment amount being zero.
                        expensePayment.DeductionAmount = expensePayment.DeductionAmount + loansToRepay.Total(x => x.DeductionAmount);
                    }

                    expensePayment.PaymentAmount = expensePayment.GrossAmount - expensePayment.DeductionAmount;

                    await this.CreateLoanRepaymentTransactionsAsync(expensePayment.ExpensePaymentId, loansToRepay, user);

                    this.Logger.LogDebug($"\tEXPENSE after processing loans to repay\t{expensePayment.GrossAmount}\t{expensePayment.DeductionAmount}\t{expensePayment.PaymentAmount}");

                    foreach (var transaction in expenseGroup)
                    {
                        // update the expense payment data
                        transaction.ExpensePaymentId = expensePayment.ExpensePaymentId;
                        transaction.ExpensePaymentStatusId = (int)ExpensePaymentStatus.HasSufficientEscrow;
                        transaction.SetAsUpdated(user);

                        await this.Context.ContractTransactions.UpdateAsync(transaction);
                    }

                    // Update cached transaction count
                    expensePayment.TransactionCount = expenseGroup.Count();

                    if (expensePayment.ContractEntityTypeId == (int)ContractEntityType.Presenter)
                    {
                        // For presenter expenses, use the actual name rather than 'PRESENTER'
                        var presenter = await this.Context.Presenters.GetByIdAsync(expensePayment.ContractEntityId);
                        expensePayment.PayeeName = presenter?.AccountName;
                    }

                    // Save changes to the database (including status, counts and payment amounts reduced due to deductions).
                    await this.UpdateExpensePaymentAsync(expensePayment, user);

                    expenseBatchAmount += expensePayment.PaymentAmount;

                    // Get the list of expense payment data for the transactions linked to the payment.
                    var expensePaymentData = await this._contractTransactionService.GetExpensePaymentDataForPaymentAsync(expensePayment.ExpensePaymentId);

                    this.DetermineExpensePaymentStatus(expensePaymentData, expenseGroup);

                    // Update the status for any that have been changed.
                    foreach (var transaction in expenseGroup.Where(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Insufficient))
                    {
                        transaction.SetAsUpdated(user);

                        await this.Context.ContractTransactions.UpdateAsync(transaction);
                    }
                }

                // update cached batch amount
                batch.BatchAmount = expenseBatchAmount;

                await this.UpdateAsync(batch, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return batch;
        }

        public async Task<ExpenseBatchDto> CreateExpenseBatchForSelectedExpensesAsync(CreatePaymentBatchDto options, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                foreach (var id in options.IdsToPay)
                {
                    var contractTransaction = await this.Context.ContractTransactions.GetByIdAsync(id);

                    contractTransaction.CanRelease = true;

                    contractTransaction.SetAsUpdated(user);

                    await this.Context.ContractTransactions.UpdateAsync(contractTransaction);
                }

                var batch = await CreateExpenseBatchAsync(options, user);

                this.Context.Commit();

                return batch;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public void DetermineExpensePaymentStatus(
            IEnumerable<ContractTransactionExpensePaymentDto> expensePaymentData,
            IEnumerable<ContractTransactionDto> expenseGroup)
        {
            var contractGroups = from d in expensePaymentData
                                 group d by new { d.ContractId, d.ContractRequiredAmount, d.ContractEscrowAmount };

            foreach (var contractGroup in contractGroups)
            {
                var availableBalance = contractGroup.Key.ContractEscrowAmount.GetValueOrDefault();

                foreach (var transaction in contractGroup)
                {
                    var match = expenseGroup.FirstOrDefault(x => x.IsExpense && x.ContractTransactionId == transaction.ContractTransactionId);
                    if (match != null)
                    {
                        var expenseAmount = match.RequiredAmount.GetValueOrDefault();
                        var paidAmount = match.PaidAmount.GetValueOrDefault();

                        if (paidAmount > decimal.Zero)
                        {
                            availableBalance -= paidAmount;
                        }
                        else
                        {
                            if (availableBalance >= expenseAmount)
                            {
                                paidAmount = expenseAmount;
                                availableBalance -= expenseAmount;
                            }
                            else
                            {
                                paidAmount = availableBalance;
                                availableBalance = decimal.Zero;
                            }
                        }

                        match.EscrowAmount = paidAmount;

                        if (expenseAmount - paidAmount > decimal.Zero)
                        {
                            match.ExpensePaymentStatusId = (int)ExpensePaymentStatus.Insufficient;
                        }
                    }
                }
            }
        }

        public async Task ResolveEscrowDeficiencyAsync(
            EscrowDeficiencyAction selectedAction,
            int contractTransactionId,
            int expensePaymentId,
            decimal paidAmount,
            IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var contractTransaction = await this._contractTransactionService.GetByIdAsync(contractTransactionId);
                if (contractTransaction == null)
                {
                    throw new Exception($"Contract Transaction #{contractTransactionId} Not Found");
                }

                var expensePayment = await this._expensePaymentService.GetByIdAsync(expensePaymentId);
                if (expensePayment == null)
                {
                    throw new Exception($"Expense Payment #{expensePaymentId} Not Found");
                }

                this.Logger.LogInformation($"ResolveEscrowDeficiency: contractTransactionId {contractTransactionId}, expensePaymentId {expensePaymentId}, action {selectedAction.ToString()}, paidAmount {paidAmount}");

                switch (selectedAction)
                {
                    case EscrowDeficiencyAction.Remove:
                        await this._expensePaymentService.RemoveTransactionFromPaymentAsync(contractTransactionId, expensePaymentId, user);
                        break;

                    case EscrowDeficiencyAction.Partial:

                        /*
                         * The user has selected to split the expense into paid and unpaid amounts, where the unpaid
                         * expense represents the amount of missing escrow funds.
                         */

                        var unpaidAmount = contractTransaction.RequiredAmount.GetValueOrDefault() - paidAmount;
                        if (unpaidAmount <= decimal.Zero)
                        {
                            throw new Exception("Cannot split a negative expense.");
                        }

                        // Reduce the amount required for this expense
                        contractTransaction.RequiredAmount = paidAmount;
                        await this._contractTransactionService.UpdateAsync(contractTransaction, user);

                        var unpaidExpense = Mapper.Map<ContractTransactionDto>(contractTransaction);

                        // Make an additional expense for the unpaid amount.
                        unpaidExpense.ContractTransactionId = 0;
                        unpaidExpense.OriginalRequiredAmount = unpaidAmount;
                        unpaidExpense.RequiredAmount = unpaidAmount;
                        unpaidExpense.RequiredPercentage = null;

                        // Clear out the associated expense payment data
                        unpaidExpense.ExpensePaymentId = null;
                        unpaidExpense.ExpensePayment = null;
                        unpaidExpense.ExpensePaymentStatusId = null;
                        unpaidExpense.PaidAmount = decimal.Zero;

                        // Reset audit columns
                        unpaidExpense.SetAsCreated(user);
                        unpaidExpense.UpdatedById = null;
                        unpaidExpense.UpdatedDate = null;

                        await this._contractTransactionService.CreateAsync(unpaidExpense, user);

                        // Synchronize the expense payment amounts by removing the unpaid amount.
                        expensePayment.GrossAmount -= unpaidAmount;
                        expensePayment.PaymentAmount -= unpaidAmount;

                        await this.UpdateExpensePaymentAsync(expensePayment, user);

                        break;

                    case EscrowDeficiencyAction.Full:

                        contractTransaction.ExpensePaymentStatusId = (int)ExpensePaymentStatus.PayInFull;
                        await this._contractTransactionService.UpdateAsync(contractTransaction, user);

                        break;

                    default:
                        break;
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ExpensePaymentDto> RemoveTransactionFromPaymentAsync(int contractTransactionId, int expensePaymentId, IPrincipal user)
        {
            return await this._expensePaymentService.RemoveTransactionFromPaymentAsync(contractTransactionId, expensePaymentId, user);
        }

        public async Task ProcessPaymentsAsync(ExpenseBatchDto batch, IPrincipal user)
        {
            var transactions = await this.Context.ContractTransactions.GetByExpenseBatchIdAsync(batch.ExpenseBatchId);

            foreach (var payment in batch.ExpensePayments)
            {
                var transactionsForPayment = transactions.Where(x => x.ExpensePaymentId == payment.ExpensePaymentId);

                foreach (var transaction in transactionsForPayment)
                {
                    var status = (ExpensePaymentStatus)transaction.ExpensePaymentStatusId.GetValueOrDefault();

                    switch (status)
                    {
                        case ExpensePaymentStatus.Withhold:
                            // Remove transaction
                            break;

                        case ExpensePaymentStatus.PayEscrowBalance:
                            // Split
                            break;

                        default:
                            break;
                    }
                }
            }
        }

        public async Task<bool> PostBatchAsync(ExpenseBatchDto batch, int? nextCheckSequenceNumber, IPrincipal user)
        {
            if (batch == null)
            {
                throw new ArgumentNullException(nameof(batch));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            if (batch.IsPosted)
            {
                throw new AlreadyPostedException($"Expense batch {batch.ExpenseBatchId} is already posted.");
            }

            if (batch.ExpensePayments == null || !batch.ExpensePayments.Any())
            {
                throw new AlreadyPostedException($"Expense batch {batch.ExpenseBatchId} cannot be posted; no payments exist.");
            }

            bool success = false;

            decimal batchAmount = 0;

            try
            {
                if (nextCheckSequenceNumber.HasValue)
                {
                    await this.Context.EntitySequences.UpdateSequenceAsync(EntitySequenceConstants.CheckNumber, nextCheckSequenceNumber.Value);
                }

                this.Context.BeginTransaction();

                var orderedPayments = batch.ExpensePayments
                    .Where(x => x.IsDeleted == false)
                    .OrderBy(x => x.PayeeName);

                var refunds = await this.Context.PresenterRefunds.GetByExpenseBatchIdAsync(batch.ExpenseBatchId);

                Logger.LogDebug("PostBatchAsync");

                foreach (var payment in orderedPayments)
                {
                    var stopwatch = System.Diagnostics.Stopwatch.StartNew();

                    await this.PostPaymentAsync(payment, user);

                    stopwatch.Stop();

                    Logger.LogDebug($"PostPayment {payment.ExpensePaymentId} {stopwatch.ElapsedMilliseconds} {payment.PaymentAmount:C}");

                    batchAmount += payment.PaymentAmount;

                    payment.Refund = refunds.FirstOrDefault(x => x.ExpensePaymentId == payment.ExpensePaymentId);
                }

                // create Check Report file
                var checkPayments = orderedPayments
                    .Where(x => x.ExpensePaymentTypeId == (int)ExpensePaymentType.Check && x.PaymentAmount != decimal.Zero)
                    .ToList();

                IList<ContractTransactionDto> batchTransactions = null;

                if (checkPayments.Any())
                {
                    Logger.LogDebug("CreateCheckReportFilesAsync: Before");

                    await this.CreateCheckReportFilesAsync(batch, checkPayments, user);

                    Logger.LogDebug("CreateCheckReportFilesAsync: After");
                }

                // create ACH file
                var achPayments = orderedPayments
                    .Where(x => x.ExpensePaymentTypeId == (int)ExpensePaymentType.DirectDeposit && x.PaymentAmount != decimal.Zero)
                    .ToList();

                batch.DatePosted = DateTime.Now;

                batch.BatchAmount = batchAmount;

                if (achPayments.Any())
                {
                    Logger.LogDebug("CreateACHFileAsync: Before");

                    batchTransactions = await this.GetBatchTransactionsAsync(batch);

                    await this.CreateACHFileAsync(batch, achPayments, user);

                    Logger.LogDebug("CreateACHNotificationsAsync: Before");

                    await this.CreateACHNotificationsAsync(batch, achPayments, user);

                    Logger.LogDebug("CreateACHNotificationsAsync: After");
                }

                // update the ExpenseBatch record
                await this.UpdateAsync(batch, user);

                if (batch.ExpenseBatchTypeId == (int)ExpenseBatchType.Artist)
                {
                    Logger.LogDebug("GetBatchTransactionsAsync: Before");

                    if (batchTransactions == null)
                    {
                        batchTransactions = await this.GetBatchTransactionsAsync(batch);
                    }

                    Logger.LogDebug("CreateArtistSummaryFileAsync: Before");

                    await this.CreateArtistSummaryFileAsync(batch, batchTransactions, user);

                    Logger.LogDebug("CreateArtistSummaryFileAsync: After");
                }

                this.Context.Commit();

                success = true;
            }
            catch (InvalidACHPayeeException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return success;
        }

        public async Task<EntitySequenceDto> GetCheckNumberSequenceAsync()
        {
            var sequence = await Context.EntitySequences.GetSequenceByEntityAsync(EntitySequenceConstants.CheckNumber);

            return sequence;
        }

        public async Task<string> GetReferenceNumberAsync(ExpensePaymentDto payment)
        {
            string referenceNumber = string.Empty;

            if (payment.PaymentAmount == 0)
            {
                referenceNumber = $"Z{payment.ExpensePaymentId}";
            }
            else if (payment.ExpensePaymentTypeId == (int)ExpensePaymentType.DirectDeposit)
            {
                var directDepositNumber = await Context.EntitySequences.GetNextSequenceByEntityAsync(EntitySequenceConstants.DirectDepositNumber);
                referenceNumber = $"D{directDepositNumber}";
            }
            else if (payment.ExpensePaymentTypeId == (int)ExpensePaymentType.WireTransfer)
            {
                var wireNumber = await Context.EntitySequences.GetNextSequenceByEntityAsync(EntitySequenceConstants.WireNumber);
                referenceNumber = $"w-{wireNumber}";
            }
            else
            {
                var checkNumber = await Context.EntitySequences.GetNextSequenceByEntityAsync(EntitySequenceConstants.CheckNumber);
                referenceNumber = $"{checkNumber}";
            }

            return referenceNumber;
        }

        public void SetContractTransactionAsPosted(ContractTransactionDto transaction, string referenceNumber, decimal paidAmount)
        {
            transaction.ReferenceNumber = referenceNumber;

            transaction.ExpensePaymentStatusId = (int)ExpensePaymentStatus.FullyPaid;

            transaction.PaidDate = DateTime.Today;
            transaction.PaidAmount = transaction.RequiredAmount;
        }

        public async Task PostPaymentAsync(ExpensePaymentDto payment, IPrincipal user)
        {
            string referenceNumber = await this.GetReferenceNumberAsync(payment);

            payment.DatePosted = DateTime.Now;

            payment.ReferenceNumber = referenceNumber;

            // Get contract transactions for this payment
            var contractTransactions = await this._contractTransactionService.GetByExpensePaymentIdAsync(payment.ExpensePaymentId);

            payment.ExpenseTransactions = contractTransactions;

            foreach (var transaction in contractTransactions)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();

                var paidAmount = transaction.RequiredAmount.GetValueOrDefault();

                this.SetContractTransactionAsPosted(transaction, referenceNumber, paidAmount);

                await this._contractTransactionService.UpdateAsync(transaction, user);

                // Add GL Entries indicating the expense has been paid.
                var glEvent = this._generalLedgerService.GetEventForPayingNonEceExpense(transaction);

                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(glEvent, paidAmount, transaction, user, transaction.ReferenceNumber, payment.ExpenseBatchId);

                stopwatch.Stop();
                Logger.LogDebug($"Post Transaction # {transaction.ContractTransactionId} {stopwatch.ElapsedMilliseconds}");
            }

            var crossDeductions = await this.Context.ContractDeposits.GetCrossDeductionsAsync(payment.ExpensePaymentId);

            foreach (var crossDeductionDeposit in crossDeductions)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();

                if (crossDeductionDeposit.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold)
                {
                    await this.Context.ContractDeposits.DeleteAsync(crossDeductionDeposit);
                }
                else
                {
                    crossDeductionDeposit.ReferenceNumber = $"XDED. for {payment.ReferenceNumber}";

                    await this._contractDepositService.PostContractDepositAsync(crossDeductionDeposit, payment, user);
                }

                stopwatch.Stop();
                Logger.LogDebug($"Post XDED # {crossDeductionDeposit.ContractDepositId} {stopwatch.ElapsedMilliseconds}");
            }

            await this._artistChargeService.PostArtistChargeRepaymentsAsync(payment.ExpensePaymentId, user);

            await this.UpdateExpensePaymentAsync(payment, user);
        }

        public async Task CreateACHNotificationsAsync(ExpenseBatchDto batch, List<ExpensePaymentDto> achPayments, IPrincipal user, bool useBulkInserts = true)
        {
            var batchTransactions = new List<ContractTransactionDto>();

            var expensePaymentIds = achPayments.Select(x => x.ExpensePaymentId).ToArray();

            var transactions = await this._contractTransactionService.GetByExpensePaymentIdsAsync(expensePaymentIds);
            batchTransactions.AddRange(transactions);

            var artistChargeTransactions = await this.Context.ArtistCharges.GetLoanRepaymentsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var loanRepayments = artistChargeTransactions
                .AsQueryable()
                .Select(ExpenseBatchService.MapRepayments);

            batchTransactions.AddRange(loanRepayments);

            var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var crossDeductions = crossDeductionDeposits
                .AsQueryable()
                .Select(ExpenseBatchService.MapCrossDeduction);

            batchTransactions.AddRange(crossDeductions);

            Logger.LogDebug("GetChecksToPrint Before");

            var directDepositsToSendNotifications = await this._checkGenerationService.GetChecksToPrint(achPayments, batchTransactions);

            Logger.LogDebug("GetChecksToPrint After");

            EmailTemplateDto bodyTemplate = null;

            bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendACHNotification);

            var smtpManager = new SmtpManager(this.Context, useBulkInserts);

            var releaseDate = GetACHNotificationReleaseDate(TimeProvider.Current);

            var agent = await Context.Users.GetByIdAsync(user.GetUserId());

            IDictionary<int, ContactDto> primaryContacts = null;

            if (batch.ExpenseBatchTypeId == (int)ExpenseBatchType.Artist)
            {
                var primaryContactData = await this.Context.Contacts.GetBatchPrimaryContactsAsync(batch.ExpenseBatchId);

                primaryContacts = primaryContactData.ToDictionary(x => x.EntityId);
            }

            foreach (var directDeposit in directDepositsToSendNotifications)
            {
                var message = AccountingFileGenerators.CreateACHNotificationMessage(bodyTemplate, directDeposit);

                ContactDto primaryContact = null;

                if (primaryContacts.ContainsKey(directDeposit.EntityId))
                {
                    primaryContact = primaryContacts[directDeposit.EntityId];
                }
                else
                {
                    primaryContact = await this.Context.Contacts.GetPrimaryContactAsync((EntityType)directDeposit.EntityTypeId, directDeposit.EntityId);
                }

                message.AddRecipient(primaryContact);

                // If the primary contact doesn't exist or does not have an e-mail address then send
                // the notification to the user posting the batch for them to research
                if (message.HasRecipient == false)
                {
                    message.AddRecipient(agent.Username, agent.FullName);
                }

                smtpManager.SendMessage(message, user.GetUserId(), releaseDate, SendMessageMode.Queued);

                var commLog = new CommunicationLogDto
                {
                    CommunicationMethodId = (int)CommunicationMethod.Email,
                    ContactId = primaryContact == null ? 0 : primaryContact.ContactId,
                   //ContactId = primaryContact?.ContactId ?? 0,
                    EntityId = directDeposit.EntityId,
                    EntityTypeId = (int)EntityType.Artist,
                    EmailQueueId = message.EmailQueueId,
                    LogDate = DateTime.Now,
                    LogTime = DateTime.Now.ToShortTimeString(),
                    Notes = "Send ACH Notification to Artist"
                };

                _communicationLogService.AddCommunicationLog(commLog, user);
            }
        }

        public DateTime GetACHNotificationReleaseDate(ITimeProvider timeProvider)
        {
            // Release at configured date/time (default = the day after tomorrow at noon).
            // Typically, Contract PRocessing will generate these messages Tuesday afternoons. The expectation
            // is for these notifications to be released Thursday at noon.
            var defaultValue = TimeSpan.FromDays(2).Add(TimeSpan.FromHours(12));

            var releaseDepositReceivedMessage = MobiusConfiguration.GetTimeSpan("Application.ACHNotificationReleaseDate", defaultValue);

            var releaseDate = timeProvider.Today.Add(releaseDepositReceivedMessage);

            return releaseDate;
        }

        public async Task<DateTime> ResendACHNotificationAsync(int id, IPrincipal user)
        {
            var expensePayment = await this.Context.ExpensePayments.GetByIdAsync(id);
            if (expensePayment == null)
            {
                throw new Exception($"Payment # {id} not found");
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var batch = await this.Context.ExpenseBatches.GetByIdAsync(expensePayment.ExpenseBatchId);

            var achPayments = new List<ExpensePaymentDto> { expensePayment };

            await this.CreateACHNotificationsAsync(batch, achPayments, user, false);

            return this.GetACHNotificationReleaseDate(TimeProvider.Current);
        }

        public async Task<List<ContractDto>> GetBatchContractsAsync(int expenseBatchId)
        {
            Logger.LogDebug("GetBatchContractsAsync");

            var results = await this.Context.Contracts.GetBatchContractsAsync(expenseBatchId);

            Logger.LogDebug($"\tresults.Count = {results.Count}");

            return results;
        }

        public async Task<List<ContractTransactionDto>> GetBatchTransactionsAsync(ExpenseBatchDto batch)
        {
            var batchTransactions = new List<ContractTransactionDto>();

            var transactions = await this._contractTransactionService.GetByExpenseBatchIdAsync(batch.ExpenseBatchId);

            batchTransactions.AddRange(transactions);

            var artistChargeTransactions = await this.Context.ArtistCharges.GetLoanRepaymentsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var loanRepayments = artistChargeTransactions
                .AsQueryable()
                .Select(ExpenseBatchService.MapRepayments);

            batchTransactions.AddRange(loanRepayments);

            var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var crossDeductions = crossDeductionDeposits
                .AsQueryable()
                .Select(ExpenseBatchService.MapCrossDeduction);

            batchTransactions.AddRange(crossDeductions);

            var contracts = await this.GetBatchContractsAsync(batch.ExpenseBatchId);

            foreach (var item in batchTransactions)
            {
                var contract = contracts.FirstOrDefault(x => x.ContractId == item.ContractId);
                item.ParentContract = contract;

                var expensePayment = batch.ExpensePayments.FirstOrDefault(x => x.ExpensePaymentId == item.ExpensePaymentId);
                item.ExpensePayment = expensePayment;
            }

            return batchTransactions;
        }

        public async Task<List<ContractTransactionDto>> CreateCheckReportFilesAsync(ExpenseBatchDto batch, List<ExpensePaymentDto> checkPayments, IPrincipal user)
        {
            var checkFile = AccountingFileGenerators.GenerateCheckReportFile(batch.ExpenseBatchId, (ExpenseBatchType)batch.ExpenseBatchTypeId, checkPayments);

            try
            {
                var firstCheck = checkPayments.FirstOrDefault();
                if (firstCheck != null)
                {
                    // Set file name to match format expected by banking institution.
                    checkFile.OriginalFileName = $"sun{firstCheck.ReferenceNumber}";
                }

                this._documentService.AddDocumentTo(EntityType.Accounting, batch.ExpenseBatchId, checkFile, user.GetUserId());

                var checkFileExpenseBatchFile = new ExpenseBatchFileDto()
                {
                    ExpenseBatchId = batch.ExpenseBatchId,
                    ExpenseBatchFileTypeId = (int)ExpenseBatchFileType.CheckFile,
                    DocumentExtension = checkFile.DocumentExtension.Text,
                    DocumentExtensionId = checkFile.DocumentExtensionId,
                    OriginalFileName = checkFile.OriginalFileName,
                    StorageFileName = checkFile.StorageFileName,
                    Description = checkFile.Description,
                    DateUploaded = checkFile.CreatedDate
                };

                await this.CreateExpenseBatchFileAsync(checkFileExpenseBatchFile, user);
            }
            finally
            {
                if (checkFile.Contents != null)
                {
                    checkFile.Contents.Close();
                    checkFile.Contents.Dispose();
                }
            }

            var batchTransactions = new List<ContractTransactionDto>();

            // log the checks in the GL
            foreach (var check in checkPayments)
            {
                var transactions = await this._contractTransactionService.GetByExpensePaymentIdAsync(check.ExpensePaymentId);

                batchTransactions.AddRange(transactions);
            }

            var artistChargeTransactions = await this.Context.ArtistCharges.GetLoanRepaymentsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var loanRepayments = artistChargeTransactions
                .AsQueryable()
                .Select(ExpenseBatchService.MapRepayments);

            batchTransactions.AddRange(loanRepayments);

            var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            var crossDeductions = crossDeductionDeposits
                .AsQueryable()
                .Select(ExpenseBatchService.MapCrossDeduction);

            batchTransactions.AddRange(crossDeductions);

            var checksToPrint = await this._checkGenerationService.GetChecksToPrint(checkPayments, batchTransactions);

            var checksToPrintFile = AccountingFileGenerators.GenerateCheckListFile((ExpenseBatchType)batch.ExpenseBatchTypeId, checksToPrint);

            try
            {
                this._documentService.AddDocumentTo(EntityType.Accounting, batch.ExpenseBatchId, checksToPrintFile, user.GetUserId());

                var checksToPrintExpenseBatchFile = new ExpenseBatchFileDto()
                {
                    ExpenseBatchId = batch.ExpenseBatchId,
                    ExpenseBatchFileTypeId = (int)ExpenseBatchFileType.ACH,
                    DocumentExtension = checksToPrintFile.DocumentExtension.Text,
                    DocumentExtensionId = checksToPrintFile.DocumentExtensionId,
                    OriginalFileName = checksToPrintFile.OriginalFileName,
                    StorageFileName = checksToPrintFile.StorageFileName,
                    Description = checksToPrintFile.Description,
                    DateUploaded = checksToPrintFile.CreatedDate
                };

                await this.CreateExpenseBatchFileAsync(checksToPrintExpenseBatchFile, user);
            }
            finally
            {
                if (checksToPrintFile.Contents != null)
                {
                    checksToPrintFile.Contents.Close();
                    checksToPrintFile.Contents.Dispose();
                }
            }

            return batchTransactions;
        }

        public async Task CreateACHFileAsync(ExpenseBatchDto batch, List<ExpensePaymentDto> achPayments, IPrincipal user)
        {
            var artistIds = achPayments.Select(x => x.ContractEntityId).ToArray();
            var artists = await this.Context.Artists.GetByArtistIdsAsync(artistIds);

            foreach (var payment in achPayments.Where(x => x.ContractEntityTypeId == (int)ContractEntityType.Artist))
            {
                var artist = artists.FirstOrDefault(x => x.ArtistId == payment.ContractEntityId);
                if (artist == null)
                {
                    artist = await this._artistService.GetArtistByIdAsync(payment.ContractEntityId);
                }

                payment.Artist = artist;

                if (string.IsNullOrWhiteSpace(artist.RoutingNumber) ||
                    artist.RoutingNumber.Length != 9)
                {
                    throw new InvalidACHPayeeException(artist);
                }

                if (string.IsNullOrWhiteSpace(artist.AccountNumber))
                {
                    throw new InvalidACHPayeeException(artist);
                }
            }

            Logger.LogDebug($"CreateACHFileAsync: After Processing Payments");

            var generator = new ACHFileGenerator(this.Context);

            var achFile = await generator.GenerateACHFileAsync((ExpenseBatchType)batch.ExpenseBatchTypeId, achPayments);

            Logger.LogDebug($"CreateACHFileAsync: After GenerateACHFileAsync");

            try
            {
                // Set file name to match format expected by banking institution.
                achFile.OriginalFileName = $"{batch.DatePosted:yyMMdd}{batch.ExpenseBatchId}";

                this._documentService.AddDocumentTo(EntityType.Accounting, batch.ExpenseBatchId, achFile, user.GetUserId());

                var achFileExpenseBatchFile = new ExpenseBatchFileDto()
                {
                    ExpenseBatchId = batch.ExpenseBatchId,
                    ExpenseBatchFileTypeId = (int)ExpenseBatchFileType.ACH,
                    DocumentExtension = achFile.DocumentExtension.Text,
                    DocumentExtensionId = achFile.DocumentExtensionId,
                    OriginalFileName = achFile.OriginalFileName,
                    StorageFileName = achFile.StorageFileName,
                    Description = achFile.Description,
                    DateUploaded = achFile.CreatedDate
                };

                await this.CreateExpenseBatchFileAsync(achFileExpenseBatchFile, user);
            }
            finally
            {
                if (achFile.Contents != null)
                {
                    achFile.Contents.Close();
                    achFile.Contents.Dispose();
                }
            }

            Logger.LogDebug($"CreateACHFileAsync: After Batch Loaded");
        }

        public async Task<IList<PaymentSearchResultDto>> GetPaymentsByCriteriaAsync(PaymentSearchCriteriaDto criteria)
        {
            var results = await this.Context.ExpensePayments.GetPaymentsByCriteriaAsync(criteria);

            return results;
        }

        public async Task<IList<BatchSearchResultDto>> GetBatchesByCriteriaAsync(BatchSearchCriteriaDto criteria)
        {
            var results = await this.Context.ExpenseBatches.GetByCriteriaAsync(criteria);

            return results;
        }

        public async Task<IList<ContractTransactionDto>> GetExpensePaymentTransactionsAsync(int id)
        {
            var transactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(id);

            // Filter out any transactions being withheld.
            if (transactions.Any(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold))
            {
                transactions = transactions
                    .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                    .ToList();
            }

            var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsAsync(id);

            // Filter out any cross deductions being withheld.
            if (crossDeductionDeposits.Any(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold))
            {
                crossDeductionDeposits = crossDeductionDeposits
                    .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                    .ToList();
            }

            if (crossDeductionDeposits.Any())
            {
                var crossDeductions = crossDeductionDeposits
                    .AsQueryable()
                    .Select(ExpenseBatchService.MapCrossDeduction);

                foreach (var crossDeduction in crossDeductions)
                {
                    transactions.Add(crossDeduction);
                }

                transactions = transactions
                    .OrderBy(x => x.ContractId)
                    .ThenBy(x => x.DueDate)
                    .ThenBy(x => x.ContractTransactionTypeId)
                    .ThenBy(x => x.ContractTransactionId)
                    .ToList();
            }

            var loanRepayments = await this.GetLoanRepaymentsAsync(id);
            if (loanRepayments.Any())
            {
                var artistPaymentIndex = transactions.Count - 1;

                var artistPayment = transactions.FirstOrDefault(x => x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);
                if (artistPayment != null)
                {
                    // Insert the loan repayments immediately after the first artist payment.
                    artistPaymentIndex = transactions.IndexOf(artistPayment);

                    for (int i = 0; i < loanRepayments.Count; i++)
                    {
                        transactions.Insert(artistPaymentIndex + 1 + i, loanRepayments[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < loanRepayments.Count; i++)
                    {
                        transactions.Add(loanRepayments[i]);
                    }
                }
            }

            foreach (var transaction in transactions.Where(x => x.IsIncome && x.ContractTransactionTypeId == (int)ContractTransactionType.Deposit))
            {
                transaction.PaidAmount = transaction.PaidAmount * decimal.MinusOne;
                transaction.RequiredAmount = transaction.RequiredAmount * decimal.MinusOne;
            }

            return transactions;
        }

        public async Task<IList<ContractTransactionDto>> GetExpensePaymentTransactionsAsync(int expensePaymentId, ExpenseBatchDto batch)
        {
            IList<ContractTransactionDto> transactions;

            if (batch.ExpenseBatchTypeId == (int)ExpenseBatchType.ECE)
            {
                /*
                 * For ECE batches, the amount for the batch is based on the GL Journal entries, not the required amounts listed on the transactions.
                 * Each ECE Batch has one payment, containing all the transactions for the day. Hence, getting all the transactions
                 * in the batch is the same as getting all the transactions for the expense.
                 */
                var batchTransactions = await this.Context.ExpenseBatches.GetPaymentTransactionsByExpenseBatchIdAsync(batch.ExpenseBatchId);

                // Get a distinct list of all the transactions
                transactions = batchTransactions
                    .GroupBy(x => x.ContractTransactionId)
                    .Select(x => x.First())
                    .ToList();

                // Get all the GL Journal entries for the batch.
                var activity = await this.Context.GeneralLedgers.GetJournalActivityByExpenseBatchIdAsync(batch.ExpenseBatchId);

                foreach (var transaction in transactions)
                {
                    // For each transaction, the required amount is the amount posted to the ECE Operating account.
                    var creditAmount = activity
                        .Where(x => x.ContractTransactionId == transaction.ContractTransactionId && x.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Operating)
                        .Where(x => x.ChangeType == "C")
                        .Total(x => x.PostedAmount);
                    var debitAmount = activity
                        .Where(x => x.ContractTransactionId == transaction.ContractTransactionId && x.GeneralLedgerAccountId == (int)GeneralLedgerAccounts.Operating)
                        .Where(x => x.ChangeType == "D")
                        .Total(x => x.PostedAmount);
                    transaction.RequiredAmount = debitAmount - creditAmount;
                }
            }
            else
            {
                transactions = await this.Context.ContractTransactions.GetByExpensePaymentIdAsync(expensePaymentId);
            }

            // Filter out any transactions being withheld.
            if (transactions.Any(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold))
            {
                transactions = transactions
                    .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                    .ToList();
            }

            var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsAsync(expensePaymentId);

            // Filter out any cross deductions being withheld.
            if (crossDeductionDeposits.Any(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold))
            {
                crossDeductionDeposits = crossDeductionDeposits
                    .Where(x => x.ExpensePaymentStatusId != (int)ExpensePaymentStatus.Withhold)
                    .ToList();
            }

            if (crossDeductionDeposits.Any())
            {
                var crossDeductions = crossDeductionDeposits
                    .AsQueryable()
                    .Select(ExpenseBatchService.MapCrossDeduction);

                foreach (var crossDeduction in crossDeductions)
                {
                    transactions.Add(crossDeduction);
                }

                transactions = transactions
                    .OrderBy(x => x.ContractId)
                    .ThenBy(x => x.DueDate)
                    .ThenBy(x => x.ContractTransactionTypeId)
                    .ThenBy(x => x.ContractTransactionId)
                    .ToList();
            }

            var loanRepayments = await this.GetLoanRepaymentsAsync(expensePaymentId);
            if (loanRepayments.Any())
            {
                var artistPaymentIndex = transactions.Count - 1;

                var artistPayment = transactions.FirstOrDefault(x => x.ContractTransactionTypeId == (int)ContractTransactionType.ArtistPayment);
                if (artistPayment != null)
                {
                    // Insert the loan repayments immediately after the first artist payment.
                    artistPaymentIndex = transactions.IndexOf(artistPayment);

                    for (int i = 0; i < loanRepayments.Count; i++)
                    {
                        transactions.Insert(artistPaymentIndex + 1 + i, loanRepayments[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < loanRepayments.Count; i++)
                    {
                        transactions.Add(loanRepayments[i]);
                    }
                }
            }

            if (batch.ExpenseBatchTypeId != (int)ExpenseBatchType.ECE)
            {
                foreach (var transaction in transactions.Where(x => x.IsIncome && x.ContractTransactionTypeId == (int)ContractTransactionType.Deposit))
                {
                    transaction.PaidAmount = transaction.PaidAmount * decimal.MinusOne;
                    transaction.RequiredAmount = transaction.RequiredAmount * decimal.MinusOne;
                }

                if (transactions.Any(x => x.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Insufficient))
                {
                    var expensePaymentData = await this._contractTransactionService.GetExpensePaymentDataForPaymentAsync(expensePaymentId);

                    this.DetermineExpensePaymentStatus(expensePaymentData, transactions);
                }
            }

            return transactions;
        }

        public async Task<List<ContractTransactionDto>> GetLoanRepaymentsAsync(int expensePaymentId)
        {
            var results = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(expensePaymentId);

            return results
                .AsQueryable()
                .Select(ExpenseBatchService.MapRepayments)
                .ToList();
        }

        public async Task CreateExpenseBatchFileAsync(ExpenseBatchFileDto dto, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                dto.SetAsCreated(user.GetUserId());

                await this.Context.ExpenseBatches.CreateExpenseBatchFileAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<ContractTransactionDto>> GetExpensesToPayAsync(CreatePaymentBatchDto options)
        {
            if (options.IdsToPay.Any())
            {
                return await Context.ContractTransactions.GetSelectedExpensesAsync(options.IdsToPay);
            }
            else
            {
                return await this.GetExpensesToPayAsync(options.ExpenseBatchType, options.IncludeSharedBonus, options.IncludeGasCard, options.IncludeNational);
            }
        }

        public async Task<List<ContractTransactionDto>> GetExpensesToPayAsync(ExpenseBatchType batchType, bool sharedBonusOption, bool gasCardOption, bool payNationalsOption)
        {
            var expensesToPay = new List<ContractTransactionDto>();

            // get ContractTransactions approved for release
            if (batchType == ExpenseBatchType.Artist)
            {
                var agentPayments = await this._contractTransactionService.GetPayableByContractTransactionTypeAsync(ContractTransactionType.ArtistPayment);

                expensesToPay.AddRange(agentPayments);

                if (sharedBonusOption)
                {
                    var sharedBonuses = await this._contractTransactionService.GetPayableByContractTransactionTypeAsync(ContractTransactionType.SharedBonus);

                    expensesToPay.AddRange(sharedBonuses);
                }

                if (gasCardOption)
                {
                    var gasCards = await this._contractTransactionService.GetPayableByContractTransactionTypeAsync(ContractTransactionType.GasCard);

                    expensesToPay.AddRange(gasCards);

                    var reservedAllowances = await this._contractTransactionService.GetPayableByContractTransactionTypeAsync(ContractTransactionType.ReserveAllowance);

                    expensesToPay.AddRange(reservedAllowances);
                }

                if (payNationalsOption)
                {
                    var nationals = await this._contractTransactionService.GetPayableByContractTransactionTypeAsync(ContractTransactionType.NationalBuyingFee);

                    expensesToPay.AddRange(nationals);
                }

                var otherArtistTransactions = await this._contractTransactionService.GetOtherPayableArtistTransactionsAsync();

                expensesToPay.AddRange(otherArtistTransactions);
            }
            else if (batchType == ExpenseBatchType.OtherExpenses)
            {
                // pay other expenses
                var others = await this._contractTransactionService.GetPayableOtherExpensesAsync();

                expensesToPay.AddRange(others);
            }
            else
            {
                throw new ArgumentException($"Invalid batch type: {batchType}");
            }

            return expensesToPay;
        }

        public async Task<IEnumerable<ContractTransactionDto>> GetExistingTransactionsByExpenseBatchIdAsync(int id)
        {
            var existingTransactions = await this._contractTransactionService.GetByExpenseBatchIdAsync(id);

            return existingTransactions.Where(x => x.IsExpense);
        }

        public async Task RemoveExpensesNoLongerApprovedForReleaseAsync(IEnumerable<ContractTransactionDto> existingExpenses, IPrincipal user)
        {
            foreach (var existingExpense in existingExpenses)
            {
                // If any existing transactions are no longer approved for release, then withhold them from
                // being paid with this batch.
                if (!existingExpense.CanRelease)
                {
                    await this._contractTransactionService.UpdateExpensePaymentStatusAsync(existingExpense, ExpensePaymentStatus.Withhold, user);
                }
            }
        }

        public IEnumerable<ContractTransactionDto> CombineExpensesForBatch(
            IList<ContractTransactionDto> expensesToPay,
            IEnumerable<ContractTransactionDto> existingExpenses)
        {
            foreach (var existingExpense in existingExpenses)
            {
                expensesToPay.Add(existingExpense);
            }

            // Get a distinct list of the expenses
            var expenses = expensesToPay
                .GroupBy(x => x.ContractTransactionId)
                .Select(x => x.First());

            return expenses;
        }

        public ExpensePaymentDto GetOrCreateExpensePayment(
            IEnumerable<ExpensePaymentDto> existingPayments,
            ExpenseGroupKey key,
            ExpensePaymentAmounts amounts)
        {
            var expensePayment = existingPayments.FirstOrDefault(x => x.ContractEntityId == key.ContractEntityId && x.ContractEntityTypeId == key.ContractEntityTypeId);
            if (expensePayment == null)
            {
                var payeeName = key.PayeeName;

                expensePayment = new ExpensePaymentDto()
                {
                    ExpensePaymentTypeId = (int)ExpensePaymentType.Check, // Check by Default
                    ContractEntityTypeId = key.ContractEntityTypeId,
                    ContractEntityId = key.ContractEntityId,
                    DateIssued = DateTime.Now,
                    GrossAmount = amounts.GrossAmount,
                    DeductionAmount = amounts.DeductionAmount,
                    PaymentAmount = amounts.PaymentAmount,
                    PayeeName = payeeName
                };
            }
            else
            {
                expensePayment.GrossAmount = amounts.GrossAmount;
                expensePayment.DeductionAmount = amounts.DeductionAmount;
                expensePayment.PaymentAmount = amounts.PaymentAmount;
            }

            return expensePayment;
        }

        public async Task<IEnumerable<IGrouping<ExpenseGroupKey, ContractTransactionDto>>> GetExpenseGroupsAsync(ExpenseBatchDto batch, bool sharedBonusOption, bool gasCardOption, bool payNationalsOption, IPrincipal user)
        {
            var existingExpenses = await this.GetExistingTransactionsByExpenseBatchIdAsync(batch.ExpenseBatchId);

            await this.RemoveExpensesNoLongerApprovedForReleaseAsync(existingExpenses, user);

            var batchType = (ExpenseBatchType)batch.ExpenseBatchTypeId;

            var expensesToPay = await this.GetExpensesToPayAsync(batchType, sharedBonusOption, gasCardOption, payNationalsOption);

            // Get a distinct list of the expenses
            var expenses = this.CombineExpensesForBatch(expensesToPay, existingExpenses);

            return GroupsExpenses(expenses);
        }

        public IList<ContractTransactionDto> RemoveExpensesWithoutW9OnFile(IList<ArtistDto> artists, IList<ContractTransactionDto> expensesToPay)
        {
            var withoutW9 = artists.Where(x => x.W9OnFileDate == null).Select(x => x.ArtistId);

            return expensesToPay.Where(x => !withoutW9.Contains(x.ContractEntityId)).ToList();
        }

        public async Task<IEnumerable<IGrouping<ExpenseGroupKey, ContractTransactionDto>>> GetExpenseGroupsAsync(ExpenseBatchDto batch, CreatePaymentBatchDto options, IPrincipal user)
        {
            var existingExpenses = await this.GetExistingTransactionsByExpenseBatchIdAsync(batch.ExpenseBatchId);
            this.Logger.LogDebug($"After GetExistingTransactionsByExpenseBatchIdAsync");

            await this.RemoveExpensesNoLongerApprovedForReleaseAsync(existingExpenses, user);
            this.Logger.LogDebug($"After RemoveExpensesNoLongerApprovedForReleaseAsync");

            var expensesToPay = await this.GetExpensesToPayAsync(options);
            this.Logger.LogDebug($"After GetExpensesToPayAsync");

            if (batch.ExpenseBatchTypeId == (int)ExpenseBatchType.Artist)
            {
                var artistIds = expensesToPay.Select(x => x.ContractEntityId).ToArray();
                var artists = await this.Context.Artists.GetByArtistIdsAsync(artistIds);
                this.Logger.LogDebug($"After GetByExpenseBatchIdAsync");

                expensesToPay = this.RemoveExpensesWithoutW9OnFile(artists, expensesToPay);

                foreach (var expenseToPay in expensesToPay)
                {
                    var artist = artists.FirstOrDefault(x => x.ArtistId == expenseToPay.ContractEntityId);
                    if (artist != null && !string.IsNullOrWhiteSpace(artist.PayeeName))
                    {
                        expenseToPay.PayeeName = artist.PayeeName;
                    }
                }
            }
            else if (batch.ExpenseBatchTypeId == (int)ExpenseBatchType.OtherExpenses)
            {
                foreach (var payment in expensesToPay)
                {
                    switch ((ContractEntityType)payment.ContractEntityTypeId)
                    {
                        case ContractEntityType.Reseller:
                            var reseller = await this.Context.Resellers.GetByIdAsync(payment.ContractEntityId);
                            if (reseller != null && !string.IsNullOrWhiteSpace(reseller.PayeeName))
                            {
                                payment.PayeeName = reseller.PayeeName;
                            }

                            break;

                        case ContractEntityType.Vendor:
                            var vendor = await this.Context.Vendors.GetByIdAsync(payment.ContractEntityId);
                            if (vendor != null && !string.IsNullOrWhiteSpace(vendor.PayeeName))
                            {
                                payment.PayeeName = vendor.PayeeName;
                            }

                            break;

                        case ContractEntityType.Artist:
                            var artist = await this.Context.Artists.GetByIdAsync(payment.ContractEntityId);
                            if (artist != null && !string.IsNullOrWhiteSpace(artist.PayeeName))
                            {
                                payment.PayeeName = artist.PayeeName;
                            }

                            break;

                        default:
                            break;
                    }
                }
            }

            // Get a distinct list of the expenses
            var expenses = this.CombineExpensesForBatch(expensesToPay, existingExpenses);
            this.Logger.LogDebug($"After CombineExpensesForBatch");

            return GroupsExpenses(expenses);
        }

        public async Task<IList<ContractTransactionDto>> CheckForIncomeRecordsAsync(int contractEntityId, ContractEntityType contractEntityType, decimal paymentAmount)
        {
            var incomeRecords = await this.Context.ContractTransactions.GetUnpaidIncomeRecordsByPayeeAsync(contractEntityId, contractEntityType);

            return incomeRecords;
        }

        public async Task CreateArtistSummaryFileAsync(ExpenseBatchDto batch, IList<ContractTransactionDto> batchTransactions, IPrincipal user)
        {
            foreach (var payment in batch.ExpensePayments)
            {
                if (payment.Artist == null)
                {
                    var artist = await this._artistService.GetArtistByIdAsync(payment.ContractEntityId);

                    payment.Artist = artist;
                }
            }

            var generator = new ArtistSummaryFileGenerator(this.Context);

            Logger.LogDebug($"GenerateSummaryFile: Before");

            var summaryFile = generator.GenerateSummaryFile(batch, batchTransactions);

            Logger.LogDebug($"GenerateSummaryFile: After");

            try
            {
                this._documentService.AddDocumentTo(EntityType.Accounting, batch.ExpenseBatchId, summaryFile, user.GetUserId());

                var achFileExpenseBatchFile = new ExpenseBatchFileDto()
                {
                    ExpenseBatchId = batch.ExpenseBatchId,
                    ExpenseBatchFileTypeId = (int)ExpenseBatchFileType.ArtistSummary,
                    DocumentExtension = summaryFile.DocumentExtension.Text,
                    DocumentExtensionId = summaryFile.DocumentExtensionId,
                    OriginalFileName = summaryFile.OriginalFileName,
                    StorageFileName = summaryFile.StorageFileName,
                    Description = summaryFile.Description,
                    DateUploaded = summaryFile.CreatedDate
                };

                await this.CreateExpenseBatchFileAsync(achFileExpenseBatchFile, user);
            }
            finally
            {
                if (summaryFile.Contents != null)
                {
                    summaryFile.Contents.Close();
                    summaryFile.Contents.Dispose();
                }
            }
        }
    }
}
