﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ResellerService : IResellerService
    {
        private readonly IContactService _contactService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ITINHistoryService _tinHistoryService;

        public ResellerService(
            IUnitOfWork context,
            IContactService contactService,
            IEntityHistoryService entityHistoryService,
            ITINHistoryService tinHistoryService)
        {
            this.Context = context;

            this._contactService = contactService;
            this._entityHistoryService = entityHistoryService;
            this._tinHistoryService = tinHistoryService;
        }

        public ResellerService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<ResellerDto> GetByIdAsync(int id)
        {
            if (id <= 0)
            {
                throw new ArgumentException(nameof(id));
            }

            return await Context.Resellers.GetByIdAsync(id);
        }

        public Task<IList<ResellerDto>> GetByCharsAsync(string chars)
        {
            return this.Context.Resellers.GetByCharsAsync(chars);
        }

        public async Task<bool> CheckForDuplicatesAsync(int resellerId, string resellerName)
        {
            if (string.IsNullOrWhiteSpace(resellerName))
            {
                throw new ArgumentNullException(nameof(resellerName));
            }

            var result = await this.Context.Resellers.CheckForDuplicatesAsync(resellerId, resellerName.Trim());

            return result;
        }

        public Task<IList<ResellerDto>> GetByCriteriaAsync(ResellerSearchCriteriaDto criteria)
        {
            SecurityHelper.EncryptFederalTINCriteria(criteria);

            return this.Context.Resellers.GetByCriteriaAsync(criteria);
        }

        public async Task CreateAsync(ResellerDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                SecurityHelper.EncryptFederalTIN(dto);

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                await this.Context.Resellers.CreateAsync(dto);

                this._contactService.SyncContacts(EntityType.Reseller, dto.ResellerId, dto.Contacts, user);

                // Audit Status Change
                var history = new EntityHistoryDto
                {
                    EntityId = dto.ResellerId,
                    Type = EntityType.Reseller,
                    Event = AuditEvent.Created,
                    Description = "Created",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Reseller, null, ex);
            }
        }

        public async Task UpdateAsync(ResellerDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            var original = await this.GetByIdAsync(dto.ResellerId);

            try
            {
                if (original == null)
                {
                    throw new Exception($"Reseller {dto.ResellerId} not found.");
                }

                dto.SetAsUpdated(user);

                SecurityHelper.EncryptFederalTIN(dto);

                if (SecurityHelper.TINHasChanged(original, dto))
                {
                    // Save previous TIN
                    await _tinHistoryService.CreateTINHistoryAsync(original, user);
                }

                // Set the W9 on file flag based on existence of date
                dto.IsW9OnFile = dto.W9OnFileDate.HasValue;

                await this.Context.Resellers.UpdateAsync(dto);

                this._contactService.SyncContacts(EntityType.Reseller, dto.ResellerId, dto.Contacts, user);

                await this.AuditUpdatedEntity(original, dto, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Reseller, dto.ResellerId, ex);
            }
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateNotesAsync(int id, string notes)
        {
            try
            {
                this.Context.BeginTransaction();

                var reseller = await this.GetByIdAsync(id);
                if (reseller == null)
                {
                    throw new Exception($"Reseller {id} not found.");
                }

                reseller.Notes = notes;

                await this.Context.Resellers.UpdateAsync(reseller);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Reseller, id, ex);
            }
        }

        private async Task AuditUpdatedEntity(ResellerDto original, ResellerDto updated, IPrincipal user)
        {
            // Audit Reseller Name change
            if (!string.Equals(updated.Name, original.Name, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.Name))
                {
                    original.Name = "--";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = updated.ResellerId,
                    Type = EntityType.Reseller,
                    Event = AuditEvent.ResellerNameChanged,
                    Description = original.Name,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Payee Name change
            if (!string.Equals(updated.PayeeName, original.PayeeName, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.PayeeName))
                {
                    original.PayeeName = "--";
                }

                var history = new EntityHistoryDto
                {
                    EntityId = updated.ResellerId,
                    Type = EntityType.Reseller,
                    Event = AuditEvent.ResellerPayeeNameChanged,
                    Description = original.PayeeName,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }

            // Audit Payee Name change
            if (!string.Equals(updated.TaxIdentificationNumber, original.TaxIdentificationNumber, StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(original.TaxIdentificationNumber))
                {
                    original.TaxIdentificationNumber = string.Empty;
                }

                string hiddenTIN = SecurityHelper.HideTaxIdentificationNumber(original.TaxIdentificationNumber) ?? "--";

                var history = new EntityHistoryDto
                {
                    EntityId = updated.ResellerId,
                    Type = EntityType.Reseller,
                    Event = AuditEvent.ResellerTINChanged,
                    Description = hiddenTIN,
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);
            }
        }
    }
}
