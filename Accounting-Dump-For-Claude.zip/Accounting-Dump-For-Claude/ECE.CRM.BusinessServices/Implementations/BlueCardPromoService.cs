﻿namespace ECE.CRM.BusinessServices
{
	using ECE.CRM.BusinessServices.Utilities;
	using ECE.CRM.DataAccess;
	using ECE.CRM.DataTransferObjects;
	using Infinity.Mobius.Configuration;
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Security.Principal;
	using System.Text;
	using System.Threading.Tasks;
	using System.Web;

	public class BlueCardPromoService : IBlueCardPromoService
	{
		private readonly IBlueCardService _blueCardService;
		private readonly ILookupService _lookupService;
		private readonly IContactService _contactService;
		private readonly IWebLinkService _webLinkService;
		private readonly IDocumentService _documentService;
		private readonly ICommunicationLogService _communicationLogService;
		private readonly IUserService _userService;
		private readonly IEceCrmEntities _eceCrmEntities;
		public BlueCardPromoService(IUnitOfWork context,
									IBlueCardService blueCardService,
									ILookupService lookupService,
									IContactService contactService,
									IWebLinkService webLinkService,
									IDocumentService documentService,
									ICommunicationLogService communicationLogService,
									IUserService userService, IEceCrmEntities eceCrmEntities)
		{
			this.Context = context;

			this._blueCardService = blueCardService;
			this._lookupService = lookupService;
			this._contactService = contactService;
			this._webLinkService = webLinkService;
			this._documentService = documentService;
			this._communicationLogService = communicationLogService;
			this._userService = userService;
			this._eceCrmEntities = eceCrmEntities;
		}

		public IUnitOfWork Context { get; private set; }

		public async Task<BlueCardPromoDto> GetBlueCardPromoByIdAsync(int id)
		{
			var dto = await this.Context.BlueCardPromos.GetBlueCardPromoByBlueCardIdAsync(id);

			if (dto == null)
			{
				dto = new BlueCardPromoDto { BlueCardId = id };
			}

			return dto;
		}

		public async Task<BlueCardPromoDto> GetBlueCardPromoByUrlKeyAsync(string key, bool trackPageView = false, bool isMobile = false, string browserName = "", string ipAddress = "")
		{
			var currentTime = DateTime.Now;
			var dto = await this.Context.BlueCardPromos.GetBlueCardPromoByUrlKeyAsync(key);
			if (dto != null && trackPageView)
			{
				var logData = _eceCrmEntities.PromoViewDeviceLogs
				.Where(log => log.BlueCardPromoId == dto.BlueCardPromoId && log.IpAddress == ipAddress)
				.AsEnumerable()
				.FirstOrDefault(log =>
					(currentTime - log.ViewedOn).HasValue && (currentTime - log.ViewedOn).Value.TotalMinutes < 1);
				if (logData == null)
				{
					await this.Context.BlueCardPromos.IncrementPageViewCountAsync(dto);
					await this.Context.BlueCardPromos.AddPromoViewDeviceLogAsync(new PromoViewDeviceLogDto
					{
						BlueCardPromoId = dto.BlueCardPromoId,
						BlueCardId = dto.BlueCardId,
						ViewedOn = DateTime.Now,
						DeviceType = isMobile ? "Mobile" : "Desktop",
						BrowserName = browserName,
						IpAddress = ipAddress
					});
				}
			}

			return dto;
		}

		public async Task<int> CreateOrUpdateBlueCardPromoAsync(BlueCardPromoDto dto, IPrincipal user)
		{
			this.Context.BeginTransaction();

			try
			{
				var currentPromo = await this.Context.BlueCardPromos.GetBlueCardPromoByBlueCardIdAsync(dto.BlueCardId);
				if (currentPromo != null)
				{
					dto.SetAsUpdated(user);
					dto.BlueCardPromoId = await this.Context.BlueCardPromos.UpdateBlueCardPromoAsync(dto);

					var currentBlueCardArtists = await this.Context.BlueCardPromos.GetPromoArtists(dto.BlueCardPromoId);
					var currentBlueCardArtistIds = currentBlueCardArtists.Select(x => x.ArtistId).ToList();

					var newBlueCardArtistIds = dto.Artists.Select(x => x.ArtistId).ToList();

					var artistIdsToDelete = currentBlueCardArtistIds.Except(newBlueCardArtistIds).ToList();
					var artistIdsToCreate = newBlueCardArtistIds.Except(currentBlueCardArtistIds).ToList();
					var artistIdsToUpdate = currentBlueCardArtistIds.Intersect(newBlueCardArtistIds).ToList();

					foreach (var artistId in artistIdsToCreate)
					{
						var artist = dto.Artists.Where(x => x.ArtistId == artistId).FirstOrDefault();
						if (artist != null)
						{
							artist.SetAsCreated(user);
							artist.BlueCardPromoId = dto.BlueCardPromoId;
							artist.BlueCardId = dto.BlueCardId;
							artist.BlueCardPromoArtistId = await this.Context.BlueCardPromos.CreatePromoArtistLinkAsync(artist);

							if (artist.WebLinks != null)
							{
								foreach (var webLink in artist.WebLinks)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistWebLinkAsync(webLink, artist.BlueCardPromoArtistId);
								}
							}

							if (artist.Documents != null)
							{
								foreach (var document in artist.Documents)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistDocumentLinkAsync(document, artist.BlueCardPromoArtistId);
								}
							}
						}
					}

					foreach (var a in artistIdsToDelete)
					{
						var artist = currentBlueCardArtists.Where(x => x.ArtistId == a).FirstOrDefault();
						if (artist != null)
						{
							artist.SetAsUpdated(user);

							await this.Context.BlueCardPromos.DeletePromoArtist(artist);
						}
					}

					foreach (var artistId in artistIdsToUpdate)
					{
						var artist = dto.Artists.Where(x => x.ArtistId == artistId).FirstOrDefault();
						if (artist != null)
						{
							artist.BlueCardPromoArtistId = currentBlueCardArtists.Where(x => x.ArtistId == artistId).Select(x => x.BlueCardPromoArtistId).FirstOrDefault();
							artist.SetAsUpdated(user);

							await this.Context.BlueCardPromos.UpdatePromoArtist(artist);

							if (artist.WebLinks == null)
							{
								artist.WebLinks = new List<int>();
							}

							var currentWebLinks = await this.Context.BlueCardPromos.GetWebLinkIdsForPromoArtist(artist.BlueCardPromoArtistId);

							var webLinksToAdd = artist.WebLinks.Except(currentWebLinks).ToList();
							var webLinksToDelete = currentWebLinks.Except(artist.WebLinks).ToList();

							if (webLinksToAdd != null && webLinksToAdd.Count() > 0)
							{
								foreach (var w in webLinksToAdd)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistWebLinkAsync(w, artist.BlueCardPromoArtistId);
								}
							}

							if (webLinksToDelete != null && webLinksToDelete.Count() > 0)
							{
								foreach (var w in webLinksToDelete)
								{
									await this.Context.BlueCardPromos.DeletePromoArtistWebLinkAsync(w, artist.BlueCardPromoArtistId);
								}
							}

							if (artist.Documents == null)
							{
								artist.Documents = new List<int>();
							}

							var currentDocuments = await this.Context.BlueCardPromos.GetDocumentIdsForPromoArtist(artist.BlueCardPromoArtistId);

							var documentsToAdd = artist.Documents.Except(currentDocuments).ToList();
							var documentsToDelete = currentDocuments.Except(artist.Documents).ToList();

							if (documentsToAdd != null && documentsToAdd.Count() > 0)
							{
								foreach (var d in documentsToAdd)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistDocumentLinkAsync(d, artist.BlueCardPromoArtistId);
								}
							}

							if (documentsToDelete != null && documentsToDelete.Count() > 0)
							{
								foreach (var d in documentsToDelete)
								{
									await this.Context.BlueCardPromos.DeletePromoArtistDocumentLinkAsync(d, artist.BlueCardPromoArtistId);
								}
							}
						}
					}
				}
				else
				{
					dto.SetAsCreated(user);
					dto.UrlKey = SecurityHelper.GeneratePasswordToken();
					dto.BlueCardPromoId = await this.Context.BlueCardPromos.CreateBlueCardPromoAsync(dto);

					if (dto.Artists != null)
					{
						foreach (var artist in dto.Artists)
						{
							artist.SetAsCreated(user);
							artist.BlueCardPromoId = dto.BlueCardPromoId;
							artist.BlueCardId = dto.BlueCardId;
							artist.BlueCardPromoArtistId = await this.Context.BlueCardPromos.CreatePromoArtistLinkAsync(artist);

							if (artist.WebLinks != null)
							{
								foreach (var webLink in artist.WebLinks)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistWebLinkAsync(webLink, artist.BlueCardPromoArtistId);
								}
							}

							if (artist.Documents != null)
							{
								foreach (var document in artist.Documents)
								{
									await this.Context.BlueCardPromos.CreatePromoArtistDocumentLinkAsync(document, artist.BlueCardPromoArtistId);
								}
							}
						}
					}
				}

				this.Context.Commit();
			}
			catch (Exception ex)
			{
				this.Context.Rollback();
				throw new UnhandledBusinessException(ex);
			}

			return dto.BlueCardPromoId;
		}

		public async Task<int> SendPromoAsync(BlueCardPromoDto dto, IPrincipal user)
		{
			this.Context.BeginTransaction();

			try
			{
				dto.SetAsUpdated(user);

				var blueCard = await this._blueCardService.GetBlueCardByIdAsync(dto.BlueCardId);
				dto.AgentId = blueCard.AgentId;

				var originalDto = await GetBlueCardPromoByIdAsync(dto.BlueCardId);
				originalDto.Artists = await this.Context.BlueCardPromos.GetPromoArtists(originalDto.BlueCardPromoId);

				foreach (var a in originalDto.Artists)
				{
					a.WebLinkDtos = await this.Context.BlueCardPromos.GetWebLinksForPromoArtist(a.BlueCardPromoArtistId);
					a.DocumentDtos = await this.Context.BlueCardPromos.GetDocumentsForPromoArtist(a.BlueCardPromoArtistId);
				}

				// Set the data in the promo table
				await this.Context.BlueCardPromos.UpdateBlueCardPromoAsyncForSend(dto);

				// Set the data in the email table
				await SendOutgoingEmail(dto, originalDto, user);

				this.Context.Commit();
			}
			catch (Exception ex)
			{
				this.Context.Rollback();
				throw new UnhandledBusinessException(ex);
			}

			return dto.BlueCardPromoId;
		}

		public async Task<IList<BlueCardPromoArtistDto>> GetArtistsByUrlKeyAsync(string key)
		{
			var promo = await this.GetBlueCardPromoByUrlKeyAsync(key);
			if (promo == null)
			{
				return new List<BlueCardPromoArtistDto>();
			}

			var artists = await this.Context.BlueCardPromos.GetPromoArtists(promo.BlueCardPromoId);

			foreach (var artist in artists)
			{
				this._blueCardService.FilterNationalArtistData(artist);
			}

			return artists;
		}

		public async Task<IList<WebLinkDto>> GetWebLinksAsync(int artistId, string key)
		{
			var webLinks = await this.Context.BlueCardPromos.GetWebLinksAsync(artistId, key);

			return webLinks;
		}

		public async Task<IList<DocumentDto>> GetDocumentsAsync(int artistId, string key)
		{
			var documents = await this.Context.BlueCardPromos.GetDocumentsAsync(artistId, key);

			return documents;
		}

		public IList<DocumentDto> FilterDocuments(IList<DocumentDto> documents)
		{
			var typesToExclude = new[]
			{
				DocumentType.ExclusiveAgreement,
				DocumentType.SignedLogo,
				DocumentType.SignedContract,
				DocumentType.Other,
				DocumentType.ClientFollowup,
				DocumentType.COIInsurance,
				DocumentType.Contract,
				DocumentType.ContractAddendum,
				DocumentType.Email,
				DocumentType.Fax,
				DocumentType.InputList,
				DocumentType.InternetLead,
				DocumentType.Itineraries,
				DocumentType.Miscellaneous,
				DocumentType.Notes,
				DocumentType.PlannerFollowup,
				DocumentType.VenueFollowup,
				DocumentType.W9,
				DocumentType.ArtistOffer,
				DocumentType.ArtistAgreement,
				DocumentType.Invoice,
				DocumentType.Check,
				DocumentType.CheckReport,
				DocumentType.ACH
			};

			var typeIdsToExclude = typesToExclude.Select(x => (int)x);

			return documents
				.Where(x => !typeIdsToExclude.Contains(x.DocumentTypeId))
				.ToList();
		}

		public async Task BookArtistAsync(int blueCardPromoId, int artistId)
		{
			this.Context.BeginTransaction();

			try
			{
				var promo = await this.Context.BlueCardPromos.GetBlueCardPromoByIdAsync(blueCardPromoId);
				if (promo == null)
				{
					throw new Exception($"Blue card promo ${blueCardPromoId} not found");
				}

				var blueCard = await this.Context.BlueCards.GetBlueCardByIdAsync(promo.BlueCardId);

				var agent = await this._userService.GetUserByIdAsync(blueCard.AgentId, true);

				var artist = promo.Artists.FirstOrDefault(x => x.ArtistId == artistId);
				if (artist == null)
				{
					throw new Exception($"Blue card promo artist ${artistId} not found");
				}

				// Send an alert to the responsible agent
				var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.BlueCardPromoBookArtist);
				var alertText = appEvent.Text
					.Replace("{ArtistName}", artist.Name)
					.Replace("{AccountName}", blueCard.AccountName);

				var alert = new AlertDto
				{
					AppUserId = blueCard.AgentId,
					Description = alertText,
					IsRead = false,
					EntityTypeId = (int)EntityType.BlueCard,
					EntityId = blueCard.BlueCardId,
					AppEventTypeId = (int)AppEventType.BlueCardPromoBookArtist,
				};

				alert.SetAsCreated(blueCard.AgentId);

				await this.Context.Alerts.CreateAsync(alert);

				// Send an e-mail message to responsible agent.
				var responsibleAgent = await this._userService.GetUserByIdAsync(blueCard.AgentId, true);

				var message = await this.GenerateBookArtistEmailAsync(artist.Name, responsibleAgent, blueCard);
				if (message.HasRecipient)
				{
					var smtpManager = new SmtpManager(this.Context);

					var sentBy = SecurityHelper.SystemEmailAccountId;
					if (!agent.UserIsInOffice(Constants.HoustonOfficeId))
					{
						smtpManager.SendMessage(message, sentBy, SendMessageMode.Queued);
					}
				}

				this.Context.Commit();
			}
			catch (Exception ex)
			{
				this.Context.Rollback();
				throw new UnhandledBusinessException(ex);
			}
		}

		public async Task<TemplateMailMessage> GenerateBookArtistEmailAsync(string artistName, AppUserDto responsibleAgent, BlueCardDto blueCard)
		{
			var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
			var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendBookArtistNotification);

			var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

			string appName = MobiusConfiguration.GetString("Application.Name");
			string url = this.GenerateBlueCardLinkUrl(blueCard.BlueCardId);

			var bodyBuilder = new StringBuilder(layoutTemplate.Body);

			var subject = bodyTemplate.Subject.Replace("{AppName}", appName);

			var body = bodyBuilder
				.Replace("{Body}", bodyTemplate.Body)
				.Replace("{AppName}", appName)
				.Replace("{Subject}", subject)
				.Replace("{AgentName}", responsibleAgent.FullName)
				.Replace("{ArtistName}", artistName)
				.Replace("{AccountName}", blueCard.AccountName)
				.Replace("{BlueCardDetailsUrl}", url)
				.ToString();

			email.Subject = subject;
			email.Body = body;
			email.IsBodyHtml = bodyTemplate.IsHtml;

			email.AddRecipient(responsibleAgent.Username, responsibleAgent.FullName);

			return email;
		}

		public string GenerateBlueCardLinkUrl(int id)
		{
			string url = string.Format(
				"{0}{1}/{2}",
				MobiusConfiguration.GetString("Application.Url"),
				"BlueCard/Details",
				id);

			return url;
		}

		public string GeneratePromoLinkUrl(string key)
		{
			string url = string.Format(
				"{0}{1}{2}",
				MobiusConfiguration.GetString("Application.Url"),
				MobiusConfiguration.GetString("Application.BlueCardPromoUrl"),
				key);

			return url;
		}

		public async Task<TemplateMailMessage> GeneratePromoEmailAsync(BlueCardPromoDto dto, BlueCardPromoDto originalDto, bool preview = false)
		{
			TemplateMailMessage email = null;
			EmailTemplateDto bodyTemplate = null;

			var agents = _lookupService.GetAllAgents();
			var agent = agents.FirstOrDefault(x => x.AppUserId == dto.AgentId);

			// get agent info
			var agentInfoString = this.GeneratePromoEmailAgentInfo(dto, agent);

			if (dto.IsBranded)
			{
				var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
				bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendPromoLink);

				email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

				string appName = MobiusConfiguration.GetString("Application.Name");
				string url = this.GeneratePromoLinkUrl(dto.UrlKey);

				string urlText = !string.IsNullOrEmpty(originalDto.UrlFriendlyName) ? originalDto.UrlFriendlyName : url;

				string supportEmail = MobiusConfiguration.GetString("Email.SupportAddress");

				if (preview)
				{
					// In preview mode, the layout template is ignored.
					layoutTemplate.Body = "{Body}";
				}

				var bodyBuilder = new StringBuilder(layoutTemplate.Body);
				
					var body = bodyBuilder
						.Replace("{AgentEmailAddress}", agent == null ? string.Empty : agent.Username)
						.Replace("{Year}", DateTime.Now.Year.ToString())
						.Replace("{Body}", bodyTemplate.Body)
						.Replace("{BodyInput}", dto.Body)
						.Replace("{Url}", url)
						.Replace("{UrlText}", urlText)
						.Replace("{SupportEmail}", supportEmail)
						.Replace("{AppName}", appName)
						.Replace("{Subject}", dto.Subject)
						.Replace("{AgentSection}", agentInfoString)
						.Replace("''", "'")
						.ToString();

					email.Subject = dto.Subject;
					email.Body = body;
					email.IsBodyHtml = bodyTemplate.IsHtml;
				
			}
			else
			{
				var blueCardDto = await this._blueCardService.GetBlueCardByIdAsync(originalDto.BlueCardId);

				bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendPromoLinkNoBranding);

				email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

				var intro = originalDto.Intro;
				var body = dto.Body;

				var introString = new StringBuilder();
				introString.AppendFormat("<div>{0}</div> <div>{1}</div>", body, intro);

				// add event info
				var eventInfoString = new StringBuilder();

				var eventType = this._lookupService.GetAllEventTypes().Where(x => x.EventTypeId == blueCardDto.EventTypeId).FirstOrDefault();
				eventInfoString.Append("<h4 style=\"margin-bottom:.5em\">Event Info</h4>");
				eventInfoString.AppendFormat("<div>Event Type: {0}</div>", eventType == null ? string.Empty : eventType.Name);
				eventInfoString.AppendFormat("<div>Event Time: {0}</div>", blueCardDto.EventTime);

				var eventDates = blueCardDto.EventDates;
				var eventDatesString = string.Empty;

				foreach (var ed in eventDates)
				{
					eventDatesString += ed.ToString("MM/dd/yyyy (ddd)") + ", ";
				}

				eventDatesString = eventDatesString.TrimEnd(',', ' ');
				eventInfoString.AppendFormat("<div>Event Dates: {0}</div>", eventDatesString);

				var eventBudget = blueCardDto.EventBudget;

				if (!string.IsNullOrWhiteSpace(blueCardDto.EventBudget))
				{
					decimal temp = decimal.Zero;

					if (decimal.TryParse(blueCardDto.EventBudget.Trim(), out temp))
					{
						eventBudget = string.Format("{0:C}", temp);
					}
				}

				eventInfoString.AppendFormat("<div>Event Budget: {0}</div>", eventBudget);

				// add venue info
				var venueInfoString = new StringBuilder();

				venueInfoString.Append("<h4 style=\"margin-bottom:.5em\">Venue Info</h4>");
				venueInfoString.AppendFormat("<div>Venue Name: {0}</div>", blueCardDto.VenueName);
				var venueState = this._lookupService.GetAllStates(true).Where(x => x.StateId == blueCardDto.VenuePhysicalStateId).FirstOrDefault();
				var venueCountry = this._lookupService.GetAllCountries().Where(x => x.CountryId == blueCardDto.VenuePhysicalCountryId).FirstOrDefault();
				var stateAbrv = venueState == null ? string.Empty : venueState.Abbreviation;
				var countryAbrv = venueCountry == null ? string.Empty : venueCountry.Abbreviation;
				venueInfoString.AppendFormat("<div><div>Venue Address: {0}</div><div>{1}</div><div>{2} {3} {4}</div><div>{5}</div></div>",
											  blueCardDto.VenuePhysicalAddress1,
											  blueCardDto.VenuePhysicalAddress2,
											  blueCardDto.VenuePhysicalCity,
											  stateAbrv,
											  blueCardDto.VenuePhysicalZip,
											  countryAbrv);

				introString.AppendFormat(agentInfoString);
				introString.AppendFormat(eventInfoString.ToString());
				introString.AppendFormat(venueInfoString.ToString());

				var artistsString = new StringBuilder();
				var allBlueCardArtists = await this._blueCardService.GetBlueCardArtistsAsync(dto.BlueCardId);

				foreach (var a in originalDto.Artists)
				{
					// check for artist picture
					var isArtistPicture = false;
					string artistImageUrl = string.Empty;

					var document = a.DocumentDtos.FirstOrDefault(x => x.DocumentTypeId == (int)DocumentType.ArtistProfileImage);
					if (document != null)
					{
						artistImageUrl = string.Format(
							"{0}blue-card-promo-doc/{1}/artist/{2}/{3}",
							MobiusConfiguration.GetString("Application.Url"),
							dto.UrlKey,
							a.ArtistId,
							document.DocumentId);

						isArtistPicture = true;
					}

					var artistString = new StringBuilder();

					if (a.IsGrossShown && a.Gross != null)
					{
						artistString.AppendFormat("<h3>{0} - {1:C}</h3>", a.Name, a.Gross);
					}
					else
					{
						artistString.AppendFormat("<h3>{0}</h3>", a.Name);
					}

					if (a.IsSalesPitchShown && !string.IsNullOrWhiteSpace(a.SalesPitch))
					{
						artistString.AppendFormat("<p>{0}</p>", a.SalesPitch);
					}

					if (!string.IsNullOrWhiteSpace(a.Notes))
					{
						artistString.AppendFormat("<p>{0}</p>", a.Notes);
					}

					if (isArtistPicture)
					{
						artistString.AppendFormat("<img style='max-height: {0}px;' src='{1}'></img>", 150, artistImageUrl);
					}

					if (a.WebLinkDtos != null)
					{
						var videos = a.WebLinkDtos.Where(x => x.WebLinkType.Text == "YouTube");
						if (videos.Any())
						{
							artistString.Append("<h4>Videos</h4>");
							artistString.Append("<dl>");

							foreach (var w in videos)
							{
								var text = w.Description;
								if (string.IsNullOrWhiteSpace(text))
								{
									text = w.WebLinkType.Text;
								}

								artistString.AppendFormat("<dt>{0}</dt><dd><a href='{1}'>{1}</a></dd>", text, w.Url);
							}

							artistString.Append("</dl>");
						}

						var moreInfoLinks = a.WebLinkDtos.Where(x => x.WebLinkType.Text != "YouTube");
						if (moreInfoLinks.Any())
						{
							artistString.Append("<h4>More Info</h4>");
							artistString.Append("<dl>");

							foreach (var w in moreInfoLinks)
							{
								var text = w.Description;
								if (string.IsNullOrWhiteSpace(text))
								{
									text = w.WebLinkType.Text;
								}

								artistString.AppendFormat("<dt>{0}</dt><dd><a href='{1}'>{1}</a></dd>", text, w.Url);
							}

							artistString.Append("</dl>");
						}
					}

					if (a.DocumentDtos != null)
					{
						if (a.DocumentDtos.Any())
						{
							artistString.Append("<h4>Documents</h4>");
							artistString.Append("<dl>");

							foreach (var d in a.DocumentDtos)
							{
								var text = d.Description;
								if (string.IsNullOrWhiteSpace(text))
								{
									text = d.DocumentType.Text;
								}

								artistString.AppendFormat(
									"<dt>{0}</dt><dd><a href='{1}'>{2}</a></dd>",
									text,
									string.Format(
										"{0}blue-card-promo-doc/{1}/artist/{2}/{3}",
										MobiusConfiguration.GetString("Application.Url"),
										dto.UrlKey,
										a.ArtistId,
										d.DocumentId),
									d.OriginalFileName);
							}

							artistString.Append("</dl>");
						}
					}

					artistsString.Append(artistString.ToString());
				}

				var subject = dto.Subject;

				if (subject == string.Empty)
				{
					subject = bodyTemplate.Subject;
				}

				var bodyBuilder = new StringBuilder(bodyTemplate.Body);
				body = bodyBuilder.Replace("{BodyInput}", introString.ToString())
								  .Replace("{ArtistsInput}", artistsString.ToString())
								  .Replace("{Subject}", subject)
								  .Replace("''", "'").ToString();

				email.Subject = subject;
				email.Body = body;
				email.IsBodyHtml = bodyTemplate.IsHtml;
			}

			if (agent != null)
			{
				if (TextHelper.IsValidEmail(agent.Username))
				{
					email.SetFrom(agent.Username, agent.FullName);
				}
			}

			// Override agent's email address with the no-reply email address
			// We need to leave the call in to get the agent's email address because we'll add it
			// the email body in the future.
			if (MobiusConfiguration.GetBoolean("Email.UseNoReply"))
			{
				var noReplyEmailAddress = MobiusConfiguration.GetString("Email.FromAddress");
				var noReplyEmailName = MobiusConfiguration.GetString("Email.FromName");

				email.SetFrom(noReplyEmailAddress, noReplyEmailName);
			}

			return email;
		}

		private async Task SendOutgoingEmail(BlueCardPromoDto dto, BlueCardPromoDto originalDto, IPrincipal user)
		{
			this.Context.BeginTransaction();

			try
			{
				var email = await this.GeneratePromoEmailAsync(dto, originalDto);

				var commLogList = new List<CommunicationLogDto>();

				var contacts = this._contactService.GetContacts(EntityType.BlueCard, dto.BlueCardId);

				var agent = await this._userService.GetUserByIdAsync(dto.AgentId, true);

				foreach (var c in dto.Contacts)
				{
					var contact = contacts.Single(x => x.ContactId == c);

					email.AddRecipient(contact.EmailAddress, $"{contact.FirstName} {contact.LastName}");

					commLogList.Add(new CommunicationLogDto
					{
						CommunicationMethodId = (int)CommunicationMethod.Email,
						ContactId = contact.ContactId,
						EntityId = dto.BlueCardId,
						EntityTypeId = (int)EntityType.BlueCard,
						LogDate = DateTime.Now,
						LogTime = DateTime.Now.ToShortTimeString(),
						Notes = "Sent Blue Card Promo"
					});
				}

				if (email.HasRecipient)
				{
					var smtpManager = new SmtpManager(this.Context);

					if (!agent.UserIsInOffice(Constants.HoustonOfficeId))
					{
						smtpManager.SendMessage(email, user.GetUserId(), DateTime.Now, SendMessageMode.Directly);
					}
				}

				// Add a comm log for each person included on the promo
				foreach (var commLog in commLogList)
				{
					commLog.EmailQueueId = email.EmailQueueId;
					_communicationLogService.AddCommunicationLog(commLog, user);
				}

				this.Context.Commit();
			}
			catch (Exception ex)
			{
				this.Context.Rollback();
				throw new UnhandledBusinessException(ex);
			}
		}

		private string GeneratePromoEmailAgentInfo(BlueCardPromoDto dto, AppUserDto assignedAgent)
		{
			string formattedAgentOffice = string.Empty;
			string formattedAgentCell = string.Empty;

			var agentName = $"{assignedAgent.FirstName} {assignedAgent.LastName}";

			var agentOfficeNumber = assignedAgent.PhoneOffice;
			if (!string.IsNullOrEmpty(agentOfficeNumber))
			{
				formattedAgentOffice = $"<div>Office: {agentOfficeNumber}</div>";
			}

			var agentCellNumber = assignedAgent.PhoneCell;
			if (!string.IsNullOrEmpty(agentCellNumber))
			{
				formattedAgentCell = $"<div>Cell: {agentCellNumber}</div>";
			}

			var agentEmail = assignedAgent.Username;

			var agentInfo = string.Format("<div>{0}</div>{1}{2}<div>Email: {3}</div>",
				agentName,
				formattedAgentOffice,
				formattedAgentCell,
				agentEmail);

			return agentInfo;
		}

		public async Task AddPromoViewDeviceLogAsync(PromoViewDeviceLogDto viewDeviceLogDto)
		{
			await this.Context.BlueCardPromos.AddPromoViewDeviceLogAsync(viewDeviceLogDto);
		}

		

	}
}
