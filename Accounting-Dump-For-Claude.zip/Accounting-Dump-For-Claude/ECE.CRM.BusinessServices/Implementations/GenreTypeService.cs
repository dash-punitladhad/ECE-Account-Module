﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class GenreTypeService<T> : IGenreTypeService<T>
        where T : BaseGenreTypeDto, new()
    {
        public GenreTypeService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public ISyncDao<T> GetDataAccessObject(T dto)
        {
            ISyncDao<T> dao = null;

            switch (dto.EntityType)
            {
                case EntityType.Presenter:
                    dao = this.Context.PresenterGenreTypes as ISyncDao<T>;
                    break;

                case EntityType.Artist:
                    dao = this.Context.ArtistGenreTypes as ISyncDao<T>;
                    break;

                case EntityType.Venue:
                    dao = this.Context.VenueGenreTypes as ISyncDao<T>;
                    break;

                case EntityType.Inquiry:
                    dao = this.Context.InquiryGenreTypes as ISyncDao<T>;
                    break;

                default:
                    break;
            }

            if (dao == null)
            {
                throw new NotImplementedException($"No ISyncDao for {dto.EntityType.ToString()}");
            }

            return dao;
        }

        public async Task<IList<T>> GetChildrenAsync(int id)
        {
            ISyncDao<T> dao = this.GetDataAccessObject(new T());

            return await dao.GetChildrenAsync(id);
        }

        public async Task SyncChildrenAsync(int parentId, IEnumerable<string> selectedChildren)
        {
            if (selectedChildren == null)
            {
                await SyncChildrenAsync(parentId, Enumerable.Empty<int>());
                return;
            }

            var listOfSelectedGenreTypes =
                selectedChildren.Select(x => Convert.ToInt32(x.Trim())).ToList();

            await SyncChildrenAsync(parentId, listOfSelectedGenreTypes);
        }

        public async Task SyncChildrenAsync(int parentId, IEnumerable<int> selectedChildren)
        {
            var parentType = new T();

            ISyncDao<T> dao = this.GetDataAccessObject(parentType);

            this.Context.BeginTransaction();

            try
            {
                var selectedGenreTypes = selectedChildren;
                if (selectedChildren == null)
                {
                    selectedGenreTypes = Enumerable.Empty<int>();
                }

                var existingChildren = await dao.GetChildrenAsync(parentId);

                var genreTypesToKeep =
                    existingChildren.Where(x => selectedGenreTypes.Contains(x.GenreTypeId)).ToList();

                var genreTypesToAdd = selectedGenreTypes.Except(
                    genreTypesToKeep.Select(x => x.GenreTypeId).ToList(),
                    x => x);

                var genreTypesToRemove = existingChildren.Except(genreTypesToKeep).ToList();
                var parentGenreTypesToRemove = new List<T>();

                foreach (var genreType in genreTypesToRemove)
                {
                    var newEntity = new T
                    {
                        ParentId = parentId,
                        GenreTypeId = genreType.GenreTypeId
                    };

                    parentGenreTypesToRemove.Add(newEntity);
                }

                foreach (int i in genreTypesToAdd)
                {
                    var a = new T
                    {
                        GenreTypeId = i,
                        ParentId = parentId
                    };

                    await dao.CreateChildAsync(a);
                }

                foreach (T atd in parentGenreTypesToRemove)
                {
                    await dao.DeleteChildAsync(atd);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(parentType.EntityType, parentId, ex);
            }
        }
    }
}
