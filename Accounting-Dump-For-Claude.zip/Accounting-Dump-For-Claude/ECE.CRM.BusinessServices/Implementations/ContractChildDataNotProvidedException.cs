﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Runtime.Serialization;

    public class ContractChildDataNotProvidedException : Exception
    {
        /// <summary>
        /// The default exception message
        /// </summary>
        public const string DefaultExceptionMessage = "Contract child data not provided";

        /// <summary>
        /// The DTO that was used to generate the exception.
        /// </summary>
        private ContractDto _dto = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class.
        /// </summary>
        public ContractChildDataNotProvidedException()
            : base(DefaultExceptionMessage)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        public ContractChildDataNotProvidedException(ContractDto dto)
            : base(DefaultExceptionMessage)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class
        /// for the specified DTO.
        /// </summary>
        /// <param name="dto">The DTO.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public ContractChildDataNotProvidedException(ContractDto dto, Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
            this._dto = dto;
            this.SerializeDto();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class
        /// with a specified error message.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        public ContractChildDataNotProvidedException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class with a
        /// reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public ContractChildDataNotProvidedException(Exception innerException)
            : base(DefaultExceptionMessage, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class with a
        /// specified error message and a reference to the inner exception that
        /// is the cause of this exception.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception. If the
        /// innerException parameter is not a null reference, the current
        /// exception is raised in a catch block that handles the inner exception.</param>
        public ContractChildDataNotProvidedException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractChildDataNotProvidedException" /> class with
        /// serialized data.
        /// </summary>
        /// <param name="info">The object that holds the serialized object data.</param>
        /// <param name="context">The contextual information about the source or destination.</param>
        public ContractChildDataNotProvidedException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        private void SerializeDto()
        {
            if (this._dto == null)
            {
                return;
            }

            this.Data["Contract"] = this._dto.ContractId;
        }
    }
}
