﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using Infinity.Mobius.Logging;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Mail;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web;

    public class ContractSignatureService : IContractSignatureService
    {
        private readonly IContactService _contactService;
        private readonly Lazy<IContractService> _contractService;
        private readonly IDocumentService _documentService;
        private readonly ILookupService _lookupService;
        private readonly IUserService _userService;
        private readonly IAlertService _alertService;
        private readonly ICommunicationLogService _communicationLogService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly IContractDao _contractDao;
        private readonly ISignatureService _signatureService;

        public ContractSignatureService(
            IUnitOfWork context,
            ILogger logger,
            IContactService contactService,
            Lazy<IContractService> contractService,
            IDocumentService documentService,
            ILookupService lookupService,
            IUserService userService,
            IAlertService alertService,
            ICommunicationLogService communicationLogService,
            IEntityHistoryService entityHistoryService,
            IContractDao contractDao, ISignatureService signatureService)
        {
            this.Context = context;
            this.Logger = logger;
            this._contactService = contactService;
            this._contractService = contractService;
            this._documentService = documentService;
            this._lookupService = lookupService;
            this._userService = userService;
            this._alertService = alertService;
            this._communicationLogService = communicationLogService;
            this._entityHistoryService = entityHistoryService;
            this._contractDao = contractDao;
            this._signatureService = signatureService;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<IEnumerable<ContractSignatureDto>> GetByContractIdAsync(int contractId)
        {
            var signatures = await this.Context.ContractSignatures.GetByContractIdAsync(contractId);

            return signatures;
        }

        public Task<IEnumerable<ContractSignatureDto>> GetByEntityIdAndEntityTypeAsync(int contractId, int entityId, int entityType)
        {
            return this.Context.ContractSignatures.GetByEntityIdAndEntityTypeAsync(contractId, entityId, entityType);
        }

        public async Task<ContractSignatureDto> GetByIdAsync(int id)
        {
            if (id <= 0)
            {
                return null;
            }

            return await this.Context.ContractSignatures.GetByIdAsync(id);
        }

        public async Task CreateAsync(ContractSignatureDto dto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user.GetUserId());

                await this.Context.ContractSignatures.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task UpdateAsync(ContractSignatureDto dto, int updatedById)
        {
            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(updatedById);

                await this.Context.ContractSignatures.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task RejectSignatureAsync(int contractId, int contractSignatureId, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var contractSignatureDto = new ContractSignatureDto()
                {
                    ContractId = contractId,
                    ContractSignatureId = contractSignatureId,
                    ReceivedDate = null,
                    IsReceived = false
                };

                contractSignatureDto.SetAsUpdated(user);

                await this.Context.ContractSignatures.UpdateAsync(contractSignatureDto);

                var contract = await this._contractService.Value.GetByIdAsync(contractId, true);

                await this.UpdateContractStatusAsync(contract, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task GenerateSignatureAlertAsync(int agentId, int contractId, string signedByName, IPrincipal user)
        {
            // Create alert
            var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractSigned);
            var alertText = appEvent.Text
                            .Replace("{ContractId}", contractId.ToString())
                            .Replace("{Name}", signedByName);

            // Get all Admin users and add the agent
            var adminUsers = this._userService.GetUsersByRole((int)ECERole.AccountingAdmin, false);
            var recipients = adminUsers.Select(x => x.AppUserId).ToList();
            recipients.Add(agentId);

            recipients = recipients.Distinct().ToList();

            this.Context.BeginTransaction();

            try
            {
                foreach (var recipient in recipients)
                {
                    var alert = new AlertDto
                    {
                        AppUserId = recipient.Value,
                        Description = alertText,
                        EntityTypeId = (int)EntityType.Contract,
                        EntityId = contractId,
                        AppEventTypeId = (int)AppEventType.ContractSigned
                    };

                    await this._alertService.CreateAsync(alert, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task UpdateContractStatusAsync(ContractDto contract, IPrincipal user)
        {
            if ((ContractStatus)contract.ContractStatusId == ContractStatus.PartiallyCanceled ||
                (ContractStatus)contract.ContractStatusId == ContractStatus.Canceled)
            {
                return;
            }

            var updatedStatus = ContractStatus.Issued;

            bool isIssued = contract.IssueDate.HasValue;

            int signatureCount = contract.SignatureProgress.Count();
            int signatureReceivedCount = contract.SignatureProgress.Count(x => x.SignatureReceived != null);

            int depositsCount = contract.ContractTransactions.Count(x => !x.IsExpense);
            int depositsReceivedCount = contract.ContractTransactions.Count(x => !x.IsExpense && x.PaidDate != null);

            if (isIssued &&
                signatureReceivedCount == signatureCount &&
                depositsReceivedCount == depositsCount)
            {
                // Issued, all signatures received, all deposits received
                contract.ContractStatusId = (int)ContractStatus.Completed;
            }
            else if (isIssued &&
                     signatureReceivedCount == signatureCount &&
                     depositsReceivedCount < depositsCount)
            {
                // Issued, all signatures received, some deposits received
                contract.ContractStatusId = (int)ContractStatus.FullyExecuted;
            }

            if (updatedStatus != (ContractStatus)contract.ContractStatusId)
            {
                if ((contract.ContractStatusId == (int)ContractStatus.Issued || contract.ContractStatusId == (int)ContractStatus.ReIssue) &&
                   updatedStatus == ContractStatus.Issued || updatedStatus == ContractStatus.ReIssue)
                {
                    updatedStatus = (contract.ContractStatusId == (int)ContractStatus.ReIssue) ? ContractStatus.ReIssue : ContractStatus.Issued;

                    if (updatedStatus == ContractStatus.Issued && !isIssued)
                    {
                        contract.IssueDate = DateTime.Now;
                    }
                    contract.ContractStatusId = (int)updatedStatus;
                }

                await this._contractService.Value.UpdateAsync(contract, user);
            }

        }

        public async Task MarkAsReceivedAsync(ContractSignatureDto signatureDto, DocumentDto documentDto, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var updatedById = user.GetUserId();
                int? signatureId = null;
                string name = null;
                var contract = await this._contractService.Value.GetByIdAsync(signatureDto.ContractId, true);

                if (documentDto != null)
                {
                    this._documentService.AddDocumentTo(EntityType.Contract, signatureDto.ContractId, documentDto, updatedById);
                    if (Convert.ToString(DocumentExtension.PNG) == Convert.ToString(documentDto.DocumentExtension.Text).ToUpper() || Convert.ToString(DocumentExtension.JPEG) == Convert.ToString(documentDto.DocumentExtension.Text).ToUpper() || Convert.ToString(DocumentExtension.JPG) == Convert.ToString(documentDto.DocumentExtension.Text).ToUpper())
                    {
                        String stringImg = string.Empty;
                        Stream stream = documentDto.Contents;
                        if (stream is MemoryStream memoryStream)
                        {
                            stringImg = Convert.ToBase64String(memoryStream.ToArray());
                        }

                        var bytes = new Byte[(int)stream.Length];

                        stream.Seek(0, SeekOrigin.Begin);
                        stream.Read(bytes, 0, (int)stream.Length);

                        stringImg = Convert.ToBase64String(bytes);
                        if (!string.IsNullOrEmpty(stringImg))
                        {
                            stringImg = "data:image/png;base64," + stringImg;
                        }

                        var presenterEntityType = (int)EntityType.Presenter;
                        var artistEntityType = (int)EntityType.Artist;

                        if (signatureDto.EntityTypeId == artistEntityType)
                        {
                            var contractartist = contract.ContractArtists.FirstOrDefault(a => a.ArtistId == signatureDto.EntityId);
                            name = contractartist == null ? string.Empty : contractartist.ArtistName;
                        }
                        else if (signatureDto.EntityTypeId == presenterEntityType)
                        {
                            name = contract.PresenterOrganizationName;
                        }

                        signatureId = this._signatureService.UploadSignature(updatedById, stringImg, name, user);
                    }
                }


                ContractSignatureDto contractSignature = null;

                if (signatureDto.ContractSignatureId == 0)
                {
                    // Assume this is a placeholder and create the actual record in the database since it is now due.
                    contractSignature = new ContractSignatureDto
                    {
                        ContractId = signatureDto.ContractId,
                        DueDate = DateTime.Today,
                        EntityId = signatureDto.EntityId,
                        EntityTypeId = signatureDto.EntityTypeId,
                        IsReceived = true,
                        ReceivedDate = signatureDto.ReceivedDate,
                        SignatureId = signatureId
                    };

                    contractSignature.SetAsCreated(updatedById);

                    await this.Context.ContractSignatures.CreateAsync(contractSignature);
                }
                else
                {
                    contractSignature = await this.GetByIdAsync(signatureDto.ContractSignatureId);
                    contractSignature.ReceivedDate = signatureDto.ReceivedDate;
                    contractSignature.IsReceived = true;
                    if (documentDto != null)
                    {
                        contractSignature.SignatureId = signatureId;
                    }
                    if (contractSignature.DueDate == null)
                    {
                        contractSignature.DueDate = DateTime.Today;
                    }

                    contractSignature.SetAsUpdated(updatedById);

                    await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                }

                if (documentDto != null)
                {
                    this._documentService.LinkDocumentTo(EntityType.ContractSignature, signatureDto.ContractSignatureId, documentDto, updatedById);
                }

                var @event = contractSignature.EntityTypeId == (int)EntityType.Presenter
                    ? AuditEvent.ContractPresenterSignatureReceived
                    : AuditEvent.ContractArtistSignatureReceived;

                // Audit contract event
                var history = new EntityHistoryDto
                {
                    EntityId = contract.ContractId,
                    Type = EntityType.Contract,
                    Event = @event,
                    Description = "--",
                    CreatedDate = DateTime.Now,
                    CreatedById = user.GetUserId()
                };

                await this._entityHistoryService.CreateEntityHistoryAsync(history);

                string signatoryEmailAddress = null;
                PresenterPortalDto portal = null;

                // Get the updated contract signatures
                contract.SignatureProgress = await this.Context.Signatures.GetSignatoriesByContractAsync(contract);

                // If all signatures are received, send email to contract signatory
                if (contract.IsNoIssue == false && contract.SignatureProgress.All(x => x.SignatureReceived != null))
                {
                    await this.UpdateContractStatusAsync(contract, user);

                    var contractContacts =
                        await this._contactService.GetContactsAsync(EntityType.Contract, contract.ContractId);

                    var signatoryContact = contractContacts.FirstOrDefault(x => x.IsSigner);

                    signatoryEmailAddress = signatoryContact?.EmailAddress;

                    if (!string.IsNullOrWhiteSpace(signatoryEmailAddress))
                    {
                        portal = await this.Context.Contracts.GetPresenterPortalForContractAsync(contract.ContractId);
                        if (portal == null)
                        {
                            // Create a portal for this contract if one does not exist.
                            portal = await this._contractService.Value.CreatePresenterPortalAsync(contract, user);
                        }

                        portal.ParentContract = contract;

                        await SendAllSignaturesReceivedEmailForPresenterPortalUserAsync(signatoryContact, portal, user, contract.AgentId);
                    }
                }

                if (contract.IsNoIssue == false && contractSignature.EntityTypeId == (int)EntityType.Presenter)
                {
                    /*
                     * Send an e-mail notification to the Presenter notifying them that a signature has been received.
                     * Suppress this notification if the 'Send Contract' notification above was sent to the same address.
                     */

                    var primaryContact = await this.Context.Contacts.GetPrimaryContactAsync(EntityType.Contract, contractSignature.ContractId);
                    if (primaryContact != null &&
                        !string.IsNullOrWhiteSpace(primaryContact.EmailAddress) &&
                        primaryContact.EmailAddress.Equals(signatoryEmailAddress, StringComparison.OrdinalIgnoreCase) == false)
                    {
                        if (portal == null)
                        {
                            portal = await this.Context.Contracts.GetPresenterPortalForContractAsync(contract.ContractId);
                            if (portal == null)
                            {
                                // Create a portal for this contract if one does not exist.
                                portal = await this._contractService.Value.CreatePresenterPortalAsync(contract, user);
                            }
                        }

                        portal.ParentContract = contract;

                        await SendSignatureReceivedEmailAsync(primaryContact, portal, user, contract.AgentId);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, null, ex);
            }
        }

        public async Task<bool> SendContractAsync(ContractSignatureDto signatureDto, ContactDto contact, IPrincipal user, HttpClient httpClient, Uri url)
        {
            var email = contact.EmailAddress;
            var firstName = contact.FirstName;

            this.Logger.LogDebug($"SendContractAsync: Contract # {signatureDto.ContractId} {email}");

            var success = false;
            TemplateMailMessage message = null;
            var sendContractEmail = false;

            var updatedById = user.GetUserId();

            ContractDto contract = null;

            ContractSignatureDto contractSignature = null;

            this.Context.BeginTransaction();

            try
            {
                contractSignature = await this.GetByIdAsync(signatureDto.ContractSignatureId);
                if (contractSignature == null)
                {
                    // Assume this is a placeholder and create the actual record in the database since it is now due.
                    contractSignature = new ContractSignatureDto
                    {
                        ContractId = signatureDto.ContractId,
                        DueDate = signatureDto.DueDate,
                        EntityId = signatureDto.EntityId,
                        EntityTypeId = signatureDto.EntityTypeId,
                        IsReceived = false
                    };

                    contractSignature.SetAsCreated(updatedById);

                    await this.Context.ContractSignatures.CreateAsync(contractSignature);
                }
                else
                {
                    contractSignature.DueDate = signatureDto.DueDate;
                    contractSignature.SetAsUpdated(updatedById);
                    await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                }

                contract = await this._contractService.Value.GetByIdAsync(contractSignature.ContractId, true);

                switch ((ContractEntityType)contractSignature.EntityTypeId)
                {
                    case ContractEntityType.Artist:

                        var contractArtist =
                            contract.ContractArtists.FirstOrDefault(x => x.ArtistId == contractSignature.EntityId);

                        var artistAgreement = await this.Context.ContractArtistAgreements.GetByContractArtistIdAsync(contractArtist == null ? 0 : contractArtist.ContractArtistId);
                        if (artistAgreement != null && artistAgreement.ContractSignatureId != contractSignature.ContractSignatureId)
                        {
                            // Associate the artist agreement with the signature.
                            artistAgreement.ContractSignatureId = contractSignature.ContractSignatureId;
                            artistAgreement.SetAsUpdated(user);

                            await this.Context.ContractArtistAgreements.LinkToSignatureAsync(artistAgreement);
                        }

                        var eventDates = await this.Context.ContractArtistEventDates.GetByContractArtistIdAsync(contractArtist == null ? 0 : contractArtist.ContractArtistId);

                        contract.EventDatesObject = eventDates
                            .OrderBy(x => x.EventDate)
                            .Select(y => new ContractEventDateDto { EventDate = y.EventDate.GetValueOrDefault() })
                            .ToList();

                        if (!contract.EventDatesObject.Any())
                        {
                            throw new SendContractEmailException($"No event dates on contract for artist '{signatureDto.EntityName}'");
                        }

                        if (contractArtist != null && contractArtist.IsNational)
                        {
                            break;
                        }

                        var artistUser =
                            await this._userService.GetUserByEntityAsync(contractSignature.EntityId, ECERole.Artist, true);

                        if (artistUser != null)
                        {
                            // Send artistUser an email with a link to the portal.
                            this.Logger.LogDebug("Send artistUser an email with a link to the portal.");
                            await SendContractEmailForArtistPortalUserAsync(artistUser.FirstName, artistUser.Username, contract, user);

                            success = true;
                        }
                        else
                        {
                            if ((contract.IsBuySell.HasValue && contract.IsBuySell.Value) ||
                                    contract.ContractTypeId == (int)ContractType.Special)
                            {
                                if (artistAgreement == null)
                                {
                                    throw new NoArtistAgreementException($"No artist agreement found for contract artist {(contractArtist == null ? 0 : contractArtist.ContractArtistId)}.");
                                }

                                // Email artist agreement to artist (specified email address)
                                var agreementDoc = this.Context.Documents.GetDocumentById(artistAgreement.DocumentId.GetValueOrDefault());

                                this.Logger.LogDebug("Email artist agreement to artist (specified email address)");
                                message = await SendContractEmailWithAttachmentAsync(email, firstName, contract, agreementDoc);
                                if (message != null)
                                {
                                    success = true;

                                    var commLog = new CommunicationLogDto
                                    {
                                        CommunicationMethodId = (int)CommunicationMethod.Email,
                                        ContactId = contact.ContactId,
                                        EntityId = contract.ContractId,
                                        EntityTypeId = (int)EntityType.Contract,
                                        EmailQueueId = message.EmailQueueId,
                                        LogDate = DateTime.Now,
                                        LogTime = DateTime.Now.ToShortTimeString(),
                                        Notes = "Send artist agreement to the artist."
                                    };

                                    _communicationLogService.AddCommunicationLog(commLog, user);
                                }
                                else
                                {
                                    success = false;
                                }
                            }
                            else
                            {
                                // If an uploaded contract (wet signature) exists, get the latest one and send it. Otherwise generate a pdf and send that.
                                var contractDoc = _documentService
                                    .GetDocuments(EntityType.Contract, contract.ContractId)
                                    .OrderByDescending(x => x.CreatedDate)
                                    .FirstOrDefault(x => x.DocumentTypeId == (int)DocumentType.Contract);
                                if (artistUser == null)
                                {
                                    sendContractEmail = true;
                                }

                                if (contractDoc != null && !sendContractEmail)
                                {
                                    this.Logger.LogDebug("Email artist the latest uploaded contract");
                                    message = await SendContractEmailWithAttachmentAsync(email, firstName, contract, contractDoc);
                                    if (message != null)
                                    {
                                        success = true;

                                        var commLog = new CommunicationLogDto
                                        {
                                            CommunicationMethodId = (int)CommunicationMethod.Email,
                                            ContactId = contact.ContactId,
                                            EntityId = contract.ContractId,
                                            EntityTypeId = (int)EntityType.Contract,
                                            EmailQueueId = message.EmailQueueId,
                                            LogDate = DateTime.Now,
                                            LogTime = DateTime.Now.ToShortTimeString(),
                                            Notes = "Send artist the latest uploaded contract."
                                        };

                                        _communicationLogService.AddCommunicationLog(commLog, user);
                                    }
                                    else
                                    {
                                        success = false;
                                    }
                                }
                                else
                                {
                                    this.Logger.LogDebug("Generate a new contract PDF and email it to the artist");
                                    sendContractEmail = true;
                                }
                            }
                        }

                        break;

                    case ContractEntityType.Presenter:
                        // Send an email the contract contacts with link to the portal.
                        var portal = await this.Context.Contracts.GetPresenterPortalForContractAsync(contract.ContractId);
                        if (portal == null)
                        {
                            // Make the contract available in the Presenter Portal
                            portal = await this._contractService.Value.CreatePresenterPortalAsync(contract, user);
                        }

                        portal.ParentContract = contract;

                        var contractContacts =
                            await this._contactService.GetContactsAsync(EntityType.Contract, contract.ContractId);

                        foreach (var contractContact in contractContacts)
                        {
                            if (!string.IsNullOrWhiteSpace(contractContact.EmailAddress))
                            {
                                this.Logger.LogDebug("Send an email to the contract contacts with link to the portal.");
                                await SendContractEmailForPresenterPortalUserAsync(contractContact, portal, user, contract.AgentId);
                            }
                        }

                        success = true;
                        break;
                }

                this.Context.Commit();
            }
            catch (NoArtistAgreementException)
            {
                this.Logger.LogDebug($"No Artist Agreement");
                this.Context.Rollback();
                throw;
            }
            catch (SendContractEmailException ex)
            {
                this.Logger.LogDebug($"SendContractEmailException {ex.Message}");
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();

                ex.Data["signatureDto.ContractId"] = signatureDto.ContractId;
                ex.Data["signatureDto.ContractSignatureId"] = signatureDto.ContractSignatureId;
                ex.Data["email"] = email;
                ex.Data["updatedById"] = updatedById;

                this.Logger.LogDebug("Could not send email message");
                throw new SendContractEmailException($"Could not send email message", ex);
            }

            if (sendContractEmail)
            {
                DocumentDto contractDoc = null;
                HttpResponseMessage result = null;
                System.IO.Stream resultContents = null;

                try
                {
                    // generate pdf of contract and email to the artist
                    result = await httpClient.GetAsync(url);
                    if (!result.IsSuccessStatusCode)
                    {
                        throw new Exception($"Contract not created (Status Code = {(int)result.StatusCode})");
                    }

                    resultContents = await result.Content.ReadAsStreamAsync();

                    var name = $"{contract.ContractId}-{DateTime.Now.ToString("MM_dd_yyyy")}";

                    contractDoc = new DocumentDto()
                    {
                        Contents = resultContents,
                        OriginalFileName = name,
                        StorageFileName = name,
                        Description = $"{DateTime.Now.ToString("MM_dd_yyyy")} Contract",
                        DocumentTypeId = (int)DocumentType.Contract,
                        DocumentExtension = new LookupDto() { Text = "PDF" },
                        DocumentExtensionId = (int)DocumentExtension.PDF
                    };

                    this._documentService.AddDocumentTo(EntityType.Contract, signatureDto.ContractId, contractDoc, updatedById);

                    message = await SendContractEmailWithAttachmentAsync(email, firstName, contract, contractDoc);
                    if (message != null)
                    {
                        success = true;

                        var commLog = new CommunicationLogDto
                        {
                            CommunicationMethodId = (int)CommunicationMethod.Email,
                            ContactId = contact.ContactId,
                            EntityId = contract.ContractId,
                            EntityTypeId = (int)EntityType.Contract,
                            EmailQueueId = message.EmailQueueId,
                            LogDate = DateTime.Now,
                            LogTime = DateTime.Now.ToShortTimeString(),
                            Notes = "Send artist a copy of the contract."
                        };

                        _communicationLogService.AddCommunicationLog(commLog, user);
                    }
                    else
                    {
                        success = false;
                    }
                }
                catch (SendContractEmailException ex)
                {
                    ex.Data["signatureDto.ContractId"] = signatureDto.ContractId;
                    ex.Data["signatureDto.ContractSignatureId"] = signatureDto.ContractSignatureId;
                    ex.Data["email"] = email;
                    ex.Data["updatedById"] = updatedById;
                    ex.Data["url"] = url;

                    if (contractSignature != null)
                    {
                        // Reset the signature record to allow the contract to be re-sent.
                        contractSignature.DueDate = null;
                        contractSignature.SetAsUpdated(updatedById);
                        await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                    }

                    throw;
                }
                catch (Exception ex)
                {
                    var sendException = new SendContractEmailException("Could not generate contract PDF", ex);
                    sendException.Data["signatureDto.ContractId"] = signatureDto.ContractId;
                    sendException.Data["signatureDto.ContractSignatureId"] = signatureDto.ContractSignatureId;
                    sendException.Data["email"] = email;
                    sendException.Data["updatedById"] = updatedById;
                    sendException.Data["url"] = url;

                    if (contractSignature != null)
                    {
                        // Reset the signature record to allow the contract to be re-sent.
                        contractSignature.DueDate = null;
                        contractSignature.SetAsUpdated(updatedById);
                        await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                    }

                    throw sendException;
                }
                finally
                {
                    if (resultContents != null)
                    {
                        resultContents.Close();
                        resultContents.Dispose();
                    }

                    if (result != null)
                    {
                        result.Dispose();
                    }
                }
            }

            return success;
        }

        public async Task DeleteAsync(int contractSignatureId)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.ContractSignatures.DeleteAsync(contractSignatureId);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ContactDto> GetContractSignerAsync(int contractId)
        {
            return await this.Context.Contacts.GetContractSignerAsync(contractId);
        }

        public async Task<ContactDto> GetPrimaryContactAsync(int contractId)
        {
            return await this.Context.Contacts.GetPrimaryContactAsync(EntityType.Contract, contractId);
        }

        public async Task<ContractSignatureDto> SaveSignatureAsync(SaveSignatureDto saveSignature, IPrincipal user)
        {
            this.Context.BeginTransaction();

            ContractSignatureDto contractSignature = null;

            try
            {
                var dto = new SignatureDto
                {
                    AppUserId = user.GetUserId(),
                    SignatureImage = saveSignature.SignatureImage,
                    SignerName = saveSignature.SignerName,
                    SignerTitle = saveSignature.SignerTitle,
                    IsCurrent = true
                };

                dto.SetAsCreated(user);

                var signatureId = Context.Signatures.Create(dto);

                var contractSignatures = await this.GetByContractIdAsync(saveSignature.Contract.ContractId);

                contractSignature = contractSignatures
                    .FirstOrDefault(x => x.EntityTypeId == (int)saveSignature.EntityType && x.EntityId == saveSignature.EntityId);

                if (contractSignature == null)
                {
                    contractSignature = new ContractSignatureDto();
                }

                contractSignature.SignatureId = signatureId;
                contractSignature.ReceivedDate = TimeProvider.Current.Now;
                contractSignature.IsReceived = true;

                if (contractSignature.ContractSignatureId == 0)
                {
                    var @event = contractSignature.EntityTypeId == (int)EntityType.Presenter
                        ? AuditEvent.ContractPresenterSignatureReceived
                        : AuditEvent.ContractArtistSignatureReceived;

                    // Audit contract event
                    var history = new EntityHistoryDto
                    {
                        EntityId = saveSignature.Contract.ContractId,
                        Type = EntityType.Contract,
                        Event = @event,
                        Description = "--",
                        CreatedDate = DateTime.Now,
                        CreatedById = user.GetUserId()
                    };

                    await this._entityHistoryService.CreateEntityHistoryAsync(history);

                    contractSignature.DueDate = TimeProvider.Current.Today;
                    contractSignature.SetAsCreated(user);
                    await this.Context.ContractSignatures.CreateAsync(contractSignature);
                }
                else
                {
                    contractSignature.SetAsUpdated(user);
                    await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                }

                await this.MarkAsReceivedAsync(contractSignature, null, user);

                await this.GenerateSignatureAlertAsync(saveSignature.Contract.AgentId, contractSignature.ContractId, contractSignature.EntityName, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Contract, saveSignature.Contract.ContractId, ex);
            }

            return contractSignature;
        }

        public async Task<ContractSignatureDto> SaveSignatureAsync(SaveSignatureDto saveSignature, IPrincipal user, HttpClient httpClient, Uri url)
        {
            ContractSignatureDto contractSignature = null;

            contractSignature = await this.SaveSignatureAsync(saveSignature, user);

            DocumentDto contractDoc = null;
            HttpResponseMessage result = null;
            System.IO.Stream resultContents = null;
            var contractId = saveSignature.Contract.ContractId;

            this.Context.BeginTransaction();

            try
            {
                // generate pdf of contract and email to the artist
                result = await httpClient.GetAsync(url);
                if (!result.IsSuccessStatusCode)
                {
                    throw new Exception($"Contract not created (Status Code = {(int)result.StatusCode})");
                }

                resultContents = await result.Content.ReadAsStreamAsync();

                var name = $"{contractId}-{DateTime.Now.ToString("MM_dd_yyyy_hhmm")}";

                contractDoc = new DocumentDto()
                {
                    Contents = resultContents,
                    OriginalFileName = name,
                    StorageFileName = name,
                    Description = $"{DateTime.Now.ToString("MM_dd_yyyy_hhmm")} Contract",
                    DocumentTypeId = (int)DocumentType.Contract,
                    DocumentExtension = new LookupDto() { Text = "PDF" },
                    DocumentExtensionId = (int)DocumentExtension.PDF
                };

                this._documentService.AddDocumentTo(EntityType.Contract, contractId, contractDoc, user.GetUserId());

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();

                if (contractSignature != null)
                {
                    // Reset the signature record to allow the contract to be re-sent.
                    contractSignature.ReceivedDate = null;
                    contractSignature.IsReceived = false;
                    contractSignature.SetAsUpdated(user.GetUserId());
                    await this.Context.ContractSignatures.UpdateAsync(contractSignature);
                }

                throw;
            }
            finally
            {
                if (resultContents != null)
                {
                    resultContents.Close();
                    resultContents.Dispose();
                }

                if (result != null)
                {
                    result.Dispose();
                }
            }

            return contractSignature;
        }

        public async Task<TemplateMailMessage> SendContractEmailWithAttachmentAsync(string emailAddress, string firstName, ContractDto contract, DocumentDto doc)
        {
            try
            {
                var firstEventDate = contract.FirstEventDate.GetValueOrDefault();

                var agents = _lookupService.GetAllAgents();
                var agent = agents.FirstOrDefault(x => x.AppUserId == contract.AgentId);

                var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
                var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendContractToArtistWithAttachment);

                string appName = MobiusConfiguration.GetString("Application.Name");
                string url = MobiusConfiguration.GetString("Application.Url");

                var subject = bodyTemplate.Subject.Replace("{ContractNumber}", contract.ContractId.ToString());

                var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                var body = bodyBuilder
                    .Replace("{AgentEmailAddress}", agent == null ? string.Empty : agent.Username)
                    .Replace("{Year}", DateTime.Now.Year.ToString())
                    .Replace("{Body}", bodyTemplate.Body)
                    .Replace("{ContractId}", contract.ContractId.ToString())
                    .Replace("{FirstName}", firstName)
                    .Replace("{EventDate}", firstEventDate.ToString(DateTimeConstants.StandardDateWithDays))
                    .ToString();

                var mailMessage = new TemplateMailMessage(EmailTemplate.SendContractToArtistWithAttachment)
                {
                    Body = body,
                    Subject = subject,
                    To = { emailAddress },
                    IsBodyHtml = true
                };

                var docExt = Context.Lookups.GetDocumentExtensions().First(x => x.DocumentExtensionId == doc.DocumentExtensionId);

                using (var ms = this._documentService.GetFromStorage(doc, EntityType.Contract.ToString()))
                {
                    var fileExtension = docExt.Name.ToLower();

                    var fileName = doc.OriginalFileName;

                    if (!fileName.EndsWith("." + fileExtension))
                    {
                        fileName = $"{doc.OriginalFileName}.{fileExtension}";
                    }

                    mailMessage.Attachments.Add(new Attachment(ms, fileName, docExt.MimeType));

                    var smtpManager = new SmtpManager(this.Context);
                    if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                    {
                        if (smtpManager.SendMessage(mailMessage, contract.AgentId, SendMessageMode.Directly))
                        {
                            if (mailMessage.EmailQueueId > 0)
                            {
                                this._documentService.LinkDocumentTo(EntityType.EmailQueue, mailMessage.EmailQueueId.GetValueOrDefault(), doc, contract.AgentId);
                            }

                            return mailMessage;
                        }
                    }
                }
            }
            catch (SendContractEmailException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new SendContractEmailException($"Could not send email message with attachment", ex);
            }

            return null;
        }

        public async Task<TemplateMailMessage> SendContractEmailWithAttachmentPandaDocAsync(string emailAddress, string firstName, ContractDto contract, DocumentDto doc, int artistId)
        {
            try
            {
                // Get first event date
                var firstEventDate = contract.FirstEventDate.GetValueOrDefault();

                // Get agent info
                var agents = _lookupService.GetAllAgents();
                var agent = agents.FirstOrDefault(x => x.AppUserId == contract.AgentId);

                // Get email templates
                var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
                var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendContractToArtistWithAttachmentForPandaDoc);

                string appName = MobiusConfiguration.GetString("Application.Name");

                // Build the dynamic PandaDoc view/sign link
                string baseUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                string encryptedKey = EncryptDecrypt.Encrypt(contract.ContractId.ToString() + "/" + artistId.ToString());
                string linkUrl = $"{baseUrl}/artist/viewsignpandadoc/{encryptedKey}";
                string linkHtml = $"<a target='_blank' href='{linkUrl}'>View/Sign Contract</a>";

                // Build email subject and body
                var subject = bodyTemplate.Subject.Replace("{ContractNumber}", contract.ContractId.ToString());

                var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                var body = bodyBuilder
                    .Replace("{AgentEmailAddress}", agent != null ? agent.Username : string.Empty)
                    .Replace("{Year}", DateTime.Now.Year.ToString())
                    .Replace("{Body}", bodyTemplate.Body)
                    .Replace("{ContractId}", contract.ContractId.ToString())
                    .Replace("{FirstName}", firstName)
                    .Replace("{EventDate}", firstEventDate.ToString(DateTimeConstants.StandardDateWithDays))
                    .Replace("{PandaDoc Link}", linkHtml)
                    .ToString();

                // Create mail message
                var mailMessage = new TemplateMailMessage(EmailTemplate.SendContractToArtistWithAttachment)
                {
                    Body = body,
                    Subject = subject,
                    To = { emailAddress },
                    IsBodyHtml = true
                };

                // Get file extension info
                var docExt = Context.Lookups.GetDocumentExtensions().First(x => x.DocumentExtensionId == doc.DocumentExtensionId);

                using (var ms = _documentService.GetFromStorage(doc, EntityType.Contract.ToString()))
                {
                    string fileExtension = docExt.Name.ToLower();
                    string fileName = doc.OriginalFileName;

                    if (!fileName.EndsWith("." + fileExtension, StringComparison.OrdinalIgnoreCase))
                    {
                        fileName = $"{doc.OriginalFileName}.{fileExtension}";
                    }

                    // Attach file
                    mailMessage.Attachments.Add(new Attachment(ms, fileName, docExt.MimeType));

                    var smtpManager = new SmtpManager(Context);
                    if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                    {
                        if (smtpManager.SendMessage(mailMessage, contract.AgentId, SendMessageMode.Directly))
                        {
                            if (mailMessage.EmailQueueId > 0)
                            {
                                _documentService.LinkDocumentTo(
                                    EntityType.EmailQueue,
                                    mailMessage.EmailQueueId.GetValueOrDefault(),
                                    doc,
                                    contract.AgentId
                                );
                            }

                            return mailMessage;
                        }
                    }
                }
            }
            catch (SendContractEmailException)
            {
                throw; // Custom known exception
            }
            catch (Exception ex)
            {
                throw new SendContractEmailException("Could not send email message with attachment", ex);
            }

            return null;

        }

        private async Task<TemplateMailMessage> SendContractEmailForAppUserAsync(ContactDto contact, int contractId, string url, int userId, EmailTemplate emailTemplate, DateTime firstEventDate, int agentId)
        {
            var agents = _lookupService.GetAllAgents();
            var agent = agents.FirstOrDefault(x => x.AppUserId == agentId);
            var contract = await _contractDao.GetByIdAsync(contractId);

            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)emailTemplate);

            var message = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");

            var subject = bodyTemplate.Subject
                .Replace("{AppName}", appName)
                .Replace("{ContractNumber}", contractId.ToString());
            var bodyTemplateString = bodyTemplate.Body;

            //if (contract.IsPandaDoc && (int)emailTemplate == (int)EmailTemplate.SendContractToArtistWithPortalLink)
            //{
            //    var contractArtists = await Context.ContractArtists
            //        .GetByContractIdAsync(contract.ContractId);

            //    var artistId = contractArtists?.FirstOrDefault()?.ArtistId;
            //    if (artistId.HasValue)
            //    {
            //        string encryptedKey = EncryptDecrypt.Encrypt(contract.ContractId.ToString() + "/" + artistId.Value.ToString());
            //        string linkUrl = $"{MobiusConfiguration.GetString("Application.Url")}artist/viewsignpandadoc/{encryptedKey}";
            //        string pandadocSignUrl = string.Format(
            //        "{0}artist/viewsignpandadoc/{1}",
            //        MobiusConfiguration.GetString("Application.Url"),
            //        encryptedKey);                    

            //        var pandadocSignLinkHtml = string.Format(
            //        "<a target=\"_blank\" rel=\"noopener noreferrer\" href=\"{0}\">View/Sign Contract</a>",
            //         pandadocSignUrl
            //        );

            //        if (!string.IsNullOrWhiteSpace(bodyTemplateString))
            //        {
            //            bodyTemplateString += string.Concat("<br/><br/>", pandadocSignLinkHtml, "<br/><br/>");
            //        }

            //    }
            //}
            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
            var body = bodyBuilder
                .Replace("{AgentEmailAddress}", agent == null ? string.Empty : agent.Username)
                .Replace("{Year}", DateTime.Now.Year.ToString())
                .Replace("{Body}", bodyTemplateString)
                .Replace("{FirstName}", contact.FirstName)
                .Replace("{ContractId}", contractId.ToString())
                .Replace("{EventDate}", firstEventDate.ToString(DateTimeConstants.StandardDateWithDays))
                .Replace("{URL}", url)
                .ToString();

            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = bodyTemplate.IsHtml;

            message.AddRecipient(contact);

            if (message.HasRecipient)
            {
                var smtpManager = new SmtpManager(this.Context);

                var sentBy = agentId;
                if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                {
                    smtpManager.SendMessage(message, sentBy, SendMessageMode.Queued);
                }

                return message;
            }

            return null;
        }

        private async Task SendSignatureReceivedEmailAsync(ContactDto primaryContact, PresenterPortalDto portal, IPrincipal user, int agentId)
        {
            var agents = _lookupService.GetAllAgents();
            var agent = agents.FirstOrDefault(x => x.AppUserId == agentId);
            var contract = await _contractDao.GetByIdAsync(portal.ContractId);

            var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.EceClientLayoutTemplate);
            var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SendSignatureDepositNotification);

            var message = new TemplateMailMessage(bodyTemplate.EmailTemplateId);

            string appName = MobiusConfiguration.GetString("Application.Name");
            string url = string.Format(
                "{0}{1}{2}",
                MobiusConfiguration.GetString("Application.Url"),
                MobiusConfiguration.GetString("Application.EventDetailsUrl"),
                portal.UrlKey);
            var contractId = portal.ContractId.ToString();

            var firstEventDate = portal.ParentContract.FirstEventDate.GetValueOrDefault();

            var bodyBuilder = new StringBuilder(layoutTemplate.Body);

            var subject = bodyTemplate.Subject
                .Replace("{ContractNumber}", contractId)
                .Replace("{EventType}", "Signature");

            var body = bodyBuilder
                .Replace("{AgentEmailAddress}", agent == null ? string.Empty : agent.Username)
                .Replace("{Year}", DateTime.Now.Year.ToString())
                .Replace("{Body}", bodyTemplate.Body)
                .Replace("{AppName}", appName)
                .Replace("{Subject}", subject)
                .Replace("{EventType}", "signature")
                .Replace("{EventDate}", firstEventDate.ToString(DateTimeConstants.StandardDateWithDays))
                .Replace("{ContractId}", contractId)
                .Replace("{ContactName}", primaryContact?.FullName)
                .Replace("{ContractDetailsUrl}", url)
                .ToString();

            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = bodyTemplate.IsHtml;

            message.AddRecipient(primaryContact);

            if (message.HasRecipient)
            {
                var smtpManager = new SmtpManager(this.Context);

                var sentBy = agentId;

                var releaseDate = ContractDepositService.GetDepositReceivedReleaseDate(TimeProvider.Current);
                if (!smtpManager.SuppressMessageForOffice(contract.OfficeId ?? 0))
                {
                    smtpManager.SendMessage(message, sentBy, releaseDate, SendMessageMode.Queued);
                }

                var commLog = new CommunicationLogDto
                {
                    CommunicationMethodId = (int)CommunicationMethod.Email,
                    ContactId = primaryContact == null ? 0 : primaryContact.ContactId,
                    EntityId = portal.ContractId,
                    EntityTypeId = (int)EntityType.Contract,
                    EmailQueueId = message.EmailQueueId,
                    LogDate = DateTime.Now,
                    LogTime = DateTime.Now.ToShortTimeString(),
                    Notes = "Send Signature Notification to Presenter"
                };

                _communicationLogService.AddCommunicationLog(commLog, user);
            }
        }

        private async Task SendContractEmailForPresenterPortalUserAsync(ContactDto contact, PresenterPortalDto portal, IPrincipal user, int agentId)
        {
            try
            {
                var firstEventDate = portal.ParentContract.FirstEventDate.GetValueOrDefault();

                string url = string.Format(
                    "{0}{1}{2}",
                    MobiusConfiguration.GetString("Application.Url"),
                    MobiusConfiguration.GetString("Application.EventDetailsUrl"),
                    portal.UrlKey);

                var message = await SendContractEmailForAppUserAsync(contact, portal.ContractId, url, user.GetUserId(), EmailTemplate.SendContractToPresenterWithPortalLink, firstEventDate, agentId);
                if (message != null)
                {
                    var commLog = new CommunicationLogDto
                    {
                        CommunicationMethodId = (int)CommunicationMethod.Email,
                        ContactId = contact.ContactId,
                        EntityId = portal.ContractId,
                        EntityTypeId = (int)EntityType.Contract,
                        EmailQueueId = message.EmailQueueId,
                        LogDate = DateTime.Now,
                        LogTime = DateTime.Now.ToShortTimeString(),
                        Notes = "Send email with link to the presenter portal."
                    };

                    _communicationLogService.AddCommunicationLog(commLog, user);
                }
            }
            catch (Exception ex)
            {
                throw new SendContractEmailException($"Could not send email message for presenter portal user", ex);
            }
        }

        public async Task SendAllSignaturesReceivedEmailForPresenterPortalUserAsync(ContactDto contact, PresenterPortalDto portal, IPrincipal user, int agentId)
        {
            try
            {
                var firstEventDate = portal.ParentContract.FirstEventDate.GetValueOrDefault();

                string url = string.Format(
                    "{0}{1}{2}",
                    MobiusConfiguration.GetString("Application.Url"),
                    MobiusConfiguration.GetString("Application.EventDetailsUrl"),
                    portal.UrlKey);

                var message = await SendContractEmailForAppUserAsync(contact, portal.ContractId, url, user.GetUserId(), EmailTemplate.SendAllSignaturesReceived, firstEventDate, agentId);
                if (message != null)
                {
                    var commLog = new CommunicationLogDto
                    {
                        CommunicationMethodId = (int)CommunicationMethod.Email,
                        ContactId = contact.ContactId,
                        EntityId = portal.ContractId,
                        EntityTypeId = (int)EntityType.Contract,
                        EmailQueueId = message.EmailQueueId,
                        LogDate = DateTime.Now,
                        LogTime = DateTime.Now.ToShortTimeString(),
                        Notes = "Send email with notification that all signatures have been received."
                    };

                    _communicationLogService.AddCommunicationLog(commLog, user);
                }
            }
            catch (Exception ex)
            {
                throw new SendContractEmailException($"Could not send email message for presenter portal user", ex);
            }
        }

        public async Task SendContractEmailForArtistPortalUserAsync(string firstName, string emailAddress, ContractDto contract, IPrincipal user)
        {
            try
            {
                string url = MobiusConfiguration.GetString("Application.Url");

                var contact = new ContactDto
                {
                    FirstName = firstName,
                    EmailAddress = emailAddress,
                };

                var firstEventDate = contract.FirstEventDate.GetValueOrDefault();

                var message = await SendContractEmailForAppUserAsync(contact, contract.ContractId, url, contract.AgentId, EmailTemplate.SendContractToArtistWithPortalLink, firstEventDate, contract.AgentId);
                if (message != null)
                {
                    var commLog = new CommunicationLogDto
                    {
                        CommunicationMethodId = (int)CommunicationMethod.Email,
                        ContactId = contact.ContactId,
                        EntityId = contract.ContractId,
                        EntityTypeId = (int)EntityType.Contract,
                        EmailQueueId = message.EmailQueueId,
                        LogDate = DateTime.Now,
                        LogTime = DateTime.Now.ToShortTimeString(),
                        Notes = "Send email to artist that contract is ready for signature."
                    };

                    _communicationLogService.AddCommunicationLog(commLog, user);
                }
            }
            catch (Exception ex)
            {
                throw new SendContractEmailException($"Could not send email message for artist portal user", ex);
            }
        }
    }
}