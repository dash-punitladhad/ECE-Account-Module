﻿namespace ECE.CRM.BusinessServices
{
    using System;

    public class NoArtistAgreementException : Exception
    {
        public NoArtistAgreementException(string message)
            : base(message)
        {
        }

        public NoArtistAgreementException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
