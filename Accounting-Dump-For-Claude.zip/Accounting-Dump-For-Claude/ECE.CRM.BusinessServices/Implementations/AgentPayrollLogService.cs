﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AgentPayrollLogService : IAgentPayrollLogService
    {
        public AgentPayrollLogService(IUnitOfWork context, ILogger logger)
        {
            this.Context = context;
            this.Logger = logger;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<IList<AgentPayrollLogDto>> GetUnpaidByAgentAsync(int agentId, DateTime startDate, DateTime endDate)
        {
            return await this.Context.AgentPayrollLogs.GetUnpaidByAgentAsync(agentId, startDate, endDate);
        }

        public async Task CreateAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.AgentPayrollLogs.CreateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAsync(AgentPayrollLogDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.AgentPayrollLogs.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteAsync(int id)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.AgentPayrollLogs.DeleteAsync(id);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
