﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ArtistPortalService : IArtistPortalService
    {
        private readonly IRolePermissionService _rolePermissionService;
        private readonly IContractDocumentService _contractDocumentService;

        public ArtistPortalService(IRolePermissionService rolePermissionService,
                                    IContractDocumentService contractDocumentService,
                                    IUnitOfWork context)
        {
            this._rolePermissionService = rolePermissionService;
            this._contractDocumentService = contractDocumentService;
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<bool> CanReadContractDocument(ContractDocumentDto contractDocument, int userId)
        {
            var artistId = await this._rolePermissionService.GetEntityIdFromRole(userId, (int)ECERole.Artist);

            if (artistId.HasValue)
            {
                var allowedDocs = await this._contractDocumentService.GetContractDocumentsForArtistAsync(contractDocument.ContractId, artistId.Value);

                return allowedDocs.Any(x => x.ContractDocumentId == contractDocument.ContractDocumentId);
            }

            return false;
        }

        public async Task<bool> CanReadAsync(int userId, int artistId)
        {
            var role = await this._rolePermissionService.GetRoleForUserEntity(userId, ECERole.Artist, artistId);

            return role != null;
        }

        public async Task<List<ArtistPortalBookDateDto>> GetBookedDatesForPortalAsync(int id)
        {
            return await this.Context.ArtistPortals.GetBookedDatesForPortalAsync(id);
        }

        public async Task<IList<ArtistPortalActionDto>> GetArtistActionsNeededAsync(int artistId)
        {
            var results = await this.Context.ArtistPortals.GetArtistActionsNeededAsync(artistId);

            var actions = new List<ArtistPortalActionDto>();

            foreach (var r in results)
            {
                if (actions.All(x => x.ContractId != r.ContractId))
                {
                    if (r.DueDate.HasValue)
                    {
                        if (r.DueDate.Value.Date < DateTime.Now.Date && r.ArtistSignatureCount <= 0)
                        {
                            r.Flag = ArtistPortalActionFlags.SignatureOverdue;
                            actions.Add(r);
                        }
                        else if ((r.DueDate.Value.Date >= DateTime.Now.Date && r.ArtistSignatureCount <= 0) || r.IsPresenterSignButNoArtistSign)
                        {
                            r.Flag = ArtistPortalActionFlags.SignatureDue;
                            actions.Add(r);
                        }
                        else if (r.EventDate.Subtract(DateTime.Now).Days >= 30 &&
                                  r.EventDate.Subtract(DateTime.Now).Days <= 45 && r.ArtistSignatureCount > 0)
                        {
                            r.Flag = ArtistPortalActionFlags.AdvanceDate;
                            actions.Add(r);
                        }
                    }
                    else if (r.IsPresenterSignButNoArtistSign)
                    {
                        r.Flag = ArtistPortalActionFlags.SignatureDue;
                        actions.Add(r);
                    }
                }
            }

            return actions;
        }
    }
}