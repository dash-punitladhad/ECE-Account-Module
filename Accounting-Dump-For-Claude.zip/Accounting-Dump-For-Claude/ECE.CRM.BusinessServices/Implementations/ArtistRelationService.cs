﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistRelationService : IArtistRelationService
    {
        private readonly IUserService _userService;

        public ArtistRelationService(IUnitOfWork context, IUserService userService)
        {
            this.Context = context;
            _userService = userService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<ArtistDto>> GetAsync(int id)
        {
            return await this.Context.ArtistRelations.GetAsync(id);
        }

        public async Task CreateAsync(int id, int relatedArtistId, IPrincipal user)
        {
            // First we find all the connections to be made.
            var relatedToSource = await this.GetAsync(id);
            var relatedToTarget = await this.GetAsync(relatedArtistId);

            // Relate the two entities in question.
            var dto = new ArtistRelationDto
            {
                ArtistId = id,
                RelatedArtistId = relatedArtistId,
            };

            dto.SetAsCreated(user);

            try
            {
                this.Context.BeginTransaction();

                await this.Context.ArtistRelations.CreateAsync(dto);

                // Relate the target's immediate relationships to the source.
                foreach (var i in relatedToSource)
                {
                    var sourceToTargetDto = new ArtistRelationDto
                    {
                        ArtistId = i.ArtistId,
                        RelatedArtistId = relatedArtistId
                    };

                    sourceToTargetDto.SetAsCreated(user);

                    await this.Context.ArtistRelations.CreateAsync(sourceToTargetDto);
                }

                // Relate the source's immediate relationships to the target.
                foreach (var j in relatedToTarget)
                {
                    var targetToSourceDto = new ArtistRelationDto
                    {
                        ArtistId = j.ArtistId,
                        RelatedArtistId = id
                    };

                    targetToSourceDto.SetAsCreated(user);

                    await this.Context.ArtistRelations.CreateAsync(targetToSourceDto);
                }

                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task DeleteAllAsync(int id, IPrincipal user)
        {
            var dto = new ArtistRelationDto
            {
                ArtistId = id
            };

            dto.SetAsUpdated(user);

            try
            {
                this.Context.BeginTransaction();
                await this.Context.ArtistRelations.DeleteAllAsync(dto);
                this.Context.Commit();
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task<List<int>> GetIdsAsync(int id)
        {
            var relatedArtistIds = new List<int>();
            var relatedArtists = await this.Context.ArtistRelations.GetAsync(id);

            if (relatedArtists != null && relatedArtists.Count > 0)
            {
                relatedArtistIds = relatedArtists.Select(x => x.ArtistId).ToList();
            }

            relatedArtistIds.Add(id);

            return relatedArtistIds;
        }
    }
}
