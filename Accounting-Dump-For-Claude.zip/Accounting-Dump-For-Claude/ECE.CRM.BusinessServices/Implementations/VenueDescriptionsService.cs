﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class VenueDescriptionsService : IVenueDescriptionService
    {
        public VenueDescriptionsService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<int> CreateAsync(VenueDescriptionDto venueDescription)
        {
            return await this.Context.VenueDescriptions.CreateAsync(venueDescription);
        }

        public async Task<List<VenueDescriptionDto>> GetVenueTypesByVenueAsync(int id)
        {
            return await this.Context.VenueDescriptions.GetVenueTypesByVenueAsync(id);
        }

        public async Task SyncVenueDescriptionsAsync(int venueId, IEnumerable<string> venueTypes)
        {
            this.Context.BeginTransaction();

            try
            {
                var existingVenueDescriptions = await this.Context.VenueDescriptions.GetVenueTypesByVenueAsync(venueId);

                var listOfSelectedVenueTypes =
                        venueTypes?.Select(x => Convert.ToInt32(x.Trim())).ToList()
                    ?? new List<int>();

                var venueTypesToKeep =
                    existingVenueDescriptions.Where(x => listOfSelectedVenueTypes.Contains(x.VenueTypeId)).ToList();

                var venueTypesToAdd = listOfSelectedVenueTypes.Except(
                                    venueTypesToKeep.Select(x => x.VenueTypeId).ToList(),
                                    x => x);

                foreach (int venueTypeId in venueTypesToAdd)
                {
                    var v = new VenueDescriptionDto()
                    {
                        VenueId = venueId,
                        VenueTypeId = venueTypeId,
                        VenueDescriptionId = 0
                    };

                    await this.Context.VenueDescriptions.CreateAsync(v);
                }

                var venueTypesToRemove = existingVenueDescriptions.Except(venueTypesToKeep);

                foreach (var dto in venueTypesToRemove)
                {
                    await this.Context.VenueDescriptions.DeleteAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
