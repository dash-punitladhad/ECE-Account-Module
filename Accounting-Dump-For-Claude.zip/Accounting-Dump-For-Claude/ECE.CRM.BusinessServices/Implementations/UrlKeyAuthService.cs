﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Threading.Tasks;

    public class UrlKeyAuthService : IUrlKeyAuthService
    {
        public UrlKeyAuthService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<bool> EntityIsRelatedToUrlKey(UrlKeyRelatedEntityDto relatedEntity)
        {
            if (relatedEntity == null)
            {
                return false;
            }

            switch (relatedEntity.KeyHolderType)
            {
                case UrlKeyHolderType.BlueCardPromos:

                    var dto = await this.Context.BlueCardPromos.GetBlueCardPromoByUrlKeyAsync(relatedEntity.UrlKey);

                    if (dto != null && dto.BlueCardId == relatedEntity.OriginalEntityId)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case UrlKeyHolderType.BlueCardPromoArtists:

                    return await this.Context.Artists.ArtistIsRelatedToUrlKey(
                        relatedEntity.KeyHolderType,
                        relatedEntity.UrlKey,
                        relatedEntity.OriginalEntityId);

                case UrlKeyHolderType.BlueCardPromoArtistWebLinks:

                    return await this.Context.WebLinks.WebLinkIsRelatedToUrlKey(
                        relatedEntity.KeyHolderType,
                        relatedEntity.UrlKey,
                        relatedEntity.OriginalEntityId);

                case UrlKeyHolderType.BlueCardPromoArtistDocuments:

                    return await this.Context.Documents.DocumentIsRelatedToUrlKeyAsync(
                        relatedEntity.KeyHolderType,
                        relatedEntity.UrlKey,
                        relatedEntity.OriginalEntityId);

                case UrlKeyHolderType.Sample:
                    return true;

                default:
                    break;
            }

            return false;
        }
    }
}
