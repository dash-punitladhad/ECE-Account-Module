﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class MarketingService : IMarketingService
    {
        private readonly ILookupService _lookupService;

        public MarketingService(IUnitOfWork context, ILookupService lookupService)
        {
            this.Context = context;
            this._lookupService = lookupService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<LineOfBusinessActivityDto>> GetLineOfBusinessActivityAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.AddYears(-4).Year, 1, 1);
            }

            var results = await this.Context.Marketing.GetLineOfBusinessActivityAsync(startDate.Value, endDate.Value);

            return results;
        }

        public async Task<IList<LeadSourceActivityDto>> GetLeadSourceActitvtyAsync(DateTime? startDate = null, DateTime? endDate = null, int? eventTypeId = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.AddYears(-4).Year, 1, 1);
            }

            var results =
                await this.Context.Marketing.GetLeadSourceActitvtyAsync(startDate.Value, endDate.Value, eventTypeId);

            return results;
        }

        public async Task<IList<EntityActivityDto>> GetOfficeActivityAsync(DateTime? startDate = null, DateTime? endDate = null, int? eventTypeId = null)
        {
            if (!endDate.HasValue)
            {
                endDate = DateTime.Now;
            }

            if (!startDate.HasValue)
            {
                startDate = new DateTime(DateTime.Now.AddYears(-4).Year, 1, 1);
            }

            var endYear = endDate.Value.Year;
            var startYear = startDate.Value.Year;
            var yearDiff = endYear - startYear;

            var offices = this._lookupService.GetAllOffices();

            var results =
                await this.Context.Marketing.GetOfficeActivityAsync(startDate.Value, endDate.Value, eventTypeId);

            var officeActivityList = new List<EntityActivityDto>();

            foreach (var office in offices)
            {
                for (int i = 0; i <= yearDiff; i++)
                {
                    var year = startYear + i;

                    var ea = new EntityActivityDto
                    {
                        EntityId = office.OfficeId,
                        EntityName = office.Name,
                        Year = year,
                        Amount = 0
                    };

                    var result = results.FirstOrDefault(x => x.EntityId == office.OfficeId && x.Year == year);

                    if (result != null)
                    {
                        ea.Amount = result.Amount;
                        ea.ItemCount = result.ItemCount;
                    }

                    if (i > 0)
                    {
                        var prev = officeActivityList.FirstOrDefault(x => x.EntityId == office.OfficeId && x.Year == year - 1);

                        if (prev != null)
                        {
                            ea.PreviousAmount = prev.Amount;
                            ea.PreviousItemCount = prev.ItemCount;
                        }
                    }

                    officeActivityList.Add(ea);
                }
            }

            return officeActivityList;
        }

        public async Task<IList<EntityLocationDto>> GetContractVenueActivityAsync(DateTime startDate, DateTime endDate, int? eventTypeId = null)
        {
            if (eventTypeId.HasValue && eventTypeId.Value == 0)
            {
                eventTypeId = null;
            }

            return await this.Context.Marketing.GetContractVenueActivityAsync(startDate, endDate, eventTypeId);
        }

        public async Task<IList<ArtistBookingCostStatsDto>> GetArtistPricingFrequencyAsync(
            DateTime startDate,
            DateTime endDate,
            int officeId,
            int eventTypeId,
            bool? isExclusive)
        {
            return await this.Context.Marketing.GetArtistPricingFrequencyAsync(
                       startDate,
                       endDate,
                       officeId,
                       eventTypeId,
                       isExclusive);
        }
    }
}
