﻿namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class MapService : IMapService
    {
        public MapService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public MapSearchTypesDto GetMapSearchTypes(string searchTypesString)
        {
            var selectedParentTypes = new List<int>();
            var selectedGenreTypes = new List<int>();

            int? selectedAgentId = null;

            var tokens = (searchTypesString ?? string.Empty)
                .Split(new[] { '|' })
                .ToArray();

            if (tokens.Length > 2)
            {
                var value = tokens[2];
                if (!string.IsNullOrWhiteSpace(value))
                {
                    selectedAgentId = Convert.ToInt32(value.Trim());
                }
            }

            if (tokens.Length > 1)
            {
                selectedGenreTypes.AddRange(tokens[1]
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => Convert.ToInt32(x.Trim())));
            }

            if (tokens.Length > 0)
            {
                selectedParentTypes.AddRange(tokens[0]
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => Convert.ToInt32(x.Trim())));
            }

            return new MapSearchTypesDto
            {
                AgentId = selectedAgentId,
                GenreTypes = selectedGenreTypes,
                ParentTypes = selectedParentTypes,
            };
        }

        public async Task<IList<LocationDto>> GetLocationsAtDistanceAsync(LocationsAtDistanceCriteriaDto criteria)
        {
            if (criteria.EntityType == EntityType.Presenter)
            {
                var searchTypes = this.GetMapSearchTypes(criteria.SearchTypes);

                var presenterCriteria = new PresenterSearchCriteriaDto
                {
                    Latitude = criteria.OriginLatitude,
                    Longitude = criteria.OriginLongitude,
                    Distance = criteria.MaximumDistance,
                    PresenterTypes = searchTypes.ParentTypes,
                    GenreTypes = searchTypes.GenreTypes,
                    AssignedAgent = searchTypes.AgentId,
                    Status = 1 // active only
                };

                var presenters = await this.Context.Presenters.GetPresentersWithinDistanceAsync(presenterCriteria);

                var presenterList = Mapper.Map<IList<LocationDto>>(presenters);

                return presenterList;
            }
            else if (criteria.EntityType == EntityType.Venue)
            {
                var searchTypes = this.GetMapSearchTypes(criteria.SearchTypes);

                IList<int> actTypes = new List<int>();

                var venueCriteria = new VenueSearchCriteriaDto
                {
                    Latitude = criteria.OriginLatitude,
                    Longitude = criteria.OriginLongitude,
                    DistanceInMiles = criteria.MaximumDistance,
                    VenueTypes = searchTypes.ParentTypes,
                    GenreTypes = searchTypes.GenreTypes,
                    AssignedAgent = searchTypes.AgentId,
                    MaximumCapacity = criteria.MaximumCapacity,
                    MinimumCapacity = criteria.MinimumCapacity,
                    ActTypes = actTypes,
                    Status = 1 // active only
                };

                var venues = await this.Context.Venues.GetVenuesWithinDistanceAsync(venueCriteria);

                var venuesList = Mapper.Map<IList<LocationDto>>(venues);

                return venuesList;
            }
            else
            {
                IList<string> typeCollection = new List<string>((criteria.SearchTypes ?? string.Empty).Split('|'));
                IList<int> actTypes = new List<int>();
                IList<int> genreTypes = new List<int>();
                IList<int> eventTypes = new List<int>();

                if (typeCollection.Count > 0 && typeCollection[0] != string.Empty)
                {
                    actTypes = new List<int>(typeCollection[0].Split(',').Select(int.Parse));
                }

                if (typeCollection.Count > 1 && typeCollection[1] != string.Empty)
                {
                    genreTypes = new List<int>(typeCollection[1].Split(',').Select(int.Parse));
                }

                if (typeCollection.Count > 2 && typeCollection[2] != string.Empty)
                {
                    eventTypes = new List<int>(typeCollection[2].Split(',').Select(int.Parse));
                }

                var artistCriteria = new ArtistSearchCriteriaDto
                {
                    Latitude = criteria.OriginLatitude,
                    Longitude = criteria.OriginLongitude,
                    Distance = criteria.MaximumDistance,
                    ActTypes = actTypes,
                    GenreTypes = genreTypes,
                    EventTypes = eventTypes,
                    Status = true // active only
                };

                var artists = await this.Context.Artists.GetByCriteriaAsync(artistCriteria);

                var artistsList = Mapper.Map<IList<LocationDto>>(artists.Where(x => x.IsNational == false));

                return artistsList;
            }
        }

        public async Task<IList<LocationDto>> GetLocationsAtDistanceAsync(EntityType entityType, decimal originLatitude, decimal originLongitude, string searchTypes, int maxDistance, int minDistance = 0)
        {
            if (entityType == EntityType.Presenter)
            {
                IList<int> presenterTypes = searchTypes
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => Convert.ToInt32(x.Trim()))
                    .ToList();

                var criteria = new PresenterSearchCriteriaDto
                {
                    Latitude = originLatitude,
                    Longitude = originLongitude,
                    Distance = maxDistance,
                    PresenterTypes = presenterTypes,
                    Status = 1 // active only
                };

                var presenters = await this.Context.Presenters.GetByCriteriaAsync(criteria);

                var presenterList = Mapper.Map<IList<LocationDto>>(presenters);

                return presenterList;
            }
            else if (entityType == EntityType.Venue)
            {
                IList<int> venueTypes = searchTypes
                    .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => Convert.ToInt32(x.Trim()))
                    .ToList();

                IList<int> actTypes = new List<int>();

                var criteria = new VenueSearchCriteriaDto
                {
                    Latitude = originLatitude,
                    Longitude = originLongitude,
                    MaxDistance = maxDistance,
                    MinDistance = minDistance,
                    VenueTypes = venueTypes,
                    ActTypes = actTypes,
                    Status = 1 // active only
                };

                var venues = await this.Context.Venues.GetVenueByCriteriaAsync(criteria);

                var venuesList = Mapper.Map<IList<LocationDto>>(venues);

                return venuesList;
            }
            else
            {
                IList<string> typeCollection = new List<string>(searchTypes.Split('|'));
                IList<int> actTypes = new List<int>();
                IList<int> genreTypes = new List<int>();
                IList<int> eventTypes = new List<int>();

                if (typeCollection[0] != string.Empty)
                {
                    actTypes = new List<int>(typeCollection[0].Split(',').Select(int.Parse));
                }

                if (typeCollection[1] != string.Empty)
                {
                    genreTypes = new List<int>(typeCollection[1].Split(',').Select(int.Parse));
                }

                if (typeCollection[2] != string.Empty)
                {
                    eventTypes = new List<int>(typeCollection[2].Split(',').Select(int.Parse));
                }

                var criteria = new ArtistSearchCriteriaDto
                {
                    Latitude = originLatitude,
                    Longitude = originLongitude,
                    Distance = maxDistance,
                    ActTypes = actTypes,
                    GenreTypes = genreTypes,
                    EventTypes = eventTypes,
                    Status = true // active only
                };

                var artists = await this.Context.Artists.GetByCriteriaAsync(criteria);

                var artistsList = Mapper.Map<IList<LocationDto>>(artists);

                return artistsList;
            }
        }

        public async Task<IList<LocationDto>> GetLocationsAlongRouteAsync(EntityType entityType, int[] entityIds)
        {
            var result = new List<LocationDto>();

            if (entityType == EntityType.Presenter)
            {
                foreach (var destinationId in entityIds)
                {
                    var presenterDto = await this.Context.Presenters.GetByIdAsync(destinationId);
                    result.Add(new LocationDto
                    {
                        Latitude = (decimal)presenterDto.PhysicalGeoLatitude,
                        Longitude = (decimal)presenterDto.PhysicalGeoLongitude,
                        EntityType = EntityType.Presenter,
                        EntityId = presenterDto.PresenterId,
                        PresenterType = presenterDto.PresenterTypeId,
                        AddressOne = presenterDto.PhysicalAddress1,
                        AddressTwo = presenterDto.PhysicalAddress2,
                        LocationName = presenterDto.AccountName
                    });
                }
            }
            else
            {
                // Once Venues are in the system, put in logic here to handle that case and the case of artists.
            }

            return result;
        }
    }
}
