﻿namespace ECE.CRM.BusinessServices
{
    using System;

    public class Constants
    {
        /// <summary>
        /// The duration a pending email will remaining in the queue before it is released automatically.
        /// </summary>
        public static readonly TimeSpan PendingReleaseDuration = TimeSpan.FromHours(1);

        /// <summary>
        /// The OfficeId of Houston for filtering purposes.
        /// </summary>
        public static readonly int HoustonOfficeId = 21;
    }
}
