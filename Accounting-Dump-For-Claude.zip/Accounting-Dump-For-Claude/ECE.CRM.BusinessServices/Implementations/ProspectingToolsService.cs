﻿namespace ECE.CRM.BusinessServices.Implementations
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ProspectingToolsService : IProspectingToolsService
    {
        public ProspectingToolsService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; }

        public async Task<IList<ContractProspectingToolDto>> GetPreviousContractsAsync(
            int? agentId = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            if (!startDate.HasValue)
            {
                startDate = DateTime.Now.AddMonths(-18);
            }

            if (!endDate.HasValue)
            {
                endDate = DateTime.Now.AddMonths(-12);
            }

            var results =
                await this.Context.ProspectingTools.GetPreviousContractsAsync(agentId, startDate.Value, endDate.Value);

            return results;
        }

        public async Task<IList<ContractProspectingToolDto>> GetNewContractsAsync(int? officeId, DateTime issueDate, int numberOfDays)
        {
            if (numberOfDays > 0)
            {
                numberOfDays = numberOfDays * -1;
            }

            return await this.Context.ProspectingTools.GetNewContractsAsync(officeId, issueDate, numberOfDays);
        }

        public async Task<IList<ContractProspectingToolDto>> GetCanceledContractsAsync(
            int numberOfDays,
            DateTime issueDate)
        {
            if (numberOfDays > 0)
            {
                numberOfDays = numberOfDays * -1;
            }

            return await this.Context.ProspectingTools.GetCanceledContractsAsync(numberOfDays, issueDate);
        }

        public async Task<IList<PresenterProspectingToolDto>> GetNewPresentersAsync(int numberOfDays, DateTime createDate)
        {
            var startDate = createDate.AddDays(numberOfDays);
            var endDate = createDate;

            return await this.Context.ProspectingTools.GetNewPresentersAsync(startDate, endDate);
        }

        public async Task<IList<ContractChangeLogDto>> GetContractChangesAsync(int numberOfDays, DateTime issueDate)
        {
            if (numberOfDays > 0)
            {
                numberOfDays = numberOfDays * -1;
            }

            return await this.Context.ProspectingTools.GetContractChangesAsync(numberOfDays, issueDate);
        }
    }
}
