﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistGoalsService : IArtistGoalsService
    {
        private readonly IUserService _userService;
        private readonly IArtistService _artistService;

        public ArtistGoalsService(IUnitOfWork context, IUserService userService, IArtistService artistService)
        {
            this.Context = context;
            _userService = userService;
            _artistService = artistService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ArtistGoalDto>> GetArtistGoalsAsync(int artistId, int numOfYears)
        {
            return await this.Context.ArtistGoals.GetArtistGoalsAsync(artistId, numOfYears);
        }

        public async Task CreateArtistGoalAsync(ArtistGoalDto goal)
        {
            try
            {
                this.Context.BeginTransaction();
                await this.Context.ArtistGoals.CreateArtistGoalAsync(goal);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.Artist, goal.ArtistId, ex);
            }
        }

        public async Task UpdateArtistGoalAsync(ArtistGoalDto goal)
        {
            try
            {
                this.Context.BeginTransaction();
                await this.Context.ArtistGoals.UpdateArtistGoalAsync(goal);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("ArtistGoal", goal.ArtistGoalId, ex);
            }
        }

        public async Task<IList<ArtistBookingsDto>> GetArtistBookingsAsync(int artistId, int? year)
        {
            if (!year.HasValue)
            {
                year = DateTime.Now.Year;
            }

            var bookings = await this.Context.ArtistGoals.GetArtistBookingsAsync(artistId, year.Value);

            // Pad out the missing months
            for (var month = 1; month <= 12; month++)
            {
                if (!bookings.Where(x => x.Month == month).Any())
                {
                    var dto = new ArtistBookingsDto
                    {
                        ArtistId = artistId,
                        Month = month,
                        NumberOfBookings = 0
                    };

                    bookings.Insert(month - 1, dto);
                }
            }

            return bookings;
        }

        public async Task<IList<ArtistYtdAgentBookingsDto>> GetAgentBookingsForArtistAsync(int artistId)
        {
            return await this.Context.ArtistGoals.GetAgentBookingsForArtist(artistId, DateTime.Now.Year);
        }

        public async Task<bool> VerifyCanEditArtistGoal(IPrincipal user, ArtistGoalDto goal)
        {
            var artist = await this._artistService.GetArtistByIdAsync(goal.ArtistId);

            if (artist == null)
            {
                throw new NullReferenceException(nameof(artist));
            }

            var isResponsibleAgent = artist.AgentId.HasValue && user.GetUserId() == artist.AgentId.Value;

            var isLmdOrOwner = user.IsInRole(ECERole.LMD) || user.IsInRole(ECERole.Owner);

            var isGoalCurrent = goal.Year == DateTime.Now.Year;

            var isGoalFuture = goal.Year > DateTime.Now.Year;

            if ((isGoalFuture && isResponsibleAgent) || (isGoalFuture && isLmdOrOwner))
            {
                return true;
            }

            if (isGoalCurrent && isLmdOrOwner)
            {
                return true;
            }

            if (user.IsInRole(ECERole.Assistant))
            {
                if (!artist.AgentId.HasValue)
                {
                    // Assistants can edit any artist that does not have an RA assigned.
                    return true;
                }

                // An assistant can edit artists 'owned' by agents in the same office as the assistant.
                var agentsInSameOffices = await this.Context.Users.GetOfficeCoworkersAsync(user.GetUserId(), (int)ECERole.Assistant);
                return agentsInSameOffices.Any(x => x.AppUserId == artist.AgentId.Value);
            }

            return false;
        }
    }
}
