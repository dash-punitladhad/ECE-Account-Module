﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.TimeProvider;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class AlertService : IAlertService
    {
        public AlertService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task CreateAsync(AlertDto alert, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                alert.SetAsCreated(user);

                await this.Context.Alerts.CreateAsync(alert);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task DismissAsync(int alertId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var alert = await this.Context.Alerts.GetByIdAsync(alertId);
                if (alert == null)
                {
                    throw new ArgumentException($"Alert {alertId} not found.");
                }

                if (!alert.IsRead)
                {
                    alert.IsRead = true;
                    alert.ReadDate = TimeProvider.Current.Now;
                    alert.SetAsUpdated(user);

                    await this.Context.Alerts.UpdateAsync(alert);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }

        public async Task<bool> DismissAllAsync(IPrincipal user)
        {
            var result = await this.Context.Alerts.DismissAllAsync(user);
            return result;
        }

        public async Task<List<AlertDto>> GetAlerts(int userId, bool includeDismissed)
        {
            return await this.Context.Alerts.GetAlerts(userId, includeDismissed);
        }
        public async Task<List<AlertAdvDto>> GetAlertsAdv(int userId, bool includeDismissed, int? entitytypeid, string search, DateTime? startDate, DateTime? endDate)
        {
            return await this.Context.Alerts.GetAlertsAdv(userId, includeDismissed, entitytypeid, search, startDate, endDate);
        }
        public async Task<bool> SetReadAlertAsync(AlertViewMode viewModel, IPrincipal user)
        {
            return await this.Context.Alerts.SetReadAlertAsync(viewModel, user);
        }
    }
}
