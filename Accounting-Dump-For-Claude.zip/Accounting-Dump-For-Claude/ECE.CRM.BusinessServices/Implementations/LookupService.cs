﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    /// <summary>
    /// Lookup Service Implementation.
    /// </summary>
    /// <seealso cref="ECE.CRM.BusinessServices.ILookupService" />
    public class LookupService : ILookupService
    {
        private readonly IDocumentService _documentService;

        /// <summary>
        /// Initializes a new instance of the <see cref="LookupService" /> class.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="documentService">The document service.</param>
        public LookupService(
            IUnitOfWork context,
            IDocumentService documentService)
        {
            this.Context = context;
            this._documentService = documentService;
        }

        /// <summary>
        /// Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public IUnitOfWork Context { get; private set; }

        /// <summary>
        /// Get all states.
        /// </summary>
        /// <param name="activeStatus">if set to <c>true</c> [active status].</param>
        /// <returns>A collection of all states.</returns>
        public IList<StateDto> GetAllStates(bool? activeStatus = true)
        {
            return this.Context.Lookups.GetAllStates(activeStatus);
        }

        /// <summary>
        /// Get all states.
        /// </summary>
        /// <param name="activeStatus">if set to <c>true</c> [active status].</param>
        /// <returns>A collection of all states.</returns>
        public async Task<IList<StateDto>> GetAllStatesAsync(bool? activeStatus = true)
        {
            return await this.Context.Lookups.GetAllStatesAsync(activeStatus);
        }

        /// <summary>
        /// Get all states using the specified country identifier.
        /// </summary>
        /// <param name="countryId">The country identifier.</param>
        /// <returns>A collection of all states.</returns>
        public IList<StateDto> GetAllStatesByCountry(int countryId)
        {
            return this.Context.Lookups.GetAllStatesByCountry(countryId);
        }

        public async Task<StateDto> GetStateByIdAsync(int id)
        {
            return await this.Context.Lookups.GetStateByIdAsync(id);
        }

        public IList<LookupDto> GetAllCancelledReasons()
        {
            return this.Context.Lookups.GetAllCancelledReasons();
        }

        public IList<LookupDto> GetAllClosedReasons()
        {
            return this.Context.Lookups.GetAllClosedReasons();
        }

        public IList<LookupDto> GetAllAgentCommissionTypes()
        {
            return this.Context.Lookups.GetAllAgentCommissionTypes();
        }

        public IList<LookupDto> GetAllTerms()
        {
            return this.Context.Lookups.GetAllTerms();
        }

        public IList<LookupDto> GetAllVenueTypes()
        {
            return this.Context.Lookups.GetAllVenueTypes();
        }

        public IList<VenueTypeDto> GetAllVenueTypes(bool includeDeleted)
        {
            return this.Context.Lookups.GetAllVenueTypes(includeDeleted);
        }

        public async Task CreateVenueTypeAsync(VenueTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateVenueTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateVenueTypeAsync(VenueTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateVenueTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteVenueTypeAsync(VenueTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteVenueTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<ContactTypeDto> GetContactTypes(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetContactTypes(includeDeleted);
        }

        public async Task CreateContactTypeAsync(ContactTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateContactTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateContactTypeAsync(ContactTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateContactTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteContactTypeAsync(ContactTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteContactTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// Gets all countries.
        /// </summary>
        /// <returns>A list of all countries.</returns>
        public IList<CountryDto> GetAllCountries()
        {
            return this.Context.Lookups.GetAllCountries();
        }

        /// <summary>
        /// get all countries as an asynchronous operation.
        /// </summary>
        /// <returns>A list of all countries.</returns>
        public async Task<IList<CountryDto>> GetAllCountriesAsync()
        {
            return await this.Context.Lookups.GetAllCountriesAsync();
        }

        public IList<VenueSettingDto> GetAllSettings()
        {
            return this.Context.Lookups.GetAllSettings();
        }

        /// <summary>
        /// Gets the email template.
        /// </summary>
        /// <param name="templateId">The template identifier.</param>
        /// <returns>An Email Template object.</returns>
        public async Task<EmailTemplateDto> GetEmailTemplateAsync(int templateId)
        {
            var template = await this.Context.Lookups.GetEmailTemplateAsync(templateId);
            if (template != null)
            {
                template.Body = template.Body.Replace("{BaseUrl}", MobiusConfiguration.GetString("Application.Url"));
            }

            return template;
        }

        /// <summary>
        /// Gets all email templates.
        /// </summary>
        /// <returns>A list of all templates.</returns>
        public async Task<IList<EmailTemplateDto>> GetAllEmailTemplatesAsync()
        {
            return await this.Context.Lookups.GetAllEmailTemplatesAsync();
        }

        /// <summary>
        /// Gets all the landing pages.
        /// </summary>
        /// <returns>A list of landing pages.</returns>
        public IList<LandingPageDto> GetAllLandingPages()
        {
            return this.Context.Lookups.GetAllLandingPages();
        }

        /// <summary>
        /// Gets all the landing pages.
        /// </summary>
        /// <returns>A list of landing pages.</returns>
        public async Task<IList<LandingPageDto>> GetAllLandingPagesAsync()
        {
            return await this.Context.Lookups.GetAllLandingPagesAsync();
        }

        /// <summary>
        /// Gets the landing page by criteria.
        /// </summary>
        /// <param name="criteria">The criteria.</param>
        /// <returns>A LandingPageDto if found.</returns>
        public async Task<IList<LandingPageDto>> GetLandingPagesByCriteriaAsync(LandingPageDto criteria)
        {
            return await this.Context.Lookups.GetLandingPagesByCriteriaAsync(criteria);
        }

        /// <summary>
        /// Gets all act types.
        /// </summary>
        /// <returns>A list of all act types.</returns>
        public IList<LookupDto> GetAllActTypes()
        {
            return this.Context.Lookups.GetAllActTypes();
        }

        public IList<ActTypeDto> GetAllActTypes(bool includeDeleted)
        {
            return this.Context.Lookups.GetAllActTypes(includeDeleted);
        }

        public async Task CreateActTypeAsync(ActTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateActTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateActTypeAsync(ActTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateActTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteActTypeAsync(ActTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteActTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<EventTypeDto> GetAllEventTypes(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetAllEventTypes(includeDeleted);
        }

        public async Task CreateEventTypeAsync(EventTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateEventTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateEventTypeAsync(EventTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateEventTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteEventTypeAsync(EventTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteEventTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<TermDto> GetAllTerms(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetAllTerms(includeDeleted);
        }

        public async Task CreateTermAsync(TermDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateTermAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateTermAsync(TermDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateTermAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteTermAsync(TermDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteTermAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// Gets all Presenter Types, both active and inactive.
        /// </summary>
        /// <param name="active">Option to get active, inactive, or both types</param>
        /// <returns>A collection of PresenterTypeDto</returns>
        public IList<PresenterTypeDto> GetAllPresenterTypes(bool? active = true)
        {
            return this.Context.Lookups.GetAllPresenterTypes(active);
        }

        public async Task CreatePresenterTypeAsync(PresenterTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreatePresenterTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdatePresenterTypeAsync(PresenterTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdatePresenterTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeletePresenterTypeAsync(PresenterTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeletePresenterTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<GenreTypeDto> GetAllGenreTypes(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetAllGenreTypes(includeDeleted);
        }

        public async Task CreateGenreTypeAsync(GenreTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateGenreTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateGenreTypeAsync(GenreTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateGenreTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteGenreTypeAsync(GenreTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteGenreTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateEmailTemplateAsync(EmailTemplateDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateEmailTemplateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<OfferBindingTypeDto> GetAllOfferBindingTypes()
        {
            return this.Context.Lookups.GetAllOfferBindingTypes();
        }

        public async Task<OfferBindingTypeDto> GetOfferBindingTypeAsync(int id)
        {
            return await this.Context.Lookups.GetOfferBindingTypeAsync(id);
        }

        public IList<OfferStatusDto> GetAllOfferStatuses()
        {
            return this.Context.Lookups.GetAllOfferStatuses();
        }

        /// <summary>
        /// Get all Offices.
        /// </summary>
        /// <returns>A collection of OfficeDto</returns>
        public IList<OfficeDto> GetAllOffices()
        {
            return this.Context.Lookups.GetAllOffices();
        }

        public async Task<OfficeDto> GetOfficeByIdAsync(int id)
        {
            return await this.Context.Lookups.GetOfficeByIdAsync(id);
        }

        public async Task UpdateOfficeAsync(OfficeDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.Lookups.UpdateOfficeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<ProgramDto> GetAllPrograms()
        {
            return this.Context.Lookups.GetAllPrograms();
        }

        public IList<LookupDto> GetAllCommissionPrograms()
        {
            return this.Context.Lookups.GetAllCommissionPrograms();
        }

        /// <summary>
        /// Gets all active contact types
        /// </summary>
        /// <returns>A collection of ContactTypeDtos.</returns>
        public IList<ContactTypeDto> GetContactTypes()
        {
            return this.Context.Lookups.GetContactTypes();
        }

        /// <summary>
        /// Gets active contact methods
        /// </summary>
        /// <returns>A collection of PreferredContactMethodDto.</returns>
        public IList<PreferredContactMethodDto> GetPreferredContactMethods()
        {
            return this.Context.Lookups.GetPreferredContactMethods();
        }

        /// <summary>
        /// Gets active phone number types.
        /// </summary>
        /// <returns>A collection of PhoneNumberTypeDto.</returns>
        public IList<PhoneNumberTypeDto> GetPhoneNumberTypes()
        {
            return this.Context.Lookups.GetPhoneNumberTypes();
        }

        public IList<WebLinkTypeDto> GetWebLinkTypes()
        {
            return this.Context.Lookups.GetWebLinkTypes();
        }

        public IList<WebLinkTypeDto> GetAllWebLinkTypes(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetAllWebLinkTypes(includeDeleted);
        }

        public async Task CreateWebLinkTypeAsync(WebLinkTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateWebLinkTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateWebLinkTypeAsync(WebLinkTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateWebLinkTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteWebLinkTypeAsync(WebLinkTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteWebLinkTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        /// <summary>
        /// Gets active document types.
        /// </summary>
        /// <returns>A collection of DocumentTypeDto.</returns>
        public IList<DocumentTypeDto> GetDocumentTypes()
        {
            return this.Context.Lookups.GetDocumentTypes();
        }

        public IList<DocumentTypeDto> GetAllDocumentTypes(bool includeDeleted = false)
        {
            return this.Context.Lookups.GetAllDocumentTypes(includeDeleted);
        }

        public async Task CreateDocumentTypeAsync(DocumentTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateDocumentTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateDocumentTypeAsync(DocumentTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateDocumentTypeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteDocumentTypeAsync(DocumentTypeDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteDocumentTypeAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<DocumentExtensionDto> GetDocumentExtensions()
        {
            return this.Context.Lookups.GetDocumentExtensions();
        }

        /// <summary>
        /// Gets the zip code geography.
        /// </summary>
        /// <param name="zipCode">The zip code.</param>
        /// <returns>A Zip Code Geography if found.</returns>
        public Task<ZipCodeGeographyDto> GetZipCodeGeographyAsync(string zipCode)
        {
            return this.Context.Lookups.GetZipCodeGeographyAsync(zipCode);
        }

        /// <summary>
        /// Gets the application event type asynchronous.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>An App Event Type if found.</returns>
        public Task<LookupDto> GetAppEventTypeAsync(AppEventType type)
        {
            return this.Context.Lookups.GetAppEventTypeAsync(type);
        }

        public IList<TicketTypeDto> GetAllTicketTypes()
        {
            return this.Context.Lookups.GetAllTicketTypes();
        }

        public IList<EventTicketTypeDto> GetEventTicketTypes()
        {
            return this.Context.Lookups.GetEventTicketTypes();
        }

        public IList<OfferTicketTypeDto> GetOfferTicketTypes()
        {
            return this.Context.Lookups.GetOfferTicketTypes();
        }

        public IList<OfferRateTypeDto> GetOfferRateTypes()
        {
            return this.Context.Lookups.GetOfferRateTypes();
        }

        public IList<LineOfBusinessDto> GetLinesOfBusiness()
        {
            return this.Context.Lookups.GetLinesOfBusiness();
        }

        public IList<LeadSourceDto> GetLeadSources()
        {
            return this.Context.Lookups.GetLeadSources();
        }

        public IList<ContractDueFromDto> GetContractsDueFrom()
        {
            return this.Context.Lookups.GetContractsDueFrom();
        }

        public IList<ContractStatusDto> GetContractStatuses()
        {
            return this.Context.Lookups.GetContractStatuses();
        }

        public IList<TimeZoneDto> GetAllTimeZones()
        {
            return this.Context.Lookups.GetAllTimeZones();
        }

        public IList<ContractTypeDto> GetContractTypes()
        {
            return this.Context.Lookups.GetContractTypes();
        }

        public IList<SalesTaxTypeDto> GetAllSalesTaxTypes()
        {
            return this.Context.Lookups.GetAllSalesTaxTypes();
        }

        public IList<LookupDto> GetAllContractEntityTypes()
        {
            return this.Context.Lookups.GetAllContractEntityTypes();
        }

        public IList<LookupDto> GetAllContractTransactionTypes()
        {
            return this.Context.Lookups.GetAllContractTransactionTypes();
        }

        public IList<LookupDto> GetAllPaymentMethods()
        {
            return this.Context.Lookups.GetAllPaymentMethods();
        }

        public IList<AppUserDto> GetAllAgents()
        {
            return this.Context.Users.GetUsersByRole((int)ECERole.Agent);
        }

        public IList<AppUserDto> GetAllActiveAgents()
        {
            return this.Context.Users.GetUsersByRole((int)ECERole.Agent, false);
        }

        public IList<LookupDto> GetAllExpenseBatchTypes()
        {
            return this.Context.Lookups.GetAllExpenseBatchTypes();
        }

        public IList<LookupDto> GetAllExpensePaymentTypes()
        {
            return this.Context.Lookups.GetAllExpensePaymentTypes();
        }

        public IList<LookupDto> GetAllContractTransactionExpenseTypes()
        {
            return this.Context.Lookups.GetAllContractTransactionExpenseTypes();
        }

        public IList<GenericRiderDto> GetGenericRiders()
        {
            return this.Context.Lookups.GetGenericRiders();
        }

        public async Task<IList<GenericRiderDto>> GetGenericRidersAsync()
        {
            return await this.Context.Lookups.GetGenericRidersAsync();
        }

        public async Task<IList<GenericRiderDto>> GetAllGenericRidersAsync(bool includeInactive)
        {
            return await this.Context.Lookups.GetAllGenericRidersAsync(includeInactive);
        }

        public async Task<IList<GenericRiderDto>> GetGenericRidersAsync(int eventTypeId)
        {
            var riders = await this.Context.Lookups.GetGenericRidersAsync();

            var results = riders.Where(x => x.EventTypeId == eventTypeId || x.EventTypeId == null).ToList();

            return results;
        }

        public IList<GenericRiderDto> GetGenericRidersByEventType(int eventTypeId)
        {
            return this.Context.Lookups.GetGenericRidersByEventType(eventTypeId);
        }

        public async Task<GenericRiderDto> GetGenericRiderAsync(int genericRiderId)
        {
            return await this.Context.Lookups.GetGenericRiderAsync(genericRiderId);
        }

        public async Task UpdateGenericRiderAsync(GenericRiderDto dto, DocumentDto document, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                if (document != null)
                {
                    _documentService.AddGenericRider(document, user);

                    dto.DocumentId = document.DocumentId;
                }

                await this.Context.Lookups.UpdateGenericRiderAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateGenericRiderAsync(GenericRiderDto dto, DocumentDto document, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                if (document != null)
                {
                    _documentService.AddGenericRider(document, user);

                    dto.DocumentId = document.DocumentId;
                }

                await this.Context.Lookups.CreateGenericRiderAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<LookupDto> GetAllLeadParticipantTypes()
        {
            return this.Context.Lookups.GetAllLeadParticipantTypes();
        }

        public IList<LeadSourceDto> GetAllLeadSubmissionSources()
        {
            return this.Context.Lookups.GetAllLeadSubmissionSources();
        }

        public IList<LookupDto> GetArtistChargeStatuses()
        {
            return this.Context.Lookups.GetArtistChargeStatuses();
        }

        public IList<LookupDto> GetArtistChargeTypes()
        {
            return this.Context.Lookups.GetArtistChargeTypes();
        }

        public IList<LookupDto> GetArtistChargeTransactionTypes()
        {
            return this.Context.Lookups.GetArtistChargeTransactionTypes();
        }

        public IList<LookupDto> GetInterestCalculatedFrequencies()
        {
            return this.Context.Lookups.GetInterestCalculatedFrequencies();
        }

        public IList<LookupDto> GetAllRoles()
        {
            return this.Context.Lookups.GetAllRoles();
        }

        public IList<ContractWizardStepDto> GetContractWizardSteps()
        {
            return new List<ContractWizardStepDto>
                       {
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 1,
                                   ContractWizardStepId = 1,
                                   NavigationIndex = 0,
                                   PageTitle =
                                       "Contract / Event Info",
                                   UpdatedBy = string.Empty,
                                   ViewName = "EventInfo"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 2,
                                   ContractWizardStepId = 3,
                                   NavigationIndex = 0,
                                   PageTitle =
                                       "Contract / Event Info",
                                   UpdatedBy = string.Empty,
                                   ViewName = "EventInfo"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 1,
                                   ContractWizardStepId = 2,
                                   NavigationIndex = 1,
                                   PageTitle = "Presenter",
                                   UpdatedBy = string.Empty,
                                   ViewName = "Presenter"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 2,
                                   ContractWizardStepId = 4,
                                   NavigationIndex = 1,
                                   PageTitle = "Presenter",
                                   UpdatedBy = string.Empty,
                                   ViewName = "Presenter"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 1,
                                   ContractWizardStepId = 5,
                                   NavigationIndex = 2,
                                   PageTitle = "Venue Information",
                                   UpdatedBy = string.Empty,
                                   ViewName = "Venue"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 2,
                                   ContractWizardStepId = 6,
                                   NavigationIndex = 2,
                                   PageTitle = "Venue Information",
                                   UpdatedBy = string.Empty,
                                   ViewName = "Venue"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 1,
                                   ContractWizardStepId = 7,
                                   NavigationIndex = 3,
                                   PageTitle = "Artist",
                                   UpdatedBy = string.Empty,
                                   ViewName = "StandardArtist"
                               },
                           new ContractWizardStepDto
                               {
                                   CreatedDate = DateTime.Now,
                                   CreatedById = 0,
                                   UpdatedById = null,
                                   UpdatedDate = null,
                                   CreatedBy = string.Empty,
                                   ContractTypeId = 2,
                                   ContractWizardStepId = 8,
                                   NavigationIndex = 3,
                                   PageTitle = "Artists",
                                   UpdatedBy = string.Empty,
                                   ViewName = "SpecialArtistInfo"
                               },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 2,
                               ContractWizardStepId = 9,
                               NavigationIndex = 4,
                               PageTitle = "Artist Events",
                               UpdatedBy = string.Empty,
                               ViewName = "SpecialArtistEventInfo"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 1,
                               ContractWizardStepId = 10,
                               NavigationIndex = 4,
                               PageTitle = "Standard Money",
                               UpdatedBy = string.Empty,
                               ViewName = "StandardMoney"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 2,
                               ContractWizardStepId = 11,
                               NavigationIndex = 5,
                               PageTitle = "Special Money",
                               UpdatedBy = string.Empty,
                               ViewName = "SpecialMoney"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 1,
                               ContractWizardStepId = 12,
                               NavigationIndex = 5,
                               PageTitle = "Terms and Riders",
                               UpdatedBy = string.Empty,
                               ViewName = "TermsAndRiders"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 2,
                               ContractWizardStepId = 13,
                               NavigationIndex = 6,
                               PageTitle = "Terms and Riders",
                               UpdatedBy = string.Empty,
                               ViewName = "TermsAndRiders"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 1,
                               ContractWizardStepId = 13,
                               NavigationIndex = 6,
                               PageTitle = "Review",
                               UpdatedBy = string.Empty,
                               ViewName = "Review"
                           },
                           new ContractWizardStepDto
                           {
                               CreatedDate = DateTime.Now,
                               CreatedById = 0,
                               UpdatedById = null,
                               UpdatedDate = null,
                               CreatedBy = string.Empty,
                               ContractTypeId = 2,
                               ContractWizardStepId = 14,
                               NavigationIndex = 7,
                               PageTitle = "Review",
                               UpdatedBy = string.Empty,
                               ViewName = "Review"
                           }
                       };
        }

        public IList<LookupDto> GetAllGeneralLedgerEvents()
        {
            return this.Context.Lookups.GetAllGeneralLedgerEvents();
        }

        public IList<LookupDto> GetAllGeneralLedgerAccounts()
        {
            return this.Context.Lookups.GetAllGeneralLedgerAccounts();
        }

        public IList<LookupDto> GetActiveGeneralLedgerAccounts()
        {
            return this.Context.Lookups.GetActiveGeneralLedgerAccounts();
        }

        public IList<EventTimeReasonDto> GetAllEventTimeReasons()
        {
            return this.Context.Lookups.GetAllEventTimeReasons();
        }

        public IList<PayrollLogTypeDto> GetAllPayrollLogTypes()
        {
            return this.Context.Lookups.GetAllPayrollLogTypes();
        }

        /// <summary>
        ///Tires Master
        /// </summary>
        /// <returns>A collection of DocumentTypeDto.</returns>
        //public IList<TiersMasterDto> GetTiersMasters()
        //{
        //    return this.Context.TiersMaster.GetTiersMasters();
        //}

        public IList<TiersMasterDto> GetAllTiersMasters(bool includeDeleted = false)
        {
            return this.Context.TiersMaster.GetTiersMasters(includeDeleted);
        }

        public async Task<TiersMasterValidateDto> GetValidTiersMaster()
        {
            return await this.Context.TiersMaster.GetValidTiersMaster();
        }

        public async Task CreateTiersMasterAsync(TiersMasterDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.TiersMaster.CreateTiersMasterAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateTiersMasterAsync(TiersMasterDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.TiersMaster.UpdateTiersMasterAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteTiersMasterAsync(TiersMasterDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.TiersMaster.DeleteTiersMasterAsync(dto);

                this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
        public IList<DashboardDto> GetAllDashboard(bool includeDeleted)
        {
            return this.Context.Lookups.GetAllDashboard(includeDeleted);
        }

        public async Task CreateDashboardAsync(DashboardDto dto, IPrincipal principal)
        {
            //this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateDashboardAsync(dto, principal);

                //this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateDashboardAsync(DashboardDto dto, IPrincipal principal)
        {
            //this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateDashboardAsync(dto, principal);

                //this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<bool> DeleteDashboardAsync(DashboardDto dto)
        {
            //this.Context.BeginTransaction();

            try
            {
                var result = await this.Context.Lookups.DeleteDashboardAsync(dto);

                //this.Context.Commit();

                return result;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public IList<BIDashboardDto> GetAllBIDashboard(bool includeDeleted)
        {
            return this.Context.Lookups.GetAllBIDashboard(includeDeleted);
        }

        public Task<(string, string)> CreateBIDashboardAsync(BIDashboardDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.CreateBIDashboardAsync(dto, principal);
        }
        public Task<(string, string)> UpdateBIDashboardAsync(BIDashboardDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.UpdateBIDashboardAsync(dto, principal);
        }
        public Task<(string, string)> DeleteBIDashboardAsync(BIDashboardDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.DeleteBIDashboardAsync(dto, principal);
        }

        public IList<FeatureFlagDto> GetAllFeatureFlag(bool includeDeleted)
        {
            return this.Context.Lookups.GetAllFeatureFlag(includeDeleted);
        }
        public Task<(string, string)> CreateFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.CreateFeatureFlagAsync(dto, principal);
        }
        public Task<(string, string)> UpdateFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.UpdateFeatureFlagAsync(dto, principal);
        }
        public Task<(string, string)> DeleteFeatureFlagAsync(FeatureFlagDto dto, IPrincipal principal)
        {
            return this.Context.Lookups.DeleteFeatureFlagAsync(dto, principal);
        }

        public IList<FeatureFlagAndUserDto> GetAllFeatureAndUserFlags()
        {
            return this.Context.Lookups.GetAllFeatureAndUserFlags();
        }

        public async Task<UsersFeatureFlagDto> GetAllUsersFeatureFlag()
        {
            return await this.Context.Lookups.GetAllUsersFeatureFlag();
        }

        public async Task<UsersFeatureFlagWiseDto> GetAllUsersFeatureFlagWise(int id)
        {
            return await this.Context.Lookups.GetAllUsersFeatureFlagWise(id);
        }

        public async Task<List<LuKeyTypeDto>> GetAllLuKeyTypes()
        {
            return await this.Context.Lookups.GetAllLuKeyTypes();
        }

        public  IList<OfficeDto> GetRestrictedOffices()
        {
            return  this.Context.Lookups.GetRestrictedOffices();
        }

        public async Task<IList<MainTermsandConditionDto>> GetMainTermsandCondition(bool includeDeleted = false)
        {
            return await this.Context.Lookups.GetMainTermsandCondition(includeDeleted);
        }

        public async Task CreateMainTermsandConditionAsync(MainTermsandConditionDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreateMainTermsandConditionAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

        }
        public async Task UpdateMainTermsandConditionAsync(MainTermsandConditionDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdateMainTermsandConditionAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
        public async Task<bool> DeleteMainTermsandConditionAsync(MainTermsandConditionDto dto)
        {


            try
            {
                return await this.Context.Lookups.DeleteMainTermsandConditionAsync(dto);
            }
            catch (Exception ex)
            {
                throw new UnhandledBusinessException(ex);
            }
        }




        public async Task<IList<PandaDocTemplateDto>> GetPandaDocTemplate(bool includeDeleted = false)
        {
            return await this.Context.Lookups.GetPandaDocTemplate(includeDeleted);
        }

        public async Task CreatePandaDocTemplateAsync(PandaDocTemplateDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.CreatePandaDocTemplateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

        }
        public async Task UpdatePandaDocTemplateAsync(PandaDocTemplateDto dto)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Lookups.UpdatePandaDocTemplateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
        public async Task<bool> DeletePandaDocTemplateAsync(PandaDocTemplateDto dto)
        {


            try
            {
                return await this.Context.Lookups.DeletePandaDocTemplateAsync(dto);
            }
            catch (Exception ex)
            {
                throw new UnhandledBusinessException(ex);
            }
        }

    }
}
