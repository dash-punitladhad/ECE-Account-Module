﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class CheckbookService : ICheckbookService
    {
        private readonly IUserService _userService;
        private readonly IExpenseBatchService _expenseBatchService;
        private readonly IContractTransactionService _contractTransactionService;
        private readonly IGeneralLedgerService _generalLedgerService;
        private readonly IPresenterService _presenterService;
        private readonly IArtistService _artistService;
        private readonly IResellerService _resellerService;
        private readonly IVendorService _vendorService;
        private readonly ILookupService _lookupService;
        private readonly ICheckGenerationService _checkGenerationService;
        private readonly IContractDepositService _contractDepositService;

        public CheckbookService(IUnitOfWork context,
                                IUserService userService,
                                IExpenseBatchService expenseBatchService,
                                IContractTransactionService contractTransactionService,
                                IGeneralLedgerService generalLedgerService,
                                IPresenterService presenterService,
                                IArtistService artistService,
                                IResellerService resellerService,
                                IVendorService vendorService,
                                ILookupService lookupService,
                                IContractDepositService contractDepositService,
                                ICheckGenerationService checkGenerationService)
        {
            this.Context = context;
            this._userService = userService;
            this._expenseBatchService = expenseBatchService;
            this._contractTransactionService = contractTransactionService;
            this._generalLedgerService = generalLedgerService;
            this._presenterService = presenterService;
            this._artistService = artistService;
            this._resellerService = resellerService;
            this._vendorService = vendorService;
            this._lookupService = lookupService;
            this._contractDepositService = contractDepositService;
            this._checkGenerationService = checkGenerationService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<CheckSearchResultDto>> GetChecksByCriteriaAsync(CheckSearchCriteriaDto dto)
        {
            return await this.Context.Checkbooks.GetChecksByCriteriaAsync(dto);
        }

        public async Task<ReconciliationItemDto> GetReconciliationItemByIdAsync(int id)
        {
            return await this.Context.Checkbooks.GetReconciliationItemByIdAsync(id);
        }

        public async Task<ReconciliationItemDto> GetReconciliationItemByExpensePaymentIdAsync(int id)
        {
            return await this.Context.Checkbooks.GetReconciliationItemByExpensePaymentIdAsync(id);
        }

        public async Task<ReconciliationBatchDto> GetReconciliationBatchByIdAsync(int id)
        {
            return await this.Context.Checkbooks.GetReconciliationBatchByIdAsync(id);
        }

        public async Task<bool> GetIsReconciledByExpensePaymentIdAsync(int id)
        {
            return await this.Context.Checkbooks.GetIsReconciledByExpensePaymentIdAsync(id);
        }

        public async Task UpdateNotesAsync(int id, string notes)
        {
            try
            {
                this.Context.BeginTransaction();

                await this.Context.ExpensePayments.UpdateNotesAsync(id, notes);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task VoidExpenseAsync(ContractTransactionDto expense, bool recreateExpense, IPrincipal user)
        {
            var voidedExpense = AutoMapper.Mapper.Map<ContractTransactionDto>(expense);
            voidedExpense.ContractTransactionId = 0;

            voidedExpense.CanRelease = false;
            voidedExpense.RequiredAmount = -voidedExpense.RequiredAmount;
            voidedExpense.PaidAmount = -voidedExpense.PaidAmount;
            voidedExpense.ReferenceNumber = $"V{expense.ReferenceNumber}";
            voidedExpense.ExpensePaymentId = null;
            voidedExpense.ExpensePayment = null;
            voidedExpense.ExpensePaymentStatusId = null;
            voidedExpense.UpdatedById = null;
            voidedExpense.UpdatedDate = null;

            await this._contractTransactionService.CreateAsync(voidedExpense, user);

            // Find all the original GL activity
            var glActivity = await this._generalLedgerService.GetJournalActivityByContractTransactionIdAsync(expense.ContractTransactionId);

            var glEvents = glActivity.GroupBy(x => new { x.GeneralLedgerEventId, x.JournalTransactionNumber, x.ContractTransactionId, x.PostedAmount }, (key, g) => new { GeneralLedgerEventId = key.GeneralLedgerEventId, JournalTransactionNumber = key.JournalTransactionNumber, ContractTransactionId = key.ContractTransactionId, PostedAmount = key.PostedAmount });

            foreach (var glEvent in glEvents)
            {
                List<GeneralLedgerTransactionTypeDto> generalLedgerTransactionTypes;

                var generalLedgerEvent = (GeneralLedgerEvent)glEvent.GeneralLedgerEventId;

                var reversedEvent = this._generalLedgerService.GetReversedGlEvent(generalLedgerEvent);
                if (reversedEvent == GeneralLedgerEvent.Unknown)
                {
                    // Create a list of reverse transaction types.
                    generalLedgerTransactionTypes = new List<GeneralLedgerTransactionTypeDto>();

                    var originalTransactionTypes = await this.Context.GeneralLedgerTransactionTypes.GetTransactionTypesByEventIdAsync((int)generalLedgerEvent, expense.ContractEntityTypeId);
                    foreach (var originalTransactionType in originalTransactionTypes)
                    {
                        generalLedgerTransactionTypes.Add(originalTransactionType.Reverse());
                    }
                }
                else
                {
                    // Use the list of transaction types for the reverse event.
                    generalLedgerTransactionTypes = await this.Context.GeneralLedgerTransactionTypes.GetTransactionTypesByEventIdAsync((int)reversedEvent, expense.ContractEntityTypeId);
                }

                // Reverse all the GL activity from the original expense on the voided expense.
                await this._generalLedgerService.CreateGeneralLedgerJournalEntryAsync(generalLedgerTransactionTypes, glEvent.PostedAmount, voidedExpense, user);
            }

            if (recreateExpense)
            {
                // Create a replacement transaction to re-pay the expense
                var replacementExpense = AutoMapper.Mapper.Map<ContractTransactionDto>(expense);
                replacementExpense.ContractTransactionId = 0;

                replacementExpense.CanRelease = true;
                replacementExpense.PaidDate = null;
                replacementExpense.PaidAmount = decimal.Zero;
                replacementExpense.ReferenceNumber = null;
                replacementExpense.ExpensePaymentId = null;
                replacementExpense.ExpensePayment = null;
                replacementExpense.ExpensePaymentStatusId = null;
                replacementExpense.UpdatedById = null;
                replacementExpense.UpdatedDate = null;

                await this._contractTransactionService.CreateAsync(replacementExpense, user);
            }
        }

        public async Task VoidLoanRepaymentAsync(ArtistChargeTransactionDto repayment, IPrincipal user)
        {
            var artistCharge = await this.Context.ArtistCharges.GetByIdAsync(repayment.ArtistChargeId);

            // Create an adjustment for the voided amount
            var artistChargeTransaction = new ArtistChargeTransactionDto()
            {
                ArtistChargeId = artistCharge.ArtistChargeId,
                ArtistChargeTransactionTypeId = (int)ArtistChargeTransactionType.Adjustment,
                TransactionDate = DateTime.Now,
                TransactionAmount = -repayment.TransactionAmount,
                ExpensePaymentId = null
            };

            artistChargeTransaction.SetAsCreated(user);

            await this.Context.ArtistCharges.CreateArtistChargeTransactionAsync(artistChargeTransaction);

            // Increase the remaining balance by the amount being voided.
            artistCharge.RemainingBalance = artistCharge.RemainingBalance.GetHashCode() + repayment.TransactionAmount;
            artistCharge.LastPaymentDate = DateTime.Now;
            artistCharge.SetAsUpdated(user);

            await this.Context.ArtistCharges.UpdateArtistChargeAsync(artistCharge);
        }

        public async Task VoidCrossDeductionDepositAsync(ContractDepositDto crossDeductionDeposit, IPrincipal user)
        {
            await this._contractDepositService.UnpostContractDepositAsync(crossDeductionDeposit.ContractDepositId, user);
        }

        public async Task VoidCheckAsync(VoidCheckDto voidCheck, IPrincipal user)
        {
            var id = voidCheck.ExpensePaymentId;
            var reason = voidCheck.VoidedReason;

            this.Context.BeginTransaction();

            // * Mark the ExpensePayment as voided
            // * Void the payments for each associated expense transactions – which will make the expenses available in the next payment batch.
            // * Reverse GL entries caused by moving the funds for all transactions, loan repayments, and income cross deductions originally satisfied by the check.
            try
            {
                var checkExpensePayment = await this._expenseBatchService.GetExpensePaymentByIdAsync(id);
                if (checkExpensePayment == null)
                {
                    throw new Exception($"Check {id} not found.");
                }

                checkExpensePayment.DateVoided = DateTime.Now;
                checkExpensePayment.Notes = checkExpensePayment.Notes.AppendLine("Voided Reason: " + reason);

                await this._expenseBatchService.UpdateExpensePaymentAsync(checkExpensePayment, user);

                var expenses = await this._contractTransactionService.GetByExpensePaymentIdAsync(id);

                foreach (var expense in expenses)
                {
                    var recreateExpense = voidCheck.SelectedExpenses.Contains(expense.ContractTransactionId);

                    await this.VoidExpenseAsync(expense, recreateExpense, user);
                }

                var repayments = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(id);

                foreach (var repayment in repayments)
                {
                    await this.VoidLoanRepaymentAsync(repayment, user);
                }

                var crossDeductionDeposits = await this.Context.ContractDeposits.GetCrossDeductionsAsync(id);

                foreach (var crossDeductionDeposit in crossDeductionDeposits)
                {
                    await this.VoidCrossDeductionDepositAsync(crossDeductionDeposit, user);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ReconciliationBatchDto> GetExistingReconciliationBatchAsync(IPrincipal user, bool includeItems = true)
        {
            var newBatch = new ReconciliationBatchDto();

            var existingBatch = await this.Context.Checkbooks.GetInProgressReconciliationBatchAsync(includeItems);

            if (existingBatch == null)
            {
                newBatch.Description = $"SunTrust Reconciliation {DateTime.Now.ToString("MM/dd/yyyy (ddd)")}";

                newBatch.SetAsCreated(user);

                try
                {
                    this.Context.BeginTransaction();

                    await this.Context.Checkbooks.CreateReconciliationBatchAsync(newBatch);

                    this.Context.Commit();
                }
                catch (Exception ex)
                {
                    this.Context.Rollback();
                    throw new UnhandledBusinessException(ex);
                }
            }
            else
            {
                newBatch = existingBatch;
            }

            return newBatch;
        }

        public async Task<ReconciliationBatchDto> CreateReconciliationBatchAsync(IPrincipal user)
        {
            var newBatch = new ReconciliationBatchDto();

            newBatch.Description = $"Single Check Batch {DateTime.Now.ToString("MM/dd/yyyy (ddd)")}";

            newBatch.SetAsCreated(user);

            try
            {
                this.Context.BeginTransaction();

                await this.Context.Checkbooks.CreateReconciliationBatchAsync(newBatch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return newBatch;
        }

        public async Task CreateReconciliationItemsAsync(int reconciliationBatchId, IList<ReconciliationItemDto> items, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var batch = await this.Context.Checkbooks.GetReconciliationBatchByIdAsync(reconciliationBatchId);
                if (batch == null)
                {
                    throw new ArgumentException($"Reconciliation Batch {reconciliationBatchId} not found");
                }

                foreach (var dto in items.Where(x => x != null))
                {
                    var existingItem = batch.ReconciliationItems
                        .FirstOrDefault(x => x.ReferenceNumber == dto.ReferenceNumber
                            && x.PaymentAmount == dto.PaymentAmount
                            && x.IsDeleted == false);

                    if (existingItem == null)
                    {
                        dto.ReconciliationBatchId = reconciliationBatchId;
                        dto.ExpensePaymentId = null;
                        dto.IsDeleted = false;
                        dto.SetAsCreated(user);

                        // search for matching ExpensePayment
                        var expensePayment = await this._expenseBatchService.GetExpensePaymentByReferenceNumberAsync(dto.ReferenceNumber);
                        if (expensePayment != null)
                        {
                            dto.ExpensePaymentId = expensePayment.ExpensePaymentId;
                        }

                        await this.Context.Checkbooks.CreateReconciliationItemAsync(dto);
                    }
                }

                await this.UpdateBatchDetailsAsync(reconciliationBatchId, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateReconciliationItemAsync(int reconciliationBatchId, ReconciliationItemDto item, IPrincipal user)
        {
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            var items = new List<ReconciliationItemDto> { item };

            await this.CreateReconciliationItemsAsync(reconciliationBatchId, items, user);
        }

        public async Task ReconcileCheckAsync(ExpensePaymentDto check, IPrincipal user)
        {
            if (check == null)
            {
                throw new ArgumentNullException(nameof(check));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var existingItem = await this.GetReconciliationItemByExpensePaymentIdAsync(check.ExpensePaymentId);

                if (existingItem != null)
                {
                    var existingBatch = await this.GetReconciliationBatchByIdAsync(existingItem.ReconciliationBatchId);
                    if (existingBatch.DateReconciled == null)
                    {
                        // remove it from that batch
                        existingItem.IsDeleted = true;
                        existingItem.SetAsUpdated(user);

                        await this.Context.Checkbooks.UpdateReconciliationItemAsync(existingItem);

                        await this.UpdateBatchDetailsAsync(existingItem.ReconciliationBatchId, user);
                    }
                }

                // create a reconciliation batch for just this check
                var batch = await this.CreateReconciliationBatchAsync(user);

                // add the check to the batch
                var item = new ReconciliationItemDto()
                {
                    ReconciliationBatchId = batch.ReconciliationBatchId,
                    ReferenceNumber = check.ReferenceNumber,
                    PaymentAmount = check.PaymentAmount
                };

                await this.CreateReconciliationItemAsync(batch.ReconciliationBatchId, item, user);

                batch.ReconciliationItems = new List<ReconciliationItemDto> { item };

                // close the batch
                await this.CloseReconciliationBatchAsync(batch, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UnreconcileCheckAsync(ExpensePaymentDto check, IPrincipal user)
        {
            if (check == null)
            {
                throw new ArgumentNullException(nameof(check));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var item = await this.GetReconciliationItemByExpensePaymentIdAsync(check.ExpensePaymentId);

                await this.DeleteReconciliationItemAsync(item.ReconciliationItemId, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public bool HasReconciliationItemWarnings(IList<ReconciliationItemDto> reconciliationItems)
        {
            foreach (var item in reconciliationItems)
            {
                var warnings = this.GetReconciliationItemWarnings(item);
                if (warnings.Any())
                {
                    return true;
                }
            }

            return false;
        }

        public void SetReconciliationItemWarnings(IList<ReconciliationItemDto> reconciliationItems)
        {
            foreach (var item in reconciliationItems)
            {
                var warnings = this.GetReconciliationItemWarnings(item);
                if (warnings.Any())
                {
                    string warningMessage = string.Join(" ", warnings);
                    item.HasWarning = true;
                    item.WarningMessage = warningMessage;
                }
            }
        }

        public IList<string> GetReconciliationItemWarnings(ReconciliationItemDto reconciliationItem)
        {
            var warnings = new List<string>();

            var warning = string.Empty;

            if (reconciliationItem.ExpensePaymentId != null)
            {
                if (reconciliationItem.ExpensePayment.PaymentAmount != reconciliationItem.PaymentAmount)
                {
                    warning = "The check was found, but the reconciled amount is not equal to the check amount.";
                    if (!warnings.Contains(warning))
                    {
                        warnings.Add(warning);
                    }
                }

                if (reconciliationItem.ExpensePayment.DateCleared != null)
                {
                    warning = "The check was found by check number, but has already been marked as reconciled.";
                    if (!warnings.Contains(warning))
                    {
                        warnings.Add(warning);
                    }
                }

                if (reconciliationItem.ExpensePayment.DateVoided != null)
                {
                    warning = "The check was found by check number, but has been voided.";
                    if (!warnings.Contains(warning))
                    {
                        warnings.Add(warning);
                    }
                }
            }
            else
            {
                warning = "The check was not found by check number.";
                if (!warnings.Contains(warning))
                {
                    warnings.Add(warning);
                }
            }

            return warnings;
        }

        public async Task<IList<string>> CheckReconciliationItemForWarningAsync(int id)
        {
            var reconciliationItem = await this.Context.Checkbooks.GetReconciliationItemByIdAsync(id);

            return this.GetReconciliationItemWarnings(reconciliationItem);
        }

        public async Task DeleteReconciliationItemAsync(int id, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                var item = await this.GetReconciliationItemByIdAsync(id);

                if (item.ExpensePaymentId != null)
                {
                    var check = await this._expenseBatchService.GetExpensePaymentByIdAsync(item.ExpensePaymentId.Value);

                    check.DateCleared = null;

                    await this._expenseBatchService.UpdateExpensePaymentAsync(check, user);
                }

                item.IsDeleted = true;

                await this.Context.Checkbooks.UpdateReconciliationItemAsync(item);

                await this.UpdateBatchDetailsAsync(item.ReconciliationBatchId, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return;
        }

        public async Task DeleteAllReconciliationItemsAsync(IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                var existingBatch = await this.Context.Checkbooks.GetInProgressReconciliationBatchAsync(true);

                foreach (var item in existingBatch.ReconciliationItems)
                {
                    if (item.ExpensePaymentId != null)
                    {
                        var check = await this._expenseBatchService.GetExpensePaymentByIdAsync(item.ExpensePaymentId.Value);

                        check.DateCleared = null;

                        await this._expenseBatchService.UpdateExpensePaymentAsync(check, user);
                    }

                    item.IsDeleted = true;

                    await this.Context.Checkbooks.UpdateReconciliationItemAsync(item);
                }

                await this.UpdateBatchDetailsAsync(existingBatch.ReconciliationBatchId, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateBatchDetailsAsync(int id, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var batch = await this.GetReconciliationBatchByIdAsync(id);
                if (batch == null)
                {
                    throw new ArgumentException($"Reconciliation Batch {id} not found");
                }

                var totalAmount = batch.ReconciliationItems.Where(x => x.IsDeleted == false).Sum(x => x.PaymentAmount);
                var itemCount = batch.ReconciliationItems.Count(x => x.IsDeleted == false);

                batch.BatchAmount = totalAmount;
                batch.BatchCheckCount = itemCount;
                batch.ClearedAmount = totalAmount;
                batch.ClearedCheckCount = itemCount;
                batch.IsDeleted = itemCount == 0;
                batch.SetAsUpdated(user);

                await this.Context.Checkbooks.UpdateReconciliationBatchAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateReconciliationBatchAsync(ReconciliationBatchDto batch)
        {
            await this.Context.Checkbooks.UpdateReconciliationBatchAsync(batch);

            return;
        }

        public async Task CloseReconciliationBatchAsync(ReconciliationBatchDto batch, IPrincipal user)
        {
            if (batch == null)
            {
                throw new ArgumentNullException(nameof(batch));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var curDate = DateTime.Now;

                foreach (var check in batch.ReconciliationItems)
                {
                    var expensePayment = await this.Context.ExpensePayments.GetByIdAsync(check.ExpensePaymentId.Value);

                    // Mark all checks in the batch as reconciled
                    expensePayment.DateCleared = curDate;
                    expensePayment.SetAsUpdated(user);

                    await this.Context.ExpensePayments.UpdateAsync(expensePayment);

                    check.SetAsUpdated(user);

                    await this.Context.Checkbooks.UpdateReconciliationItemAsync(check);
                }

                batch.DateReconciled = curDate;
                batch.SetAsUpdated(user);

                await this.Context.Checkbooks.UpdateReconciliationBatchAsync(batch);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return;
        }

        public async Task<MemoryStream> PrintCheckAsync(ExpensePaymentDto check)
        {
            if (check == null)
            {
                throw new ArgumentNullException(nameof(check));
            }

            var transactions = await this._expenseBatchService.GetExpensePaymentTransactionsAsync(check.ExpensePaymentId);

            return await this._checkGenerationService.PrintCheckAsync(check, transactions);
        }
    }
}
