﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Logging;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    public class CheckGenerationService : ICheckGenerationService
    {
        private readonly ILookupService _lookupService;

        private IDictionary<int, StateDto> _states = null;

        private IDictionary<int, CountryDto> _countries = null;

        public CheckGenerationService(
            IUnitOfWork context,
            ILogger logger,
            ILookupService lookupService)
        {
            this.Context = context;
            this.Logger = logger;
            this._lookupService = lookupService;
        }

        public IUnitOfWork Context { get; private set; }

        public ILogger Logger { get; private set; }

        public async Task<MemoryStream> PrintCheckAsync(ExpensePaymentDto payment, IList<ContractTransactionDto> transactions)
        {
            var check = await this.GetCheckToPrint(payment, transactions);

            return AccountingFileGenerators.GenerateOneCheck(check);
        }

        public async Task<IList<CheckPrintDto>> GetChecksToPrint(IList<ExpensePaymentDto> payments, IList<ContractTransactionDto> batchTransactions)
        {
            var checks = new List<CheckPrintDto>();

            var firstPayment = payments.First();

            var contractCheckInfo = await this.Context.Contracts.GetBatchContractInfoAsync(firstPayment?.ExpenseBatchId ?? 0);

            Logger.LogDebug($"contractCheckInfo Count = {contractCheckInfo.Count}");

            var checkInfo = contractCheckInfo.ToDictionary(x => x.ContractId);

            foreach (var payment in payments.OrderBy(x => x.ReferenceNumber))
            {
                var transactions = batchTransactions
                    .Where(x => x.ExpensePaymentId == payment.ExpensePaymentId)
                    .ToList();

                var check = await this.GetCheckToPrint(payment, transactions, checkInfo);

                checks.Add(check);
            }

            return checks;
        }

        public async Task PopulateEntityDetailsAsync(ExpensePaymentDto payment, CheckPrintDto check)
        {
            if (_countries == null)
            {
                var results = await _lookupService.GetAllCountriesAsync();
                _countries = results.ToDictionary(x => x.CountryId);
            }

            switch ((ContractEntityType)payment.ContractEntityTypeId)
            {
                case ContractEntityType.Presenter:
                    check.EntityType = "Presenter";
                    check.EntityTypeId = (int)EntityType.Presenter;
                    check.EntityName = payment.PayeeName;

                    if (payment.Refund != null)
                    {
                        check.EntityMailingAddress1 = payment.Refund.MailingAddress1;
                        check.EntityMailingAddress2 = payment.Refund.MailingAddress2;
                        check.EntityMailingCity = payment.Refund.MailingCity;
                        check.EntityMailingStateId = payment.Refund.MailingStateId;
                        check.EntityMailingZip = payment.Refund.MailingZip;
                        check.EntityMailingCountryId = payment.Refund.MailingCountryId;
                        if (check.EntityMailingCountryId.HasValue &&
                            check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                        {
                            check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                        }

                        // TODO: Add Country ABBREVIATION
                        // AND MAKE STATE LOOKUP MORE EFFICEINT
                        check.EntityCityStateZip = await GetCityStateZipAsync(payment.Refund.MailingCity, payment.Refund.MailingStateId, payment.Refund.MailingZip);
                    }
                    else
                    {
                        var presenter = await this.Context.Presenters.GetByIdAsync(payment.ContractEntityId);
                        check.EntityMailingAddress1 = presenter.MailingAddress1;
                        check.EntityMailingAddress2 = presenter.MailingAddress2;
                        check.EntityMailingCity = presenter.MailingCity;
                        check.EntityMailingStateId = presenter.MailingStateId;
                        check.EntityMailingZip = presenter.MailingZip;
                        check.EntityMailingCountryId = presenter.MailingCountryId;
                        if (check.EntityMailingCountryId.HasValue &&
                            check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                        {
                            check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                        }

                        check.EntityCityStateZip = await GetCityStateZipAsync(presenter.MailingCity, presenter.MailingStateId, presenter.MailingZip);
                    }

                    break;
                case ContractEntityType.Artist:
                    check.EntityType = "Artist";
                    check.EntityTypeId = (int)EntityType.Artist;
                    var artist = await this.Context.Artists.GetByIdAsync(payment.ContractEntityId);
                    check.EntityName = artist.Name;
                    check.EntityMailingAddress1 = artist.MailingAddress1;
                    check.EntityMailingAddress2 = artist.MailingAddress2;
                    check.EntityMailingCity = artist.MailingCity;
                    check.EntityMailingStateId = artist.MailingStateId;
                    check.EntityMailingZip = artist.MailingZip;
                    check.EntityMailingCountryId = artist.MailingCountryId;
                    if (check.EntityMailingCountryId.HasValue &&
                        check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                    {
                        check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                    }

                    check.EntityCityStateZip = await GetCityStateZipAsync(artist.MailingCity, artist.MailingStateId, artist.MailingZip);
                    break;
                case ContractEntityType.Reseller:
                    check.EntityType = "Reseller";
                    check.EntityTypeId = (int)EntityType.Reseller;
                    var reseller = await this.Context.Resellers.GetByIdAsync(payment.ContractEntityId);
                    check.EntityName = reseller.Name;
                    check.EntityMailingAddress1 = reseller.MailingAddress1;
                    check.EntityMailingAddress2 = reseller.MailingAddress2;
                    check.EntityMailingCity = reseller.MailingCity;
                    check.EntityMailingStateId = reseller.MailingStateId;
                    check.EntityMailingZip = reseller.MailingZip;
                    check.EntityMailingCountryId = reseller.MailingCountryId;
                    if (check.EntityMailingCountryId.HasValue &&
                        check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                    {
                        check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                    }

                    check.EntityCityStateZip = await GetCityStateZipAsync(reseller.MailingCity, reseller.MailingStateId, reseller.MailingZip);
                    break;
                case ContractEntityType.ECE:
                    check.EntityType = "ECE";

                    // Nick picked Richmond as the default office
                    var eceOffice = await this._lookupService.GetOfficeByIdAsync((int)ECEOffice.Richmond);
                    check.EntityName = "EastCoast Entertainment";
                    check.EntityMailingAddress1 = eceOffice.MailingAddress1;
                    check.EntityMailingAddress2 = eceOffice.MailingAddress2;
                    check.EntityMailingCity = eceOffice.MailingCity;
                    check.EntityMailingStateId = eceOffice.MailingStateId;
                    check.EntityMailingZip = eceOffice.MailingZip;
                    check.EntityMailingCountryId = eceOffice.MailingCountryId;
                    if (check.EntityMailingCountryId.HasValue &&
                        check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                    {
                        check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                    }

                    check.EntityCityStateZip = await GetCityStateZipAsync(eceOffice.MailingCity, eceOffice.MailingStateId, eceOffice.MailingZip);
                    break;
                case ContractEntityType.Vendor:
                    check.EntityType = "Vendor";
                    check.EntityTypeId = (int)EntityType.Vendor;
                    var vendor = await this.Context.Vendors.GetByIdAsync(payment.ContractEntityId);
                    check.EntityName = vendor.Name;
                    check.EntityMailingAddress1 = vendor.MailingAddress1;
                    check.EntityMailingAddress2 = vendor.MailingAddress2;
                    check.EntityMailingCity = vendor.MailingCity;
                    check.EntityMailingStateId = vendor.MailingStateId;
                    check.EntityMailingZip = vendor.MailingZip;
                    check.EntityMailingCountryId = vendor.MailingCountryId;
                    if (check.EntityMailingCountryId.HasValue &&
                        check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                    {
                        check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                    }

                    check.EntityCityStateZip = await GetCityStateZipAsync(vendor.MailingCity, vendor.MailingStateId, vendor.MailingZip);
                    break;
                case ContractEntityType.Other:
                    check.EntityType = "Other";

                    // Nick picked Richmond as the default office
                    var other = await this._lookupService.GetOfficeByIdAsync((int)ECEOffice.Richmond);
                    check.EntityName = "Other";
                    check.EntityMailingAddress1 = other.MailingAddress1;
                    check.EntityMailingAddress2 = other.MailingAddress2;
                    check.EntityMailingCity = other.MailingCity;
                    check.EntityMailingStateId = other.MailingStateId;
                    check.EntityMailingZip = other.MailingZip;
                    check.EntityMailingCountryId = other.MailingCountryId;
                    if (check.EntityMailingCountryId.HasValue &&
                        check.EntityMailingCountryId.Value != ECEBusinessConstants.DefaultCountryId)
                    {
                        check.EntityMailingCountry = _countries[check.EntityMailingCountryId.Value].Abbreviation;
                    }

                    check.EntityCityStateZip = await GetCityStateZipAsync(other.MailingCity, other.MailingStateId, other.MailingZip);
                    break;
                default:
                    break;
            }
        }

        public async Task<CheckPrintDto> GetCheckToPrint(ExpensePaymentDto payment, IList<ContractTransactionDto> transactions, IDictionary<int, ContractCheckInfoDto> checkInfo = null)
        {
            CheckPrintDto check = new CheckPrintDto();

            check.CheckNumber = payment.ReferenceNumber;
            check.CheckDate = payment.DatePosted.Value;
            check.Amount = payment.PaymentAmount;
            check.PayeeName = payment.PayeeName;
            check.EntityId = payment.ContractEntityId;

            await PopulateEntityDetailsAsync(payment, check);

            foreach (var trans in transactions)
            {
                string contractId = string.Empty;
                var location = string.Empty;
                DateTime? playDate = null;
                string contractTransactionType = string.Empty;
                string agentFullName = trans.AgentFullName;

                if ((ContractEntityType)payment.ContractEntityTypeId == ContractEntityType.Artist)
                {
                    playDate = trans.DueDate;
                }

                contractId = trans.ContractId.ToString();

                if (trans.ContractTransactionTypeId == (int)ContractTransactionType.LoanRepayment)
                {
                    contractId = check.CheckDate.ToString("MM/dd/yy");
                    location = trans.ContractTransactionTypeName;
                }
                else if (trans.ContractId > 0)
                {
                    var contract = trans.ParentContract;
                    if (contract == null && checkInfo != null && checkInfo.ContainsKey(trans.ContractId))
                    {
                        var contractCheckInfo = checkInfo[trans.ContractId];
                        contract = new ContractDto
                        {
                            VenuePhysicalCity = contractCheckInfo.VenuePhysicalCity,
                            VenuePhysicalStateId = contractCheckInfo.VenuePhysicalStateId,
                            Agent = new AppUserDto
                            {
                                FirstName = contractCheckInfo.AgentFirstName,
                                LastName = contractCheckInfo.AgentLastName
                            },
                        };
                    }

                    if (contract == null)
                    {
                        Logger.LogDebug($"Getting Contract {trans.ContractId}");
                        contract = await this.Context.Contracts.GetByIdAsync(trans.ContractId);
                    }

                    location = await GetCityStateZipAsync(contract.VenuePhysicalCity, contract.VenuePhysicalStateId, string.Empty);

                    // if it's not an AREF put the contract trans type desc in the 'bonus column'
                    contractTransactionType = trans.ContractTransactionTypeId != (int)ContractTransactionType.ArtistPayment
                        ? trans.ContractTransactionTypeName
                        : string.Empty;

                    if (string.IsNullOrWhiteSpace(agentFullName))
                    {
                        agentFullName = contract.Agent?.FullName;
                    }
                }

                var summaryRow = new CheckPrintSummaryDto()
                {
                    ContractId = contractId,
                    AgentName = agentFullName,
                    Location = location,
                    PlayDate = playDate,
                    Amount = trans.PaidAmount.Value,
                    ContractTransactionType = contractTransactionType
                };

                check.SummaryTable.Add(summaryRow);
            }

            return check;
        }

        private async Task<string> GetCityStateZipAsync(string city, int? stateId, string zip)
        {
            string stateAbbr = string.Empty;

            if (stateId != null)
            {
                if (_states == null)
                {
                    var results = await _lookupService.GetAllStatesAsync(null);
                    _states = results.ToDictionary(x => x.StateId);
                }

                var state = _states[stateId.Value];

                stateAbbr = state.Abbreviation;
            }

            string result = string.Empty;

            if (!string.IsNullOrEmpty(zip))
            {
                result = $"{city}, {stateAbbr}  {zip}";
            }
            else
            {
                result = $"{city}, {stateAbbr}";
            }

            return result;
        }
    }
}
