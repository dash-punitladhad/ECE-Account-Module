﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using Infinity.Mobius.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class MessageService : IMessageService
    {
        public MessageService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<int> CreateAsync(MessageDto dto, IPrincipal user)
        {
            var messageId = 0;

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                dto.SenderId = dto.CreatedById;
                dto.SentDate = dto.CreatedDate;

                // Generate the secret key.
                dto.SecretKey = SecurityHelper.GenerateSecretKey();

                messageId = await this.Context.Messages.CreateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return messageId;
        }

        public async Task<int> CreateAsync(MessageDto dto, int? carbonCopyId, IPrincipal user)
        {
            var messageId = 0;

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                dto.SenderId = dto.CreatedById;
                dto.SentDate = dto.CreatedDate;

                if (carbonCopyId.HasValue)
                {
                    var body = dto.Body;

                    var recipient = await this.Context.Users.GetByIdAsync(dto.RecipientId);
                    if (recipient == null)
                    {
                        throw new ArgumentException($"User not found for ID {dto.RecipientId}");
                    }

                    var carbonCopy = await this.Context.Users.GetByIdAsync(carbonCopyId.Value);
                    if (carbonCopy == null)
                    {
                        throw new ArgumentException($"User not found for ID {carbonCopyId.Value}");
                    }

                    // Let the recipient know the message was CC'd
                    dto.Body = $"{body} --(cc:{carbonCopy.FullName})";

                    // Generate the secret key.
                    dto.SecretKey = SecurityHelper.GenerateSecretKey();

                    this.RedirectContractProcessing(dto);

                    // Send the message to the recipient
                    messageId = await this.Context.Messages.CreateAsync(dto);

                    if (dto.RecipientId != carbonCopyId.Value)
                    {
                        // Send a copy to the carbon copy user.
                        dto.RecipientId = carbonCopyId.Value;
                        dto.Body = $"{body} --(cc:{recipient.FullName})";

                        // Generate the secret key.
                        dto.SecretKey = SecurityHelper.GenerateSecretKey();

                        this.RedirectContractProcessing(dto);

                        await this.Context.Messages.CreateAsync(dto);
                    }
                }
                else
                {
                    // Generate the secret key.
                    dto.SecretKey = SecurityHelper.GenerateSecretKey();

                    this.RedirectContractProcessing(dto);

                    // Send the message to the recipient
                    messageId = await this.Context.Messages.CreateAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return messageId;
        }

        public async Task<int> CreateAsync(MessageDto dto, List<int> carbonCopyId, IPrincipal user)
        {
            var messageId = 0;

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                dto.SenderId = dto.CreatedById;
                dto.SentDate = dto.CreatedDate;

                if (carbonCopyId != null && carbonCopyId.Count > 0)
                {
                    var body = dto.Body;

                    var recipient = await this.Context.Users.GetByIdAsync(dto.RecipientId);
                    if (recipient == null)
                    {
                        throw new ArgumentException($"User not found for ID {dto.RecipientId}");
                    }
                    var FullName = new List<string>();
                    foreach (var cc in carbonCopyId)
                    {
                        var carbonCopy =  await this.Context.Users.GetByIdAsync(cc);
                        if (carbonCopy == null)
                        {
                            throw new ArgumentException($"User not found for ID {cc}");
                        }
                        FullName.Add(carbonCopy.FullName);
                    }
                    // Let the recipient know the message was CC'd
                   
                    dto.Body = $"{body} --(cc:{string.Join(",",FullName)})";

                    // Generate the secret key.
                    dto.SecretKey = SecurityHelper.GenerateSecretKey();

                    this.RedirectContractProcessing(dto);

                    // Send the message to the recipient
                    messageId = await this.Context.Messages.CreateAsync(dto);
                    var reciepentId = dto.RecipientId;
                    foreach(var cc in carbonCopyId)
					{
                        if (reciepentId != cc)
                        {
                            dto.RecipientId = cc;
                            recipient = await this.Context.Users.GetByIdAsync(dto.RecipientId);
                            if (recipient == null)
                            {
                                throw new ArgumentException($"User not found for ID {dto.RecipientId}");
                            }
                            dto.Body = $"{body} --(cc:{recipient.FullName})";

                            // Generate the secret key.
                            dto.SecretKey = SecurityHelper.GenerateSecretKey();

                            this.RedirectContractProcessing(dto);

                            await this.Context.Messages.CreateAsync(dto);
                        }
                    }
                    
                }
                else
                {
                    // Generate the secret key.
                    dto.SecretKey = SecurityHelper.GenerateSecretKey();

                    this.RedirectContractProcessing(dto);

                    // Send the message to the recipient
                    messageId = await this.Context.Messages.CreateAsync(dto);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }

            return messageId;
        }

        public void RedirectContractProcessing(MessageDto dto)
        {
            const int originalRecipient = 159; // Contract Processing
            const int redirectedRecipient = 301; // Lydia Sanchez

            if (MobiusConfiguration.GetBoolean("Messages.RedirectContractProcessing", false))
            {
                if (dto.RecipientId == originalRecipient)
                {
                    dto.RecipientId = redirectedRecipient;
                }
            }
        }

        public async Task<List<MessageDto>> GetContractMessagesByUserId(int userId, bool unreadOnly)
        {
            var result = await this.Context.Messages.GetContractMessagesByUserIdAsync(userId, unreadOnly);

            return result;
        }

        public async Task<List<MessageDto>> GetContractMessageHistoryAsync(int contractId)
        {
            var result = await this.Context.Messages.GetContractMessageHistoryAsync(contractId);

            return result;
        }


        public async Task<MessageDto> GetByIdAsync(int id)
        {
            var result = await this.Context.Messages.GetByIdAsync(id);

            return result;
        }

        public async Task DeleteAsync(int id, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Messages.DeleteAsync(id, user.GetUserId());
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Error deleting Message", id, ex);
            }
        }

        public async Task MarkAsReadAsync(int id, IPrincipal user)
        {
            this.Context.BeginTransaction();

            try
            {
                await this.Context.Messages.MarkAsReadAsync(id, user.GetUserId());
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Error marking Message as read", id, ex);
            }
        }

        public async Task<IList<AppUserDto>> GetContractMessagesUsersAsync(int contractId)
        {
            var result = await this.Context.Messages.GetContractMessagesUsersAsync(contractId);

            return result;
        }

        public async Task<MessageDto> GetCarbonCopyAsync(MessageDto dto)
        {
            var messageKey = $"{dto.SenderId}-{dto.SentDate.Ticks}";

            int index = dto.Body.IndexOf("--(cc:");
            if (index >= 0)
            {
                var carbonCopy = await this.Context.Messages.GetCarbonCopyAsync(dto);
                if (carbonCopy != null)
                {
                    var nextMessageKey = $"{carbonCopy.SenderId}-{carbonCopy.SentDate.Ticks}";
                    if (nextMessageKey == messageKey)
                    {
                        return carbonCopy;
                    }
                }
            }

            return null;
        }



        public async Task<bool> CreateExclusiveArtistAsync(int artistId, IPrincipal user, bool isExclusive)
        {
            bool isValid = true;
            this.Context.BeginTransaction();
            if (artistId == 0)
            {
                isValid = false;
                return isValid;
            }
            try
            {
                var artist = await this.Context.Artists.GetByIdAsync(artistId);
                //if (artist != null)
                //{
                //    artist.IsExclusive = false;
                //    artist.ExclusiveStartDate = null;
                //    await this.Context.Artists.UpdateAsync(artist, false);
                //}

                string artistName = artist?.Name;
                try
                {
                    string sql = @"select * from AppUser with(nolock) where AppUserId in (
                            select AppUserId from AppUserRole with(nolock) where RoleId in (3, 6, 7, 9)) and IsActive = 1";

                    var dt = await DaoHelper.GetDataSet(sql);
                    foreach (DataRow dr in dt.Rows)
                    {
                        string body = artistName + " " + "is no longer an exclusive artist now.";
                        if (isExclusive)
                        {
                            body = artistName + " " + "is an exclusive artist now.";
                        }
                        MessageDto dto = new MessageDto()
                        {

                            Subject = "ARTIST STATUS UPDATE",
                            Body = body,
                            EntityTypeId = (int)EntityType.Artist,
                            EntityId = artistId,
                            IsDeleted = false,
                            RecipientId = Convert.ToInt32(dr["AppUserId"])
                        };
                        dto.SetAsCreated(user);

                        dto.SenderId = dto.CreatedById;
                        dto.SentDate = dto.CreatedDate;

                        // Generate the secret key.
                        dto.SecretKey = SecurityHelper.GenerateSecretKey();

                        await this.Context.Messages.CreateAsync(dto);

                    }
                    //// Add "change log" in artist
                    //var history = new EntityHistoryDto
                    //{
                    //    EntityId = artistId,
                    //    Type = EntityType.Artist,
                    //    Event = AuditEvent.ArtistExclusiveChanged,
                    //    Description = "Exclusive",
                    //    CreatedDate = DateTime.Now,
                    //    CreatedById = user.GetUserId()
                    //};

                    //await this.Context.EntityHistory.CreateAsync(history);

                    this.Context.Commit();
                }
                catch (Exception ex)
                {
                    this.Context.Rollback();
                    throw new UnhandledBusinessException(ex);
                }
            }
            catch
            {
                this.Context.Rollback();
                isValid = false;
            }
            return isValid;
        }
    }
}
