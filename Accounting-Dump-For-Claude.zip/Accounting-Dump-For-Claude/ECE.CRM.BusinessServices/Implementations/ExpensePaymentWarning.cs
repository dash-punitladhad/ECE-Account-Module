﻿namespace ECE.CRM.BusinessServices
{
    public class ExpensePaymentWarning
    {
        public static readonly string InsufficientEscrow = "There are not enough funds in escrow to pay this expense.";

        public static readonly string NoEscrowOverride = "This expense is being included, even though there are insufficient escrow funds.";

        public static readonly string PayDateNotEventDate = "The AREF Pay Date is not the same as an Event Date on the contract.";

        public static readonly string ContractCanceled = "The associated contract is in a cancelled state.";

        public static readonly string CurrentDateAheadOfPayDate = "The current date is ahead of the Pay Date for the associated Expense record.";

        public static readonly string ExcessivePayment = "Payment amount is more than {0:C}.";

        public static readonly string NoW9OnFile = "The artist does not have a W-9 on file.";
    }
}
