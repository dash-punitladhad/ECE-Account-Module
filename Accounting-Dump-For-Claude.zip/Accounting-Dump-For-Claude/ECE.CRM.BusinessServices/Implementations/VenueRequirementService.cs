﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class VenueRequirementService  :IVenueRequirementService
	{
		public IUnitOfWork Context { get; private set; }
		public VenueRequirementService(IUnitOfWork context)
		{
			this.Context = context;
		}

		public async Task<int> AddVenueRequirement(int venueId,List<VenueRequirementDto> venueRequirements,IPrincipal user)
		{
			if(venueId <= 0)
			{
				throw new ArgumentNullException("VenueId must be greater than zero.");
			}
			if (user == null)
			{
				throw new ArgumentNullException(nameof(user));
			}
			foreach(var req in venueRequirements)
			{
				req.VenueId = venueId;
				req.CreatedBy = user.GetUserId();
				req.CreatedOn = DateTime.Now;
				req.IsActive = req.IsActive.HasValue ? req.IsActive.Value : true;
				req.UpdatedBy = user.GetUserId();
				req.UpdatedOn = DateTime.Now;
			}
			return await this.Context.venueRequirementDao.AddVenueRequirements(venueRequirements);
		}

		public async Task<List<VenueRequirementDto>> GetVenueRequirements(int venueId)
		{
			if (venueId <= 0)
			{
				throw new ArgumentNullException("VenueId must be greater than zero.");
			}
			return await this.Context.venueRequirementDao.GetVenueRequirements(venueId);
		}

		public async Task<int> AddVenueRequirementNotification(VenueRequirementNotificationDto venueRequirementNotificationDto, IPrincipal user)
		{
			if(venueRequirementNotificationDto.ContractId.HasValue && venueRequirementNotificationDto.ContractId.Value > 0)
			{
				venueRequirementNotificationDto.CreatedBy = user.GetUserId();
				venueRequirementNotificationDto.CreatedOn = DateTime.Now;
				return await this.Context.venueRequirementDao.AddVenueRequirementNotification(venueRequirementNotificationDto);
			}
			throw new ArgumentNullException("ContractId must be greater than zero.");
		}
		public async Task<bool> IsVenueNotificationRecordExists(int contractId)
		{
			if (contractId > 0)
			{
				return await this.Context.venueRequirementDao.IsVenueNotificationRecordExists(contractId);
			}
			throw new ArgumentNullException("ContractId must be greater than zero.");
		}

		public async Task<bool> IsAgentAcknowledged(int contractId,int agentId)
		{
			if (contractId > 0)
			{
				return await this.Context.venueRequirementDao.IsAgentAcknowledged(contractId,agentId);
			}
			throw new ArgumentNullException("ContractId must be greater than zero.");
		}
		public async Task<int> UpdateAgentAcknowledge(VenueRequirementNotificationDto venueRequirementNotificationDto)
		{
			if (venueRequirementNotificationDto.ContractId.HasValue && venueRequirementNotificationDto.ContractId.Value > 0)
			{
				return await this.Context.venueRequirementDao.UpdateAgentAcknowledge(venueRequirementNotificationDto);
			}
			throw new ArgumentNullException("ContractId must be greater than zero.");
		}

		public async Task<List<VenueRequirementDto>> GetAllVenueRequirements(int venueId)
		{
			if (venueId <= 0)
			{
				throw new ArgumentNullException("VenueId must be greater than zero.");
			}
			return await this.Context.venueRequirementDao.GetAllVenueRequirements(venueId);
		}

	}
}
