﻿namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class OfferWebLinkService : IOfferWebLinkService
    {
        public OfferWebLinkService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<WebLinkDto>> GetOfferWebLinksAsync(EntityType entityType, int entityId, int context)
        {
            return await this.Context.OfferWebLinks.GetOfferWebLinksAsync(entityType, entityId, context);
        }

        public async Task SyncOfferWebLinksAsync(EntityType entityType, int entityId, IEnumerable<WebLinkDto> updatedWebLinks, IPrincipal user, int originalEntityTypeId = 0)
        {
            var existingWebLinks = await this.GetOfferWebLinksAsync(entityType, entityId, originalEntityTypeId);
            var activeWebLinks = updatedWebLinks.Where(x => !x.IsDeleted);

            // Get a list of still-existing web links in the updated list.
            var webLinksToKeep =
                from w in existingWebLinks
                join a in activeWebLinks on w.WebLinkId equals a.WebLinkId
                select w;

            // Update web links that have not been deleted
            foreach (var webLinkToKeep in webLinksToKeep)
            {
                var updates = activeWebLinks.First(x => x.WebLinkId == webLinkToKeep.WebLinkId);

                webLinkToKeep.WebLinkTypeId = updates.WebLinkTypeId;
                webLinkToKeep.Url = updates.Url;
                webLinkToKeep.Description = updates.Description;

                webLinkToKeep.SetAsUpdated(user);

                this.Context.WebLinks.Update(webLinkToKeep);
            }

            // Add new web links, if necessary.
            var webLinksToAdd = activeWebLinks.Except(webLinksToKeep, x => x.WebLinkId);

            foreach (var webLinkToAdd in webLinksToAdd)
            {
                webLinkToAdd.WebLinkId = 0;
                webLinkToAdd.EntityTypeId = (int)entityType;
                webLinkToAdd.EntityId = entityId;
                webLinkToAdd.SetAsCreated(user);

                this.Context.WebLinks.Create(webLinkToAdd);

                var newItem = Mapper.Map<OfferWebLinkDto>(webLinkToAdd);
                newItem.OfferId = webLinkToAdd.EntityId;
                newItem.OriginalEntityTypeId = originalEntityTypeId;
                await this.Context.OfferWebLinks.CreateAsync(newItem);
            }

            // Delete existing web links, if necessary.
            var webLinksToRemove = existingWebLinks.Except(webLinksToKeep);

            foreach (var webLinkToRemove in webLinksToRemove)
            {
                this.Context.WebLinks.Delete(webLinkToRemove.WebLinkId, user.GetUserId());
            }
        }
    }
}
