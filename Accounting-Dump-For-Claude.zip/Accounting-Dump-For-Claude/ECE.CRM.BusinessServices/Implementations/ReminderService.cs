﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ReminderService : IReminderService
    {
        public ReminderService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public List<ReminderDto> GetReminders(int userId)
        {
            return this.Context.Reminders.GetReminders(userId);
        }

        public bool AddReminder(ReminderDto reminder)
        {
            this.Context.BeginTransaction();

            try
            {
                var result = this.Context.Reminders.Create(reminder);

                this.Context.Commit();

                return result;
            }
            catch (Exception)
            {
                this.Context.Rollback();
                throw;
            }
        }

        public async Task<IList<ReminderDto>> GetUpcomingRemindersAsync(int userId)
        {
            return await this.Context.Reminders.GetUpcomingRemindersAsync(userId);
        }
        public async Task<IList<ReminderDto>> GetUpcomingRemindersFilterAsync(int userId, int entityId, int entityTypeId)
        {
            return await this.Context.Reminders.GetUpcomingRemindersFilterAsync(userId, entityId, entityTypeId);
        }
    }
}
