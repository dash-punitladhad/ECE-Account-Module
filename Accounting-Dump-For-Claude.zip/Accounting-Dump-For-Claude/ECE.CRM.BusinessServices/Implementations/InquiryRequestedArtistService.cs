﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class InquiryRequestedArtistService : IInquiryRequestedArtistService
    {
        public InquiryRequestedArtistService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task CreateAsync(InquiryRequestedArtistDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            dto.SetAsCreated(user);

            this.Context.BeginTransaction();

            try
            {
                await this.Context.InquiryRequestedArtists.CreateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new Exception("Unhandled Business Exception", ex);
            }
        }
    }
}
