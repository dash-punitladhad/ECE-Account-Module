using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices
{
    using Dapper;
    using ECE.CRM.BusinessServices.Utilities;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.DataTransferObjects.ContractDetails;
    using ECE.CRM.DataTransferObjects.PandaDoc;
    using EO.Pdf;
    using Infinity.Mobius.BlobStorage;
    using Infinity.Mobius.Configuration;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Security.Claims;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using AutoMapper;
    using PdfPigDoc = UglyToad.PdfPig.PdfDocument;
    using PdfPigPage = UglyToad.PdfPig.Content.Page;
    using UglyToad.PdfPig.Content;
    using PdfPigIO = UglyToad.PdfPig.IO;
    using ECE.CRM.DataAccess.Utilities;
    using System.Data.SqlClient;

    public class PandaDocService : IPandaDocService
    {
        private readonly IContactService _contactService;
        private readonly IEntityHistoryService _entityHistoryService;
        private readonly ITINHistoryService _tinHistoryService;
        private readonly IContractDocumentService _contractDocumentService;
        private readonly IDocumentService _documentService;
        private readonly IBlobStorageProvider _blobStorageProvider;
        private readonly IEceCrmEntities _eceCrmEntities;
        private readonly ILookupService _lookupService;
        private readonly IMessageService _messageService;
        private readonly IContractSignatureService _contractSignatureService;
        private readonly IUserService _userService;
        private readonly ICommunicationLogService _communicationLogService;
        private readonly Lazy<IContractService> _contractService;
        private readonly IContractDynamicBackupService _contractDynamicBackupService;
        private static readonly string ApiKey = MobiusConfiguration.Current.AppSettings["Pandadoc.ApiKey"];
        private static readonly string ApiUrl = MobiusConfiguration.Current.AppSettings["Pandadoc.ApiUrl"];
        private static readonly string SignaturUrl = MobiusConfiguration.Current.AppSettings["Pandadoc.SignaturUrl"];
        public PandaDocService(
            IUnitOfWork context,
            IContactService contactService,
            IEntityHistoryService entityHistoryService,
            ITINHistoryService tinHistoryService,
            IContractDocumentService contractDocumentService,
            IDocumentService documentService,
            IBlobStorageProvider blobStorageProvider,
            IEceCrmEntities eceCrmEntities,
            ILookupService lookupService,
            IMessageService messageService,
            IContractSignatureService contractSignatureService,
            IUserService userService,
            ICommunicationLogService communicationLogService,
            Lazy<IContractService> contractService,
            IContractDynamicBackupService contractDynamicBackupService
            )
        {
            this.Context = context;

            this._contactService = contactService;
            this._entityHistoryService = entityHistoryService;
            this._tinHistoryService = tinHistoryService;
            this._contractDocumentService = contractDocumentService;
            this._documentService = documentService;
            this._blobStorageProvider = blobStorageProvider;
            this._eceCrmEntities = eceCrmEntities;
            this._lookupService = lookupService;
            this._messageService = messageService;
            this._contractSignatureService = contractSignatureService;
            this._userService = userService;
            this._communicationLogService = communicationLogService;
            this._contractService = contractService;
            this._contractDynamicBackupService = contractDynamicBackupService;
        }

        public PandaDocService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<(bool, string, string)> CreateDocument(PandaDocRequestContractInfoDto contractInfo)
        {

            var isValid = false;
            var message = string.Empty;
            var documentId = string.Empty;
            MemoryStream mst = null;

            if (contractInfo == null || contractInfo.ContractNumber <= 0)
            {
                throw new ArgumentException(nameof(contractInfo.ContractNumber));
            }
            var recipients = new List<Recipient>();
            if (contractInfo.contactInfos != null)
            {
                foreach (var item in contractInfo.contactInfos)
                {
                    recipients.Add(new Recipient
                    {
                        email = item.email,
                        first_name = item.first_name,
                        last_name = item.last_name,
                        role = item.role,
                        signing_order = item.signing_order
                    }
                    );
                }
            }

            var tuple = await GetPandaDocTemplateIdAndContractTermsAndCondtion(contractInfo.ContractNumber);
            mst = tuple.Item2;


            var pandaDocMainTemplateId = tuple.Item1;
            var document = new PandaDocCreateDocumentRequestDto();


            document = new PandaDocCreateDocumentRequestDto
            {
                name = contractInfo.ContractNumber.ToString() + "_" + DateTime.Now.ToString("ddMMMyyyy_HHmm"),
                template_uuid = pandaDocMainTemplateId,
                recipients = recipients,

                tokens = new List<Token>()
               {
                    new Token
                    {
                        name = "Artist(s)",
                        value = contractInfo.Artists
                    },
                    new Token
                    {
                        name = "Performance_Date",
                        value = contractInfo.Performance_Date
                    },
                     new Token
                    {
                        name = "Contract#",
                        value = Convert.ToString( contractInfo.ContractNumber)
                    },
                      new Token
                    {
                        name = "Contract_due_Date",
                        value = contractInfo.Contract_due_Date
                    },
                       new Token
                    {
                        name = "AgentName",
                        value = contractInfo.AgentName
                    },
                        new Token
                    {
                        name = "Issue_Date",
                        value = contractInfo.Issue_Date
                    },
                         new Token
                    {
                        name = "Performance_Location",
                        value = contractInfo.Performance_Location
                    },
                        new Token
                    {
                        name = "DateAndTime_of_Performance",
                        value = contractInfo.DateAndTime_of_Performance
                        },
                    // new Token
                    //{
                    //    name = "Gross_Price_Agreed_Upon",
                    //    value = contractInfo.Gross_Price_Agreed_Upon
                    //},
                    // new Token
                    //{
                    //    name = "Deposit_Due",
                    //    value = contractInfo.Deposit_Due
                    //},
                    //new Token
                    //{
                    //    name = "Balance_Due",
                    //    value = contractInfo.Balance_Due
                    //},
                    //new Token
                    //{
                    //    name = "Deposit_To",
                    //    value = contractInfo.Deposit_To
                    //},new Token
                    //{
                    //    name = "Balance_To",
                    //    value = contractInfo.Balance_To
                    //},
                    new Token
                    {
                        name = "Presenter_Details",
                        value = contractInfo.Presenter_Details
                    },
                    new Token
                    {
                        name = "Presenter_Address",
                        value = contractInfo.Presenter_Address
                    },
                    new Token
                    {
                        name = "Presenter_Primary_Contact",
                        value = contractInfo.Presenter_Primary_Contact
                    },
                    new Token
                    {
                        name = "Agent_Changes_Note",
                        value = string.IsNullOrEmpty(Convert.ToString( contractInfo.ChangesNote))?" ":Convert.ToString(contractInfo.ChangesNote)
                    },
                    new Token
                    {
                        name = "Other_TermsAndConditions",
                        value = string.IsNullOrEmpty(Convert.ToString( contractInfo.Other_TermsAndConditions))?" ":Convert.ToString(contractInfo.Other_TermsAndConditions)
                    }
                }

            };
            if (contractInfo.Fields != null && contractInfo.Fields.Any())
            {
                document.fields = new Dictionary<string, FieldValue>();
                foreach (var field in contractInfo.Fields)
                {
                    document.fields.Add(field.Key, new FieldValue { value = field.Value });
                }
            }
            PricingTable pricingTable = new PricingTable();
            pricingTable.data_merge = true;
            pricingTable.name = "PaymentTerms";

            List<Row> Rows = new List<Row>();
            foreach (var i in contractInfo.paymentTerms)
            {
                Rows.Add(new Row()
                {
                    options = new Options() { optional = false, optional_selected = false, qty_editable = false },
                    data = new PaymentTermData()
                    {
                        Label1 = i.Label1,
                        Value1 = i.Value1,
                        Label2 = i.Label2,
                        Value2 = i.Value2,
                        Name = ".",
                        Price = 0,
                        QTY = 0
                    }
                });
            }
            Section section = new Section();
            section.title = "deposit";
            section.@default = true;
            section.rows = Rows;
            pricingTable.sections = new List<Section>() { section };
            document.pricing_tables = new List<PricingTable>() { pricingTable };
            //pricingTable.sections
            List<string> uploadIds = null;

            using (var client = new HttpClient())
            {
                PandaDocCreateDocumentResponseDto pandaDocDoc = null;
                bool isSuccess = true;
                var responseContent = string.Empty;
                client.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");

                var json = JsonConvert.SerializeObject(document);
                var jObj = JObject.Parse(json);

                // Add fields
                //jObj["fields"] = JObject.FromObject(new
                //{
                //    Text1 = new
                //    {
                //        value = "Jerry Wadsworth",
                //        role = "Presenter",
                //        required = true
                //    }
                //});

                json = jObj.ToString();
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await client.PostAsync($"{ApiUrl}/documents", content);

                if (response.IsSuccessStatusCode)
                {
                    isValid = true;
                    responseContent = await response.Content.ReadAsStringAsync();
                    pandaDocDoc = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContent);
                    message = "Document created successfully.";
                    //Console.WriteLine("Document created successfully.");
                    //Console.WriteLine(responseContent);
                }
                else
                {
                    isValid = false;
                    isSuccess = false;
                    // Console.WriteLine("Error creating document.");
                    responseContent = await response.Content.ReadAsStringAsync();
                    // Console.WriteLine(responseContent);
                    message = "Error creating document.";
                }


                string request = "-----------Request-------------------------- \n";
                request += json;
                request += "\n \n \n \n ";
                request += "-----------Response-------------------------- \n";
                request += responseContent;

                if (isSuccess && pandaDocDoc != null)
                {
                    ExceptionLogging.SuccessSendToText(request);

                    try
                    {
                        // Wait until document reaches a ready state
                        if (!string.IsNullOrWhiteSpace(pandaDocDoc.id))
                        {
                            int retryCount = 0;
                            const int maxRetries = 60;
                            const int delayMs = 500;
                            bool isDocumentReady = false;

                            while (!isDocumentReady && retryCount < maxRetries)
                            {
                                var status = await GetCheckPandaDocMaintDocStatusAsync(pandaDocDoc.id);
                                string lowerStatus = status?.ToLowerInvariant();

                                if (lowerStatus == "document.draft" || lowerStatus == "document.completed" || lowerStatus == "document.sent")
                                {
                                    isDocumentReady = true;
                                }
                                else
                                {
                                    await Task.Delay(delayMs);
                                    retryCount++;
                                }
                            }

                            if (!isDocumentReady)
                            {
                                throw new TimeoutException("PandaDoc document status did not reach a valid state in time.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                    }

                    try
                    {
                        if (mst == null || mst.Length == 0)
                        {
                            tuple = await GetPandaDocTemplateIdAndContractTermsAndCondtion(contractInfo.ContractNumber);
                            mst = tuple.Item2;
                        }

                        if (mst == null || mst.Length == 0)
                        {
                            throw new Exception("HTML Terms and Conditions not found!");
                        }

                        List<Stream> streams1 = new List<Stream> { mst };
                        var result = await CreateUploadBundle(pandaDocDoc.id, recipients, streams1);

                        if (result.Item1)
                        {
                            uploadIds = new List<string>();
                            if (result.Item2.Any())
                            {
                                uploadIds.AddRange(result.Item2);
                            }
                            try
                            {
                                using (var conn = new SqlConnectionFactory().CreateConnection())
                                {
                                    const string sql = "UPDATE ContractTemplateHistory SET IsUploadMainTermsAndCondition = 1 WHERE ContractId = @contractId";
                                    await conn.ExecuteAsync(sql, new { contractId = contractInfo.ContractNumber });
                                }
                            }
                            catch (Exception ex)
                            {
                                new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                    }

                    try
                    {
                        var contractTemplate = await _eceCrmEntities.ContractTemplateHistory
                            .FirstOrDefaultAsync(a => a.ContractId == contractInfo.ContractNumber);

                        if (contractTemplate != null)
                        {
                            contractTemplate.PandaDocDocumentId = pandaDocDoc.id;
                            contractTemplate.PandaDocExpirationDate = null;
                            contractTemplate.PandaDocExpirationAlertSentDate = null;
                            await _eceCrmEntities.SaveChangesAsync();
                        }
                    }
                    catch (Exception ex)
                    {
                        new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                    }

                    try
                    {
                        var rs = await this.AddbundleAllDocuementsForPandadocAsync(contractInfo.ContractNumber, pandaDocDoc.id, recipients);

                        if (!rs.Item1)
                        {
                            return (false, "Error adding riders/addendums to PandaDoc bundle.", message);
                        }

                        if (rs.Item1 && rs.Item2 != null && rs.Item2.Any())
                        {
                            if (uploadIds == null)
                            {
                                uploadIds = new List<string>();
                            }
                            if (rs.Item2.Any())
                            {
                                uploadIds.AddRange(rs.Item2);
                            }

                            using (var conn = new SqlConnectionFactory().CreateConnection())
                            {
                                await conn.ExecuteAsync("Sp_set_RiderAndAddendumforHistory @contractId", new { contractId = contractInfo.ContractNumber });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                    }

                    try
                    {
                        var riderandaddendum = await _eceCrmEntities.RiderAndAddendumHistory.FirstOrDefaultAsync(a => a.ContractId == contractInfo.ContractNumber && a.DocumentType == "addendum");
                        string label = riderandaddendum == null ? ContractFileLabels.BasicContract : ContractFileLabels.BasicContractWithAmendment;
                        await this.AddContractPDFBackup(contractInfo.ContractNumber, label, uploadIds);
                    }
                    catch (Exception ex)
                    {
                        new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION").Error(ex);
                    }
                }
                else
                {
                    ExceptionLogging.SendToText(request);
                }

                if (pandaDocDoc != null)
                {
                    documentId = pandaDocDoc.id;
                }

            }


            return (isValid, message, documentId);
        }

        public async Task<byte[]> DownloadDocument(string documentId)
        {
            byte[] file = null;
            var ms = new MemoryStream();
            var filesToMerge = new List<PdfDocument>();
            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/" + documentId + "/download?separate_files=false");
                request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsByteArrayAsync();
                    // var documentResponse = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContentSendDocument);
                    if (result.Length > 0)
                    {
                        filesToMerge.Add(new PdfDocument(new MemoryStream(result)));
                    }

                }
                else
                {
                    // responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                    // throw new Exception($"Error sending document: {responseContentSendDocument}");
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }

            List<PandaDocGetDocument> attachemnts = new List<PandaDocGetDocument>();
            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/" + documentId + "/attachments/");
                request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        attachemnts = JsonConvert.DeserializeObject<List<PandaDocGetDocument>>(result);
                    }
                }

            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }



            if (attachemnts.Any())
            {
                foreach (var attachment in attachemnts)

                    try
                    {
                        var client = new HttpClient();
                        var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/" + documentId + "/attachments/" + attachment.uuid + "/download/");
                        request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                        var response = await client.SendAsync(request);
                        if (response.IsSuccessStatusCode)
                        {
                            var result = await response.Content.ReadAsByteArrayAsync();
                            if (result.Length > 0)
                            {
                                filesToMerge.Add(new PdfDocument(new MemoryStream(result)));
                            }

                        }
                        else
                        {
                            // responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                            // throw new Exception($"Error sending document: {responseContentSendDocument}");
                        }

                    }
                    catch (Exception ex)
                    {
                        var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        logger.Error(ex);
                    }
            }




            var finalPdf = new PdfDocument();
            if (filesToMerge.Any())
            {
                finalPdf = PdfDocument.Merge(filesToMerge.ToArray());



                finalPdf.Save(ms);
                ms.Position = 0;
            }

            return ms.ToArray();
        }


        public async Task<bool> CreateUploadAttachment(string documentId, List<Recipient> recipients, List<Stream> streams = null)
        {

            /*----------------------Upload docuemnt via mail----------------------------- */
            bool isUpload = true;
            string responseResult = string.Empty;
            using (var client = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{ApiUrl}/documents/" + documentId + "/attachments/");
                request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                var content = new MultipartFormDataContent();
                if (streams.Any())
                {
                    foreach (var st in streams)
                    {
                        content.Add(new StreamContent(st), "file", "Rider.pdf");
                    }
                }
                var json = JsonConvert.SerializeObject(recipients);
                content.Add(new StringContent("{  \"name\": \"Attachment Rider\"} "), "data");
                request.Content = content;
                var response = await client.SendAsync(request);
                if (response.IsSuccessStatusCode)
                {
                    responseResult = await response.Content.ReadAsStringAsync();
                    // var documentResponse = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContentSendDocument);

                }
                else
                {
                    isUpload = false;
                    responseResult = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Error sending document: {responseResult}");
                }

                string requestStr = "-----------Request-------------------------- \n";
                requestStr += requestStr + "\n";
                requestStr += content.ToString() + "\n";
                requestStr += "\n \n \n \n ";
                requestStr += "-----------Response-------------------------- \n";
                requestStr += responseResult;
                if (isUpload)
                {
                    ExceptionLogging.SuccessSendToText(requestStr);

                }
                else
                {
                    ExceptionLogging.SendToText(requestStr);
                }

            }
            return isUpload;
        }

        public async Task<Tuple<bool, List<string>>> CreateUploadBundle(string documentId, List<Recipient> recipients, List<Stream> streams = null)
        {
            var tuple = new Tuple<bool, List<string>>(false, null);
            bool isUpload = true;
            string responseResult = string.Empty;
            List<string> uploadids = null;
            try
            {
                try
                { await DraftDocument(documentId); }
                catch (Exception ex)
                {
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }
                using (var client = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, $"{ApiUrl}/documents/" + documentId + "/sections/uploads");
                    request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                    var content = new MultipartFormDataContent();
                    if (streams.Any())
                    {
                        foreach (var st in streams)
                        {
                            content.Add(new StreamContent(st), "file", "Rider.pdf");
                        }
                    }
                    var json = JsonConvert.SerializeObject(recipients);

                    content.Add(new StringContent("{  \"name\": \"Bundle Rider\", \"recipients\":" + json + "} "), "data");
                    request.Content = content;
                    var response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        responseResult = await response.Content.ReadAsStringAsync();
                        // var documentResponse = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContentSendDocument);

                        try
                        {
                            var pandaDocResponse = JsonConvert.DeserializeObject<PandaDocBundleResponse>(responseResult);

                            uploadids = new List<string>();
                            uploadids.Add(pandaDocResponse.uuid);
                        }
                        catch (Exception ex)
                        {
                            var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                            log.Error(ex);
                        }
                    }
                    else
                    {
                        isUpload = false;
                        responseResult = await response.Content.ReadAsStringAsync();
                        throw new Exception($"Error sending document: {responseResult}");
                    }

                    string requestStr = "-----------Request-------------------------- \n";
                    requestStr += requestStr + "\n";
                    requestStr += content.ToString() + "\n";
                    requestStr += "\n \n \n \n ";
                    requestStr += "-----------Response-------------------------- \n";
                    requestStr += responseResult;
                    if (isUpload)
                    {
                        ExceptionLogging.SuccessSendToText(requestStr);

                    }
                    else
                    {
                        ExceptionLogging.SendToText(requestStr);
                    }

                }
            }
            catch (Exception ex)
            {
                isUpload = false;
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
            }
            tuple = new Tuple<bool, List<string>>(isUpload, uploadids);
            return tuple;
        }

        public async Task<bool> SendDocument(string documentId, string subject = null, string body = null, bool silent = false)
        {

            /*----------------------draff docuemnt via mail----------------------------- */
            try
            { await DraftDocument(documentId); }
            catch { }
            /*----------------------send docuemnt via mail----------------------------- */
            var responseContentSendDocument = string.Empty;
            bool isSendDocument = true;
            using (var clientSendDocument = new HttpClient())
            {
                clientSendDocument.Timeout = TimeSpan.FromMinutes(10);
                clientSendDocument.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");

                string ApiUrlSendDocument = $"{ApiUrl}/documents/" + documentId + "/send";

                var payload = new
                {
                    subject = subject,
                    message = string.IsNullOrWhiteSpace(body) ? string.Empty : body.RemoveHtml(),
                    silent = silent
                };

                // Serialize the payload to JSON
                string jsonPayload = string.Empty;
                if (!string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body))
                {
                    jsonPayload = JsonConvert.SerializeObject(payload);
                }


                var requestContent = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                var responseSendDocument = await clientSendDocument.PostAsync(ApiUrlSendDocument, requestContent);

                if (responseSendDocument.IsSuccessStatusCode)
                {
                    responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                    // var documentResponse = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContentSendDocument);

                }
                else
                {
                    isSendDocument = false;
                    responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                    // throw new Exception($"Error sending document: {responseContentSendDocument}");
                }

                string request = "-----------Request-------------------------- \n";
                request += ApiUrlSendDocument;
                request += "\n \n \n \n ";
                request += "-----------Response-------------------------- \n";
                request += responseContentSendDocument;
                if (isSendDocument)
                {
                    ExceptionLogging.SuccessSendToText(request);
                    await SyncPandaDocExpirationDateAsync(documentId);
                }
                else
                {
                    ExceptionLogging.SendToText(request);
                }

            }
            return isSendDocument;
        }

        public async Task<bool> DraftDocument(string documentId)
        {

            /*----------------------send docuemnt via mail----------------------------- */
            var responseContentSendDocument = string.Empty;
            bool isSendDocument = true;
            using (var clientSendDocument = new HttpClient())
            {
                clientSendDocument.Timeout = TimeSpan.FromMinutes(10);
                clientSendDocument.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");

                string ApiUrlSendDocument = $"{ApiUrl}/documents/" + documentId + "/draft";

                var requestContent = new StringContent("", Encoding.UTF8, "application/json");
                var responseSendDocument = await clientSendDocument.PostAsync(ApiUrlSendDocument, requestContent);

                if (responseSendDocument.IsSuccessStatusCode)
                {
                    responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                    // var documentResponse = JsonConvert.DeserializeObject<PandaDocCreateDocumentResponseDto>(responseContentSendDocument);

                }
                else
                {
                    isSendDocument = false;
                    responseContentSendDocument = await responseSendDocument.Content.ReadAsStringAsync();
                    // throw new Exception($"Error sending document: {responseContentSendDocument}");
                }

                string request = "-----------Request-------------------------- \n";
                request += ApiUrlSendDocument;
                request += "\n \n \n \n ";
                request += "-----------Response-------------------------- \n";
                request += responseContentSendDocument;
                if (isSendDocument)
                {
                    ExceptionLogging.SuccessSendToText(request);

                }
                else
                {
                    ExceptionLogging.SendToText(request);
                }

            }
            return isSendDocument;
        }

        public async Task<(bool, string, string, List<Recipient>)> UpdateDocument(string documentId, PandaDocRequestContractInfoDto contractInfo, bool skipDraft = false)
        {
            if (!skipDraft)
            {
                try
                {
                    await DraftDocument(documentId);
                }
                catch { }
            }

            //string ApiUrl = $"{ApiUrl}/documents";



            var isValid = false;
            var message = string.Empty;

            if (contractInfo == null || contractInfo.ContractNumber <= 0)
            {
                throw new ArgumentException(nameof(contractInfo.ContractNumber));
            }
            List<RecipientRoleAndId> recipientRoleAndIds = new List<RecipientRoleAndId>();
            JObject jsonObjectDetails = new JObject();
            try
            {
                var client = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
                var requestAttachement = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/" + documentId + "/details");
                requestAttachement.Headers.Add("Authorization", $"API-Key {ApiKey}");
                var responseAttachement = await client.SendAsync(requestAttachement);
                if (responseAttachement.IsSuccessStatusCode)
                {
                    var result = await responseAttachement.Content.ReadAsStringAsync();
                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        jsonObjectDetails = JObject.Parse(result);
                        var jsonObject1 = jsonObjectDetails.GetValue("recipients");

                        var documentDetails = JsonConvert.DeserializeObject<List<RecipientDatail>>(jsonObject1.ToString());

                        if (documentDetails != null)
                        {
                            if (documentDetails.Any())
                            {
                                foreach (var f in documentDetails)
                                {
                                    recipientRoleAndIds.Add(new RecipientRoleAndId()
                                    {
                                        Role = f.Role,
                                        Id = f.Id,
                                        Email = f.Email,
                                        FirstName = f.FirstName,
                                        LastName = f.LastName,
                                        ContactId = f.ContactId,
                                        RecipientType = f.RecipientType
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }






            var recipients = new List<Recipient>();
            if (contractInfo.contactInfos != null)
            {
                foreach (var item in contractInfo.contactInfos)
                {
                    string id = null;
                    if (recipientRoleAndIds != null && recipientRoleAndIds.Any())
                    {
                        // Priority 1: Match by Email (best for fixed assignments)
                        var matchByEmail = recipientRoleAndIds.FirstOrDefault(a => 
                            !string.IsNullOrWhiteSpace(a.Email) && 
                            a.Email.Equals(item.email, StringComparison.OrdinalIgnoreCase));
                        
                        if (matchByEmail != null)
                        {
                            id = matchByEmail.Id;
                        }
                        else
                        {
                            // Priority 2: Match by Role (fallback if email changed but role is unique)
                            var matchByRole = recipientRoleAndIds.FirstOrDefault(a => 
                                !string.IsNullOrWhiteSpace(a.Role) && 
                                a.Role.Equals(item.role, StringComparison.OrdinalIgnoreCase));
                            
                            if (matchByRole != null)
                            {
                                id = matchByRole.Id;
                            }
                        }
                    }
                    try
                    {
                        var existing = recipientRoleAndIds.FirstOrDefault(r => r.Id == id);
                        recipients.Add(new Recipient
                        {
                            id = id,
                            email = item.email,
                            // If we have an existing recipient in PandaDoc, we send back their current names to avoid "updating" them
                            // while still satisfying PandaDoc's non-null validation requirements.
                            first_name = item.first_name,
                            last_name = item.last_name,
                            role = item.role,
                            signing_order = item.signing_order,
                            recipient_type = string.IsNullOrWhiteSpace(item.recipient_type) ? (item.role != null && item.role.Equals("CC", StringComparison.OrdinalIgnoreCase) ? "cc" : "signer") : item.recipient_type,
                            ContactId = existing?.ContactId
                        });
                    }
                    catch { };
                }

            }

            var document = new PandaDocCreateDocumentRequestDto
            {
                recipients = recipients,
                tokens = new List<Token>()
               {
                    new Token
                    {
                        name = "Artist(s)",
                        value = contractInfo.Artists
                    },
                    new Token
                    {
                        name = "Performance_Date",
                        value = contractInfo.Performance_Date
                    },
                     new Token
                    {
                        name = "Contract#",
                        value = Convert.ToString( contractInfo.ContractNumber)
                    },
                      new Token
                    {
                        name = "Contract_due_Date",
                        value = contractInfo.Contract_due_Date
                    },
                       new Token
                    {
                        name = "AgentName",
                        value = contractInfo.AgentName
                    },
                        new Token
                    {
                        name = "Issue_Date",
                        value = contractInfo.Issue_Date
                    },
                         new Token
                    {
                        name = "Performance_Location",
                        value = contractInfo.Performance_Location
                    },
                        new Token
                    {
                        name = "DateAndTime_of_Performance",
                        value = contractInfo.DateAndTime_of_Performance
                    },
                    // new Token
                    //{
                    //    name = "Gross_Price_Agreed_Upon",
                    //    value = contractInfo.Gross_Price_Agreed_Upon
                    //},
                    // new Token
                    //{
                    //    name = "Deposit_Due",
                    //    value = contractInfo.Deposit_Due
                    //},
                    //new Token
                    //{
                    //    name = "Balance_Due",
                    //    value = contractInfo.Balance_Due
                    //},
                    //new Token
                    //{
                    //    name = "Deposit_To",
                    //    value = contractInfo.Deposit_To
                    //},new Token
                    //{
                    //    name = "Balance_To",
                    //    value = contractInfo.Balance_To
                    //},
                    new Token
                    {
                        name = "Presenter_Details",
                        value = contractInfo.Presenter_Details
                    },
                    new Token
                    {
                        name = "Presenter_Address",
                        value = contractInfo.Presenter_Address
                    },
                    new Token
                    {
                        name = "Presenter_Primary_Contact",
                        value = contractInfo.Presenter_Primary_Contact
                    },
                    new Token
                    {
                        name = "Agent_Changes_Note",
                        value = string.IsNullOrEmpty(Convert.ToString( contractInfo.ChangesNote))?" ":Convert.ToString(contractInfo.ChangesNote)
                    },
                    new Token
                    {
                        name = "Other_TermsAndConditions",
                        value = string.IsNullOrEmpty(Convert.ToString( contractInfo.Other_TermsAndConditions))?" ":Convert.ToString(contractInfo.Other_TermsAndConditions)
                    }
                }
            };

            if (contractInfo.Fields != null && contractInfo.Fields.Any())
            {
                document.fields = new Dictionary<string, FieldValue>();
                foreach (var field in contractInfo.Fields)
                {
                    document.fields.Add(field.Key, new FieldValue { value = field.Value });
                }
            }

            PricingTable pricingTable = new PricingTable();
            pricingTable.data_merge = true;
            pricingTable.name = "PaymentTerms";

            List<Row> Rows = new List<Row>();
            foreach (var i in contractInfo.paymentTerms)
            {
                Rows.Add(new Row()
                {
                    options = new Options() { optional = false, optional_selected = false, qty_editable = false },
                    data = new PaymentTermData()
                    {
                        Label1 = i.Label1,
                        Value1 = i.Value1,
                        Label2 = i.Label2,
                        Value2 = i.Value2,
                        Name = ".",
                        Price = 0,
                        QTY = 0
                    }
                });
            }
            Section section = new Section();
            section.title = "deposit";
            section.@default = true;
            section.rows = Rows;
            pricingTable.sections = new List<Section>() { section };
            document.pricing_tables = new List<PricingTable>() { pricingTable };

            try
            {

                using (var clientUpdate = new HttpClient())
                {
                    clientUpdate.Timeout = TimeSpan.FromMinutes(10);
                    //PandaDocCreateDocumentResponseDto pandaDocDoc = null;
                    bool isSuccess = true;
                    var responseContent = string.Empty;
                    var json = JsonConvert.SerializeObject(document);

                    // 1. Ensure the document is in DRAFT status
                    if (!skipDraft)
                    {
                        var status = await this.GetCheckPandaDocMaintDocStatusAsync(documentId);
                        if (!status.Contains("draft"))
                        {
                            await this.DraftDocument(documentId);
                            await Task.Delay(2000); // Wait for transition
                        }
                    }

                    var restoredEmails = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                    // PASS 1: Restore role slots from ECE source of truth (Presenter / CC)
                    if (recipientRoleAndIds != null && recipientRoleAndIds.Any())
                    {
                        foreach (var targetRole in new[] { "Presenter"})
                        {
                            var targetSigner = recipients.FirstOrDefault(r => (r.role ?? "").IndexOf(targetRole, StringComparison.OrdinalIgnoreCase) >= 0);
                            if (targetSigner == null) continue;

                            var correctInSlot = recipientRoleAndIds.Any(r => 
                                r.Email.Equals(targetSigner.email, StringComparison.OrdinalIgnoreCase) 
                                && r.Role.Equals(targetSigner.role, StringComparison.OrdinalIgnoreCase) 
                                && r.RecipientType?.Equals(targetSigner.recipient_type, StringComparison.OrdinalIgnoreCase) == true);

                            if (correctInSlot) continue; 

                            var hijacked = recipientRoleAndIds.FirstOrDefault(r => 
                                r.RecipientType?.Equals(targetSigner.recipient_type, StringComparison.OrdinalIgnoreCase) == true && 
                                !recipients.Any(correct => 
                                    ((correct.role ?? "").Contains("Presenter") || (correct.role ?? "").Contains("Artist") || (correct.role ?? "").Contains("CC")) && 
                                    correct.email.Equals(r.Email, StringComparison.OrdinalIgnoreCase)));

                            var original = recipientRoleAndIds.FirstOrDefault(r => 
                                r.Email.Equals(targetSigner.email, StringComparison.OrdinalIgnoreCase) && 
                                !string.IsNullOrWhiteSpace(r.ContactId));

                            if (hijacked != null)
                            {
                                try
                                {
                                    // 1. Search PandaDoc for the contact by email
                                    var foundContactId = await GetPandaDocContactIdByEmailAsync(targetSigner.email);
                                    
                                    HttpResponseMessage syncResponse = null;

                                    if (!string.IsNullOrWhiteSpace(foundContactId))
                                    {
                                        // Case A: Contact exists in PandaDoc
                                        
                                        // 1. Update the contact's names in PandaDoc to match ECE CRM
                                        var contactUpdateObj = new JObject
                                        {
                                            ["first_name"] = !string.IsNullOrWhiteSpace(targetSigner.first_name) ? targetSigner.first_name : "N/A",
                                            ["last_name"] = !string.IsNullOrWhiteSpace(targetSigner.last_name) ? targetSigner.last_name : "N/A"
                                        };
                                        var contactUpdateContent = new StringContent(contactUpdateObj.ToString(), Encoding.UTF8, "application/json");
                                        var contactUpdateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), $"{ApiUrl.TrimEnd('/')}/contacts/{foundContactId}") { Content = contactUpdateContent };
                                        contactUpdateRequest.Headers.Add("Authorization", $"API-Key {ApiKey}");
                                        await clientUpdate.SendAsync(contactUpdateRequest);

                                        // 2. Reassign the slot to this contact
                                        var reassignObj = new JObject { ["id"] = foundContactId, ["kind"] = "contact" };
                                        var reassignContent = new StringContent(reassignObj.ToString(), Encoding.UTF8, "application/json");
                                        var reassignRequest = new HttpRequestMessage(HttpMethod.Post, $"{ApiUrl.TrimEnd('/')}/documents/{documentId}/recipients/{hijacked.Id}/reassign") { Content = reassignContent };
                                        reassignRequest.Headers.Add("Authorization", $"API-Key {ApiKey}");
                                        syncResponse = await clientUpdate.SendAsync(reassignRequest);
                                        
                                        // If reassign fails (e.g. contact already on document), we'll try PATCH as a fallback below
                                    }

                                    if (syncResponse == null || !syncResponse.IsSuccessStatusCode)
                                    {
                                        // Case B: Contact is new or Reassign failed -> Update the recipient details via PATCH
                                        var updateObj = new JObject
                                        {
                                            ["email"] = targetSigner.email,
                                            ["first_name"] = !string.IsNullOrWhiteSpace(targetSigner.first_name) ? targetSigner.first_name : "N/A",
                                            ["last_name"] = !string.IsNullOrWhiteSpace(targetSigner.last_name) ? targetSigner.last_name : "N/A"
                                        };
                                        var updateContent = new StringContent(updateObj.ToString(), Encoding.UTF8, "application/json");
                                        var recipientUpdateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), $"{ApiUrl.TrimEnd('/')}/documents/{documentId}/recipients/recipient/{hijacked.Id}") { Content = updateContent };
                                        recipientUpdateRequest.Headers.Add("Authorization", $"API-Key {ApiKey}");
                                        syncResponse = await clientUpdate.SendAsync(recipientUpdateRequest);
                                    }

                                    if (syncResponse.IsSuccessStatusCode)
                                    {
                                        if (original != null) targetSigner.id = original.Id;
                                        recipientRoleAndIds.Remove(hijacked);
                                        restoredEmails.Add(targetSigner.email);
                                    }
                                    else
                                    {
                                        var errorDetails = await syncResponse.Content.ReadAsStringAsync();
                                        var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        logger.Error($"PandaDoc Sync Failed for role {targetRole}. Status: {syncResponse.StatusCode}, Details: {errorDetails} URL: {syncResponse.RequestMessage.RequestUri}");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                    logger.Error("PandaDoc Sync Exception", ex);
                                }
                            }
                        }
                    }

                    // 2. Final Phase: Update metadata, tokens, and fields via PATCH
                    JObject jsonObject = JObject.Parse(json);
                    jsonObject.Remove("name");
                    jsonObject.Remove("template_uuid");
                    jsonObject.Remove("Status");
                    jsonObject.Remove("recipients");

                    if (skipDraft)
                    {
                        jsonObject.Remove("fields");
                        jsonObject.Remove("pricing_tables");
                    }

                    // Special handling for TitleOfSignatory fields
                    var fields = jsonObjectDetails?["fields"] as JArray;
                    var mergeFieldList = fields?
                        .Select(f => (string)f["merge_field"])
                        .Where(mf => !string.IsNullOrWhiteSpace(mf))
                        .ToList() ?? new List<string>();

                    var count = mergeFieldList.Count(mf =>
                        mf == "PresenterTitleOfSignatory" ||
                        mf == "ArtistTitleOfSignatory");

                    if (count == 0)
                    {
                        jsonObject.Remove("fields");
                    }

                    var content = new StringContent(jsonObject.ToString(), Encoding.UTF8, "application/json");
                    var updateRequest = new HttpRequestMessage(new HttpMethod("PATCH"), $"{ApiUrl.TrimEnd('/')}/documents/" + documentId)
                    {
                        Content = content
                    };
                    updateRequest.Headers.Add("Authorization", $"API-Key {ApiKey}");
                    updateRequest.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    var response = await clientUpdate.SendAsync(updateRequest);

                    if (response.IsSuccessStatusCode)
                    {
                        isValid = true;
                        message = "Document updated successfully.";
                    }
                    else
                    {
                        isValid = false;
                        isSuccess = false;
                        responseContent = await response.Content.ReadAsStringAsync();
                        message = "Error updating document: " + responseContent;
                    }


                    string request = "-----------Request-------------------------- \n";
                    request += json;
                    request += "\n \n \n \n ";
                    request += "-----------Response-------------------------- \n";
                    request += responseContent;

                    if (isSuccess)
                    {
                        ExceptionLogging.SuccessSendToText(request);
                    }
                    else
                    {
                        ExceptionLogging.SendToText(request);
                    }

                    //documentId = pandaDocDoc.id;
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }

            return (isValid, message, documentId, recipients);
        }

        private async Task<byte[]> GetBlobBytesAsync(Guid blobId, string primaryLibrary)
        {
            try
            {
                var blobLibrary = _blobStorageProvider.GetBlobLibrary(primaryLibrary);
                var blob = blobLibrary.GetBlob(blobId);

                //if (blob == null || blob.Size <= 0)
                //{
                //    blobLibrary = _blobStorageProvider.GetBlobLibrary(fallbackLibrary);
                //    blob = blobLibrary.GetBlob(blobId);
                //}

                if (blob == null || blob.Size <= 0)
                    return null;

                using (var ms = new MemoryStream())
                {
                    await blob.RetrieveToStreamAsync(ms);
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
                return null;
            }
        }

        private async Task<PdfDocument> BuildProcessedPdfAsync(byte[] bytes, int contractId)
        {
            // IMPORTANT: Do NOT use a 'using' block here. 
            // EO.Pdf.PdfDocument is 'lazy' and needs the underlying stream to remain open 
            // until the final PdfDocument.Merge call is executed.
            var stream = new MemoryStream(bytes);
            var pdf = new PdfDocument(stream);

            foreach (var field in pdf.Fields)
            {
                if (field.FullName == "Contract_Number")
                {
                    field.Value = contractId.ToString();
                }
            }

            int lastPageIndex = pdf.Pages.Count - 1;

            for (int i = 0; i < pdf.Pages.Count; i++)
            {
                if (i == lastPageIndex)
                    await SettingPdfPageAsync(pdf.Pages[i], contractId);
                else
                    await SettingPdfPageInitialsAsync(pdf.Pages[i], contractId);
            }

            return pdf;
        }

        public async Task<Tuple<bool, List<string>>> AddbundleAllDocuementsForPandadocAsync(
            int contractId,
            string documentId,
            List<Recipient> recipients)
        {
            bool isValid = false;
            List<string> uploadIds = null;

            var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");

            try
            {
                var filesToMerge = new List<PdfDocument>();

                #region 1️⃣ Load PandaDoc Static Agreement (Local File System)

                // First try direct path from config or fallback to downloads location
                var filePath = MobiusConfiguration.Current.AppSettings["PandaDoc.StaticFilePath"];
                

                if (!(string.IsNullOrEmpty(filePath)) && File.Exists(filePath))
                {
                    byte[] agreementBytes = File.ReadAllBytes(filePath);
                    var agreementPdf = await BuildProcessedPdfAsync(agreementBytes, contractId);
                    filesToMerge.Add(agreementPdf);
                }
                else
                {
                    // Fallback to Blob Storage if file doesn't exist at path
                    var configKey = MobiusConfiguration.Current.AppSettings["ECE.Consumer.Transaction.Agreement.for.PandaDoc.Key"];
                    if (Guid.TryParse(configKey, out var agreementBlobId))
                    {
                        var agreementBytes = await GetBlobBytesAsync(agreementBlobId, "GenericRiders");
                        if (agreementBytes != null)
                        {
                            var agreementPdf = await BuildProcessedPdfAsync(agreementBytes, contractId);
                            filesToMerge.Add(agreementPdf);
                        }
                    }
                }

                #endregion

                #region 2️⃣ Load Contract Riders

                var contractDocuments = await _contractDocumentService.GetContractDocumentsAsync(contractId, true);

                var riderDtos = contractDocuments?
                    .Where(x => x.IsRider && !x.IsDeleted)
                    .OrderBy(x => x.CreatedDate)
                    .ToList() ?? new List<ContractDocumentDto>();

                foreach (var riderDto in riderDtos)
                {
                    var documentDto = await _documentService.GetByIdAsync(riderDto.DocumentId);

                    if (documentDto.DocumentExtensionId != (int)DocumentExtension.PDF)
                        continue;

                    if (!Guid.TryParse(documentDto.StorageFileName, out var blobId))
                        continue;

                    var entityType = ((EntityType)riderDto.OriginalEntityTypeId).ToString();

                    // Try GenericRiders first, then original entity type library
                    var bytes = await GetBlobBytesAsync(blobId, "GenericRiders");
                    if (bytes == null)
                    {
                        bytes = await GetBlobBytesAsync(blobId, entityType);
                    }

                    if (bytes == null)
                        continue;

                    var riderPdf = await BuildProcessedPdfAsync(bytes, contractId);
                    filesToMerge.Add(riderPdf);
                }

                #endregion

                #region check and add addendum

                var contractAddendum = await this._eceCrmEntities.AddendumDocument.Where(a => a.ContractId == contractId && !a.IsDeleted && a.IsPrimary).ToListAsync();

                foreach (var addendum in contractAddendum)
                {
                    var documentDto = await _documentService.GetByIdAsync(addendum.DocumentId);

                    if (documentDto.DocumentExtensionId != (int)DocumentExtension.PDF)
                        continue;

                    if (!Guid.TryParse(documentDto.StorageFileName, out var blobId))
                        continue;

                    var entityType = ((EntityType)addendum.OriginalEntityTypeId).ToString();

                    // Try GenericRiders first, then original entity type library
                    var bytes = await GetBlobBytesAsync(blobId, "GenericRiders");
                    if (bytes == null)
                    {
                        bytes = await GetBlobBytesAsync(blobId, entityType);
                    }

                    if (bytes == null)
                        continue;

                    var riderPdf = await BuildProcessedPdfAsync(bytes, contractId);
                    filesToMerge.Add(riderPdf);
                }

                #endregion

                #region 3️⃣ Merge PDFs

                if (!filesToMerge.Any())
                    return Tuple.Create(true, uploadIds);

                // Perform the merge while all underlying streams are still alive in Memory
                var finalPdf = PdfDocument.Merge(filesToMerge.ToArray());

                using (var finalStream = new MemoryStream())
                {
                    finalPdf.Save(finalStream);
                    finalStream.Position = 0;    
                    #region 4️⃣ Upload Bundle

                    var streams = new List<Stream> { finalStream };

                    var configValue = await DaoHelper.GetConfigurationValue("IsPandadocBundle");
                    var isBundle = bool.TryParse(configValue, out var result) && result;

                    if (isBundle)
                    {
                        var uploadResult = await CreateUploadBundle(documentId, recipients, streams);
                        isValid = uploadResult.Item1;
                        uploadIds = uploadResult.Item2;
                    }
                    else
                    {
                        isValid = true;
                    }

                    #endregion

                    // isValid is already set based on uploadResult or isBundle flag above
                }
                #endregion
            }
            catch (Exception ex)
            {
                logger.Error("PandaDoc Bundle Error: " + ex.Message, ex);
                isValid = false;
            }

            return Tuple.Create(isValid, uploadIds);
        }


        private bool PageContainsImageObjects(Page page)
        {
            try
            {
                // Check 1: Try the standard GetImages() method
                // Note: It is a method (), not a property
                var images = page.GetImages();
                if (images != null && images.Any())
                {
                    return true;
                }

                // Check 2: Paths (Vector graphics)
                if (page.ExperimentalAccess?.Paths != null)
                {
                    foreach (var path in page.ExperimentalAccess.Paths)
                    {
                        if (path.IsStroked || path.IsFilled)
                            return true;
                    }
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsPdfStream(Stream stream)
        {
            byte[] buffer = new byte[5];
            long pos = stream.Position;

            stream.Position = 0;
            stream.Read(buffer, 0, 5);
            stream.Position = pos;

            return System.Text.Encoding.ASCII.GetString(buffer) == "%PDF-";
        }

        public async Task SettingPdfPageAsync(PdfPage pdfPage, int contractId)
        {
            // Use local options to ensure thread-safety for concurrent requests
            var options = new HtmlToPdfOptions();
            options.OutputArea = new RectangleF(0.1f, 0.1f, pdfPage.Size.Width - 0.2f, pdfPage.Size.Height - 0.2f);
            options.PageSize = new SizeF(pdfPage.Size.Width, pdfPage.Size.Height);

            // Combined HTML for all 3 fields in a single rendering pass for maximum performance.
            // Absolute positioning ensures we stay within the boundaries PandaDoc expects.
            string html = $@"
                <div style='position:absolute; top:0px; right:10px; font-family:Arial, sans-serif; font-size:10pt; text-align:right;'>
                    CONTRACT #: {contractId}
                </div>
                <div style='position:absolute; bottom:15px; left:10px; font-family:Arial, sans-serif; font-size:10pt;'>
                    Presenter Signature:{{signature:Presenter_______}}
                </div>
                <div style='position:absolute; bottom:15px; right:10px; font-family:Arial, sans-serif; font-size:10pt; text-align:right;'>
                    Artist Signature:{{signature:Artist_______}}
                </div>";

            HtmlToPdf.ConvertHtml(html, pdfPage, options);
        }

        public async Task SettingPdfPageInitialsAsync(PdfPage pdfPage, int contractId)
        {
            // Use local options to ensure thread-safety
            var options = new HtmlToPdfOptions();
            options.OutputArea = new RectangleF(0.1f, 0.1f, pdfPage.Size.Width - 0.2f, pdfPage.Size.Height - 0.2f);
            options.PageSize = new SizeF(pdfPage.Size.Width, pdfPage.Size.Height);

            string html = $@"
                <div style='position:absolute; top:0px; right:10px; font-family:Arial, sans-serif; font-size:10pt; text-align:right;'>
                    CONTRACT #: {contractId}
                </div>
                <div style='position:absolute; bottom:15px; left:10px; font-family:Arial, sans-serif; font-size:10pt;'>
                    Presenter Initials:{{initials:Presenter_______}}
                </div>
                <div style='position:absolute; bottom:15px; right:10px; font-family:Arial, sans-serif; font-size:10pt; text-align:right;'>
                    Artist Initials:{{initials:Artist_______}}
                </div>";

            HtmlToPdf.ConvertHtml(html, pdfPage, options);
        }

        public async Task<Tuple<bool, List<string>>> UpdatebundleDocumentsForPandadocAsync(int contractId, string documentId, List<Recipient> recipients, List<Stream> ridersAndaddendums)
        {
            bool isValid = true;
            List<string> uploadIds = null;
            try
            {
                List<PdfDocument> pdfDocuments = new List<PdfDocument>();

                foreach (var st in ridersAndaddendums)
                {
                    st.Position = 0;
                    var rider = new PdfDocument(st);
                    try
                    {
                        var blankPages = new List<int>();
                        if (IsPdfStream(st))
                        {
                            st.Position = 0;
                            using (var document = PdfPigDoc.Open(st))
                            {
                                int index = 0;

                                foreach (var page in document.GetPages())
                                {
                                    string text = page.Text?.Trim();

                                    if (string.IsNullOrWhiteSpace(text) && !PageContainsImageObjects(page))
                                    {
                                        blankPages.Add(index);
                                    }
                                    index++;
                                }
                            }
                        }

                        int previouspage = 0;
                        foreach (int index in blankPages.OrderBy(a => a))
                        {
                            var actualIndex = index - previouspage;
                            if (actualIndex >= 0 && actualIndex < rider.Pages.Count)
                            {
                                rider.Pages.RemoveAt(actualIndex);
                                previouspage++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                        var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        log.Error(ex);
                    }


                    foreach (var field in rider.Fields)
                    {
                        if (field.FullName == "Contract_Number")
                        {
                            field.Value = contractId.ToString();
                        }


                    }


                    int pageCount = rider.Pages.Count - 1;
                    for (int i = 0; i < rider.Pages.Count; i++)
                    {

                        if (pageCount == i)
                        {
                            await SettingPdfPageAsync(rider.Pages[i], contractId);
                        }
                        else
                        {
                            await SettingPdfPageInitialsAsync(rider.Pages[i], contractId);
                        }

                    }

                    pdfDocuments.Add(rider);
                }
                var finalPdf = new PdfDocument();
                if (pdfDocuments.Any())
                {
                    finalPdf = PdfDocument.Merge(pdfDocuments.ToArray());
                    var ms = new MemoryStream();


                    finalPdf.Save(ms);
                    ms.Position = 0;

                    List<Stream> streams = new List<Stream>();
                    if (ms.Length > 0)
                    {
                        streams.Add(ms);
                    }
                    if (streams.Any())
                    {

                        var value = await DaoHelper.GetConfigurationValue("IsPandadocBundle");
                        var isPandadocBundle = false;
                        try
                        {
                            if (!string.IsNullOrEmpty(value))
                            {
                                isPandadocBundle = Convert.ToBoolean(value);
                            }
                        }
                        catch { }

                        if (isPandadocBundle)
                        {
                            var result = await CreateUploadBundle(documentId, recipients, streams);
                            isValid = result.Item1;
                            uploadIds = result.Item2;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
                isValid = false;
            }
            var tuple = new Tuple<bool, List<string>>(isValid, uploadIds);
            return tuple;
        }

        public async Task<Tuple<bool, MemoryStream>> GetContractTermsAndCondtion(string termsAndConditonHtml, string contractNumber = null, string agentName = null)
        {
            var tuple = new Tuple<bool, MemoryStream>(false, null);
            if (contractNumber == null)
            {
                contractNumber = "000000";
            }

            if (agentName == null)
            {
                agentName = "Testing Purpose";
            }
            try
            {
                var msTC = new MemoryStream();

                if (termsAndConditonHtml != null)
                {
                    PdfDocument pdfDocument = new PdfDocument();

                    string url = string.Empty;
                    if (MobiusConfiguration.IsDevelopment())
                    {
                        url = MobiusConfiguration.GetString("Application.Url");
                    }
                    else
                    {
                        url = MobiusConfiguration.GetString("Application.Other");
                    }

                    string html = @"
                            <!DOCTYPE html>
                            <html lang='en'>
                            <head>
                           <link rel='stylesheet' href='" + url + @"Content/Site.min.css' >
                            
 <link href='https://fonts.googleapis.com/css?family=Archivo+Narrow' rel='stylesheet'>
    <link href = 'https://fonts.googleapis.com/css?family=Lato' rel = 'stylesheet'>
   
     <link rel='stylesheet' href='" + url + @"Content/DynamicTermsAndCondition.css' >

                            
                            </head>
                            <body>
   <div class='row'>
        <div class='col-xs-4'>
            Do Not Staple<br /><br />
            P.O.Box 73210<br />
            North Chesterfield<br />
            VA 23235
        </div>
        <div class='col-xs-4 text-center'>
            <img class='header-logo' style='width:200px' src='" + url + @"Content/images/ece_new_logo_no_sm_text.png' /><br /><br />
        </div>
        <div class='col-xs-4'>
                    <div class='container-fluid' style='padding:0'>
                        <div class='row'>
                            <div class='col-xs-12'>
                                <div class='pull-right' style='margin-top:15px'>
                                <div class='tooltip-container'>
                                        <span class='tooltip-text'>Contract:</span>
                                        <div class='info-box' style='padding:0px 10px 0px 10px'>
                                            <legend>Contract:</legend>
                                            <p style='margin-top:11px'><strong>Contract #</strong> " + contractNumber + @"</p>
                                        <p style='margin-top:-7px'><strong>Agent</strong>  " + agentName + @"</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    </div>
                            <div class='panel panel-default'><div class='panel-body'><div class='paragraphcls'>" + termsAndConditonHtml +
                            @"<p  style='margin-top:15px;'></p> 
                                </div>
                            </div></div></div>
                            </body>
                            </html>";
                    HtmlToPdf.Options.PageSize = new SizeF(8.5f, 11f); //US Letter
                    float pageWidth = HtmlToPdf.Options.PageSize.Width;  // Default width for A4
                    float pageHeight = HtmlToPdf.Options.PageSize.Height; // Default height for A4
                    float leftMargin = 0.6f;  // 50 points (about 0.7 inches)
                    float rightMargin = 0.45f;
                    float topMargin = 0.4f;   // Reduced top margin (20 points = ~0.28 inches)
                    float bottomMargin = 0.4f; // Reduced bottom margin

                    HtmlToPdf.Options.OutputArea = new System.Drawing.RectangleF(
                        leftMargin, // Left margin
                        topMargin,  // Top margin
                        pageWidth - leftMargin - rightMargin, // Content width
                        pageHeight - topMargin - bottomMargin // Content height
                    );

                    HtmlToPdf.ConvertHtml(html, pdfDocument);

                    pdfDocument.Save(msTC);
                    msTC.Position = 0;
                    return new Tuple<bool, MemoryStream>(true, msTC);
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }



            return tuple;
        }


        public async Task<Tuple<string, MemoryStream>> GetPandaDocTemplateIdAndContractTermsAndCondtion(int contractId)
        {
            try
            {
                string pandaDocTemplateId = string.Empty;
                MemoryStream ms = null;

                var contract = await _eceCrmEntities.Contracts
                    .FirstOrDefaultAsync(c => c.ContractId == contractId);
                if (contract == null)
                    throw new ArgumentException("Contract not found!");

                var contractTemplate = await _eceCrmEntities.ContractTemplateHistory
                    .FirstOrDefaultAsync(ct => ct.ContractId == contract.ContractId);
                if (contractTemplate == null)
                    throw new ArgumentException("Contract template history not found!");

                string content = contractTemplate.ContentTermsAndCondition;
                pandaDocTemplateId = contractTemplate.PandaDocMainTemplateId;

                if (string.IsNullOrWhiteSpace(pandaDocTemplateId))
                    throw new ArgumentException("PandaDoc Template Id is empty!");

                if (string.IsNullOrWhiteSpace(content))
                    throw new ArgumentException("Terms and conditions HTML content is empty!");

                var agent = await _eceCrmEntities.AppUsers
                    .FirstOrDefaultAsync(u => u.AppUserId == contract.AgentId);
                if (agent == null)
                    throw new ArgumentException("Agent not found!");

                string agentName = $"{agent.FirstName} {agent.LastName}";

                // Retry logic
                const int maxRetries = 3;
                for (int retry = 0; retry < maxRetries; retry++)
                {
                    var (isSuccess, stream) = await GetContractTermsAndCondtion(
                        content,
                        contract.ContractId.ToString(),
                        agentName
                    );

                    if (isSuccess)
                    {
                        ms = stream;
                        break;
                    }

                    await Task.Delay(5000); // Wait 1 second before retrying
                }

                return Tuple.Create(pandaDocTemplateId, ms);
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
                return Tuple.Create(string.Empty, (MemoryStream)null);
            }
        }

        public async Task SetPandaDocTemplateIdAndContractTermsAndCondtion(int contractId)
        {
            try
            {
                var value = DaoHelper.GetConfigurationValue("DynamicallyApplyTermsAndConditions").Result;
                DateTime dateTime = DateTime.Now.AddDays(10);
                try
                {
                    if (!string.IsNullOrEmpty(value))
                    {
                        dateTime = Convert.ToDateTime(value);
                    }
                }
                catch { }
                var contract = await _eceCrmEntities.Contracts.FirstOrDefaultAsync(a => a.ContractId == contractId);

                if (contract != null && contract.CreatedDate.Date >= dateTime.Date)
                {

                    int contractTypeId = contract.ContractTypeId ?? 0;

                    bool isBuySell = contract.IsBuySell ?? false;

                    bool isNationalContract =
                        contract.LineOfBusinessId.HasValue &&
                        contract.LineOfBusinessId.Value == (int)LineOfBusiness.National;


                    int contractTemplateTypeId = 0;


                    if (contract.LineOfBusinessId.Value == (int)LineOfBusiness.National)
                    {
                        if (isBuySell)
                        {
                            contractTemplateTypeId = (int)ECEContractTemplateType.NationalContractWithBuySell;
                        }
                        else if (contractTypeId == (int)ContractType.Special)
                        {
                            contractTemplateTypeId = (int)ECEContractTemplateType.NationalContractWithSpecial;
                        }
                        else
                        {
                            contractTemplateTypeId = (int)ECEContractTemplateType.NationalContractOnly;
                        }
                    }
                    else if (contract.IsBuySell.Value)
                    {
                        contractTemplateTypeId = (int)ECEContractTemplateType.BuySell;
                    }
                    else if (contractTypeId == (int)ContractType.Standard)
                    {
                        contractTemplateTypeId = (int)ECEContractTemplateType.Standard;
                    }
                    else if (contractTypeId == (int)ContractType.Special)
                    {
                        contractTemplateTypeId = (int)ECEContractTemplateType.Special;
                    }



                    var contractTemplateHis = await _eceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.ContractId == contractId);
                    if (contractTemplateHis == null || (contract.IsPandaDoc && string.IsNullOrWhiteSpace(contractTemplateHis.PandaDocMainTemplateId)))
                    {
                        var pandaDocTemplate = await _eceCrmEntities.LuPandaDocTemplate.Where(a => a.ContractTemplateTypeId == contractTemplateTypeId && a.IsActive && !a.IsDeleted && DbFunctions.TruncateTime(a.EffectiveStartDate) <= DbFunctions.TruncateTime(contract.CreatedDate)).OrderByDescending(a => a.PandaDocTemplateId).FirstOrDefaultAsync();

                        var mainTermsAndCondition = await _eceCrmEntities.LuMainTermsandCondition.Where(a => a.ContractTemplateTypeId == contractTemplateTypeId && a.IsActive && !a.IsDeleted && DbFunctions.TruncateTime(a.EffectiveStartDate) <= DbFunctions.TruncateTime(contract.CreatedDate)).OrderByDescending(a => a.MainTermsandConditionId).FirstOrDefaultAsync();
                        if (mainTermsAndCondition != null && pandaDocTemplate != null)
                        {
                            if (contractTemplateHis == null)
                            {
                                contractTemplateHis = new ContractTemplateHistory();
                                contractTemplateHis.ContractId = contractId;
                                _eceCrmEntities.ContractTemplateHistory.Add(contractTemplateHis);
                            }

                            contractTemplateHis.ContentTermsAndCondition = mainTermsAndCondition.Content;
                            contractTemplateHis.MainTermsandConditionId = mainTermsAndCondition.MainTermsandConditionId;
                            contractTemplateHis.PandaDocMainTemplateId = pandaDocTemplate.PandaDocMainTemplateId;
                            contractTemplateHis.PandaDocTemplateId = pandaDocTemplate.PandaDocTemplateId;

                        }
                        else if (contractTemplateHis == null && mainTermsAndCondition != null && !contract.IsPandaDoc)
                        {

                            ContractTemplateHistory contractTemplateHistory = new ContractTemplateHistory();

                            contractTemplateHistory.ContractId = contractId;
                            contractTemplateHistory.ContentTermsAndCondition = mainTermsAndCondition.Content;
                            contractTemplateHistory.MainTermsandConditionId = mainTermsAndCondition.MainTermsandConditionId;
                            _eceCrmEntities.ContractTemplateHistory.Add(contractTemplateHistory);
                        }
                        await _eceCrmEntities.SaveChangesAsync();
                    }

                }

            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }
        }
        public async Task SetPandaDocSignatureForContractAsync(string pandaDocDocumentId, string emailid)
        {
            var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");

            try
            {
                var contractTemplate = await _eceCrmEntities.ContractTemplateHistory
                    .FirstOrDefaultAsync(a => a.PandaDocDocumentId == pandaDocDocumentId);

                if (contractTemplate == null)
                    return;

                int contractId = contractTemplate.ContractId;

                //var contactList = await _eceCrmEntities.Contacts
                //    .Where(a => a.EmailAddress == emailid)
                //    .ToListAsync();

                //if (!contactList.Any())
                //    return;

                var contract = await _eceCrmEntities.Contracts.Include(a => a.ContractArtists).FirstOrDefaultAsync(a => a.ContractId == contractId);


                if (contract == null)
                    return;



                //var contractArtists = await _eceCrmEntities.ContractArtists.Where(a => a.ContractId == contractId).ToListAsync();
                var signatoryTypesToCheckPresenter = new List<int> { (int)EntityType.Presenter, (int)EntityType.Contract };

                var existingSignaturePresenter = await _eceCrmEntities.ContractSignatures
                    .FirstOrDefaultAsync(a => a.ContractId == contractId &&
                                              signatoryTypesToCheckPresenter.Contains(a.EntityTypeId) &&
                                              a.IsReceived);


                var signatoryTypesToCheckArtist = new List<int> { (int)EntityType.Artist };

                var existingSignatureArtist = await _eceCrmEntities.ContractSignatures
                    .FirstOrDefaultAsync(a => a.ContractId == contractId &&
                                              signatoryTypesToCheckArtist.Contains(a.EntityTypeId) &&
                                              a.IsReceived);

                int entityId = 0;
                int signatoryTypeId;

                if (existingSignaturePresenter == null && existingSignatureArtist==null)
                {
                    signatoryTypeId = (int)EntityType.Presenter;
                    entityId = contract.PresenterId ?? 0;
                }
                else if (existingSignaturePresenter != null && existingSignatureArtist == null)
                {
                    signatoryTypeId = (int)EntityType.Artist;
                    if (contract.ContractArtists.Any())
                    {
                        entityId = contract.ContractArtists.FirstOrDefault()?.ArtistId ?? 0;
                    }
                }
                else
                {
                    return;
                }

                try
                {
                    var existingSignatures = await _eceCrmEntities.ContractSignatures
                        .Where(a => a.ContractId == contractId && a.EntityTypeId == signatoryTypeId && a.EntityId != entityId)
                        .ToListAsync();


                    if (existingSignatures.Any())
                    {
                        foreach (var item in existingSignatures)
                        {
                            _eceCrmEntities.ContractSignatures.Remove(item);
                        }
                        await _eceCrmEntities.SaveChangesAsync();
                    }
                }
                catch (Exception ex)
                {
                    logger.Error("Error removing extra ContractSignatures", ex);
                }

                var currentSignature = await _eceCrmEntities.ContractSignatures
                    .FirstOrDefaultAsync(a => a.ContractId == contractId && a.EntityTypeId == signatoryTypeId);

                if (currentSignature != null)
                {
                    currentSignature.ReceivedDate = DateTime.Now;
                    currentSignature.IsReceived = true;
                    currentSignature.UpdatedById = 999999;
                    currentSignature.UpdatedDate = DateTime.Now;
                }
                else
                {
                    var newSignature = new ContractSignature
                    {
                        ContractId = contractId,
                        EntityId = entityId,
                        EntityTypeId = signatoryTypeId,
                        ReceivedDate = DateTime.Now,
                        DueDate = DateTime.Now.AddDays(7),
                        IsReceived = true,
                        CreatedById = 999999,
                        CreatedDate = DateTime.Now
                    };
                    _eceCrmEntities.ContractSignatures.Add(newSignature);
                }

                var entityTypeIdArtist = (int)EntityType.Artist;

                var currentSignatureForArtist = await _eceCrmEntities.ContractSignatures
                    .FirstOrDefaultAsync(a => a.ContractId == contractId && a.EntityTypeId == entityTypeIdArtist);

                if (currentSignatureForArtist == null)
                {
                    var contractArtist = await _eceCrmEntities.ContractArtists
                    .FirstOrDefaultAsync(a => a.ContractId == contractId);
                    if (contractArtist != null)
                    {
                        var newSignature = new ContractSignature
                        {
                            ContractId = contractId,
                            EntityId = contractArtist.ArtistId,
                            EntityTypeId = entityTypeIdArtist,
                            DueDate = DateTime.Now.AddDays(15),
                            IsReceived = false,
                            CreatedById = 999999,
                            CreatedDate = DateTime.Now
                        };
                        _eceCrmEntities.ContractSignatures.Add(newSignature);
                    }
                }

                await _eceCrmEntities.SaveChangesAsync();

                string actionNote = signatoryTypeId == (int)EntityType.Presenter
                    ? ContractFileLabels.PresenterSigned
                    : signatoryTypeId == (int)EntityType.Artist
                        ? ContractFileLabels.ArtistSigned
                        : string.Empty;

                await AddContractPDFBackup(contractId, actionNote);

                try
                {
                    var artistTypeId = (int)EntityType.Artist;
                    var isArtist = signatoryTypeId == artistTypeId;
                    var isPresenter = signatoryTypeId == (int)EntityType.Presenter;

                    var contractSignature = await _eceCrmEntities.ContractSignatures
                        .FirstOrDefaultAsync(a => a.ContractId == contractId && a.EntityTypeId == artistTypeId);

                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.NameIdentifier, "999999"),
                        new Claim(ClaimTypes.Name, "SYSTEM")
                    };
                    var user = new ClaimsPrincipal(new ClaimsIdentity(claims));

                    var contractDto = Mapper.Map<ContractDto>(contract);
                    contractDto.SignatureProgress = await this.Context.Signatures.GetSignatoriesByContractAsync(contractDto);
                    contractDto.EventDatesObject = await this.Context.ContractEventDates.GetByContractIdAsync(contractDto.ContractId);
                    if (isPresenter && contractSignature != null && contractDto != null)
                    {
                        await HandlePresenterSignatureAsync(contractSignature, contractDto, user);

                        // Create alert for contract agent when presenter signs
                        try
                        {
                            var appEvent = await this._lookupService.GetAppEventTypeAsync(AppEventType.ContractSigned);
                            var presenterName = contract.PresenterAccountName ?? "Presenter";
                            var alertText = appEvent.Text
                                            .Replace("{ContractId}", contractId.ToString())
                                            .Replace("{Name}", presenterName);

                            var alert = new AlertDto
                            {
                                AppUserId = contract.AgentId,
                                Description = alertText,
                                IsRead = false,
                                EntityTypeId = (int)EntityType.Contract,
                                EntityId = contract.ContractId,
                                AppEventTypeId = (int)AppEventType.ContractSigned
                            };

                            alert.SetAsCreated(999999);
                            _eceCrmEntities.Alerts.Add(Mapper.Map<Alert>(alert));
                            await _eceCrmEntities.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                            logger.Error("Error creating presenter signature alert", ex);
                        }
                    }
                    else if (isArtist && contractDto != null)
                    {
                        await HandleArtistSignatureAsync(contract, contractDto, user);
                    }
                }
                catch (Exception ex)
                {
                    logger.Error("Error in Send Artist Signature", ex);
                }

                if (actionNote == ContractFileLabels.ArtistSigned)
                {
                    var contractUpdated = await _contractService.Value.GetByIdAsync(contractId);
                    await this._contractDynamicBackupService.CreateBackup(contractId, contract.UpdatedById.HasValue ? contract.UpdatedById.Value : contract.CreatedById);
                }

            }
            catch (Exception ex)
            {
                logger.Error("Error in SetPandaDocSignatureForContractAsync", ex);
            }
        }


        private async Task HandlePresenterSignatureAsync(ContractSignature contractSignature, ContractDto contractDto, ClaimsPrincipal user)
        {

            
                var artistUser = await _userService.GetUserByEntityAsync(contractSignature.EntityId, ECERole.Artist, true);
                if (artistUser != null)
                {
                    await _contractSignatureService.SendContractEmailForArtistPortalUserAsync(
                        artistUser.FirstName, artistUser.Username, contractDto, user);
                    return;
                }

            //var contractDoc = _documentService.GetDocuments(EntityType.Contract, contractDto.ContractId)
            //    .Where(x => x.DocumentTypeId == (int)DocumentType.Contract)
            //    .OrderByDescending(x => x.CreatedDate)
            //    .FirstOrDefault();

            //var contact = await _eceCrmEntities.Contacts
            //    .Where(c => c.EntityTypeId == (int)EntityType.Artist
            //                && c.EntityId == contractSignature.EntityId
            //                && !c.IsDeleted)
            //    .OrderByDescending(c => c.IsPrimary)
            //    .FirstOrDefaultAsync();

            //if (contractDoc != null && contact != null &&
            //    !string.IsNullOrWhiteSpace(contact.EmailAddress) &&
            //    contractDto.ContractTypeId == (int)ContractType.Standard &&
            //    contractDto.IsBuySell.HasValue && !contractDto.IsBuySell.Value)
            //{
            //    var message = await _contractSignatureService.SendContractEmailWithAttachmentPandaDocAsync(
            //        contact.EmailAddress, contact.FirstName, contractDto, contractDoc, contractSignature.EntityId);

            //    if (message != null)
            //    {
            //        var commLog = new CommunicationLogDto
            //        {
            //            CommunicationMethodId = (int)CommunicationMethod.Email,
            //            ContactId = contact.ContactId,
            //            EntityId = contractDto.ContractId,
            //            EntityTypeId = (int)EntityType.Contract,
            //            EmailQueueId = message.EmailQueueId,
            //            LogDate = DateTime.Now,
            //            LogTime = DateTime.Now.ToShortTimeString(),
            //            Notes = "Send artist the latest uploaded contract."
            //        };

            //        _communicationLogService.AddCommunicationLog(commLog, user);
            //    }
            //}
        }


        private async Task HandleArtistSignatureAsync(Contract contract, ContractDto contractDto, ClaimsPrincipal user)
        {
            if (contractDto.IsNoIssue == false && contractDto.SignatureProgress.All(x => x.SignatureReceived != null))
            {
                contractDto.ContractTransactions = await this.Context.ContractTransactions.GetByContractIdAsync(contractDto.ContractId);
                await _contractSignatureService.UpdateContractStatusAsync(contractDto, user);
                var contractContacts = await _contactService.GetContactsAsync(EntityType.Contract, contract.ContractId);
                var signatoryContact = contractContacts.FirstOrDefault(x => x.IsSigner);
                var signatoryEmailAddress = signatoryContact?.EmailAddress;

                if (!string.IsNullOrWhiteSpace(signatoryEmailAddress))
                {
                    var portal = await this.Context.Contracts.GetPresenterPortalForContractAsync(contract.ContractId);
                    if (portal == null)
                    {
                        portal = await _contractService.Value.CreatePresenterPortalAsync(contractDto, user);
                    }

                    portal.ParentContract = contractDto;

                    await _contractSignatureService.SendAllSignaturesReceivedEmailForPresenterPortalUserAsync(
                        signatoryContact, portal, user, contract.AgentId);
                }
            }
        }


        public async Task SetPandaDocSentSignatureAndStatusChangeForContractAsync(string pandaDocDocumentId, string presenterEmailid, string artistEmailid)
        {
            try
            {
                var contract = await _eceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.PandaDocDocumentId == pandaDocDocumentId);
                if (contract != null)
                {
                    int contractId = contract.ContractId;
                    var contact = await _eceCrmEntities.Contacts.FirstOrDefaultAsync(a => a.EmailAddress == presenterEmailid);
                    if (contact != null)
                    {
                        var contractSignature = await _eceCrmEntities.ContractSignatures.FirstOrDefaultAsync(a => a.ContractId == contractId && a.EntityId == contact.EntityId && a.EntityTypeId == contact.EntityTypeId);
                        if (contractSignature == null)
                        {
                            ContractSignature contractSignatureNew = new ContractSignature();
                            contractSignatureNew.ContractId = contractId;
                            contractSignatureNew.EntityId = contact.EntityId;
                            contractSignatureNew.EntityTypeId = contact.EntityTypeId;
                            contractSignatureNew.ReceivedDate = null;
                            contractSignatureNew.DueDate = DateTime.Now.AddDays(7);
                            contractSignatureNew.IsReceived = false;
                            contractSignatureNew.CreatedById = 999999;
                            contractSignatureNew.CreatedDate = DateTime.Now;
                            _eceCrmEntities.ContractSignatures.Add(contractSignatureNew);
                        }
                        else
                        {
                            contractSignature.ReceivedDate = null;
                            contractSignature.IsReceived = false;
                        }
                        await _eceCrmEntities.SaveChangesAsync();

                    }

                    var contactArtist = await _eceCrmEntities.Contacts.FirstOrDefaultAsync(a => a.EmailAddress == artistEmailid);
                    if (contactArtist != null)
                    {
                        var contractSignature = await _eceCrmEntities.ContractSignatures.FirstOrDefaultAsync(a => a.ContractId == contractId && a.EntityId == contactArtist.EntityId && a.EntityTypeId == contactArtist.EntityTypeId);
                        if (contractSignature == null)
                        {
                            ContractSignature contractSignatureNew = new ContractSignature();
                            contractSignatureNew.ContractId = contractId;
                            contractSignatureNew.EntityId = contactArtist.EntityId;
                            contractSignatureNew.EntityTypeId = contactArtist.EntityTypeId;
                            contractSignatureNew.ReceivedDate = null;
                            contractSignatureNew.DueDate = DateTime.Now.AddDays(7);
                            contractSignatureNew.IsReceived = false;
                            contractSignatureNew.CreatedById = 999999;
                            contractSignatureNew.CreatedDate = DateTime.Now;
                            _eceCrmEntities.ContractSignatures.Add(contractSignatureNew);
                        }
                        else
                        {
                            contractSignature.ReceivedDate = null;
                            contractSignature.IsReceived = false;
                        }
                        await _eceCrmEntities.SaveChangesAsync();

                    }

                    //var mainContract = await _eceCrmEntities.Contracts.FirstOrDefaultAsync(a => a.ContractId == contractId);
                    //if(mainContract!=null)
                    //{
                    //   if( mainContract.ContractStatusId==(int)ContractStatus.Created)
                    //    {
                    //        mainContract.IssueDate = DateTime.Now;
                    //        mainContract.ContractStatusId = (int)ContractStatus.Issued;
                    //    }
                    //}

                    //var claims = new List<Claim>();

                    //claims.Add(new Claim(ClaimTypes.NameIdentifier, "999999"));
                    //claims.Add(new Claim(ClaimTypes.Name, "SYSTEM"));

                    //var identity = new ClaimsIdentity(claims);
                    //ClaimsPrincipal principal = new ClaimsPrincipal(identity);

                    //await _eceCrmEntities.SaveChangesAsync();
                }


            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }
        }
        public async Task AddContractPDFBackup(int contractId, string Description = ContractFileLabels.BasicContract, List<string> uploadIds = null)
        {

            try
            {
                var sqlQuery = string.Format("Sp_Get_ContractTemplateHistoryContractWise @contractid={0}", contractId);
                //System.Threading.Thread.Sleep(1000);
                var contractTH = (await this._eceCrmEntities.SqlQueryAsync<ContractTemplateHistory>(sqlQuery)).FirstOrDefault();

                try
                {

                    bool isValid = false;

                    while (!isValid)
                    {
                        bool isCheck = true;

                        if (!uploadIds.Any() && contractTH != null)
                        {
                            isValid = true;
                            break;
                        }
                        if (uploadIds.Any())
                        {
                            foreach (var a in uploadIds)
                            {
                                var status = await GetPandaDocDocumentStatus(contractTH.PandaDocDocumentId, a);
                                if (isCheck)
                                {
                                    if (!(status.ToLower().Contains("processed") || status.ToLower().Contains("error")))
                                    {
                                        isCheck = false;
                                    }
                                }
                            }
                        }


                        if (isCheck)
                        {
                            isValid = true;
                            break;
                        }
                        if (!isValid)
                        {
                            System.Threading.Thread.Sleep(500);
                        }
                    }

                }
                catch (Exception ex)
                {
                    var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                    log.Error(ex);
                }

                var file = await this.DownloadDocument(contractTH.PandaDocDocumentId);

                if (file.Length > 0)
                {
                    Stream stream = new MemoryStream(file);


                    var name = "Contract_" + contractId.ToString() + "_" + DateTime.Now.ToString("MMM_dd_yyyy_hh_mm_ss_tt");
                    var ext = "PDF";

                    var documentDto = new DocumentDto()
                    {
                        Contents = stream,
                        OriginalFileName = name,
                        StorageFileName = name,
                        Description = Description,
                        DocumentTypeId = (int)DocumentType.Contract,
                        DocumentExtension = new LookupDto() { Text = ext },
                        IsContractPDF = true

                    };

                    try
                    {
                        this._documentService.AddDocumentTo(EntityType.Contract, contractId, documentDto, 999999);

                    }
                    finally
                    {
                        if (documentDto.Contents != null)
                        {
                            documentDto.Contents.Close();
                            documentDto.Contents.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                log.Error(ex);
            }
        }

        public async Task RemovePandaDocSignatureForContractAsync(string pandaDocDocumentId)
        {
            try
            {
                var contract = await _eceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.PandaDocDocumentId == pandaDocDocumentId);
                if (contract != null)
                {
                    int contractId = contract.ContractId;

                    //When both the presenter and the artist have signed, their Rockit signatures should not be removed after a partial or full cancellation.
                    var contractDto = await _contractService.Value.GetByIdAsync(contractId, true);
                    contractDto = this._contractService.Value.GetProgressAsync(contractDto);
                    if (contractDto.PresenterSigned && contractDto.ArtistSigned && (contractDto.ContractStatusId == (int)ContractStatus.Canceled || contractDto.ContractStatusId == (int)ContractStatus.PartiallyCanceled))
                    {
                        return;
                    }


                    var contractSignature = await _eceCrmEntities.ContractSignatures.Where(a => a.ContractId == contractId).ToListAsync();
                    foreach (var cs in contractSignature)
                    {
                        cs.IsReceived = false;
                        cs.ReceivedDate = null;
                        cs.UpdatedById = 999999;
                        cs.UpdatedDate = DateTime.Now;
                    }
                    await _eceCrmEntities.SaveChangesAsync();
                    //999999

                }


            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }
        }

        public async Task<Tuple<bool, bool, List<RiderAndAddendumDto>>> GetIsCreateNewContratact(int contractId)
        {
            bool isNew = false;
            var randa = new List<RiderAndAddendumDto>();
            var tuple = new Tuple<bool, bool, List<RiderAndAddendumDto>>(false, isNew, randa);

            try
            {
                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var conn = sqlConnectionFactory.CreateConnection();
                    var dp = new DynamicParameters();
                    dp.Add("@contractId", contractId);
                    var multiObj = await conn.QueryMultipleAsync("Sp_get_isCreateNewContratact @contractId", dp);
                    isNew = (await multiObj.ReadAsync<bool>()).FirstOrDefault();
                    randa = (await multiObj.ReadAsync<RiderAndAddendumDto>()).ToList();
                }
                tuple = new Tuple<bool, bool, List<RiderAndAddendumDto>>(true, isNew, randa);
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }

            return tuple;
        }



        public async Task<bool> AddOrUpdateContractPandaDocAsync(PandaDocRequestContractInfoDto contractInfo, string subject = null, string body = null,bool onIssue = false)
        {
            bool status = true;

            if (contractInfo.ContractNumber == null || contractInfo.ContractNumber <= 0)
            {
                throw new ArgumentException("Contract Number not Found!");
            }

            var contractId = contractInfo.ContractNumber;

            var contracth = (await this._eceCrmEntities
                .SqlQueryAsync<ContractTemplateHistory>(
                    "SELECT TOP 1 * FROM ContractTemplateHistory WHERE ContractId = @ContractId",
                    new SqlParameter("@ContractId", contractId)
                ))
                .FirstOrDefault();
            if (contracth == null)
            {
                throw new ArgumentException("Contract Template Histories not Found!");
            }
            try
            {
                await this.DraftDocument(contracth.PandaDocDocumentId);
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);

            }

            try
            {

                var (isValid, isNew, riderAndAddendumList) = await this.GetIsCreateNewContratact(contractInfo.ContractNumber);


                if (isValid)
                {
                    //Below is the logic used to retrieve all previous draft documents from PandaDoc and Sigantures.
                    await UpdatePreviousDraftDocumentsAsync(contractInfo.ContractNumber);

                    if (isNew)
                    {
                        var (isValidDocument, message, documentId) = await this.CreateDocument(contractInfo);
                        contracth = await this._eceCrmEntities.ContractTemplateHistory.FirstOrDefaultAsync(a => a.ContractId == contractInfo.ContractNumber);
                        contracth.PandaDocDocumentId = documentId;
                        contracth.PandaDocExpirationDate = null;
                        contracth.PandaDocExpirationAlertSentDate = null;
                        await this._eceCrmEntities.SaveChangesAsync();
                        if (isValidDocument)
                        {
                           SetPDFChanges(contractInfo.ContractNumber);
                        }
                    }
                    else
                    {
                        List<RiderAndAddendumDto> randa = riderAndAddendumList;
                        contracth = (await this._eceCrmEntities
                                    .SqlQueryAsync<ContractTemplateHistory>(
                                        "SELECT TOP 1 * FROM ContractTemplateHistory WHERE ContractId = @ContractId",
                                        new SqlParameter("@ContractId", contractId)
                                    ))
                                    .FirstOrDefault();
                        if (contracth != null)
                        {
                            var tupleUpdate = await this.UpdateDocument(contracth.PandaDocDocumentId, contractInfo);

                            if (tupleUpdate.Item1)
                            {
                                List<Stream> streams = new List<Stream>();
                                var contractRiders = await this._eceCrmEntities.ContractDocuments.Where(a => a.ContractId == contractInfo.ContractNumber && a.IsRider && !a.IsDeleted).ToListAsync();
                                var contractAddendum = await this._eceCrmEntities.AddendumDocument.Where(a => a.ContractId == contractInfo.ContractNumber && !a.IsDeleted && a.IsPrimary).ToListAsync();
                                var libraryName = "GenericRiders";
                                foreach (var i in randa.OrderBy(a => a.createddate))
                                {
                                    try
                                    {
                                        EntityType entityType;
                                        DocumentDto documentDto = new DocumentDto();

                                        if (i.documentType == "rider")
                                        {
                                            var cr = contractRiders.FirstOrDefault(a => a.ContractDocumentId == i.documentTypeId);

                                            entityType = (EntityType)cr.OriginalEntityTypeId;
                                            documentDto = await this._documentService.GetByIdAsync(cr.DocumentId);
                                        }
                                        else
                                        {
                                            var cr = contractAddendum.FirstOrDefault(a => a.AddendumDocumentId == i.documentTypeId);

                                            entityType = (EntityType)cr.OriginalEntityTypeId;
                                            documentDto = await this._documentService.GetByIdAsync(cr.DocumentId);
                                        }


                                        if (documentDto.DocumentExtensionId != (int)DocumentExtension.PDF)
                                        {
                                            continue;
                                        }

                                        var blobId = Guid.Parse(documentDto.StorageFileName);

                                        var blobLibrary = this._blobStorageProvider.GetBlobLibrary(entityType.ToString());
                                        var blob = blobLibrary.GetBlob(blobId);
                                        if (blob.Size < 0)
                                        {
                                            blobLibrary = this._blobStorageProvider.GetBlobLibrary(libraryName);
                                            blob = blobLibrary.GetBlob(blobId);
                                        }

                                        if (blob.Size >= 0)
                                        {
                                            var docMs = new MemoryStream();
                                            blob.RetrieveToStream(docMs);
                                            docMs.Position = 0;
                                            streams.Add(docMs);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                        logger.Error(ex);

                                    }
                                }

                                if (streams != null && streams.Any())
                                {
                                    var result = await UpdatebundleDocumentsForPandadocAsync(
                                        contractInfo.ContractNumber,
                                        contracth.PandaDocDocumentId,
                                        tupleUpdate.Item4,
                                        streams);

                                    if (result.Item1)
                                    {
                                        try
                                        {
                                            using (var sqlConnectionFactory = new SqlConnectionFactory())
                                            {
                                                var conn = sqlConnectionFactory.CreateConnection();
                                                var dp = new DynamicParameters();
                                                dp.Add("@contractId", contractInfo.ContractNumber);

                                                await conn.ExecuteAsync(
                                                    "Sp_set_RiderAndAddendumforHistory @contractId",
                                                    dp);
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            await Helper.LogError("UpdatebundleDocumentsForPandadoc", ex);
                                        }

                                        await HandleContractPdfBackupAsync(
                                            contractInfo.ContractNumber,
                                            result.Item2);
                                    }
                                    else
                                    {
                                        // CRITICAL: If bundle upload failed, we must NOT send the document
                                        // Return false so the user keeps seeing the error instead of sending a truncated document.
                                        return false;
                                    }
                                }
                                else
                                {
                                    await HandleContractPdfBackupAsync(
                                        contractInfo.ContractNumber,
                                        null);
                                }

                                SetPDFChanges(contractInfo.ContractNumber);
                            }
                        }

                    }

                    contracth = (await this._eceCrmEntities
                                    .SqlQueryAsync<ContractTemplateHistory>(
                                        "SELECT TOP 1 * FROM ContractTemplateHistory WHERE ContractId = @ContractId",
                                        new SqlParameter("@ContractId", contractId)
                                    ))
                                    .FirstOrDefault();
                    if (contracth != null && onIssue)
                    {
                        status = await this.SendDocument(contracth.PandaDocDocumentId, subject, body);
                    }
                }
                else
                {
                    status = isValid;
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
                status = false;
            }

            return status;
        }

        private async Task HandleContractPdfBackupAsync(int contractId, List<string> uploadIds)
        {
            try
            {
                var riderAndAddendum =
                    await _eceCrmEntities.RiderAndAddendumHistory
                        .FirstOrDefaultAsync(a =>
                            a.ContractId == contractId &&
                            a.DocumentType == "addendum");

                if (riderAndAddendum == null)
                {
                    await AddContractPDFBackup(
                        contractId,
                        uploadIds: uploadIds);
                }
                else
                {
                    await AddContractPDFBackup(
                        contractId,
                        ContractFileLabels.BasicContractWithAmendment,
                        uploadIds);
                }
            }
            catch (Exception ex)
            {
                await Helper.LogError("HandleContractPdfBackup", ex);
            }
        }

        public async Task<string> GetPandaDocDocumentStatus(string documentId, string uploadId)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");
                HttpResponseMessage response = await client.GetAsync($"{ApiUrl}/documents/{documentId}/sections/uploads/{uploadId}");

                if (!response.IsSuccessStatusCode)
                {
                    return "Error fetching status";
                }

                string jsonResponse = await response.Content.ReadAsStringAsync();
                var doc = JsonConvert.DeserializeObject<DocumentStatusDto>(jsonResponse);
                return doc.Status;
            }


        }

        public async Task<string> GetCheckPandaDocMaintDocStatusAsync(string documentId)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");
                HttpResponseMessage response = await client.GetAsync($"{ApiUrl}/documents/{documentId}");

                if (!response.IsSuccessStatusCode)
                {
                    return "Error fetching status";
                }

                string jsonResponse = await response.Content.ReadAsStringAsync();
                var doc = JsonConvert.DeserializeObject<MainDocumentStatusResponse>(jsonResponse);
                return doc.status;
            }


        }

        public async Task SendMailAsPerStatusWiseForPandaDoc(string status, string pandaDocDocumentId, int sendBy, object data = null)
        {

            if (status.ToLower().Trim() == "document.declined")
            {
                var contractTH = await _eceCrmEntities.ContractTemplateHistory.Where(a => a.PandaDocDocumentId == pandaDocDocumentId).FirstOrDefaultAsync();
                if (contractTH != null)
                {

                    var contractId = contractTH.ContractId;

                    var contract = await _eceCrmEntities.Contracts.Where(a => a.ContractId == contractId).FirstOrDefaultAsync();

                    if (contract != null && data != null)
                    {
                        var declineObject = (DeclineRecipient)data;

                        var decliner = Convert.ToString(declineObject.first_name) + " " + Convert.ToString(declineObject.last_name);
                        var layoutTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.RockItDefaultLayoutTemplate);
                        var bodyTemplate = await _lookupService.GetEmailTemplateAsync((int)EmailTemplate.SignatureDeclinedforcontract);

                        var email = new TemplateMailMessage(bodyTemplate.EmailTemplateId);
                        var agent = await _eceCrmEntities.AppUsers.Where(a => a.AppUserId == contract.AgentId).FirstOrDefaultAsync();
                        if (agent != null)
                        {
                            string appName = MobiusConfiguration.GetString("Application.Name");
                            string supportEmail = MobiusConfiguration.GetString("Email.SupportAddress");

                            var subject = bodyTemplate.Subject.Replace("{AppName}", appName).Replace("{ContractNo}", contractId.ToString());

                            var bodyBuilder = new StringBuilder(layoutTemplate.Body);
                            var body = bodyBuilder.Replace("{Body}", bodyTemplate.Body)
                                .Replace("{ReceiverName}", agent.FirstName + " " + agent.LastName)
                                .Replace("{ContractNo}", contractId.ToString())
                                .Replace("{Decliner}", decliner)
                                .Replace("{SupportEmail}", supportEmail)
                                .Replace("{AppName}", appName)
                                .Replace("''", "'")
                                .ToString();

                            email.Subject = subject;
                            email.Body = body;
                            email.IsBodyHtml = bodyTemplate.IsHtml;


                            email.To.Add(agent.Username);


                            var systemAdminId = (int)ECERole.SysAdmin;
                            var admins = await (from au in _eceCrmEntities.AppUsers
                                                join ro in _eceCrmEntities.AppUserRoles on au.AppUserId equals ro.AppUserId
                                                where ro.RoleId == systemAdminId && au.IsActive && !ro.IsDeleted && au.AppUserId != agent.AppUserId
                                                select au).ToListAsync();
                            foreach (var a in admins)
                            {
                                email.CC.Add(a.Username);
                            }

                            this.Context.BeginTransaction();

                            try
                            {
                                var smtpManager = new SmtpManager(this.Context);

                                // Send the message, bypassing the email message queue.
                                smtpManager.SendMessage(email, sendBy, SendMessageMode.Directly);

                                this.Context.Commit();
                            }
                            catch (Exception ex)
                            {
                                this.Context.Rollback();
                                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                log.Error(ex);
                            }



                            try
                            {

                                MessageDto model = new MessageDto();
                                model.SenderId = 999999;
                                model.RecipientId = agent.AppUserId;
                                model.EntityId = contractId;
                                model.EntityTypeId = (int)EntityType.Contract;

                                model.Body = "The " + decliner + " has declined to sign the contract # " + Convert.ToString(contractId);
                                model.Subject = "Signature Declined for contract # " + Convert.ToString(contractId);


                                var identity = new ClaimsIdentity("Custom");
                                identity.AddClaim(new Claim(ClaimTypes.Name, "System"));
                                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, "999999"));
                                var principal = new GenericPrincipal(identity, new[] { "SystemAdmin" });

                                await this._messageService.CreateAsync(model, principal);



                            }
                            catch (Exception ex)
                            {
                                var log = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                                log.Error(ex);
                            }
                        }
                    }
                }
            }
        }


        public async Task<List<RecipientDatail>> GetRecipientsContractAsync(string documentId)
        {
            List<RecipientDatail> recipientDetails = null;

            try
            {
                using (var client = new HttpClient())
                {
                    using (var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/{documentId}/details"))
                    {
                        request.Headers.Add("Authorization", $"API-Key {ApiKey}");

                        var response = await client.SendAsync(request);
                        if (response.IsSuccessStatusCode)
                        {
                            var content = await response.Content.ReadAsStringAsync();
                            if (!string.IsNullOrWhiteSpace(content))
                            {
                                var json = JObject.Parse(content);
                                var recipientsToken = json["recipients"];
                                if (recipientsToken != null)
                                {
                                    recipientDetails = JsonConvert.DeserializeObject<List<RecipientDatail>>(recipientsToken.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error("Error in GetRecipientsContractAsync", ex);
            }

            return recipientDetails;
        }

        public async Task SyncPandaDocExpirationDateAsync(string pandaDocDocumentId)
        {
            var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");

            if (string.IsNullOrWhiteSpace(pandaDocDocumentId))
            {
                return;
            }

            try
            {
                var contractTemplate = await _eceCrmEntities.ContractTemplateHistory
                    .FirstOrDefaultAsync(a => a.PandaDocDocumentId == pandaDocDocumentId);

                if (contractTemplate == null)
                {
                    return;
                }

                using (var client = new HttpClient())
                {
                    using (var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl}/documents/{pandaDocDocumentId}/details"))
                    {
                        request.Headers.Add("Authorization", $"API-Key {ApiKey}");

                        var response = await client.SendAsync(request);
                        if (!response.IsSuccessStatusCode)
                        {
                            return;
                        }

                        var content = await response.Content.ReadAsStringAsync();
                        if (string.IsNullOrWhiteSpace(content))
                        {
                            return;
                        }

                        var json = JObject.Parse(content);
                        var expirationToken = json["expiration_date"];
                        if (expirationToken == null || expirationToken.Type == JTokenType.Null)
                        {
                            return;
                        }

                        DateTime expirationDate;
                        if (!DateTime.TryParse(expirationToken.ToString(), out expirationDate))
                        {
                            return;
                        }

                        if (contractTemplate.PandaDocExpirationDate != expirationDate)
                        {
                            contractTemplate.PandaDocExpirationAlertSentDate = null;
                        }

                        contractTemplate.PandaDocExpirationDate = expirationDate;
                        await _eceCrmEntities.SaveChangesAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error in SyncPandaDocExpirationDateAsync", ex);
            }
        }

        public async Task<string> CreateSigningSessionAsync(string documentId, string recipientEmail)
        {
            string signatureUrl = null;

            PandaDocSessionResponse sessionResponse = null;

            try
            {
                var requestUrl = $"{ApiUrl}/documents/{documentId}/session";

                var payload = new
                {
                    recipient = recipientEmail,
                    lifetime = 3600
                };

                var jsonPayload = JsonConvert.SerializeObject(payload);
                var httpContent = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Authorization", $"API-Key {ApiKey}");

                    var response = await client.PostAsync(requestUrl, httpContent);
                    if (response.IsSuccessStatusCode)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        sessionResponse = JsonConvert.DeserializeObject<PandaDocSessionResponse>(jsonString);
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        throw new Exception($"API Error: {response.StatusCode} - {error}");
                    }
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error("Error creating PandaDoc signing session", ex);
            }


            if (sessionResponse != null)
            {
                signatureUrl = $"{SignaturUrl}/" + sessionResponse.id;
            }
            return signatureUrl;
        }

        public async Task RemoveSignaturesAndRevertDraftAsync(ContractDto contract, IPrincipal user)
        {
            if (!contract.IsPandaDoc)
            {
                return;
            }
            if (contract == null ||
                contract.ContractTemplateHistory == null ||
                string.IsNullOrEmpty(contract.ContractTemplateHistory.PandaDocDocumentId))
            {
                return;
            }

            if (user == null)
            {
                throw new ArgumentNullException("user");
            }
            // Revert PandaDoc document to draft
            await DraftDocument(contract.ContractTemplateHistory.PandaDocDocumentId);

            contract = await _contractService.Value.GetByIdAsync(contract.ContractId, true);
            contract = this._contractService.Value.GetProgressAsync(contract);

            if (contract.PresenterSigned && contract.ArtistSigned)
            {
                return;
            }



            var signatures = await _contractSignatureService
                .GetByContractIdAsync(contract.ContractId);

            if (!signatures.Any())
            {
                return;
            }

            var userId = user.GetUserId();


            foreach (var signature in signatures)
            {
                if (signature == null)
                {
                    continue;
                }

                signature.IsReceived = false;
                signature.ReceivedDate = null;
                signature.UpdatedById = userId;
                signature.UpdatedDate = DateTime.Now;

                if (signature.ContractSignatureId > 0)
                {
                    await _contractSignatureService.UpdateAsync(signature, userId);
                }
            }
        }
        private async Task UpdatePreviousDraftDocumentsAsync(int contractId)
        {

            var contractVersions = await _eceCrmEntities.ContractVersion.Where(a => a.ContractId == contractId).ToListAsync(); ;
            if (contractVersions.Any())
            {
                foreach (var item in contractVersions)
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(item.PandaDocDocumentId))
                        {
                            await this.DraftDocument(item.PandaDocDocumentId);
                        }
                    }
                    catch (Exception ex)
                    {
                        var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                        logger.Error(ex);

                    }
                }
            }

            try
            {
                var contractSignatures = _eceCrmEntities.ContractSignatures.Where(a => a.ContractId == contractId);
                if (contractSignatures.Any())
                {
                    foreach (var cs in contractSignatures)
                    {
                        cs.IsReceived = false;
                        cs.ReceivedDate = null;
                    }
                    await _eceCrmEntities.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);

            }
        }
   
        public async Task SetPDFChanges(int contractId)
        {
            try
            {

                using (SqlConnectionFactory sqlConnectionFactory = new SqlConnectionFactory())
                {
                    var conn = sqlConnectionFactory.CreateConnection();
                    var dp = new DynamicParameters();
                    dp.Add("@contractId", contractId);
                   await conn.ExecuteAsync("Sp_set_Update_IsPdfChanges_ContractWise @contractId", dp);
                }
            }
            catch (Exception ex)
            {
                var logger = new Infinity.Mobius.Logging.Log4net.Log4netLogger("APPLICATION");
                logger.Error(ex);
            }
        }

        private async Task<string> GetPandaDocContactIdByEmailAsync(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return null;
            try
            {
                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromMinutes(5);
                    var request = new HttpRequestMessage(HttpMethod.Get, $"{ApiUrl.TrimEnd('/')}/contacts?q={Uri.EscapeDataString(email)}");
                    request.Headers.Add("Authorization", $"API-Key {ApiKey}");
                    var response = await client.SendAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        var json = JObject.Parse(result);
                        var results = json["results"] as JArray;
                        if (results != null && results.Any())
                        {
                            var match = results.FirstOrDefault(c => (string)c["email"] == email);
                            return match != null ? (string)match["id"] : (string)results[0]["id"];
                        }
                    }
                }
            }
            catch { }
            return null;
        }
    }
}
