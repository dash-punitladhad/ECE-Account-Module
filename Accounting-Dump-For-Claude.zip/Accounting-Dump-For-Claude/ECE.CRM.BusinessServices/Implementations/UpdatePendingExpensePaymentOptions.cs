﻿namespace ECE.CRM.BusinessServices
{
    using System;

    [Flags]
    public enum UpdatePendingExpensePaymentOptions
    {
        ResyncNothing = 1,

        ResyncLoanRepayments = 2,

        ResyncDeposits = 4,

        ResyncExpenses = 8,

        Default = ResyncLoanRepayments | ResyncDeposits | ResyncExpenses
    }
}
