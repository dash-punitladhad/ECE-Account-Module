﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class NationalArtistContactService : INationalArtistContactService
    {
        private readonly IContactService _contactService;

        public NationalArtistContactService(IUnitOfWork context, IContactService contactService)
        {
            this.Context = context;
            this._contactService = contactService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<NationalArtistContactDto>> GetByNationalArtistAsync(int nationalArtistId)
        {
            var results = await this.Context.NationalArtistContacts.GetByNationalArtistAsync(nationalArtistId);
            return results;
        }

        public async Task<IList<NationalArtistContactDto>> GetByAgencyAndArtistAsync(int nationalAgencyId, int? nationalArtistId)
        {
            var agencyContacts = this._contactService.GetContacts(EntityType.National, nationalAgencyId);

            IList<NationalArtistContactDto> artistContacts = new List<NationalArtistContactDto>();
            if (nationalArtistId.HasValue && nationalArtistId.Value > 0)
            {
                artistContacts = await this.Context.NationalArtistContacts.GetByNationalArtistAsync(nationalArtistId.Value);
            }

            var results = new List<NationalArtistContactDto>();

            foreach (var agencyContact in agencyContacts)
            {
                // If artist already has a record for this contact, add to list.
                // Otherwise, create new Dto and add to list.
                var contact = artistContacts.FirstOrDefault(x => x.ContactId == agencyContact.ContactId);
                if (contact == null)
                {
                    results.Add(new NationalArtistContactDto()
                    {
                        NationalArtistContactId = 0,
                        ArtistId = nationalArtistId ?? 0,
                        ContactId = agencyContact.ContactId,
                        FullName = agencyContact.FullName,
                        IsPrimary = false,
                        IsArtistContact = false
                    });
                }
                else
                {
                    results.Add(contact);
                }
            }

            return results;
        }

        public async Task CreateAsync(NationalArtistContactDto dto, IPrincipal user)
        {
            dto.SetAsCreated(user);
            await this.Context.NationalArtistContacts.CreateAsync(dto);
        }

        public async Task UpdateAsync(NationalArtistContactDto dto, IPrincipal user)
        {
            dto.SetAsUpdated(user);
            await this.Context.NationalArtistContacts.UpdateAsync(dto);
        }

        public async Task HardDeleteAsync(NationalArtistContactDto dto)
        {
            await this.Context.NationalArtistContacts.HardDeleteAsync(dto);
        }
    }
}
