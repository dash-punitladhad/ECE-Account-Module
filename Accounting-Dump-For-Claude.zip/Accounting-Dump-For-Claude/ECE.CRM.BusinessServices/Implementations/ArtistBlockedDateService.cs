﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistBlockedDateService : IArtistBlockedDateService
    {
        public ArtistBlockedDateService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<ArtistBlockedDateDto> GetByIdAsync(int id)
        {
            return await this.Context.ArtistBlockDates.GetByIdAsync(id);
        }

        public async Task<IList<ArtistBlockedDateDto>> GetByArtistIdAsync(int id)
        {
            return await this.Context.ArtistBlockDates.GetByArtistIdAsync(id);
        }

        public async Task<IList<ArtistBlockedDateDto>> GetUpcomingByArtistIdAsync(int id, DateTime today)
        {
            return await this.Context.ArtistBlockDates.GetUpcomingByArtistIdAsync(id, today);
        }

        public async Task DeleteAsync(ArtistBlockedDateDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.IsDeleted = true;
                dto.SetAsUpdated(user);

                await this.Context.ArtistBlockDates.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task CreateAsync(ArtistBlockedDateCreateDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (dto.BlockedDate == null && (dto.BlockedStartDate == null || dto.BlockedEndDate == null))
            {
                throw new ArgumentException("Missing blocked date", nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                if (dto.BlockedDate.HasValue)
                {
                    var newDate = new ArtistBlockedDateDto();
                    newDate.BlockedDate = dto.BlockedDate.Value;
                    newDate.ArtistId = dto.ArtistId;
                    newDate.IsMovable = dto.IsMovable;
                    newDate.Notes = dto.Notes;
                    newDate.PhysicalAddressCity = dto.PhysicalAddressCity;
                    newDate.PhysicalAddressCountryId = dto.PhysicalAddressCountryId;
                    newDate.PhysicalAddressStateId = dto.PhysicalAddressStateId;
                    newDate.PhysicalStateAbbreviation = dto.PhysicalStateAbbreviation;

                    newDate.IsDeleted = false;
                    newDate.SetAsCreated(user);

                    await this.Context.ArtistBlockDates.CreateAsync(newDate);
                }
                else
                {
                    var dateRange = dto.BlockedEndDate.Value.Subtract(dto.BlockedStartDate.Value);

                    for (int i = 0; i <= dateRange.Days; i++)
                    {
                        var newDate = new ArtistBlockedDateDto();
                        newDate.BlockedDate = dto.BlockedStartDate.Value.AddDays(i);
                        newDate.ArtistId = dto.ArtistId;
                        newDate.IsMovable = dto.IsMovable;
                        newDate.Notes = dto.Notes;
                        newDate.PhysicalAddressCity = dto.PhysicalAddressCity;
                        newDate.PhysicalAddressCountryId = dto.PhysicalAddressCountryId;
                        newDate.PhysicalAddressStateId = dto.PhysicalAddressStateId;
                        newDate.PhysicalStateAbbreviation = dto.PhysicalStateAbbreviation;

                        newDate.IsDeleted = false;
                        newDate.SetAsCreated(user);

                        await this.Context.ArtistBlockDates.CreateAsync(newDate);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAsync(ArtistBlockedDateDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.ArtistBlockDates.UpdateAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
