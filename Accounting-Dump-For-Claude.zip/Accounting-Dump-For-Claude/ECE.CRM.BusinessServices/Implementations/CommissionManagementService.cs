﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class CommissionManagementService : ICommissionManagementService
    {
        public const decimal PresenterTransferCommissionPercentage = 20m;

        public const decimal MentorCommissionPercentage = 20m;

        public const int PresenterTransferCommissionMaxDurationYears = 4;

        public const int PresenterMentorshipDurationMonths = 12;

        public CommissionManagementService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public static DateTime GetPresenterTransferCommissionMaximumEndDate(DateTime startDate)
        {
            return startDate.AddYears(PresenterTransferCommissionMaxDurationYears);
        }

        public async Task<IEnumerable<CommissionManagementSearchResultDto>> GetAgentCommissionsByCriteriaAsync(CommissionManagementSearchCriteriaDto criteria)
        {
            var results = await this.Context.AgentCommissions.GetAgentCommissionsByCriteriaAsync(criteria);

            return results;
        }

        public async Task<AgentCommissionDto> GetAgentCommissionByAgentIdAsync(int id, bool includeChildren = false)
        {
            var dto = await this.Context.AgentCommissions.GetByAgentIdAsync(id);

            if (includeChildren && dto != null)
            {
                if (dto.AgentCommissionId.HasValue)
                {
                    if (dto.AgentCommissionTypeId.Value == (int)AgentCommissionType.TieredInstancePlan)
                    {
                        var typeDataValues = await this.Context.AgentCommissions.GetCommissionInstanceRates();

                        dto.CommissionTiers.AddRange(typeDataValues);
                    }
                    else
                    {
                        var typeDataValues = await this.Context.AgentCommissions.GetTypeDataByAgentCommissionIdAsync(dto.AgentCommissionId.Value);

                        dto.CommissionTiers.AddRange(typeDataValues);
                    }
                }
            }

            return dto;
        }

        public async Task<IEnumerable<AgentCommissionTypeDataDto>> GetTypeDataByAgentCommissionIdAsync(int id)
        {
            var results = await this.Context.AgentCommissions.GetTypeDataByAgentCommissionIdAsync(id);

            return results;
        }

        public async Task ChangeCommissionTypeAsync(int agentId, AgentCommissionType newCommissionType, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var agentCommission = await this.Context.AgentCommissions.GetByAgentIdAsync(agentId);
                if (agentCommission != null && agentCommission.AgentCommissionId != null)
                {
                    // If no changes are made then exist without saving changes.
                    if (agentCommission.AgentCommissionTypeId == (int)newCommissionType)
                    {
                        this.Context.Rollback();
                        return;
                    }

                    // Delete the existing commmission data
                    agentCommission.SetAsUpdated(user);

                    await this.Context.AgentCommissions.DeleteAgentCommissionAsync(agentCommission);
                }

                // Create a new commmission data record.
                agentCommission = new AgentCommissionDto();
                agentCommission.AgentId = agentId;
                agentCommission.AgentCommissionTypeId = (int)newCommissionType;

                agentCommission.SetAsCreated(user);

                await this.Context.AgentCommissions.CreateAgentCommissionAsync(agentCommission);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateMentorAsync(AgentCommissionDto data, IPrincipal user)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var program = await this.Context.AgentCommissions.GetMentorByAgentIdAsync(data.AgentId);
                if (program == null)
                {
                    program = new AgentCommissionProgramDto();
                    program.CommissionProgramId = (int)CommissionProgram.Mentor;

                    // The mentor
                    program.ToAppUserId = data.MentorId.Value;

                    // Is receiving commissions from the agent
                    program.FromEntityId = data.AgentId;
                    program.FromEntityTypeId = (int)EntityType.Agent;

                    // At this percentage
                    program.SplitPercentage = data.MentorshipPercentage.Value;

                    // For contract commissions paid within this time span
                    program.StartDate = data.MentorshipStartDate.Value;
                    program.EndDate = data.MentorshipEndDate ?? program.StartDate.AddMonths(PresenterMentorshipDurationMonths);

                    program.SetAsCreated(user);

                    await this.Context.AgentCommissions.CreateAgentCommissionProgramAsync(program);

                    data.MentorshipEndDate = program.EndDate;
                }
                else
                {
                    // Update the mentor
                    program.ToAppUserId = data.MentorId.Value;

                    // Update the percentage
                    program.SplitPercentage = data.MentorshipPercentage.Value;

                    // Update the time span
                    program.StartDate = data.MentorshipStartDate.Value;
                    program.EndDate = data.MentorshipEndDate ?? program.StartDate.AddMonths(PresenterMentorshipDurationMonths);

                    program.SetAsUpdated(user);

                    await this.Context.AgentCommissions.UpdateAgentCommissionProgramAsync(program);

                    data.MentorshipEndDate = program.EndDate;
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task AddTierAsync(int agentId, AgentCommissionTypeDataDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var agentCommission = await this.GetAgentCommissionByAgentIdAsync(agentId, includeChildren: true);
                if (agentCommission == null || agentCommission.AgentCommissionId == null)
                {
                    throw new Exception($"Agent commission data not found for agent {agentId}");
                }

                var lastTier = agentCommission.CommissionTiers.LastOrDefault();
                if (lastTier != null)
                {
                    if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredDatesPlan)
                    {
                        if (lastTier.UpperDate >= dto.LowerDate)
                        {
                            throw new InvalidOperationException($"Lower Limit of {dto.LowerDate:MM/dd/yyyy} is not less than {lastTier.UpperDate:MM/dd/yyyy}");
                        }
                    }
                    else if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredCumulativePlan)
                    {
                        if (lastTier.UpperNumeric >= dto.LowerNumeric)
                        {
                            throw new InvalidOperationException($"Lower Limit of {dto.LowerNumeric:N2} is not less than {lastTier.UpperNumeric:N2}");
                        }
                    }
                }

                dto.SetAsCreated(user);

                await this.Context.AgentCommissions.AddAgentCommissionTypeDataAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateTierAsync(int agentId, AgentCommissionTypeDataDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var agentCommission = await this.GetAgentCommissionByAgentIdAsync(agentId, includeChildren: true);
                if (agentCommission == null || agentCommission.AgentCommissionId == null)
                {
                    throw new Exception($"Agent commission data not found for agent {agentId}");
                }

                var selectedTier = agentCommission.CommissionTiers.FirstOrDefault(x => x.AgentCommissionTypeDataId == dto.AgentCommissionTypeDataId);
                if (selectedTier == null)
                {
                    throw new Exception($"Agent commission type data not found for key {dto.AgentCommissionTypeDataId}");
                }

                selectedTier.LowerNumeric = dto.LowerNumeric;
                selectedTier.LowerDate = dto.LowerDate;
                selectedTier.UpperNumeric = dto.UpperNumeric;
                selectedTier.UpperDate = dto.UpperDate;
                selectedTier.Percentage = dto.Percentage;
                selectedTier.SetAsUpdated(user);

                await this.Context.AgentCommissions.UpdateAgentCommissionTypeDataAsync(selectedTier);

                var nextTier = agentCommission.CommissionTiers
                    .SkipWhile(x => x != selectedTier)
                    .Skip(1)
                    .FirstOrDefault();

                if (nextTier != null)
                {
                    if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredDatesPlan)
                    {
                        nextTier.LowerDate = selectedTier.UpperDate.Value.AddDays(1);
                    }
                    else if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredCumulativePlan)
                    {
                        nextTier.LowerNumeric = selectedTier.UpperNumeric.Value + 0.01m;
                    }

                    nextTier.SetAsUpdated(user);

                    await this.Context.AgentCommissions.UpdateAgentCommissionTypeDataAsync(nextTier);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeleteTierAsync(int agentId, int agentCommissionTypeDataId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var agentCommission = await this.GetAgentCommissionByAgentIdAsync(agentId, includeChildren: true);
                if (agentCommission == null || agentCommission.AgentCommissionId == null)
                {
                    throw new Exception($"Agent commission data not found for agent {agentId}");
                }

                var selectedTier = agentCommission.CommissionTiers.FirstOrDefault(x => x.AgentCommissionTypeDataId == agentCommissionTypeDataId);
                if (selectedTier == null)
                {
                    throw new Exception($"Agent commission type data not found for key {agentCommissionTypeDataId}");
                }

                selectedTier.SetAsUpdated(user);

                await this.Context.AgentCommissions.DeleteAgentCommissionTypeDataAsync(selectedTier);

                var selectedTierIndex = agentCommission.CommissionTiers.IndexOf(selectedTier);

                var previousTier = agentCommission.CommissionTiers
                    .Skip(selectedTierIndex - 1)
                    .FirstOrDefault();

                var nextTier = agentCommission.CommissionTiers
                    .Skip(selectedTierIndex + 1)
                    .FirstOrDefault();

                if (previousTier != null && nextTier != null)
                {
                    if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredDatesPlan)
                    {
                        nextTier.LowerDate = previousTier.UpperDate.Value.AddDays(1);
                    }
                    else if (agentCommission.AgentCommissionTypeId == (int)AgentCommissionType.TieredCumulativePlan)
                    {
                        nextTier.LowerNumeric = previousTier.UpperNumeric.Value + 0.01m;
                    }

                    nextTier.SetAsUpdated(user);

                    await this.Context.AgentCommissions.UpdateAgentCommissionTypeDataAsync(nextTier);
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IEnumerable<AgentCommissionProgramDto>> GetPresenterTransfersByAgentIdAsync(int id)
        {
            var results = await this.Context.AgentCommissions.GetPresenterTransfersByAgentIdAsync(id);

            return results;
        }

        public async Task<AgentCommissionProgramDto> GetPresenterTransferAsync(int presenterId)
        {
            var presenterTransfer = await this.Context.AgentCommissions.GetPresenterTransferAsync(presenterId);

            return presenterTransfer;
        }

        public async Task AddPresenterTransferAsync(AgentCommissionProgramDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                // Check for duplicates...
                var existingPresenterTransfer = await this.Context.AgentCommissions.GetPresenterTransferAsync(dto.FromEntityId);
                if (existingPresenterTransfer != null)
                {
                    throw new DuplicateCommissionProgramException(dto.ToAppUserId, (EntityType)dto.FromEntityTypeId, dto.FromEntityId);
                }

                dto.SetAsCreated(user);

                await this.Context.AgentCommissions.CreateAgentCommissionProgramAsync(dto);

                this.Context.Commit();
            }
            catch (DuplicateCommissionProgramException)
            {
                this.Context.Rollback();
                throw;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdatePresenterTransferAsync(AgentCommissionProgramDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var existingPresenterTransfer = await this.Context.AgentCommissions.GetPresenterTransferAsync(dto.FromEntityId);
                if (existingPresenterTransfer == null)
                {
                    throw new ArgumentException($"Presenter transfer data not found for presenter {dto.FromEntityId}");
                }

                // Ensure the presenter is linked to the provided agent.
                if (existingPresenterTransfer.ToAppUserId != dto.ToAppUserId)
                {
                    throw new ArgumentException($"Presenter transfer data linked to a different agent.");
                }

                existingPresenterTransfer.StartDate = dto.StartDate;
                existingPresenterTransfer.EndDate = dto.EndDate;
                existingPresenterTransfer.SplitPercentage = dto.SplitPercentage;

                existingPresenterTransfer.SetAsUpdated(user);

                await this.Context.AgentCommissions.UpdateAgentCommissionProgramAsync(existingPresenterTransfer);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task DeletePresenterTransferAsync(int presenterId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                var existingPresenterTransfer = await this.Context.AgentCommissions.GetPresenterTransferAsync(presenterId);
                if (existingPresenterTransfer == null)
                {
                    throw new ArgumentException($"Presenter transfer data not found for presenter {presenterId}");
                }

                existingPresenterTransfer.SetAsUpdated(user);

                await this.Context.AgentCommissions.DeleteAgentCommissionProgramAsync(existingPresenterTransfer);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
