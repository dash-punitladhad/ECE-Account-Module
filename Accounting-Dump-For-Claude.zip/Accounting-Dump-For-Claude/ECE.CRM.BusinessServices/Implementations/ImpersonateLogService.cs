﻿using ECE.CRM.BusinessServices.Interfaces;
using ECE.CRM.DataAccess;
using ECE.CRM.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ECE.CRM.BusinessServices.Implementations
{
	public class ImpersonateLogService : IImpersonateLogService
	{
		public IUnitOfWork Context { get; private set; }
		public ImpersonateLogService(IUnitOfWork context)
		{
			Context = context;
		}

		public async Task CreateAsync(ImpersonateLogDto impersonateLogDto, IPrincipal user)
		{
			this.Context.BeginTransaction();
			try
			{
				await this.Context.impersonateLogDao.CreateAsync(impersonateLogDto);
				this.Context.Commit();
			}
			catch(Exception ex)
			{
				this.Context.Rollback();
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<List<ImpersonateUsersDto>> GetImpersonateLogListAsync()
		{
			try
			{
				return await this.Context.impersonateLogDao.GetImpersonateLogListAsync();
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<bool> CheckImpersonateLogExistsAsync(ImpersonateLogDto impersonateUsersDto)
		{
			try
			{
				return await this.Context.impersonateLogDao.CheckImpersonateLogExistsAsync(impersonateUsersDto);
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

		public async Task<bool> RevereseImpersonateLogAsync(ImpersonateLogDto impersonateUsersDto)
		{
			try
			{
				return await this.Context.impersonateLogDao.RevereseImpersonateLogAsync(impersonateUsersDto);
			}
			catch (Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}
	
		public async Task UpdateImpersonateLogAsync(ImpersonateLogDto impersonateLogDto)
		{
			
			try
			{
				await this.Context.impersonateLogDao.UpdateImpersonateLogAsync(impersonateLogDto);
			}
			catch(Exception ex)
			{
				throw new Exception("Unhandled Business Exception", ex);
			}
		}

	}
}
