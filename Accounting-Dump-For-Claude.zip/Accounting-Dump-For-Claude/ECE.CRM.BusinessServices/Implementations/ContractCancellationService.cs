﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractCancellationService : IContractCancellationService
    {
        public ContractCancellationService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<IList<ContractCancellationDto>> GetByContractIdAsync(int contractId)
        {
            return await this.Context.ContractCancellations.GetByContractIdAsync(contractId);
        }

        public Task<IList<ContractCancellationDto>> GetByCancellationReasonIdAsync(int cancellationReasonId)
        {
            throw new NotImplementedException();
        }

        public Task<IList<ContractCancellationDto>> GetByReplacementContractIdAsync(int replacementContractId)
        {
            throw new NotImplementedException();
        }

        public Task<ContractCancellationDto> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task CreateAsync(ContractCancellationDto dto, IPrincipal user)
        {
            try
            {
                this.Context.BeginTransaction();

                dto.SetAsCreated(user);
                await this.Context.ContractCancellations.CreateAsync(dto);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException("Unhandled Business Exception", ex);
            }
        }

        public Task UpdateAsync(ContractCancellationDto dto, IPrincipal user)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}
