﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class NationalAgencyService : INationalAgencyService
    {
        private readonly IUserService _userService;
        private readonly IContactService _contactService;
        private readonly IWebLinkService _webLinkService;
        private readonly IDocumentService _documentService;
        public NationalAgencyService(IUnitOfWork context,
                                        IUserService userService,
                                        IContactService contactService,
                                        IWebLinkService webLinkService,
                                        IDocumentService documentService)
        {
            this.Context = context;

            this._userService = userService;
            this._contactService = contactService;
            this._webLinkService = webLinkService;
            this._documentService = documentService;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task<List<NationalAgencyDto>> GetByCharsAsync(string chars)
        {
            var result = await this.Context.NationalAgencies.GetByCharsAsync(chars);

            return result;
        }

        public async Task<NationalAgencyDto> GetByIdAsync(int id)
        {
            var result = await this.Context.NationalAgencies.GetByIdAsync(id);
            await _userService.LoadAuditInfoAsync(result);

            return result;
        }

        public async Task CreateAsync(NationalAgencyDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsCreated(user);

                await this.Context.NationalAgencies.CreateAsync(dto);

                this._contactService.SyncContacts(EntityType.National, dto.NationalAgencyId, dto.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.National, dto.NationalAgencyId, dto.WebLinks, user);
                this._documentService.SyncDocuments(EntityType.National, dto.NationalAgencyId, dto.Documents, user);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.National, null, ex);
            }
        }

        public async Task UpdateAsync(NationalAgencyDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            this.Context.BeginTransaction();

            try
            {
                dto.SetAsUpdated(user);

                await this.Context.NationalAgencies.UpdateAsync(dto);

                this._contactService.SyncContacts(EntityType.National, dto.NationalAgencyId, dto.Contacts, user);
                this._webLinkService.SyncWebLinks(EntityType.National, dto.NationalAgencyId, dto.WebLinks, user);
                this._documentService.SyncDocuments(EntityType.National, dto.NationalAgencyId, dto.Documents, user);
                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(EntityType.National, dto.NationalAgencyId, ex);
            }
        }

        public async Task<IList<NationalAgencySearchResultDto>> GetByCriteriaAsync(NationalAgencySearchCriteriaDto criteria)
        {
            var results = await this.Context.NationalAgencies.GetByCriteriaAsync(criteria);

            return results;
        }

        public async Task<IList<NationalAgencyDto>> GetAllAsync()
        {
            var results = await this.Context.NationalAgencies.GetAllAsync();

            return results;
        }
    }
}