﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataTransferObjects;
    using System;

    public class ExpenseGroupKey
    {
        /*
         * The custom Equals and GetHashCode methods ensure the correct comparison is done
         * between objects.
         */
        public ExpenseGroupKey()
        {
            this.ContractEntityId = 0;
        }

        public ExpenseGroupKey(int contractEntityId, int contractEntityTypeId, string payeeName)
        {
            this.ContractEntityId = contractEntityId;
            this.ContractEntityTypeId = contractEntityTypeId;
            this.PayeeName = payeeName;

            if (!Enum.IsDefined(typeof(ContractEntityType), contractEntityTypeId))
            {
                throw new ArgumentOutOfRangeException("contractEntityTypeId", $"Invalid ContractEntityType = {contractEntityTypeId}");
            }
        }

        public int ContractEntityId { get; set; }

        public int ContractEntityTypeId { get; set; }

        public string PayeeName { get; set; }

        public override bool Equals(object obj)
        {
            var key = obj as ExpenseGroupKey;
            if (key != null)
            {
                return this.ContractEntityId == key.ContractEntityId &&
                    this.ContractEntityTypeId == key.ContractEntityTypeId &&
                    this.PayeeName == key.PayeeName;
            }

            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return this.ContractEntityId.GetHashCode() ^
                this.ContractEntityTypeId.GetHashCode() ^
                this.PayeeName.GetHashCode();
        }
    }
}
