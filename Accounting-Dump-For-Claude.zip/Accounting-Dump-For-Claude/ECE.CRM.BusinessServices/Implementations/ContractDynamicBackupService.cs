﻿namespace ECE.CRM.BusinessServices
{
    using AutoMapper;
    using ECE.CRM.BusinessServices.Interfaces;
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataAccess.Utilities;
    using ECE.CRM.DataTransferObjects;
    using ECE.CRM.DataTransferObjects.BackupRestore;
    using Infinity.Mobius.BlobStorage;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ContractDynamicBackupService : IContractDynamicBackupService
    {
        public IUnitOfWork _context { get; private set; }

        public ContractDynamicBackupService(IUnitOfWork context)
        {
            this._context = context;
        }


        public async Task<int> CreateBackup(int contractId, int userId)
        {
            return await this._context.ContractDynamicBackupDao.CreateBackupAsync(contractId, userId);
        }



    }
}
