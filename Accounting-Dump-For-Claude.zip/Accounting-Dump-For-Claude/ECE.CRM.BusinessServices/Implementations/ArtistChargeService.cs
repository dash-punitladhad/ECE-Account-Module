﻿namespace ECE.CRM.BusinessServices
{
    using ECE.CRM.DataAccess;
    using ECE.CRM.DataTransferObjects;
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Threading.Tasks;

    public class ArtistChargeService : IArtistChargeService
    {
        public ArtistChargeService(IUnitOfWork context)
        {
            this.Context = context;
        }

        public IUnitOfWork Context { get; private set; }

        public async Task CreateAsync(ArtistChargeDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                dto.ArtistChargeStatusId = (int)ArtistChargeStatus.Outstanding;
                dto.OriginalDate = DateTime.Now;

                // Start with owing the entire amount.
                dto.RemainingBalance = dto.OriginalAmount;

                dto.SetAsCreated(user);

                await this.Context.ArtistCharges.CreateArtistChargeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task UpdateAsync(ArtistChargeDto dto, IPrincipal user)
        {
            if (dto == null)
            {
                throw new ArgumentNullException(nameof(dto));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                dto.SetAsUpdated(user);
                await this.Context.ArtistCharges.UpdateArtistChargeAsync(dto);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<IList<ArtistChargeDto>> GetArtistChargesByArtistIdAsync(int artistId)
        {
            return await this.Context.ArtistCharges.GetArtistChargesByArtistIdAsync(artistId);
        }

        public async Task<ArtistChargeDto> GetArtistChargeByIdAsync(int id)
        {
            return await this.Context.ArtistCharges.GetByIdAsync(id);
        }

        public async Task<IList<ArtistChargeTransactionDto>> GetArtistChargeTransactionsByArtistChargeIdAsync(int artistChargeId)
        {
            var results = await this.Context.ArtistCharges.GetArtistChargeTransactionsByArtistChargeIdAsync(artistChargeId);

            return results;
        }

        public async Task<IList<ArtistChargeSearchResultDto>> GetArtistChargesByCriteriaAsync(ArtistChargeSearchCriteriaDto criteria)
        {
            return await this.Context.ArtistCharges.GetArtistChargesByCriteriaAsync(criteria);
        }

        public async Task SaveArtistChargePaymentAsync(int artistChargeId, int expensePaymentId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                // get artist charge
                var artistCharge = await this.Context.ArtistCharges.GetByIdAsync(artistChargeId);
                if (artistCharge == null)
                {
                    throw new Exception($"Artist charge {artistChargeId} not found.");
                }

                // create new artist charge transaction
                var artistChargeTransaction = new ArtistChargeTransactionDto()
                {
                    ArtistChargeId = artistCharge.ArtistChargeId,
                    ArtistChargeTransactionTypeId = (int)ArtistChargeTransactionType.Repayment,
                    TransactionDate = DateTime.Now,
                    TransactionAmount = artistCharge.DeductionAmount,
                    ExpensePaymentId = expensePaymentId
                };

                artistChargeTransaction.SetAsCreated(user);

                await this.Context.ArtistCharges.CreateArtistChargeTransactionAsync(artistChargeTransaction);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task<ArtistChargeTransactionDto> CreateArtistChargeRepaymentAsync(ArtistChargeDto artistCharge, int expensePaymentId, IPrincipal user)
        {
            if (artistCharge == null)
            {
                throw new ArgumentNullException(nameof(artistCharge));
            }

            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                // create new artist charge transaction
                var artistChargeTransaction = new ArtistChargeTransactionDto()
                {
                    ArtistChargeId = artistCharge.ArtistChargeId,
                    ArtistChargeTransactionTypeId = (int)ArtistChargeTransactionType.Repayment,
                    TransactionDate = DateTime.Now,
                    TransactionAmount = artistCharge.DeductionAmount,
                    ExpensePaymentId = expensePaymentId,
                    ExpensePaymentStatusId = (int)ExpensePaymentStatus.HasSufficientEscrow
                };

                artistChargeTransaction.SetAsCreated(user);

                await this.Context.ArtistCharges.CreateArtistChargeTransactionAsync(artistChargeTransaction);

                this.Context.Commit();

                return artistChargeTransaction;
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task PostArtistChargeRepaymentsAsync(int expensePaymentId, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                var repayments = await this.Context.ArtistCharges.GetLoanRepaymentsAsync(expensePaymentId, includeWithheld: true);

                foreach (var repayment in repayments)
                {
                    if (repayment.ExpensePaymentStatusId == (int)ExpensePaymentStatus.Withhold)
                    {
                        repayment.IsDeleted = true;
                        repayment.SetAsUpdated(user);

                        await this.Context.ArtistCharges.UpdateArtistChargeTransactionAsync(repayment);
                    }
                    else
                    {
                        var artistCharge = await this.Context.ArtistCharges.GetByIdAsync(repayment.ArtistChargeId);

                        artistCharge.TotalPaymentsReceived = artistCharge.TotalPaymentsReceived.GetValueOrDefault() + repayment.TransactionAmount;
                        artistCharge.RemainingBalance = artistCharge.RemainingBalance.GetValueOrDefault() - repayment.TransactionAmount;
                        if (artistCharge.RemainingBalance == decimal.Zero)
                        {
                            artistCharge.ArtistChargeStatusId = (int)ArtistChargeStatus.PaidInFull;
                        }

                        artistCharge.LastPaymentDate = DateTime.Now;
                        artistCharge.SetAsUpdated(user);

                        await this.Context.ArtistCharges.UpdateArtistChargeAsync(artistCharge);

                        repayment.ExpensePaymentStatusId = (int)ExpensePaymentStatus.FullyPaid;
                        repayment.SetAsUpdated(user);

                        await this.Context.ArtistCharges.UpdateArtistChargeTransactionAsync(repayment);
                    }
                }

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }

        public async Task SaveArtistChargeAdjustmentAsync(int artistChargeId, decimal amount, IPrincipal user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            try
            {
                this.Context.BeginTransaction();

                // get artist charge
                var artistCharge = await this.Context.ArtistCharges.GetByIdAsync(artistChargeId);
                if (artistCharge == null)
                {
                    throw new Exception($"Artist charge {artistChargeId} not found.");
                }

                // create new artist charge transaction
                var artistChargeTransaction = new ArtistChargeTransactionDto()
                {
                    ArtistChargeId = artistCharge.ArtistChargeId,
                    ArtistChargeTransactionTypeId = (int)ArtistChargeTransactionType.Adjustment,
                    TransactionDate = DateTime.Now,
                    TransactionAmount = amount,
                    ExpensePaymentId = null,
                    ExpensePaymentStatusId = null
                };

                artistChargeTransaction.SetAsCreated(user.GetUserId());

                await this.Context.ArtistCharges.CreateArtistChargeTransactionAsync(artistChargeTransaction);

                artistCharge.SetAsUpdated(user.GetUserId());

                // update artist charge
                artistCharge.TotalPaymentsReceived = artistCharge.TotalPaymentsReceived.GetValueOrDefault() + amount;
                artistCharge.RemainingBalance = artistCharge.RemainingBalance.GetValueOrDefault() - amount;
                if (artistCharge.RemainingBalance <= decimal.Zero)
                {
                    artistCharge.ArtistChargeStatusId = (int)ArtistChargeStatus.PaidInFull;
                }
                else if (artistCharge.RemainingBalance > decimal.Zero)
                {
                    artistCharge.ArtistChargeStatusId = (int)ArtistChargeStatus.Outstanding;
                }

                artistCharge.LastPaymentDate = DateTime.Now;
                artistCharge.SetAsUpdated(user);

                await this.Context.ArtistCharges.UpdateArtistChargeAsync(artistCharge);

                this.Context.Commit();
            }
            catch (Exception ex)
            {
                this.Context.Rollback();
                throw new UnhandledBusinessException(ex);
            }
        }
    }
}
