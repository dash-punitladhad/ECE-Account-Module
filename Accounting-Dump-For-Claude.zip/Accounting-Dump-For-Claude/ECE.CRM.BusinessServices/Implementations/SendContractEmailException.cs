﻿namespace ECE.CRM.BusinessServices
{
    using System;

    public class SendContractEmailException : Exception
    {
        public SendContractEmailException(string message)
            : base(message)
        {
        }

        public SendContractEmailException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
